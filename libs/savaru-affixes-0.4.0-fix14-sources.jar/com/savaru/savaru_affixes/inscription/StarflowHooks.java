package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 「星流七連」：提供 DOT 與「DOT 結束後回復」等需要跨 tick 的效果。
 * 其餘連段狀態機在 InscriptionRuntime / PlayerEntityTickMixin 內管理。
 */
public final class StarflowHooks {
    private StarflowHooks() {}

    // DOT: every 20 ticks deal 25 true magic damage, total 15s (300 ticks) => 15 hits.
    private static final int DOT_PERIOD = 20;
    private static final int DOT_TOTAL_TICKS = 15 * 20;
    private static final double DOT_DMG = 25.0;

    private static final class Dot {
        final class_5321<class_1937> worldKey;
        final UUID playerId;
        int ticksLeft;
        int periodLeft;
        Dot(class_5321<class_1937> worldKey, UUID playerId) {
            this.worldKey = worldKey;
            this.playerId = playerId;
            this.ticksLeft = DOT_TOTAL_TICKS;
            this.periodLeft = DOT_PERIOD;
        }
    }

    private static final Map<UUID, Dot> DOTS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> REGEN_AT = new ConcurrentHashMap<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(StarflowHooks::tick);
    }

    /** Start DOT on target and schedule a 3s regen for player after DOT ends. */
    public static void startDot(class_3218 world, class_1309 target, class_3222 player) {
        if (world == null || target == null || player == null) return;
        if (!target.method_5805()) return;
        DOTS.put(target.method_5667(), new Dot(world.method_27983(), player.method_5667()));
        // regen scheduled at now + DOT_TOTAL_TICKS (handled in tick)
        REGEN_AT.put(player.method_5667(), world.method_8510() + DOT_TOTAL_TICKS);
    }

    private static void tick(MinecraftServer server) {
        // DOT ticking
        if (!DOTS.isEmpty()) {
            Iterator<Map.Entry<UUID, Dot>> it = DOTS.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Dot> e = it.next();
                UUID targetId = e.getKey();
                Dot d = e.getValue();

                class_3218 world = server.method_3847(d.worldKey);
                if (world == null) {
                    it.remove();
                    continue;
                }
                class_1309 target = (world.method_14190(targetId) instanceof class_1309 le) ? le : null;
                if (target == null || !target.method_5805()) {
                    it.remove();
                    continue;
                }

                d.ticksLeft--;
                d.periodLeft--;
                if (d.ticksLeft <= 0) {
                    it.remove();
                    continue;
                }
                if (d.periodLeft > 0) continue;

                d.periodLeft = DOT_PERIOD;
                InscriptionRuntime.magicTrueDamage(target, DOT_DMG);
            }
        }

        // regen after DOT
        if (!REGEN_AT.isEmpty()) {
            Iterator<Map.Entry<UUID, Long>> it = REGEN_AT.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Long> e = it.next();
                UUID pid = e.getKey();
                long at = e.getValue();
                // use overworld time as baseline; any server tick ok
                class_3218 any = server.method_30002();
                if (any == null) break;
                if (any.method_8510() < at) continue;

                class_3222 p = server.method_3760().method_14602(pid);
                if (p != null) {
                    p.method_6092(new class_1293(class_1294.field_5924, 3 * 20, 0, false, true, true));
                }
                it.remove();
            }
        }
    }
}
