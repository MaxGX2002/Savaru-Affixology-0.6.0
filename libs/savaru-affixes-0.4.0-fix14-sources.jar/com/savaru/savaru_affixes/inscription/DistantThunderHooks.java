package com.savaru.savaru_affixes.inscription;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class DistantThunderHooks {
    private DistantThunderHooks() {}
    private static final double PROC_CHANCE = 0.30;
    private static final Map<UUID, Integer> MARKS = new ConcurrentHashMap<>();

    public static void onBowHit(class_3218 world, class_1665 proj, class_1309 target, class_1799 weapon, class_1309 owner) {
        if (world == null || target == null) return;
        if (world.field_9229.method_43058() < PROC_CHANCE) {
            strike(world, target, owner instanceof class_3222 sp ? sp : null);
            MARKS.remove(target.method_5667());
            return;
        }
        int hits = MARKS.getOrDefault(target.method_5667(), 0) + 1;
        if (hits >= 3) {
            strike(world, target, owner instanceof class_3222 sp ? sp : null);
            MARKS.remove(target.method_5667());
        } else {
            MARKS.put(target.method_5667(), hits);
        }
    }

    private static void strike(class_3218 world, class_1309 target, class_3222 owner) {
        class_1538 lightning = class_1299.field_6112.method_5883(world);
        if (lightning == null) return;
        lightning.method_5814(target.method_23317(), target.method_23318(), target.method_23321());
        world.method_8649(lightning);
    }
}
