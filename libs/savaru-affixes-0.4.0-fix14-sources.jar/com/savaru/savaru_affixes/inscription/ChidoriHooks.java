package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_8956;
import net.minecraft.server.MinecraftServer;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 千鳥（Chidori）— 秘傳遠程銘刻
 *
 * 命中目標有 50% 機率觸發（冷卻 30 秒）：
 *   → 向玩家顯示訊息「風が私を呼んでいる」
 *   → 對目標產生風爆擊退
 *   → 目標獲得「蘊風」效果（發光 + 緩降，5 秒）
 *
 * 5 秒後：
 *   → 目標受到 40 點爆炸傷害
 *   → 目標周圍生成 8 枚風彈（向四周發射）
 *   → 目標獲得懸浮效果，持續 10 秒
 *
 * 10 秒後（懸浮結束後）：
 *   → 目標受到雷擊
 */
public final class ChidoriHooks {
    private ChidoriHooks() {}

    private static final double PROC_CHANCE         = 0.50;
    private static final long   COOLDOWN_TICKS      = 30L * 20L;   // 30s
    private static final long   WIND_DELAY_TICKS    = 5L  * 20L;   // 5s until wind explosion
    private static final int    LEVITATION_DURATION = 10  * 20;    // 10s levitation
    // Lightning fires after levitation ends
    private static final long   LIGHTNING_DELAY_TICKS = WIND_DELAY_TICKS + LEVITATION_DURATION;
    private static final float  EXPLOSION_DAMAGE    = 40.0f;
    private static final int    WIND_CHARGES        = 8;
    private static final double WIND_CHARGE_SPEED   = 1.4;

    // Player UUID → CD expiry tick
    private static final Map<UUID, Long> COOLDOWNS = new ConcurrentHashMap<>();
    // Target UUID → pending state
    private static final Map<UUID, PendingChidori> PENDING = new ConcurrentHashMap<>();

    // -----------------------------------------------------------------------
    private static final class PendingChidori {
        final net.minecraft.class_5321<net.minecraft.class_1937> worldKey;
        final UUID ownerId;
        final UUID targetId;
        final class_243 fallbackPos;
        final long windAt;
        final long lightningAt;
        boolean windFired;

        PendingChidori(class_3218 world, UUID ownerId, UUID targetId, class_243 pos, long now) {
            this.worldKey     = world.method_27983();
            this.ownerId      = ownerId;
            this.targetId     = targetId;
            this.fallbackPos  = pos;
            this.windAt       = now + WIND_DELAY_TICKS;
            this.lightningAt  = now + LIGHTNING_DELAY_TICKS;
        }
    }

    // -----------------------------------------------------------------------
    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(ChidoriHooks::tick);
    }

    public static void onBowHit(class_3218 world, class_1665 proj,
                                 class_1309 target, class_1799 weapon, class_1309 owner) {
        if (!(owner instanceof class_3222 player)) return;

        long now = world.method_8510();
        UUID pid = player.method_5667();

        // Cooldown check
        if (now < COOLDOWNS.getOrDefault(pid, 0L)) return;

        // 50% proc
        if (world.field_9229.method_43058() >= PROC_CHANCE) return;

        // Set cooldown immediately
        COOLDOWNS.put(pid, now + COOLDOWN_TICKS);

        // ── Trigger ──────────────────────────────────────────────────────

        // 1. Message — chat (false = chat box, visible and not overwritten by other action bars)
        player.method_7353(
                class_2561.method_43470("風が私を呼んでいる").method_27692(class_124.field_1075),
                false);

        // 2. Wind burst knockback (push target away from player)
        class_243 delta = target.method_19538().method_1020(player.method_19538());
        class_243 dir   = delta.method_1027() > 0.001 ? delta.method_1029() : new class_243(0, 1, 0);
        target.method_6005(2.8, -dir.field_1352, -dir.field_1350);

        // 3. 「蘊風」visual: Glowing + Slow Falling for the 5s waiting period
        target.method_6092(new class_1293(
                class_1294.field_5912,      (int) WIND_DELAY_TICKS, 0, false, false, true));
        target.method_6092(new class_1293(
                class_1294.field_5906, (int) WIND_DELAY_TICKS, 0, false, true,  true));

        // 4. Wind particles + sound on initial hit
        spawnWindBurst(world, target.method_19538(), 18);
        world.method_8396(null, target.method_24515(),
                class_3417.field_15152.comp_349(), class_3419.field_15248, 0.6f, 1.6f);

        // 5. Schedule pending phases
        PENDING.put(target.method_5667(),
                new PendingChidori(world, pid, target.method_5667(), target.method_19538(), now));
    }

    // -----------------------------------------------------------------------
    private static void tick(MinecraftServer server) {
        long now = server.method_30002().method_8510();

        Iterator<Map.Entry<UUID, PendingChidori>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, PendingChidori> e = it.next();
            PendingChidori pc = e.getValue();
            class_3218 world = server.method_3847(pc.worldKey);
            if (world == null) { it.remove(); continue; }

            // Resolve target (may have died)
            class_1309 target = null;
            var entity = world.method_14190(pc.targetId);
            if (entity instanceof class_1309 living && living.method_5805()) {
                target = living;
            }

            // ── Phase 1: Wind explosion + wind charges + levitation (5s) ──
            if (!pc.windFired && now >= pc.windAt) {
                pc.windFired = true;
                class_243 pos = target != null ? target.method_19538() : pc.fallbackPos;
                class_3222 ownerPlayer = server.method_3760().method_14602(pc.ownerId);

                // Explosion damage
                if (target != null) {
                    boolean ok = target.method_5643(
                            world.method_48963().method_48819(ownerPlayer, ownerPlayer),
                            EXPLOSION_DAMAGE);
                    if (!ok && target.method_5805()) {
                        InscriptionRuntime.magicTrueDamage(target, EXPLOSION_DAMAGE);
                    }
                    // Levitation for 10s (phase 2 timer is already set from construction)
                    target.method_6092(new class_1293(
                            class_1294.field_5902, LEVITATION_DURATION, 1, false, true, true));
                }

                // Spawn 8 wind charges outward in a ring
                spawnWindCharges(world, ownerPlayer, pos);

                // Visual + sound
                world.method_14199(class_2398.field_11221,
                        pos.field_1352, pos.field_1351 + 0.5, pos.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
                world.method_14199(class_2398.field_11204,
                        pos.field_1352, pos.field_1351 + 1.0, pos.field_1350, 30, 0.7, 0.5, 0.7, 0.08);
                world.method_14199(class_2398.field_11203,
                        pos.field_1352, pos.field_1351 + 1.5, pos.field_1350, 20, 0.5, 0.6, 0.5, 0.06);
                world.method_8396(null, class_2338.method_49638(pos),
                        class_3417.field_15152.comp_349(), class_3419.field_15248, 1.1f, 1.4f);
            }

            // ── Phase 2: Lightning strike (after levitation ends) ─────────
            if (pc.windFired && now >= pc.lightningAt) {
                class_243 pos = target != null ? target.method_19538() : pc.fallbackPos;
                spawnLightning(world, pos);
                it.remove();
            }
        }

        // Periodic cooldown cleanup
        if (server.method_3780() % 1200 == 0) {
            COOLDOWNS.entrySet().removeIf(ce -> now > ce.getValue() + 20L * 120L);
        }
    }

    // -----------------------------------------------------------------------
    private static void spawnWindBurst(class_3218 world, class_243 pos, int count) {
        world.method_14199(class_2398.field_11204,
                pos.field_1352, pos.field_1351 + 0.8, pos.field_1350, count, 0.45, 0.35, 0.45, 0.07);
        world.method_14199(class_2398.field_11203,
                pos.field_1352, pos.field_1351 + 0.4, pos.field_1350, count / 2, 0.4, 0.3, 0.4, 0.05);
    }

    /**
     * Spawn {@value WIND_CHARGES} wind-charge projectiles in a horizontal ring
     * around {@code center}, all shooting outward.
     *
     * Note: Uses {@code EntityType.WIND_CHARGE} (added in MC 1.21).
     * Verify the import path matches your Yarn/Quilt mapping version if needed.
     */
    private static void spawnWindCharges(class_3218 world, class_3222 owner, class_243 center) {
        for (int i = 0; i < WIND_CHARGES; i++) {
            double angle = (2.0 * Math.PI * i) / WIND_CHARGES;
            double vx = Math.cos(angle) * WIND_CHARGE_SPEED;
            double vz = Math.sin(angle) * WIND_CHARGE_SPEED;

            class_8956 wc = new class_8956(class_1299.field_47243, world);
            wc.method_5814(center.field_1352, center.field_1351 + 1.0, center.field_1350);
            wc.method_18800(vx, 0.1, vz);
            if (owner != null) wc.method_7432(owner);
            world.method_8649(wc);
        }
    }

    private static void spawnLightning(class_3218 world, class_243 pos) {
        class_1538 bolt = class_1299.field_6112.method_5883(world);
        if (bolt == null) return;
        bolt.method_24203(pos.field_1352, pos.field_1351, pos.field_1350);
        world.method_8649(bolt);
    }
}
