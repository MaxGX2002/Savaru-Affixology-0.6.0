package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class HundredBlossomsHooks {
    private HundredBlossomsHooks() {}

    private static final long COOLDOWN_TICKS = 20L * 20L;
    private static final double PROC_CHANCE = 0.20;
    private static final int ARROW_COUNT = 50;
    private static final double BURST_DAMAGE_MULT = 3.0;
    private static final double SEARCH_RADIUS = 12.0;
    private static final int MAX_CHAIN_TARGETS = 24;

    private static final Map<UUID, Long> PLAYER_CD = new ConcurrentHashMap<>();
    private static final Map<UUID, SpecialArrow> SPECIAL_ARROWS = new ConcurrentHashMap<>();
    private static final Map<UUID, ChainState> CHAINS = new ConcurrentHashMap<>();

    private static final class SpecialArrow {
        final UUID chainId;
        final double damage;
        final UUID ownerId;
        SpecialArrow(UUID chainId, double damage, UUID ownerId) {
            this.chainId = chainId;
            this.damage = damage;
            this.ownerId = ownerId;
        }
    }

    private static final class ChainState {
        final UUID ownerId;
        final Set<UUID> visited = new HashSet<>();
        int burstsUsed = 0;
        long createdAt;
        ChainState(UUID ownerId, long createdAt) {
            this.ownerId = ownerId;
            this.createdAt = createdAt;
        }
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(HundredBlossomsHooks::tick);
    }

    public static boolean isManagedProjectile(class_1665 proj) {
        return proj != null && SPECIAL_ARROWS.containsKey(proj.method_5667());
    }

    public static boolean handleSpecialArrowHit(class_1665 proj, class_1309 target) {
        SpecialArrow data = SPECIAL_ARROWS.remove(proj.method_5667());
        if (data == null || target == null) return false;
        if (data.ownerId != null && data.ownerId.equals(target.method_5667())) return true;

        ChainState chain = CHAINS.get(data.chainId);
        if (chain == null) return true;

        InscriptionRuntime.magicTrueDamage(target, data.damage);

        // avoid ping-pong between the same entities
        if (!chain.visited.add(target.method_5667())) return true;

        if (!(target.method_37908() instanceof class_3218 world)) return true;
        spawnMark(world, target.method_19538());

        if (chain.burstsUsed >= MAX_CHAIN_TARGETS) return true;
        if (!hasUnvisitedTargetsNearby(world, target, chain.visited)) return true;

        var owner = world.method_8503().method_3760().method_14602(data.ownerId);
        burstFrom(world, owner, target.method_19538(), data.damage, data.chainId, chain);
        return true;
    }

    public static void onBowHit(class_3218 world, class_1665 projectile, class_1309 target, class_1799 weapon, class_1309 owner) {
        if (world == null || projectile == null || target == null || owner == null) return;
        if (!(owner instanceof class_3222 player)) return;

        long now = world.method_8510();
        long next = PLAYER_CD.getOrDefault(player.method_5667(), 0L);
        if (now < next) return;
        if (world.field_9229.method_43058() >= PROC_CHANCE) return;

        PLAYER_CD.put(player.method_5667(), now + COOLDOWN_TICKS);

        double baseDamage = Math.max(1.0, projectile.method_7448());
        double burstDamage = baseDamage * BURST_DAMAGE_MULT;
        UUID chainId = UUID.randomUUID();
        ChainState chain = new ChainState(player.method_5667(), now);
        chain.visited.add(target.method_5667());
        CHAINS.put(chainId, chain);

        spawnMark(world, target.method_19538());
        burstFrom(world, player, target.method_19538(), burstDamage, chainId, chain);
    }

    private static void burstFrom(class_3218 world, class_3222 owner, class_243 center, double damage, UUID chainId, ChainState chain) {
        chain.burstsUsed++;
        for (int i = 0; i < ARROW_COUNT; i++) {
            double angle = (Math.PI * 2.0 * i) / ARROW_COUNT;
            class_243 dir = new class_243(Math.cos(angle), 0.06, Math.sin(angle)).method_1029();
            class_1667 arrow = new class_1667(class_1299.field_6122, world);
            arrow.method_23327(center.field_1352, center.field_1351 + 0.6, center.field_1350);
            if (owner != null) arrow.method_7432(owner);
            arrow.method_18800(dir.field_1352 * 2.3, dir.field_1351 * 2.3, dir.field_1350 * 2.3);
            arrow.method_7438(0.0);
            arrow.method_7439(true);
            InscriptionArrowRuntime.register(arrow, owner, world, 5L * 20L);
            SPECIAL_ARROWS.put(arrow.method_5667(), new SpecialArrow(chainId, damage, owner != null ? owner.method_5667() : chain.ownerId));
            world.method_8649(arrow);
        }
    }

    private static boolean hasUnvisitedTargetsNearby(class_3218 world, class_1309 center, Set<UUID> visited) {
        class_238 box = center.method_5829().method_1009(SEARCH_RADIUS, 6.0, SEARCH_RADIUS);
        for (class_1309 other : world.method_8390(class_1309.class, box, e -> e.method_5805() && e != center)) {
            if (!visited.contains(other.method_5667())) return true;
        }
        return false;
    }

    private static void spawnMark(class_3218 world, class_243 center) {
        for (int i = 0; i < 26; i++) {
            double angle = (Math.PI * 2.0 * i) / 26.0;
            double x = center.field_1352 + Math.cos(angle) * 1.8;
            double z = center.field_1350 + Math.sin(angle) * 1.8;
            world.method_14199(class_2398.field_43379, x, center.field_1351 + 0.1, z, 1, 0.01, 0.02, 0.01, 0.0);
        }
        world.method_14199(class_2398.field_43379, center.field_1352, center.field_1351 + 0.7, center.field_1350, 16, 0.45, 0.25, 0.45, 0.02);
    }

    private static void tick(MinecraftServer server) {
        long now = server.method_30002().method_8510();
        if (server.method_3780() % 200 != 0) return;

        PLAYER_CD.entrySet().removeIf(e -> now - e.getValue() > 20L * 120L);
        CHAINS.entrySet().removeIf(e -> now - e.getValue().createdAt > 20L * 30L || e.getValue().burstsUsed > MAX_CHAIN_TARGETS);

        Iterator<Map.Entry<UUID, SpecialArrow>> it = SPECIAL_ARROWS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, SpecialArrow> e = it.next();
            boolean exists = false;
            for (class_3218 world : server.method_3738()) {
                if (world.method_14190(e.getKey()) != null) {
                    exists = true;
                    break;
                }
            }
            if (!exists) it.remove();
        }
    }
}
