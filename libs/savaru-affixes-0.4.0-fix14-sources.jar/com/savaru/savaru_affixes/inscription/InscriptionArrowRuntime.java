package com.savaru.savaru_affixes.inscription;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_3218;

public final class InscriptionArrowRuntime {
    private InscriptionArrowRuntime() {}

    private static final class Meta {
        final UUID ownerId;
        final long bornTick;
        final long ttlTicks;
        Meta(UUID ownerId, long bornTick, long ttlTicks) {
            this.ownerId = ownerId;
            this.bornTick = bornTick;
            this.ttlTicks = ttlTicks;
        }
    }

    private static final Map<UUID, Meta> ARROWS = new ConcurrentHashMap<>();

    public static void register(class_1665 proj, class_1309 owner, class_3218 world, long ttlTicks) {
        if (proj == null || world == null) return;
        ARROWS.put(proj.method_5667(), new Meta(owner != null ? owner.method_5667() : null, world.method_8510(), ttlTicks));
    }

    public static boolean isManaged(class_1665 proj) {
        return proj != null && ARROWS.containsKey(proj.method_5667());
    }

    public static boolean isOwnerHit(class_1665 proj, class_1309 target) {
        if (proj == null || target == null) return false;
        Meta m = ARROWS.get(proj.method_5667());
        return m != null && m.ownerId != null && m.ownerId.equals(target.method_5667());
    }

    public static boolean shouldBlockPickup(class_1665 proj, class_1657 player) {
        return proj != null && player != null && ARROWS.containsKey(proj.method_5667());
    }

    public static boolean shouldExpire(class_1665 proj) {
        if (proj == null || !(proj.method_37908() instanceof class_3218 sw)) return false;
        Meta m = ARROWS.get(proj.method_5667());
        return m != null && sw.method_8510() - m.bornTick >= m.ttlTicks;
    }

    public static void forget(class_1665 proj) {
        if (proj != null) ARROWS.remove(proj.method_5667());
    }

    public static void cleanup(class_3218 world) {
        if (world == null) return;
        Iterator<Map.Entry<UUID, Meta>> it = ARROWS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Meta> e = it.next();
            if (world.method_14190(e.getKey()) == null) it.remove();
        }
    }
}
