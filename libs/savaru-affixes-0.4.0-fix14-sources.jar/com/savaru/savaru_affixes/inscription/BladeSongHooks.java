package com.savaru.savaru_affixes.inscription;
import java.util.UUID;

import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.AffixHelper;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BladeSongHooks {

    /**
     * Server time snapshot used by other runtime helpers (cooldowns, timers).
     * Updated whenever Blade Song tick logic runs.
     */
    private static long LAST_SERVER_TIME = 0L;

    /**
     * @return last captured server time (world.getTime())
     */
    public static long getServerTime() {
        return LAST_SERVER_TIME;
    }

    // Chants
    private static final String CHANT_RAIN = "射矢如雨，放各樣銃筒，亂如風雷。";
    private static final String CHANT_DONGXUAN = "二十八日，晴，出東軒公事。";
    private static final String CHANT_DECIDE = "今日固決死，願天必殲此賊。";

    private static final class Burst {
        final UUID playerId;
        int remaining;
        long nextTick;
        Burst(UUID id, int remaining, long nextTick) { this.playerId=id; this.remaining=remaining; this.nextTick=nextTick; }
    }
    private static final List<Burst> BURSTS = new ArrayList<>();

    public static void init() {
    ServerTickEvents.END_SERVER_TICK.register(BladeSongHooks::tick);
}

    
private static final class HoldState {
    long holdStartTick = -1;
    long nextTriggerTick = -1; // after first trigger, every 120s
    boolean firstTriggered = false;
}

private static final java.util.Map<UUID, HoldState> HOLD = new java.util.HashMap<>();

private static void tick(MinecraftServer server) {
    long now = server.method_30002().method_8510();

    
        LAST_SERVER_TIME = now;
// ---- Hold-timer trigger ----
    for (class_3222 player : server.method_3760().method_14571()) {
        UUID pid = player.method_5667();

        class_1799 weapon = player.method_6047();
        boolean holdingBladeSong = false;

        if (!weapon.method_7960() && !UnidentifiedHandler.isUnidentified(weapon)) {
            var ins = InscriptionHelper.getInscription(weapon);
            if (ins != null) {
                String id = ins.method_10558("id");
                // accept both "blade_song" and "savaru_affixes:blade_song"
                holdingBladeSong = "blade_song".equals(id) || "savaru_affixes:blade_song".equals(id);
            }
        }

        HoldState st = HOLD.computeIfAbsent(pid, k -> new HoldState());

        if (!holdingBladeSong) {
            // reset if not holding in main hand
            st.holdStartTick = -1;
            st.nextTriggerTick = -1;
            st.firstTriggered = false;
            continue;
        }

        // start hold timer if not started
        if (st.holdStartTick < 0) st.holdStartTick = now;

        // First trigger after 5 seconds (100 ticks) of continuous holding
        if (!st.firstTriggered) {
            if (now - st.holdStartTick >= 100) {
                triggerBladeSong(server, player, now);
                st.firstTriggered = true;
                st.nextTriggerTick = now + 2400; // 120 seconds
            }
            continue;
        }

        // Subsequent triggers every 120 seconds while still holding
        if (st.nextTriggerTick >= 0 && now >= st.nextTriggerTick) {
            triggerBladeSong(server, player, now);
            st.nextTriggerTick = now + 2400;
        }
    }

    // ---- Handle queued arrow bursts ----
    if (!BURSTS.isEmpty()) {
        for (Iterator<Burst> it = BURSTS.iterator(); it.hasNext();) {
            Burst b = it.next();
            if (now < b.nextTick) continue;

            class_3222 player = server.method_3760().method_14602(b.playerId);
            if (player == null) { it.remove(); continue; }

            class_1799 weapon = player.method_6047();
            if (weapon.method_7960() || UnidentifiedHandler.isUnidentified(weapon)) { it.remove(); continue; }
            var ins = InscriptionHelper.getInscription(weapon);
            if (ins == null) { it.remove(); continue; }
            String id = ins.method_10558("id");
            if (!"blade_song".equals(id) && !"savaru_affixes:blade_song".equals(id)) { it.remove(); continue; }

            doArrowBurst(player);
            b.remaining--;
            b.nextTick = now + 10; // 0.5s
            if (b.remaining <= 0) it.remove();
        }
    }
}

private static void triggerBladeSong(MinecraftServer server, class_3222 player, long now) {
    int pick = player.method_59922().method_43048(3);
    if (pick == 0) {
        server.method_3760().method_43514(class_2561.method_43470(CHANT_RAIN), false);
        BURSTS.add(new Burst(player.method_5667(), 3, now));
            InscriptionRuntime.setBladeSongRainActive(player.method_5667(), now + 60);
    } else if (pick == 1) {
        server.method_3760().method_43514(class_2561.method_43470(CHANT_DONGXUAN), false);
        InscriptionRuntime.setBladeSongZero(player.method_5667(), now, 5 * 20);
    } else {
        server.method_3760().method_43514(class_2561.method_43470(CHANT_DECIDE), false);
        InscriptionRuntime.setBladeSongNextMultiplier(player.method_5667(), now, 5.0, 20 * 20);
        InscriptionRuntime.applyBladeSongChant3Buff(player, 20);
    }
}


    private static void doArrowBurst(class_3222 player) {
        class_3218 world = player.method_51469();
        class_243 eye = player.method_33571();
        class_243 look = player.method_5828(1.0F);

        int count = 10 + world.field_9229.method_43048(21); // 10-30
        double baseYaw = player.method_36454();
        double spread = 60.0;

        for (int i = 0; i < count; i++) {
            double yawOff = (world.field_9229.method_43058() - 0.5) * spread;
            double pitchOff = (world.field_9229.method_43058() - 0.5) * 8.0;

            class_1667 arrow = new class_1667(class_1299.field_6122, world);
            arrow.method_7432(player);
            arrow.method_23327(eye.field_1352, eye.field_1351 - 0.1, eye.field_1350);

            // Approximate direction by rotating yaw a bit
            float yaw = (float) (baseYaw + yawOff);
            float pitch = (float) (player.method_36455() + pitchOff);
            arrow.method_24919(player, pitch, yaw, 0.0F, 2.7F, 1.0F);

            // "亂如風雷": lightning on hit.
            arrow.method_5780("savaru_bladesong_lightning");

            world.method_8649(arrow);
        }
    }
}