package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class DetonationHooks {
    private DetonationHooks() {}
    private static final double PROC_CHANCE = 0.15;
    private static final Map<UUID, Pending> PENDING = new ConcurrentHashMap<>();

    private static final class Pending {
        final net.minecraft.class_5321<net.minecraft.class_1937> worldKey;
        final UUID ownerId;
        final double damage;
        final long explodeAt;
        Pending(class_3218 world, UUID ownerId, double damage, long explodeAt) {
            this.worldKey = world.method_27983();
            this.ownerId = ownerId;
            this.damage = damage;
            this.explodeAt = explodeAt;
        }
    }

    public static void init() { ServerTickEvents.END_SERVER_TICK.register(DetonationHooks::tick); }

    public static void onBowHit(class_3218 world, class_1665 proj, class_1309 target, class_1799 weapon, class_1309 owner) {
        if (world == null || proj == null || target == null || !(owner instanceof class_3222 sp)) return;
        if (world.field_9229.method_43058() >= PROC_CHANCE) return;
        target.method_6092(new class_1293(class_1294.field_5902, 3 * 20, 0, false, true, true));
        PENDING.put(target.method_5667(), new Pending(world, sp.method_5667(), Math.max(1.0, proj.method_7448()) * 5.0, world.method_8510() + 3L * 20L));
    }

    private static void tick(MinecraftServer server) {
        long now = server.method_30002().method_8510();
        Iterator<Map.Entry<UUID, Pending>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Pending> e = it.next();
            Pending p = e.getValue();
            if (now < p.explodeAt) continue;
            class_3218 world = server.method_3847(p.worldKey);
            if (world == null) { it.remove(); continue; }
            var entity = world.method_14190(e.getKey());
            if (!(entity instanceof class_1309 target) || !target.method_5805()) { it.remove(); continue; }
            var owner = server.method_3760().method_14602(p.ownerId);
            target.method_5643(world.method_48963().method_48819(owner, owner), (float)p.damage);
            if (target.method_5805()) {
                InscriptionRuntime.magicTrueDamage(target, p.damage);
            }
            world.method_14199(class_2398.field_11236, target.method_23317(), target.method_23323(0.5), target.method_23321(), 1, 0, 0, 0, 0.0);
            it.remove();
        }
    }
}
