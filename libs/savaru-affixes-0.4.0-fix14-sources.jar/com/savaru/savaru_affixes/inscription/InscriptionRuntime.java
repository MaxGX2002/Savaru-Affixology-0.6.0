package com.savaru.savaru_affixes.inscription;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2168;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.server.MinecraftServer;

/**
 * Lightweight runtime state for inscriptions (server-only logic).
 * We keep it in-memory to avoid persistent data format churn.
 */
public class InscriptionRuntime {

    private static final ConcurrentHashMap<UUID, Long> BLACKFLASH_BUFF_UNTIL = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> BLADESONG_ZERO_UNTIL = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> BLADESONG_NEXT_MULT_UNTIL = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Double> BLADESONG_NEXT_MULT = new ConcurrentHashMap<>();

    private static final class_2960 BLADESONG_AD_ID = class_2960.method_60655("savaru_affixes", "blade_song_ad");

    private static final ConcurrentHashMap<UUID, Integer> TRUEFOCUS_LAST_TARGET = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Integer> TRUEFOCUS_HITS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> TRUEFOCUS_EXPIRE = new ConcurrentHashMap<>();

    // Temporary +5 attack damage for Blade Song chant 3

    /**
     * 固定「魔法/真實」傷害（忽略護甲與抗性）。
     * 以 outOfWorld 作為最穩定的 bypass 來源。
     */
    public static void magicTrueDamage(class_1309 target, double amount) {
        // 以「直接扣血」保證效果可見：
        // - 不吃護甲/抗性
        // - 不容易被 hurtTime/i-frames 吃掉
        if (target == null || amount <= 0.0) return;
        float hp = target.method_6032();
        float next = (float) (hp - amount);

        if (next <= 0.0f) {
            // 走正常死亡流程
            target.method_6033(0.0f);
            target.method_5643(target.method_48923().method_48829(), 9999.0f);
        } else {
            target.method_6033(next);
            target.field_6235 = 0;
            target.field_6008 = 0;
        }
    }
    
    public static void extendBlackflashBuff(class_3222 player, long nowTicks, int addTicks) {
        BLACKFLASH_BUFF_UNTIL.merge(player.method_5667(), nowTicks + addTicks, Math::max);
    }

    public static boolean isBlackflashBuffActive(UUID playerId, long nowTicks) {
        Long until = BLACKFLASH_BUFF_UNTIL.get(playerId);
        return until != null && until > nowTicks;
    }

    public static void setBladeSongZero(UUID playerId, long nowTicks, int ticks) {
        BLADESONG_ZERO_UNTIL.put(playerId, nowTicks + ticks);
    }

    public static boolean isBladeSongZero(UUID playerId, long nowTicks) {
        Long until = BLADESONG_ZERO_UNTIL.get(playerId);
        return until != null && until > nowTicks;
    }

    public static void setBladeSongNextMultiplier(UUID playerId, long nowTicks, double mult, int ttlTicks) {
        BLADESONG_NEXT_MULT.put(playerId, mult);
        BLADESONG_NEXT_MULT_UNTIL.put(playerId, nowTicks + ttlTicks);
    }

    /** Consume the next-attack multiplier if active; returns 1.0 if none. */
    public static double consumeBladeSongNextMultiplier(UUID playerId, long nowTicks) {
        Long until = BLADESONG_NEXT_MULT_UNTIL.get(playerId);
        if (until == null || until <= nowTicks) {
            BLADESONG_NEXT_MULT.remove(playerId);
            BLADESONG_NEXT_MULT_UNTIL.remove(playerId);
            return 1.0;
        }
        Double v = BLADESONG_NEXT_MULT.remove(playerId);
        BLADESONG_NEXT_MULT_UNTIL.remove(playerId);
        return v == null ? 1.0 : v;
    }

    // ---- True Focus: 4th hit true damage ----
    public static int addTrueFocusHit(UUID playerId, int targetId, long nowTicks, int ttlTicks) {
        Integer last = TRUEFOCUS_LAST_TARGET.get(playerId);
        Long exp = TRUEFOCUS_EXPIRE.get(playerId);
        if (last == null || last != targetId || exp == null || exp <= nowTicks) {
            TRUEFOCUS_LAST_TARGET.put(playerId, targetId);
            TRUEFOCUS_HITS.put(playerId, 1);
            TRUEFOCUS_EXPIRE.put(playerId, nowTicks + ttlTicks);
            return 1;
        }
        int n = TRUEFOCUS_HITS.merge(playerId, 1, Integer::sum);
        TRUEFOCUS_EXPIRE.put(playerId, nowTicks + ttlTicks);
        return n;
    }

    public static void resetTrueFocus(UUID playerId) {
        TRUEFOCUS_LAST_TARGET.remove(playerId);
        TRUEFOCUS_HITS.remove(playerId);
        TRUEFOCUS_EXPIRE.remove(playerId);
    }

    // ---- Blade Song chant 3 helpers ----
    public static void applyBladeSongChant3Buff(class_3222 player, int seconds) {
        player.method_6092(new class_1293(class_1294.field_5910, seconds * 20, 1, false, true, true));

        var inst = player.method_5996(class_5134.field_23721);
        if (inst != null) {
            inst.method_6200(BLADESONG_AD_ID);
            inst.method_26835(new class_1322(
                    BLADESONG_AD_ID, 5.0, class_1322.class_1323.field_6328));
        }
    }

private static final java.util.Map<java.util.UUID, Long> BLADESONG_RAIN_UNTIL = new java.util.HashMap<>();

public static void setBladeSongRainActive(java.util.UUID playerId, long untilTick) {
    BLADESONG_RAIN_UNTIL.put(playerId, untilTick);
}

public static boolean isBladeSongRainActive(java.util.UUID playerId) {
    Long until = BLADESONG_RAIN_UNTIL.get(playerId);
    if (until == null) return false;
    // uses server overworld time; updated by BladeSongHooks when starting rain
    return com.savaru.savaru_affixes.inscription.BladeSongHooks.getServerTime() <= until;
}

public static void clearBladeSongRain(java.util.UUID playerId) {
    BLADESONG_RAIN_UNTIL.remove(playerId);
}


    // ---- Charge (秘傳：充能) runtime (player scoped) ----
    private static final ConcurrentHashMap<UUID, String> CHARGE_FINGERPRINT = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Integer> CHARGE_PCT = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> CHARGE_NEXT_TICK = new ConcurrentHashMap<>();

    public static void resetCharge(UUID playerId) {
        CHARGE_FINGERPRINT.remove(playerId);
        CHARGE_PCT.remove(playerId);
        CHARGE_NEXT_TICK.remove(playerId);
    }

    public static int getChargePct(UUID playerId) {
        return CHARGE_PCT.getOrDefault(playerId, 0);
    }

    public static void setChargeState(UUID playerId, String fingerprint, int pct, long nextTick) {
        CHARGE_FINGERPRINT.put(playerId, fingerprint);
        CHARGE_PCT.put(playerId, pct);
        CHARGE_NEXT_TICK.put(playerId, nextTick);
    }

    public static String getChargeFingerprint(UUID playerId) {
        return CHARGE_FINGERPRINT.get(playerId);
    }

    public static long getChargeNextTick(UUID playerId) {
        return CHARGE_NEXT_TICK.getOrDefault(playerId, 0L);
    }

    // ---- Starflow Sevenfold (秘傳：星流七連) runtime (player scoped) ----
    private static final ConcurrentHashMap<UUID, Integer> STAR_STAGE = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Integer> STAR_KILLS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> STAR_LAST_HURT = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> STAR_TRANSITION_AT = new ConcurrentHashMap<>();

    // Per-stage "next attack" flags
    private static final ConcurrentHashMap<UUID, Boolean> STAR_NEXT_DOT = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Boolean> STAR_NEXT_350 = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Boolean> STAR_NEXT_ARROWS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> STAR_LEVITATE_UNTIL = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Long> STAR_BURN_UNTIL = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<UUID, Boolean> STAR_NEXT_FINAL = new ConcurrentHashMap<>();

    public static void setStarLastHurt(UUID playerId, long tick) {
        STAR_LAST_HURT.put(playerId, tick);
    }

    public static long getStarLastHurt(UUID playerId) {
        return STAR_LAST_HURT.getOrDefault(playerId, -999999L);
    }

    public static void resetStarflow(UUID playerId) {
        STAR_STAGE.remove(playerId);
        STAR_KILLS.remove(playerId);
        STAR_TRANSITION_AT.remove(playerId);
        STAR_NEXT_DOT.remove(playerId);
        STAR_NEXT_350.remove(playerId);
        STAR_NEXT_ARROWS.remove(playerId);
        STAR_LEVITATE_UNTIL.remove(playerId);
        STAR_BURN_UNTIL.remove(playerId);
        STAR_NEXT_FINAL.remove(playerId);
    }

    public static int getStarStage(UUID playerId) {
        return STAR_STAGE.getOrDefault(playerId, 0);
    }

    public static void setStarStage(UUID playerId, int stage) {
        STAR_STAGE.put(playerId, stage);
    }

    public static int addStarKill(UUID playerId) {
        return STAR_KILLS.merge(playerId, 1, Integer::sum);
    }

    public static void resetStarKills(UUID playerId) {
        STAR_KILLS.remove(playerId);
    }

    public static void setStarTransitionAt(UUID playerId, long tick) {
        if (tick <= 0) STAR_TRANSITION_AT.remove(playerId);
        else STAR_TRANSITION_AT.put(playerId, tick);
    }

    public static long getStarTransitionAt(UUID playerId) {
        return STAR_TRANSITION_AT.getOrDefault(playerId, 0L);
    }

    public static void setStarNextDot(UUID playerId, boolean v) { STAR_NEXT_DOT.put(playerId, v); }
    public static boolean consumeStarNextDot(UUID playerId) { return STAR_NEXT_DOT.remove(playerId) != null; }

    public static void setStarNext350(UUID playerId, boolean v) { STAR_NEXT_350.put(playerId, v); }
    public static boolean consumeStarNext350(UUID playerId) { return STAR_NEXT_350.remove(playerId) != null; }

    public static void setStarNextArrows(UUID playerId, boolean v) { STAR_NEXT_ARROWS.put(playerId, v); }
    public static boolean consumeStarNextArrows(UUID playerId) { return STAR_NEXT_ARROWS.remove(playerId) != null; }

    public static void setStarLevitateUntil(UUID playerId, long tick) { STAR_LEVITATE_UNTIL.put(playerId, tick); }
    public static long getStarLevitateUntil(UUID playerId) { return STAR_LEVITATE_UNTIL.getOrDefault(playerId, 0L); }

    public static void setStarBurnUntil(UUID playerId, long tick) { STAR_BURN_UNTIL.put(playerId, tick); }
    public static long getStarBurnUntil(UUID playerId) { return STAR_BURN_UNTIL.getOrDefault(playerId, 0L); }

    public static void setStarNextFinal(UUID playerId, boolean v) { STAR_NEXT_FINAL.put(playerId, v); }
    public static boolean consumeStarNextFinal(UUID playerId) { return STAR_NEXT_FINAL.remove(playerId) != null; }


    // ---- UI helpers ----
    public static void sendTitle(net.minecraft.class_3222 player, String text) {
        if (player == null) return;
        var server = player.method_5682();
        if (server == null) return;

        String safe = text.replace("\\", "\\\\").replace("\"", "\\\"");
        var src = player.method_5671().method_9217();
        server.method_3734().method_44252(src, "title @s times 5 35 10");
        server.method_3734().method_44252(src, "title @s title {\"text\":\"" + safe + "\"}");
    }


    public static void sendActionbar(net.minecraft.class_3222 player, String text) {
        if (player == null) return;
        var server = player.method_5682();
        if (server == null) return;

        String safe = text.replace("\\", "\\\\").replace("\"", "\\\"");
        var src = player.method_5671().method_9217();
        server.method_3734().method_44252(src, "title @s actionbar {\"text\":\"" + safe + "\"}");
    }

}
