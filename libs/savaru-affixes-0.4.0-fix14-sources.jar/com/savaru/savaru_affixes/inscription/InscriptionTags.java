package com.savaru.savaru_affixes.inscription;

import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public final class InscriptionTags {
    private InscriptionTags() {}
    public static final class_6862<class_1792> INSCRIPTION_ALLOWED =
            class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("savaru_affixes", "inscription_allowed"));
}
