package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ThunderfireCannonHooks {
    private ThunderfireCannonHooks() {}

    private static final long TARGET_COOLDOWN_TICKS = 60L * 20L;
    private static final long STRIKE_DELAY_TICKS = 3L * 20L;
    private static final long LIGHTNING_DELAY_TICKS = 1L * 20L;
    private static final double EXTRA_PHYSICAL_MULT = 2.0;
    private static final double FIXED_MAGIC_DAMAGE = 250.0;
    private static final float INITIAL_EXPLOSION_DAMAGE = 100.0f;
    private static final float SKYFALL_EXPLOSION_DAMAGE = 1000.0f;
    private static final double SKYFALL_RADIUS = 3.5;

    private static final Map<UUID, Integer> TARGET_HITS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> TARGET_COOLDOWNS = new ConcurrentHashMap<>();
    private static final Map<UUID, PendingStrike> PENDING = new ConcurrentHashMap<>();

    private static final class PendingStrike {
        final net.minecraft.class_5321<net.minecraft.class_1937> worldKey;
        final UUID ownerId;
        final UUID targetId;
        final class_243 fallbackPos;
        final long skyfallAt;
        long lightningAt;
        boolean arrowDropped;

        PendingStrike(class_3218 world, UUID ownerId, UUID targetId, class_243 fallbackPos, long skyfallAt) {
            this.worldKey = world.method_27983();
            this.ownerId = ownerId;
            this.targetId = targetId;
            this.fallbackPos = fallbackPos;
            this.skyfallAt = skyfallAt;
        }
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(ThunderfireCannonHooks::tick);
    }

    public static void onBowHit(class_3218 world, class_1665 proj, class_1309 target, class_1799 weapon, class_1309 owner) {
        if (world == null || proj == null || target == null || !(owner instanceof class_3222 player)) return;

        long now = world.method_8510();
        UUID targetId = target.method_5667();
        long cdUntil = TARGET_COOLDOWNS.getOrDefault(targetId, 0L);
        if (now < cdUntil) return;

        int hits = TARGET_HITS.getOrDefault(targetId, 0) + 1;
        if (hits < 3) {
            TARGET_HITS.put(targetId, hits);
            return;
        }

        TARGET_HITS.remove(targetId);
        TARGET_COOLDOWNS.put(targetId, now + TARGET_COOLDOWN_TICKS);

        float baseDamage = (float) Math.max(1.0, proj.method_7448());
        float extraPhysical = (float) (baseDamage * EXTRA_PHYSICAL_MULT);
        target.method_5643(world.method_48963().method_48803(proj, player), extraPhysical);
        InscriptionRuntime.magicTrueDamage(target, FIXED_MAGIC_DAMAGE);
        boolean exploded = target.method_5643(world.method_48963().method_48819(player, player), INITIAL_EXPLOSION_DAMAGE);
        if (!exploded && target.method_5805()) {
            InscriptionRuntime.magicTrueDamage(target, INITIAL_EXPLOSION_DAMAGE);
        }

        world.method_14199(class_2398.field_11221, target.method_23317(), target.method_23323(0.5), target.method_23321(), 1, 0.0, 0.0, 0.0, 0.0);
        world.method_14199(class_2398.field_29644, target.method_23317(), target.method_23323(0.7), target.method_23321(), 18, 0.35, 0.45, 0.35, 0.08);
        world.method_8396(null, target.method_24515(), class_3417.field_15152.comp_349(), class_3419.field_15248, 0.9f, 0.9f);

        PENDING.put(targetId, new PendingStrike(world, player.method_5667(), targetId, target.method_19538(), now + STRIKE_DELAY_TICKS));
    }

    private static void tick(MinecraftServer server) {
        long now = server.method_30002().method_8510();
        Iterator<Map.Entry<UUID, PendingStrike>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, PendingStrike> entry = it.next();
            PendingStrike pending = entry.getValue();
            class_3218 world = server.method_3847(pending.worldKey);
            if (world == null) {
                it.remove();
                continue;
            }

            class_1309 target = null;
            var entity = world.method_14190(pending.targetId);
            if (entity instanceof class_1309 living && living.method_5805()) {
                target = living;
            }

            class_243 center = target != null ? target.method_19538() : pending.fallbackPos;
            var owner = server.method_3760().method_14602(pending.ownerId);

            if (!pending.arrowDropped && now >= pending.skyfallAt) {
                pending.arrowDropped = true;
                pending.lightningAt = now + LIGHTNING_DELAY_TICKS;
                spawnSkyfallArrow(world, owner, center);
                explodeSkyfall(world, owner, center);
            }

            if (pending.arrowDropped && now >= pending.lightningAt) {
                spawnLightning(world, center);
                it.remove();
            }
        }

        if (server.method_3780() % 1200 == 0) {
            TARGET_HITS.entrySet().removeIf(e -> !TARGET_COOLDOWNS.containsKey(e.getKey()));
            TARGET_COOLDOWNS.entrySet().removeIf(e -> now > e.getValue() + 20L * 120L);
        }
    }

    private static void spawnSkyfallArrow(class_3218 world, class_3222 owner, class_243 center) {
        class_1667 arrow = new class_1667(class_1299.field_6122, world);
        arrow.method_23327(center.field_1352, center.field_1351 + 16.0, center.field_1350);
        arrow.method_18800(0.0, -4.0, 0.0);
        arrow.method_7438(0.0);
        arrow.method_7439(true);
        if (owner != null) arrow.method_7432(owner);
        InscriptionArrowRuntime.register(arrow, owner, world, 5L * 20L);
        world.method_8649(arrow);

        for (int i = 0; i < 24; i++) {
            double y = center.field_1351 + 1.0 + (i * 0.6);
            world.method_14199(class_2398.field_11207, center.field_1352, y, center.field_1350, 2, 0.08, 0.0, 0.08, 0.0);
            world.method_14199(class_2398.field_29644, center.field_1352, y, center.field_1350, 2, 0.15, 0.05, 0.15, 0.02);
        }
        world.method_8396(null, class_2338.method_49638(center), class_3417.field_14600, class_3419.field_15248, 1.1f, 0.55f);
    }

    private static void explodeSkyfall(class_3218 world, class_3222 owner, class_243 center) {
        world.method_14199(class_2398.field_11221, center.field_1352, center.field_1351 + 0.5, center.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
        world.method_14199(class_2398.field_11204, center.field_1352, center.field_1351 + 0.2, center.field_1350, 25, 0.5, 0.15, 0.5, 0.03);
        world.method_8396(null, class_2338.method_49638(center), class_3417.field_15152.comp_349(), class_3419.field_15248, 1.2f, 0.6f);

        class_238 box = class_238.method_30048(center.method_1031(0.0, 0.5, 0.0), SKYFALL_RADIUS * 2.0, 4.0, SKYFALL_RADIUS * 2.0);
        for (class_1309 hit : world.method_8390(class_1309.class, box, class_1309::method_5805)) {
            boolean ok = hit.method_5643(world.method_48963().method_48819(owner, owner), SKYFALL_EXPLOSION_DAMAGE);
            if (!ok && hit.method_5805()) {
                InscriptionRuntime.magicTrueDamage(hit, SKYFALL_EXPLOSION_DAMAGE);
            }
        }
    }

    private static void spawnLightning(class_3218 world, class_243 center) {
        class_1538 lightning = class_1299.field_6112.method_5883(world);
        if (lightning == null) return;
        lightning.method_24203(center.field_1352, center.field_1351, center.field_1350);
        world.method_8649(lightning);
    }
}
