package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 「逕庭拳」：當目標身上存在特定負面狀態時，持續每 0.5 秒造成一次固定魔法傷害。
 *
 * 設計：首次觸發由攻擊事件啟動；之後以 tick 迴圈持續檢查並輸出，直到目標死亡或不再符合條件。
 */
public final class JingtinFistHooks {
    private JingtinFistHooks() {}

    private static final int PERIOD_TICKS = 10; // 0.5s
    private static final double DAMAGE = 20.0;

    private static final class Active {
        final class_5321<class_1937> worldKey;
        int left;
        Active(class_5321<class_1937> worldKey, int left) {
            this.worldKey = worldKey;
            this.left = left;
        }
    }

    private static final Map<UUID, Active> active = new ConcurrentHashMap<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(JingtinFistHooks::onServerTick);
    }

    public static void activate(class_1309 target) {
        if (target == null || target.method_29504()) return;
        active.putIfAbsent(target.method_5667(), new Active(target.method_37908().method_27983(), PERIOD_TICKS));
    }

    private static void onServerTick(MinecraftServer server) {
        if (active.isEmpty()) return;

        Iterator<Map.Entry<UUID, Active>> it = active.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Active> e = it.next();
            UUID id = e.getKey();
            Active a = e.getValue();

            class_3218 world = server.method_3847(a.worldKey);
            if (world == null) {
                it.remove();
                continue;
            }

            class_1309 ent = (world.method_14190(id) instanceof class_1309 le) ? le : null;
            if (ent == null || ent.method_29504()) {
                it.remove();
                continue;
            }

            if (!hasDebuff(ent)) {
                it.remove();
                continue;
            }

            a.left -= 1;
            if (a.left > 0) continue;

            a.left = PERIOD_TICKS;
            InscriptionRuntime.magicTrueDamage(ent, DAMAGE);
        }
    }

    private static boolean hasDebuff(class_1309 e) {
        return e.method_6059(class_1294.field_5899)
                || e.method_6059(class_1294.field_5920)
                || e.method_6059(class_1294.field_5909)
                || e.method_6059(class_1294.field_38092)
                || e.method_6059(class_1294.field_5916)
                || e.method_6059(class_1294.field_5911);
    }
}
