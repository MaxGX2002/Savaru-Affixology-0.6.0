package com.savaru.savaru_affixes.inscription;

import com.savaru.savaru_affixes.Rarity;
import com.savaru.savaru_affixes.config.ConfigManager;
import java.util.List;
import java.util.Random;
import net.minecraft.class_124;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public final class InscriptionHelper {
    private InscriptionHelper() {}

    public static final String ROOT = "savaru_inscription";
    public static final String TYPE_OUTLAND = "outland";
    public static final String TYPE_SECRET = "secret";
    public static final String TARGET_MELEE = "melee";
    public static final String TARGET_RANGED = "ranged";

    // Pools split by weapon family
    public static final List<String> OUTLAND_POOL_MELEE = List.of(
            "blossom",
            "blackflash",
            "senlingpoison",
            "blade_song",
            "jingtin_fist",
            "heaven_inverted_spear"
    );
    public static final List<String> SECRET_POOL_MELEE = List.of(
            "truefocus",
            "soulbind",
            "bafengshen",
            "charge",
            "sunmoon_corridor",
            "starflow"
    );
    public static final List<String> OUTLAND_POOL_RANGED = List.of(
            "thunderfire_cannon",
            "kagushimei",
            "chidori"
    );
    public static final List<String> SECRET_POOL_RANGED = List.of(
            "spring_rain",
            "hundred_blossoms",
            "detonation",
            "mimic_arrow",
            "distant_thunder"
    );

    public static final List<String> OUTLAND_POOL = concat(OUTLAND_POOL_MELEE, OUTLAND_POOL_RANGED);
    public static final List<String> SECRET_POOL  = concat(SECRET_POOL_MELEE, SECRET_POOL_RANGED);

    private static List<String> concat(List<String> a, List<String> b) {
        java.util.ArrayList<String> out = new java.util.ArrayList<>(a);
        out.addAll(b);
        return java.util.List.copyOf(out);
    }

    public static boolean isRangedWeapon(class_1799 weapon) {
        if (weapon == null || weapon.method_7960()) return false;
        return weapon.method_7909() instanceof class_1753 || weapon.method_7909() instanceof class_1764;
    }

    public static String getTargetForWeapon(class_1799 weapon) {
        return isRangedWeapon(weapon) ? TARGET_RANGED : TARGET_MELEE;
    }

    public static String getTargetForId(String id) {
        if (id == null) return null;
        if (OUTLAND_POOL_MELEE.contains(id) || SECRET_POOL_MELEE.contains(id)) return TARGET_MELEE;
        if (OUTLAND_POOL_RANGED.contains(id) || SECRET_POOL_RANGED.contains(id)) return TARGET_RANGED;
        return null;
    }

    public static boolean isIdCompatibleWithWeapon(String id, class_1799 weapon) {
        String target = getTargetForId(id);
        return target != null && target.equals(getTargetForWeapon(weapon));
    }

    public static List<String> getPoolFor(String type, class_1799 weapon) {
        String target = getTargetForWeapon(weapon);
        if (TARGET_RANGED.equals(target)) {
            return TYPE_SECRET.equals(type) ? SECRET_POOL_RANGED : OUTLAND_POOL_RANGED;
        }
        return TYPE_SECRET.equals(type) ? SECRET_POOL_MELEE : OUTLAND_POOL_MELEE;
    }

    public static boolean isAllowedWeapon(class_1799 weapon) {
        if (weapon == null || weapon.method_7960()) return false;

        // Always allow normal recognized weapon families, including bows / crossbows.
        // Tags / whitelist remain available for custom items that are not vanilla weapon classes.
        if (com.savaru.savaru_affixes.AffixHelper.isWeapon(weapon)) return true;

        if (weapon.method_31573(InscriptionTags.INSCRIPTION_ALLOWED)) return true;
        String id = class_7923.field_41178.method_10221(weapon.method_7909()).toString();
        var wl = ConfigManager.get().inscriptionWhitelist;
        return wl.isEmpty() || wl.contains(id);
    }

    public static class_2487 getInscription(class_1799 stack) {
        class_9279 comp = stack.method_57824(class_9334.field_49628);
        if (comp == null) return null;
        class_2487 root = comp.method_57463();
        if (root == null || !root.method_10545(ROOT)) return null;
        class_2487 ins = root.method_10562(ROOT);
        return ins.method_33133() ? null : ins;
    }

    public static void setInscription(class_1799 stack, String type, String id) {
        class_2487 root;
        class_9279 comp = stack.method_57824(class_9334.field_49628);
        if (comp != null && comp.method_57463() != null) root = comp.method_57463().method_10553();
        else root = new class_2487();

        class_2487 ins = new class_2487();
        ins.method_10582("type", type);
        ins.method_10582("id", id);
        String target = getTargetForId(id);
        if (target != null) ins.method_10582("target", target);

        root.method_10566(ROOT, ins);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(root));
    }

    public static boolean canApplyToWeapon(String type, Rarity rarity) {
        if (rarity == null) return false;
        if (TYPE_OUTLAND.equals(type)) return rarity.ordinal() >= Rarity.MYTHIC.ordinal();
        if (TYPE_SECRET.equals(type)) return rarity.ordinal() >= Rarity.LEGENDARY.ordinal();
        return false;
    }

    public static String rollRandom(String type, class_1799 weapon, Random rnd) {
        List<String> pool = getPoolFor(type, weapon);
        if (pool.isEmpty()) return "";
        return pool.get(rnd.nextInt(pool.size()));
    }

    public static class_2561 header(String type) {
        if (TYPE_OUTLAND.equals(type)) return class_2561.method_43471("tooltip.savaru_affixes.inscription.outland").method_27692(class_124.field_1076);
        if (TYPE_SECRET.equals(type)) return class_2561.method_43471("tooltip.savaru_affixes.inscription.secret").method_27692(class_124.field_1075);
        return class_2561.method_43470("✧ Inscription");
    }

    public static class_2561 displayLine(String type, String id) {
        var name = class_2561.method_43471("inscription.savaru_affixes." + id);
        if (TYPE_OUTLAND.equals(type)) return class_2561.method_43470("⨝ ").method_27692(class_124.field_1076).method_10852(name.method_27692(class_124.field_1076));
        if (TYPE_SECRET.equals(type)) return class_2561.method_43470("⨝ ").method_27692(class_124.field_1075).method_10852(name.method_27692(class_124.field_1075));
        return class_2561.method_43470("⨝ ").method_10852(name);
    }


    /** Display name text for tooltip (no color applied here). */
    public static class_2561 displayName(String type, String id) {
        if (id == null || id.isEmpty()) return class_2561.method_43470("⨝ ???");
        // Our lang keys are namespaced:
        //   inscription.savaru_affixes.<id>
        // where <id> is stored as a plain string like "blackflash" (no namespace).
        String key = "inscription.savaru_affixes." + id;
        return class_2561.method_43470("⨝ ").method_10852(class_2561.method_43471(key));
    }

    /** Description lines for tooltip. Each line is a separate Text starting with a dash bullet. */
    public static java.util.List<class_2561> descriptionLines(String type, String id) {
        java.util.ArrayList<class_2561> out = new java.util.ArrayList<>();
        if (id == null || id.isEmpty()) return out;

        // Support both suffix styles:
        //   inscription_desc.savaru_affixes.<id>_1, _2, ...  (legacy)
        //   inscription_desc.savaru_affixes.<id>.1, .2, ...  (current)
        String baseUnderscore = "inscription_desc.savaru_affixes." + id + "_";
        String baseDot = "inscription_desc.savaru_affixes." + id + ".";

        // Up to 6 lines; missing keys will just show the key string, so guard by comparing.
        for (int i = 1; i <= 32; i++) {
            String k1 = baseUnderscore + i;
            class_2561 t1 = class_2561.method_43471(k1);
            if (!t1.getString().equals(k1)) {
                out.add(t1);
                continue;
            }

            String k2 = baseDot + i;
            class_2561 t2 = class_2561.method_43471(k2);
            if (t2.getString().equals(k2)) break;
            out.add(t2);
        }
        return out;
    }

    public static String getTypeForId(String id) {
        if (id == null) return null;
        if (OUTLAND_POOL.contains(id)) return TYPE_OUTLAND;
        if (SECRET_POOL.contains(id)) return TYPE_SECRET;
        return null;
    }

    public static boolean canApplyToWeapon(String type, Rarity rarity, class_1799 weapon, String id) {
        if (!canApplyToWeapon(type, rarity)) return false;
        if (id == null || id.isEmpty()) return false;
        return isIdCompatibleWithWeapon(id, weapon);
    }

public static String getInscriptionTarget(class_1799 stack) {
    var ins = getInscription(stack);
    if (ins == null) return null;
    if (ins.method_10545("target")) return ins.method_10558("target");
    return getTargetForId(ins.method_10558("id"));
}

public static boolean hasInscriptionId(class_1799 stack, String id) {
    if (stack == null || stack.method_7960()) return false;
    var ins = getInscription(stack);
    if (ins == null) return false;
    String got = ins.method_10558("id");
    return id.equals(got) || ("savaru_affixes:" + id).equals(got);
}

}
