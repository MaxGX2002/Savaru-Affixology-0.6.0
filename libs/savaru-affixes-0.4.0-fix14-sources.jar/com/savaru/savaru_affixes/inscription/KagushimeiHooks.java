package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 加具士命（Kagushimei）— 異鄉遠程銘刻
 *
 * 每 30 秒，玩家的下一支箭矢附帶黑色靈魂粒子。
 * 命中目標後：凋零 II + 燃燒，持續 20 秒。
 * 若效果過了 10 秒目標仍存活，在其周圍形成黑色靈魂粒子圓圈（半徑 4.5），
 * 圓圈範圍內所有生物持續燃燒，持續 10 秒。
 */
public final class KagushimeiHooks {
    private KagushimeiHooks() {}

    private static final long CHARGE_INTERVAL_TICKS = 30L * 20L; // 30s per charge
    private static final long RING_DELAY_TICKS      = 10L * 20L; // 10s after hit → ring
    private static final long RING_DURATION_TICKS   = 10L * 20L; // ring lasts 10s
    private static final double RING_RADIUS         = 4.5;
    private static final int WITHER_DURATION        = 20 * 20;   // 20s, Wither II
    private static final int FIRE_SECONDS           = 20;        // 20s fire

    // Player UUID → tick when the next charge is available (0 = immediately on first shot)
    private static final Map<UUID, Long> NEXT_CHARGE_AT = new ConcurrentHashMap<>();

    // Arrow entity UUIDs that carry the charge (emit soul particles in flight)
    // Key: arrow UUID, Value: server world-time when registered (for age-based cleanup)
    private static final Map<UUID, Long> CHARGED_ARROWS = new ConcurrentHashMap<>();

    // Target UUID → pending ring (waiting 10s after hit)
    private static final Map<UUID, PendingRing> PENDING_RINGS = new ConcurrentHashMap<>();

    // Target UUID → active ring (burning nearby mobs for 10s)
    private static final Map<UUID, ActiveRing> ACTIVE_RINGS = new ConcurrentHashMap<>();

    // -----------------------------------------------------------------------
    private static final class PendingRing {
        final net.minecraft.class_5321<net.minecraft.class_1937> worldKey;
        final UUID targetId;
        final long activateAt;

        PendingRing(class_3218 w, UUID tid, long at) {
            worldKey   = w.method_27983();
            targetId   = tid;
            activateAt = at;
        }
    }

    private static final class ActiveRing {
        final net.minecraft.class_5321<net.minecraft.class_1937> worldKey;
        final UUID targetId;
        final long expireAt;
        class_243 pos;

        ActiveRing(class_3218 w, UUID tid, class_243 pos, long exp) {
            worldKey  = w.method_27983();
            targetId  = tid;
            this.pos  = pos;
            expireAt  = exp;
        }
    }

    // -----------------------------------------------------------------------
    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(KagushimeiHooks::tick);
    }

    /**
     * Called from PersistentProjectileEntityTickMixin on the first few ticks of
     * each arrow in flight.  If the owning player's charge window has opened,
     * this arrow is marked as "charged" and the next window is pushed 30s ahead.
     */
    public static void tryClaimCharge(class_3222 player,
                                      class_1665 proj, long now) {
        UUID pid = player.method_5667();
        // Already claimed by a previous arrow this window?
        if (now < NEXT_CHARGE_AT.getOrDefault(pid, 0L)) return;
        // Already marked (re-entry guard)?
        if (CHARGED_ARROWS.containsKey(proj.method_5667())) return;

        // Claim: register arrow, advance window
        CHARGED_ARROWS.put(proj.method_5667(), now);
        NEXT_CHARGE_AT.put(pid, now + CHARGE_INTERVAL_TICKS);
    }

    /** True while the given projectile should display soul-particle trail. */
    public static boolean isChargedArrow(class_1665 proj) {
        return proj != null && CHARGED_ARROWS.containsKey(proj.method_5667());
    }

    /** Called from PersistentProjectileEntityHitMixin when a charged arrow hits. */
    public static void onBowHit(class_3218 world, class_1665 proj,
                                 class_1309 target, class_1799 weapon, class_1309 owner) {
        if (!(owner instanceof class_3222)) return;
        if (CHARGED_ARROWS.remove(proj.method_5667()) == null) return; // not a charged arrow → skip

        long now = world.method_8510();

        // Wither II (20s) + fire (20s)
        target.method_6092(new class_1293(
                class_1294.field_5920, WITHER_DURATION, 1, false, true, true));
        target.method_5639(FIRE_SECONDS);

        // Impact burst
        spawnSoulBurst(world, target.method_19538(), 35);
        world.method_8396(null, target.method_24515(),
                class_3417.field_15163, class_3419.field_15248, 1.0f, 0.8f);

        // Schedule ring check 10s later
        PENDING_RINGS.put(target.method_5667(),
                new PendingRing(world, target.method_5667(), now + RING_DELAY_TICKS));
    }

    // -----------------------------------------------------------------------
    private static void tick(MinecraftServer server) {
        long now = server.method_30002().method_8510();

        // ── Pending → Active ──────────────────────────────────────────────
        Iterator<Map.Entry<UUID, PendingRing>> pit = PENDING_RINGS.entrySet().iterator();
        while (pit.hasNext()) {
            Map.Entry<UUID, PendingRing> e = pit.next();
            PendingRing pr = e.getValue();
            if (now < pr.activateAt) continue;
            pit.remove();

            class_3218 world = server.method_3847(pr.worldKey);
            if (world == null) continue;

            var entity = world.method_14190(pr.targetId);
            if (!(entity instanceof class_1309 target) || !target.method_5805()) continue;

            // Target survived 10s → ignite the ring
            class_243 pos = target.method_19538();
            spawnRingOnce(world, pos);
            world.method_8396(null, target.method_24515(),
                    class_3417.field_14991, class_3419.field_15248, 1.2f, 0.4f);

            ACTIVE_RINGS.put(pr.targetId,
                    new ActiveRing(world, pr.targetId, pos, now + RING_DURATION_TICKS));
        }

        // ── Active rings: particles + burn ───────────────────────────────
        Iterator<Map.Entry<UUID, ActiveRing>> ait = ACTIVE_RINGS.entrySet().iterator();
        while (ait.hasNext()) {
            Map.Entry<UUID, ActiveRing> e = ait.next();
            ActiveRing ar = e.getValue();
            if (now > ar.expireAt) { ait.remove(); continue; }

            class_3218 world = server.method_3847(ar.worldKey);
            if (world == null) { ait.remove(); continue; }

            // Track target position
            var entity = world.method_14190(ar.targetId);
            if (entity instanceof class_1309 living && living.method_5805()) {
                ar.pos = living.method_19538();
            }

            // Emit ring every 4 ticks (≈12.5 fps)
            if (now % 4 == 0) {
                spawnRingOnce(world, ar.pos);
            }

            // Burn all nearby mobs every 20 ticks (1s)
            if (now % 20 == 0) {
                class_238 box = class_238.method_30048(ar.pos.method_1031(0, 1, 0),
                        (RING_RADIUS + 0.5) * 2, 4.0, (RING_RADIUS + 0.5) * 2);
                for (class_1309 nearby : world.method_8390(
                        class_1309.class, box, class_1309::method_5805)) {
                    if (nearby.method_19538().method_1020(ar.pos).method_37267() <= RING_RADIUS) {
                        nearby.method_5639(3);
                    }
                }
            }
        }

        // ── Periodic cleanup of stale charged-arrow entries (> 600 ticks old) ──
        if (server.method_3780() % 600 == 0) {
            CHARGED_ARROWS.entrySet().removeIf(e -> now - e.getValue() > 600L);
        }
    }

    // -----------------------------------------------------------------------
    private static void spawnSoulBurst(class_3218 world, class_243 pos, int count) {
        world.method_14199(class_2398.field_23114,
                pos.field_1352, pos.field_1351 + 1.0, pos.field_1350, count, 0.5, 0.6, 0.5, 0.04);
        world.method_14199(class_2398.field_22246,
                pos.field_1352, pos.field_1351 + 1.2, pos.field_1350, 18, 0.3, 0.4, 0.3, 0.02);
    }

    /** Emit one frame of the circular ring. */
    private static void spawnRingOnce(class_3218 world, class_243 center) {
        final int STEPS = 28;
        for (int i = 0; i < STEPS; i++) {
            double angle = (2.0 * Math.PI * i) / STEPS;
            double x = center.field_1352 + RING_RADIUS * Math.cos(angle);
            double z = center.field_1350 + RING_RADIUS * Math.sin(angle);
            world.method_14199(class_2398.field_23114,
                    x, center.field_1351 + 0.2, z, 1, 0.04, 0.12, 0.04, 0.0);
            world.method_14199(class_2398.field_22246,
                    x, center.field_1351 + 0.2, z, 1, 0.02, 0.06, 0.02, 0.0);
        }
    }
}
