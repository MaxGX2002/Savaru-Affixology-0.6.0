package com.savaru.savaru_affixes.inscription;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class MimicArrowHooks {
    private MimicArrowHooks() {}
    private static final Map<UUID, Integer> MODES = new ConcurrentHashMap<>();

    public static int prepareProjectile(class_3218 world, class_1665 proj) {
        return MODES.computeIfAbsent(proj.method_5667(), id -> world.field_9229.method_43048(7));
    }

    public static void onBowHit(class_3218 world, class_1665 proj, class_1309 target, class_1799 weapon, class_1309 owner) {
        int mode = prepareProjectile(world, proj);
        switch (mode) {
            case 1 -> target.method_6092(new class_1293(class_1294.field_5912, 8 * 20, 0, false, true, true)); // spectral
            case 2 -> target.method_6092(new class_1293(class_1294.field_5899, 5 * 20, 0, false, true, true));
            case 3 -> target.method_6092(new class_1293(class_1294.field_5909, 4 * 20, 1, false, true, true));
            case 4 -> target.method_6092(new class_1293(class_1294.field_5911, 5 * 20, 0, false, true, true));
            case 5 -> target.method_6092(new class_1293(class_1294.field_5921, 1, 0, false, true, true));
            case 6 -> {
                if (owner instanceof class_3222 sp) sp.method_6092(new class_1293(class_1294.field_5924, 2 * 20, 0, false, true, true));
            }
            default -> { }
        }
        MODES.remove(proj.method_5667());
    }
}
