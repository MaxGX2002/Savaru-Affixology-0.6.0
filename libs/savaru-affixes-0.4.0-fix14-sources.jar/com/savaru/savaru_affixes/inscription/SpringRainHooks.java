package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class SpringRainHooks {
    private SpringRainHooks() {}

    private static final long COOLDOWN_TICKS = 5L * 20L;
    private static final int START_DELAY = 10; // 0.5s
    private static final int WAVE_INTERVAL = 20; // 1s
    private static final int TOTAL_WAVES = 3;
    private static final double RADIUS = 3.0;
    private static final int ARROWS_PER_WAVE = 12;
    private static final double EXTRA_MAGIC_MULT = 1.5;
    private static final double RAIN_ARROW_MULT = 2.4;

    private static final Map<UUID, Long> PLAYER_CD = new ConcurrentHashMap<>();
    private static final Map<UUID, SpecialArrow> SPECIAL_ARROWS = new ConcurrentHashMap<>();
    private static final List<RainZone> ACTIVE_ZONES = new ArrayList<>();

    private static final class RainZone {
        final RegistryRef worldRef;
        final UUID ownerId;
        final class_243 center;
        final double arrowDamage;
        long nextWaveTick;
        int wavesLeft;

        RainZone(class_3218 world, UUID ownerId, class_243 center, double arrowDamage, long startTick) {
            this.worldRef = new RegistryRef(world);
            this.ownerId = ownerId;
            this.center = center;
            this.arrowDamage = arrowDamage;
            this.nextWaveTick = startTick + START_DELAY;
            this.wavesLeft = TOTAL_WAVES;
        }
    }

    private record RegistryRef(net.minecraft.class_5321<net.minecraft.class_1937> worldKey) {
        RegistryRef(class_3218 world) { this(world.method_27983()); }
    }

    private record SpecialArrow(double damage, UUID ownerId) {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(SpringRainHooks::tick);
    }

    public static boolean isManagedProjectile(class_1665 proj) {
        return proj != null && SPECIAL_ARROWS.containsKey(proj.method_5667());
    }

    public static boolean handleSpecialArrowHit(class_1665 proj, class_1309 target) {
        SpecialArrow arrow = SPECIAL_ARROWS.remove(proj.method_5667());
        if (arrow == null || target == null) return false;
        if (arrow.ownerId != null && arrow.ownerId.equals(target.method_5667())) return true;
        InscriptionRuntime.magicTrueDamage(target, arrow.damage);
        if (target.method_37908() instanceof class_3218 sw) {
            sw.method_14199(class_2398.field_11205, target.method_23317(), target.method_23323(0.5), target.method_23321(), 10, 0.25, 0.2, 0.25, 0.05);
        }
        return true;
    }

    public static void onBowHit(class_3218 world, class_1665 projectile, class_1309 target, class_1799 weapon, class_1309 owner) {
        if (world == null || projectile == null || target == null || owner == null) return;
        if (!(owner instanceof class_3222 player)) return;

        long now = world.method_8510();
        long next = PLAYER_CD.getOrDefault(player.method_5667(), 0L);
        if (now < next) return;
        PLAYER_CD.put(player.method_5667(), now + COOLDOWN_TICKS);

        double baseDamage = Math.max(1.0, projectile.method_7448());
        double extraMagic = baseDamage * EXTRA_MAGIC_MULT;
        InscriptionRuntime.magicTrueDamage(target, extraMagic);

        class_243 center = target.method_19538();
        ACTIVE_ZONES.add(new RainZone(world, player.method_5667(), center, baseDamage * RAIN_ARROW_MULT, now));
        spawnCircle(world, center, RADIUS, class_2398.field_11204, 24);
        world.method_14199(class_2398.field_11205, center.field_1352, center.field_1351 + 0.5, center.field_1350, 12, 0.4, 0.15, 0.4, 0.02);
    }

    private static void tick(MinecraftServer server) {
        long now = server.method_30002().method_8510();
        Iterator<RainZone> it = ACTIVE_ZONES.iterator();
        while (it.hasNext()) {
            RainZone zone = it.next();
            class_3218 world = server.method_3847(zone.worldRef.worldKey());
            if (world == null) {
                it.remove();
                continue;
            }
            if (now < zone.nextWaveTick) continue;

            spawnCircle(world, zone.center, RADIUS, class_2398.field_11204, 20);
            for (int i = 0; i < ARROWS_PER_WAVE; i++) {
                double angle = world.field_9229.method_43058() * Math.PI * 2.0;
                double dist = Math.sqrt(world.field_9229.method_43058()) * RADIUS;
                double x = zone.center.field_1352 + Math.cos(angle) * dist;
                double z = zone.center.field_1350 + Math.sin(angle) * dist;
                double y = zone.center.field_1351 + 8.0 + world.field_9229.method_43058() * 2.0;

                class_1667 arrow = new class_1667(class_1299.field_6122, world);
                arrow.method_23327(x, y, z);
                arrow.method_18800(0.0, -2.2, 0.0);
                var owner = server.method_3760().method_14602(zone.ownerId);
                if (owner != null) arrow.method_7432(owner);
                arrow.method_7438(0.0);
                arrow.method_7439(true);
                InscriptionArrowRuntime.register(arrow, owner, world, 5L * 20L);
                SPECIAL_ARROWS.put(arrow.method_5667(), new SpecialArrow(zone.arrowDamage, owner != null ? owner.method_5667() : null));
                world.method_8649(arrow);
            }

            zone.wavesLeft--;
            zone.nextWaveTick += WAVE_INTERVAL;
            if (zone.wavesLeft <= 0) it.remove();
        }

        // cleanup stale cooldowns lightly
        if (server.method_3780() % 1200 == 0) {
            PLAYER_CD.entrySet().removeIf(e -> now - e.getValue() > 20L * 60L);
            cleanupSpecialArrows(server);
        }
    }

    private static void cleanupSpecialArrows(MinecraftServer server) {
        Iterator<Map.Entry<UUID, SpecialArrow>> it = SPECIAL_ARROWS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, SpecialArrow> e = it.next();
            boolean exists = false;
            for (class_3218 world : server.method_3738()) {
                if (world.method_14190(e.getKey()) != null) {
                    exists = true;
                    break;
                }
            }
            if (!exists) it.remove();
        }
    }

    private static void spawnCircle(class_3218 world, class_243 center, double radius, net.minecraft.class_2394 particle, int count) {
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2.0 * i) / count;
            double x = center.field_1352 + Math.cos(angle) * radius;
            double z = center.field_1350 + Math.sin(angle) * radius;
            world.method_14199(particle, x, center.field_1351 + 0.05, z, 1, 0.02, 0.02, 0.02, 0.0);
        }
    }
}
