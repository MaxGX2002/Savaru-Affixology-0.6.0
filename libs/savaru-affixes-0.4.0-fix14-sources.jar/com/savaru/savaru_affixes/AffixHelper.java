package com.savaru.savaru_affixes;

import net.minecraft.class_1322;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1744;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_9274;
import net.minecraft.class_9279;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import java.util.*;

/**
 * Stores affix data in ItemStack CUSTOM_DATA (NBT).
 *
 * Structure:
 * custom_data: { savaru_affixes: { rarity: "MYTHIC", affixes: [ {id:"crit_chance", value:12.34}, ... ] } }
 */
public final class AffixHelper {
    private AffixHelper() {}

    public static final String ROOT_KEY = "savaru_affixes";
    public static final String KEY_RARITY = "rarity";
    static final String KEY_PENDING_ROLL = "savaru_pending_roll";
    static final String KEY_PENDING_RARITY = "savaru_pending_rarity";

    public static final String KEY_AFFIXES = "affixes";
    public static final String KEY_ID = "id";
    public static final String KEY_VALUE = "value";

    // Extra params for some affixes
    public static final String KEY_LEVEL = "level"; // wither/weakness

    // Mythic-only weapon affixes (per your spec)
    private static final Set<String> MYTHIC_ONLY_WEAPON = Set.of(
            "bonus_damage",
            "lifesteal",
            "true_damage"
    );

    // Mutual exclusion groups
    private static final Set<String> ARMOR_PEN = Set.of("armor_pen_flat", "armor_pen_pct");

    // Resistance penetration (flat or %) - mutually exclusive with armor pen and true damage.
    private static final Set<String> RES_PEN = Set.of("res_pen_flat", "res_pen_pct");
    // Health-scaling damage and execute groups
    private static final Set<String> HEALTH_DAMAGE = Set.of("max_hp_pct", "cur_hp_pct", "execute_flat", "execute_pct");

    // lifesteal / wither / weakness / frailty are mutually exclusive
    private static final Set<String> DOT_OR_DEBUFF = Set.of("wither", "weakness", "frailty", "lifesteal");
    // healing group (mutually exclusive)
    private static final Set<String> HEALING = Set.of("lifesteal", "overheal");
    // durability group (mutually exclusive)
    private static final Set<String> DURABILITY = Set.of("durability_bonus", "durability_nocost");

    // burn group (mutually exclusive with poison aoe and wither)
    private static final Set<String> BURN_GROUP = Set.of("burn", "poison_aoe", "wither");

    // devour group (mutually exclusive with lifesteal)
    private static final Set<String> DEVOUR_GROUP = Set.of("devour", "lifesteal");

    // blade mode exclusivity
    private static final Set<String> BLADE_MODE = Set.of("arcblade", "berserk");

    // --- Weapon pool routing ---
    // Ranged-only affixes: bows/crossbows can roll these.
    // Everything else that is weaponOnly is treated as melee-only, except SHARED_WEAPON.
    private static final Set<String> RANGED_ONLY = Set.of(
            "magic_arrow",
            "luminous_arrow",
            "piercing_path",
            "draw_speed",
            "lifeshot",
            "hunter_mark",
            "finisher_shot",
            "ricochet",
            "pin_arrow",
            "reserve"
    );

    // Arrow-only affixes: applied ONLY to arrow items (normal/tipped/spectral). Separate from bow/crossbow affixes.
    private static final Set<String> ARROW_ONLY = Set.of(
            "arrow_damage_boost",
            "arrow_effect_level_boost",
            "arrow_effect_duration_boost"
    );

    // Shared across melee & ranged (per spec). These may not exist yet; keeping them here stabilizes future behavior.
    private static final Set<String> SHARED_WEAPON = Set.of(
            "crit_damage",
            "crit_chance"
    );

    // greedlife vs berserk
    private static final Set<String> GREEDLIFE_GROUP = Set.of("greedlife", "berserk");

    // ── Armor-only affix IDs (never appear on weapons/arrows) ──────────────
    private static final Set<String> ARMOR_ONLY = Set.of(
            "armor_protection_flat", "armor_protection_pct",
            "armor_toughness_flat",  "armor_toughness_pct",
            "armor_hardened",
            "armor_bulletproof",
            "armor_fire_resist",
            "armor_adapt_dmg", "armor_adapt_dur", "armor_adapt_lvl",
            "armor_heavy",
            "armor_warrior",
            "armor_berserker_crit_chance", "armor_berserker_crit_dmg",
            "armor_cs_crit_chance_pct", "armor_cs_crit_chance_flat", "armor_cs_crit_dmg",
            "armor_saint_flat", "armor_saint_pct",
            "armor_grace",
            "armor_regen_flat", "armor_regen_pct",
            "armor_limiter_flat", "armor_limiter_pct",
            "armor_chest_thorns", "armor_chest_flame_steel",
            "armor_chest_charged_burst", "armor_chest_shield"
    );
    // 適性 sub-types are mutually exclusive with each other AND with toughness affixes
    private static final Set<String> ADAPT_GROUP = Set.of(
            "armor_adapt_dmg", "armor_adapt_dur", "armor_adapt_lvl"
    );
    private static final Set<String> TOUGHNESS_GROUP = Set.of(
            "armor_toughness_flat", "armor_toughness_pct"
    );
    // 狂徒(弱點) sub-types are mutually exclusive
    private static final Set<String> BERSERKER_GROUP = Set.of(
            "armor_berserker_crit_chance", "armor_berserker_crit_dmg"
    );
    // CS爆擊率 sub-types are mutually exclusive (pct vs flat)
    private static final Set<String> CS_CRIT_CHANCE_GROUP = Set.of(
            "armor_cs_crit_chance_pct", "armor_cs_crit_chance_flat"
    );
    // 聖徒 sub-types are mutually exclusive
    private static final Set<String> SAINT_GROUP = Set.of(
            "armor_saint_flat", "armor_saint_pct"
    );
    // 自然回血 sub-types are mutually exclusive
    private static final Set<String> REGEN_GROUP = Set.of(
            "armor_regen_flat", "armor_regen_pct"
    );
    // 限制器 sub-types are mutually exclusive
    private static final Set<String> LIMITER_GROUP = Set.of(
            "armor_limiter_flat", "armor_limiter_pct"
    );
    // 胸甲專用 affixes are mutually exclusive (only one per chestplate)
    private static final Set<String> CHEST_EXCLUSIVE = Set.of(
            "armor_chest_thorns", "armor_chest_flame_steel",
            "armor_chest_charged_burst", "armor_chest_shield"
    );

    public static Rarity getRarity(class_1799 stack) {
        class_2487 root = getRoot(stack);
        if (root == null || !root.method_10545(KEY_RARITY)) return null;
        try { return Rarity.valueOf(root.method_10558(KEY_RARITY)); }
        catch (Exception ignored) { return null; }
    }

    public static class_2499 getAffixes(class_1799 stack) {
        class_2487 root = getRoot(stack);
        if (root == null || !root.method_10545(KEY_AFFIXES)) return new class_2499();
        return root.method_10554(KEY_AFFIXES, 10);
    }

    public static double getAffixValue(class_1799 stack, String id) {
        class_2499 list = getAffixes(stack);
        for (int i = 0; i < list.size(); i++) {
            class_2487 c = list.method_10602(i);
            if (id.equals(c.method_10558(KEY_ID))) return c.method_10574(KEY_VALUE);
        }
        return 0.0;
    }

    public static int getAffixLevel(class_1799 stack, String id) {
        class_2499 list = getAffixes(stack);
        for (int i = 0; i < list.size(); i++) {
            class_2487 c = list.method_10602(i);
            if (id.equals(c.method_10558(KEY_ID))) return c.method_10550(KEY_LEVEL);
        }
        return 0;
    }

    public static int getAffixInt(class_1799 stack, String id, String key, int def) {
        class_2499 list = getAffixes(stack);
        for (int i = 0; i < list.size(); i++) {
            class_2487 c = list.method_10602(i);
            if (id.equals(c.method_10558(KEY_ID))) {
                return c.method_10545(key) ? c.method_10550(key) : def;
            }
        }
        return def;
    }

    public static void setAffixInt(class_1799 stack, String id, String key, int value) {
        class_2499 list = getAffixes(stack);
        for (int i = 0; i < list.size(); i++) {
            class_2487 c = list.method_10602(i);
            if (id.equals(c.method_10558(KEY_ID))) {
                c.method_10569(key, value);
                break;
            }
        }
        // Write back into our CUSTOM_DATA root (1.21+ uses components, not ItemStack#getOrCreateNbt)
        class_2487 root = getRoot(stack);
        if (root == null) root = new class_2487();
        root.method_10566(KEY_AFFIXES, list);
        setRoot(stack, root);
    }

    

    /** Clears all affixes on the item (keeps rarity and other Savaru data). */
    public static void clearAffixes(class_1799 stack) {
        if (stack == null) return;
        class_2487 root = getRoot(stack);
        if (root == null) root = new class_2487();
        root.method_10566(KEY_AFFIXES, new class_2499());
        setRoot(stack, root);
    }

    /** Adds or replaces a single affix entry (id/value/level) on the item. */
    public static void putOrReplaceAffix(class_1799 stack, String id, double value, int level) {
        if (stack == null || id == null) return;
        class_2499 list = getAffixes(stack);
        boolean found = false;
        for (int i = 0; i < list.size(); i++) {
            class_2487 c = list.method_10602(i);
            if (id.equals(c.method_10558(KEY_ID))) {
                c.method_10549(KEY_VALUE, value);
                c.method_10569(KEY_LEVEL, level);
                found = true;
                break;
            }
        }
        if (!found) {
            class_2487 entry = new class_2487();
            entry.method_10582(KEY_ID, id);
            entry.method_10549(KEY_VALUE, value);
            entry.method_10569(KEY_LEVEL, level);
            list.add(entry);
        }
        class_2487 root = getRoot(stack);
        if (root == null) root = new class_2487();
        root.method_10566(KEY_AFFIXES, list);
        setRoot(stack, root);
    }
public static void rollAffixes(class_1799 stack, Rarity rarity) {
        if (stack == null || rarity == null) return;

        final boolean weapon = isWeaponItem(stack);
        final boolean rangedWeapon = isRangedWeaponItem(stack);
        final boolean arrow = isArrowItem(stack);
        final boolean armor = !weapon && !arrow && isArmorItem(stack);

        // candidate pool
        List<Affix> pool = new ArrayList<>(AffixRegistry.getAll());

        // Arrow pool is fully separate.
        if (arrow) {
            pool.removeIf(a -> !ARROW_ONLY.contains(a.id()));
        }

        // Split pools: weapon-only affixes never appear on armor/trinkets/etc.
        if (!weapon && !arrow) {
            pool.removeIf(Affix::weaponOnly);
            if (armor) {
                // Armor: ONLY armor-only affixes allowed
                pool.removeIf(a -> !ARMOR_ONLY.contains(a.id()));
                // Chest-exclusive affixes only on chestplates
                boolean isChestplate = (stack.method_7909() instanceof class_1738 ai)
                        && ai.method_48398() == net.minecraft.class_1738.class_8051.field_41935;
                if (!isChestplate) {
                    pool.removeIf(a -> CHEST_EXCLUSIVE.contains(a.id()));
                }
            } else {
                // Other (trinkets etc.): no armor-only either
                pool.removeIf(a -> ARMOR_ONLY.contains(a.id()));
            }
        } else if (weapon) {
            // Weapons never get armor-only affixes
            pool.removeIf(a -> ARMOR_ONLY.contains(a.id()));
            // weapon pool: additionally enforce mythic-only weapon affixes.
            // Allow them for MYTHIC+ tiers.
            boolean allowMythicOnly = (rarity == Rarity.MYTHIC || rarity == Rarity.BEYOND || rarity == Rarity.UNRIVALED);
            if (!allowMythicOnly) pool.removeIf(a -> MYTHIC_ONLY_WEAPON.contains(a.id()));

            // Weapon pool routing: bows/crossbows only roll ranged-only (plus shared).
            // Melee weapons never roll ranged-only.
            if (rangedWeapon) {
                pool.removeIf(a -> a.weaponOnly() && !RANGED_ONLY.contains(a.id()) && !SHARED_WEAPON.contains(a.id()));
            } else {
                pool.removeIf(a -> RANGED_ONLY.contains(a.id()) && !SHARED_WEAPON.contains(a.id()));
            }
        }

        Random rnd = new Random();

        // how many affixes (range per rarity)
        int count;
        if (arrow) {
            // Arrow affixes: fewer slots, and rarity is capped (COMMON/UNCOMMON/RARE).
            count = switch (rarity) {
                case COMMON -> 1;
                case UNCOMMON -> 1 + rnd.nextInt(2); // 1-2
                case RARE -> 2;
                default -> 2;
            };
        } else {
            count = rollAffixCount(rarity, rnd);
        }
        Set<String> used = new HashSet<>();
        class_2499 out = new class_2499();

        int guard = 0;
        while (out.size() < count && !pool.isEmpty() && guard++ < 512) {
            Affix pick = weightedPick(pool, rnd);
            // remove the picked instance so we don't pick it again
            pool.remove(pick);

            // prevent duplicates (only commit to used after the pick is accepted)
            if (used.contains(pick.id())) continue;

            // mutual exclusions
            // armor pen vs true damage
            if ("true_damage".equals(pick.id()) && used.stream().anyMatch(ARMOR_PEN::contains)) {
                continue;
            }
            if (ARMOR_PEN.contains(pick.id()) && used.contains("true_damage")) {
                continue;
            }
            // resistance pen vs armor pen vs true damage
            if (RES_PEN.contains(pick.id())) {
                if (used.contains("true_damage") || used.stream().anyMatch(RES_PEN::contains)) {
                    continue;
                }
                // For ranged weapons, allow RES_PEN alongside ARMOR_PEN.
                if (!rangedWeapon && used.stream().anyMatch(ARMOR_PEN::contains)) {
                    continue;
                }
            }
            if (ARMOR_PEN.contains(pick.id()) && used.stream().anyMatch(RES_PEN::contains)) {
                // For ranged weapons, allow ARMOR_PEN alongside RES_PEN.
                if (!rangedWeapon) {
                    continue;
                }
            }
            if ("true_damage".equals(pick.id()) && used.stream().anyMatch(RES_PEN::contains)) {
                continue;
            }

            // health-scaling damage mutual exclusions
            if (HEALTH_DAMAGE.contains(pick.id())) {
                boolean conflict = false;
                for (String g : HEALTH_DAMAGE) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }
            // max/current hp damage can't coexist with bonus_damage
            if (("max_hp_pct".equals(pick.id()) || "cur_hp_pct".equals(pick.id())) && used.contains("bonus_damage")) {
                continue;
            }
            if ("bonus_damage".equals(pick.id()) && (used.contains("max_hp_pct") || used.contains("cur_hp_pct"))) {
                continue;
            }

            // lifesteal vs wither/weakness/frailty (and within-group exclusivity)
            if (DOT_OR_DEBUFF.contains(pick.id())) {
                boolean conflict = false;
                for (String g : DOT_OR_DEBUFF) {
                    if (!g.equals(pick.id()) && used.contains(g)) {
                        conflict = true;
                        break;
                    }
                }
                if (conflict) continue;
            }

            // lifesteal vs overheal
            if (HEALING.contains(pick.id())) {
                boolean conflict = false;
                for (String g : HEALING) {
                    if (!g.equals(pick.id()) && used.contains(g)) {
                        conflict = true;
                        break;
                    }
                }
                if (conflict) continue;
            }

            // durability exclusivity
            if (DURABILITY.contains(pick.id())) {
                boolean conflict = false;
                for (String g : DURABILITY) {
                    if (!g.equals(pick.id()) && used.contains(g)) {
                        conflict = true;
                        break;
                    }
                }
                if (conflict) continue;
            }

            
            // burn mutual exclusions (burn vs poison_aoe vs wither)
            if (BURN_GROUP.contains(pick.id())) {
                boolean conflict = false;
                for (String g : BURN_GROUP) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }

            // devour vs lifesteal
            if (DEVOUR_GROUP.contains(pick.id())) {
                boolean conflict = false;
                for (String g : DEVOUR_GROUP) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }

            // arcblade vs berserk (blade modes)
            if (BLADE_MODE.contains(pick.id())) {
                boolean conflict = false;
                for (String g : BLADE_MODE) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }


            // greedlife vs berserk
            if (GREEDLIFE_GROUP.contains(pick.id())) {
                boolean conflict = false;
                for (String g : GREEDLIFE_GROUP) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }

            // ── Armor affix mutual exclusions ─────────────────────────────
            // 適性 sub-types mutually exclusive with each other
            if (ADAPT_GROUP.contains(pick.id())) {
                boolean conflict = false;
                for (String g : ADAPT_GROUP) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
                // 適性 also mutually exclusive with toughness affixes
                if (used.stream().anyMatch(TOUGHNESS_GROUP::contains)) continue;
            }
            // toughness mutually exclusive with 適性
            if (TOUGHNESS_GROUP.contains(pick.id())) {
                if (used.stream().anyMatch(ADAPT_GROUP::contains)) continue;
            }

            // 狂徒(弱點) sub-types mutually exclusive
            if (BERSERKER_GROUP.contains(pick.id())) {
                boolean conflict = false;
                for (String g : BERSERKER_GROUP) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }

            // CS爆擊率 sub-types mutually exclusive (pct vs flat)
            if (CS_CRIT_CHANCE_GROUP.contains(pick.id())) {
                boolean conflict = false;
                for (String g : CS_CRIT_CHANCE_GROUP) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }

            // 聖徒 sub-types mutually exclusive
            if (SAINT_GROUP.contains(pick.id())) {
                boolean conflict = false;
                for (String g : SAINT_GROUP) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }

            // 自然回血 sub-types mutually exclusive
            if (REGEN_GROUP.contains(pick.id())) {
                boolean conflict = false;
                for (String g : REGEN_GROUP) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }

            // 限制器 sub-types mutually exclusive
            if (LIMITER_GROUP.contains(pick.id())) {
                boolean conflict = false;
                for (String g : LIMITER_GROUP) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }

            // 胸甲專用 affixes mutually exclusive
            if (CHEST_EXCLUSIVE.contains(pick.id())) {
                boolean conflict = false;
                for (String g : CHEST_EXCLUSIVE) {
                    if (!g.equals(pick.id()) && used.contains(g)) { conflict = true; break; }
                }
                if (conflict) continue;
            }

// Passed all checks: commit
            used.add(pick.id());

            double value = rollValueByRarity(pick, rarity, rnd);

            class_2487 entry = new class_2487();
            entry.method_10582(KEY_ID, pick.id());
            entry.method_10549(KEY_VALUE, value);

            // extra params
            if ("wither".equals(pick.id()) || "weakness".equals(pick.id()) || "frailty".equals(pick.id())) {
                // store effect level 1-2
                int level = 1 + rnd.nextInt(2);
                entry.method_10569(KEY_LEVEL, level);
            }
            // burn: store extra magic damage 1-5 in level
            if ("burn".equals(pick.id())) {
                int dmg = 1 + rnd.nextInt(5);
                entry.method_10569(KEY_LEVEL, dmg);
            }

            // devour: store hunger restore 1-5 in level
            if ("devour".equals(pick.id())) {
                int food = 1 + rnd.nextInt(5);
                entry.method_10569(KEY_LEVEL, food);
            }



            if ("res_pen_flat".equals(pick.id()) || "res_pen_pct".equals(pick.id())) {
                // store penetration level 1-3 for tooltip tiering
                int level = 1 + rnd.nextInt(3);
                entry.method_10569(KEY_LEVEL, level);
            }

            // durability bonus adds a virtual buffer (effective max durability)
            if ("durability_bonus".equals(pick.id())) {
                int extra = Math.max(1, (int) Math.round(stack.method_7936() * (value / 100.0)));
                entry.method_10569("buf", extra);
            }

            // ── 防火: snap value to 50 / 75 / 100 ──────────────────────────
            if ("armor_fire_resist".equals(pick.id())) {
                double snapped;
                if (value >= 87.5)       snapped = 100.0;
                else if (value >= 62.5)  snapped = 75.0;
                else                     snapped = 50.0;
                entry.method_10549(KEY_VALUE, snapped);
            }

            // ── 防火100%: snap adapt dmg/dur to 50 or 100 ─────────────────
            if ("armor_adapt_dmg".equals(pick.id()) || "armor_adapt_dur".equals(pick.id())) {
                double snapped = (value >= 75.0) ? 100.0 : 50.0;
                entry.method_10549(KEY_VALUE, snapped);
            }

            // ── 適性: roll and store the target effect ─────────────────────
            if ("armor_adapt_dmg".equals(pick.id())
                    || "armor_adapt_dur".equals(pick.id())
                    || "armor_adapt_lvl".equals(pick.id())) {
                int idx = rnd.nextInt(com.savaru.savaru_affixes.armor.ArmorAffixProcessor.ADAPT_EFFECTS.length);
                var effectEntry = com.savaru.savaru_affixes.armor.ArmorAffixProcessor.ADAPT_EFFECTS[idx];
                var keyOpt = effectEntry.method_40230();
                String effectId = keyOpt.map(k -> k.method_29177().toString()).orElse("minecraft:poison");
                entry.method_10582(com.savaru.savaru_affixes.armor.ArmorAffixProcessor.KEY_ADAPT_EFFECT, effectId);
            }
            out.add(entry);
        }

        class_2487 root = new class_2487();
        root.method_10582(KEY_RARITY, rarity.name());
        root.method_10566(KEY_AFFIXES, out);
        setRoot(stack, root);

        applyRarityNameColor(stack, rarity);
    }

    private static int rollAffixCount(Rarity rarity, Random rnd) {
        int min, max;
        switch (rarity) {
            case COMMON -> { min = 0; max = 1; }
            case UNCOMMON -> { min = 1; max = 2; }
            case RARE -> { min = 1; max = 2; }
            case EPIC -> { min = 2; max = 3; }
            case LEGENDARY -> { min = 3; max = 4; }
            case MYTHIC -> { min = 4; max = 5; }
            case BEYOND -> { min = 6; max = 7; }
            case UNRIVALED -> { min = 6; max = 7; }
            default -> { min = 1; max = 1; }
        }
        if (max < min) max = min;
        return min + rnd.nextInt(max - min + 1);
    }

    private static Affix weightedPick(List<Affix> pool, Random rnd) {
        int total = 0;
        for (Affix a : pool) total += Math.max(1, a.weight());
        int roll = rnd.nextInt(Math.max(1, total));
        int acc = 0;
        for (Affix a : pool) {
            acc += Math.max(1, a.weight());
            if (roll < acc) return a;
        }
        return pool.get(pool.size() - 1);
    }

    /**
     * Rolls within the affix's MYTHIC band (affix.min..affix.max), then scales down for lower rarities.
     * This keeps your mythic ranges exact while preserving progression.
     */
    private static double rollValueByRarity(Affix affix, Rarity rarity, Random rnd) {
        double base = affix.min() + (affix.max() - affix.min()) * rnd.nextDouble();

        // Keep some affixes fixed across rarities
        if ("max_hp_pct".equals(affix.id()) || "poison_aoe".equals(affix.id())) return base;

        // Percent and non-percent both scale the same way (it's a design choice; tweak if you want different curves).
        double mult;
        switch (rarity) {
            case COMMON -> mult = 0.35;
            case UNCOMMON -> mult = 0.55;
            case RARE -> mult = 0.75;
            case EPIC -> mult = 0.90;
            case LEGENDARY -> mult = 1.00;
            case MYTHIC -> mult = 1.00;
            case BEYOND -> mult = 1.00;
            case UNRIVALED -> mult = 1.00;
            default -> mult = 1.00;
        }

        double v = base * mult;

        // For mythic-only affixes, keep unscaled (already filtered out for lower rarities, but safe).
        if ((rarity == Rarity.MYTHIC || rarity == Rarity.BEYOND || rarity == Rarity.UNRIVALED)
                && MYTHIC_ONLY_WEAPON.contains(affix.id())) return base;

        return v;
    }

    /**
     * Applies rarity styling to the stack name, unless:
     * - stack is already custom-named, or
     * - the base name already has an explicit color.
     */
    public static void applyRarityNameColor(class_1799 stack, Rarity rarity) {
        if (stack == null || rarity == null) return;

        // IMPORTANT: rarity attack bonus must always apply, even if we skip renaming
        // (e.g. modded weapons that already have a custom/colored name).
        applyRarityAttackModifier(stack, rarity);
        // Wenwu attack bonus line (if present)
        try { applyWenwuAttackModifier(stack); } catch (Exception ignored) {}

        // Do not override already-custom or already-colored names.
        if (stack.method_57826(class_9334.field_49631)) return;

        class_2561 baseName = stack.method_7964();
        if (baseName.method_10866() != null && baseName.method_10866().method_10973() != null) return;

        String prefix = switch (rarity) {
            case COMMON -> "普通";
            case UNCOMMON -> "罕見";
            case RARE -> "稀有";
            case EPIC -> "史詩";
            case LEGENDARY -> "傳說";
            case MYTHIC -> "神話";
            case BEYOND -> "超乎想像";
            case UNRIVALED -> "無與倫比";
        };

        // Name format: （品質的） <原本名稱>
        String full = prefix + "的 " + baseName.getString();

        if (rarity == Rarity.UNRIVALED) {
            // Keep name text stable; client will render animated rainbow based on rarity tag.
            stack.method_57379(class_9334.field_49631, class_2561.method_43470(full).method_10862(rarity.style()));
        } else {
            class_5250 colored = class_2561.method_43470(full).method_10862(rarity.style());
            stack.method_57379(class_9334.field_49631, colored);
        }

        // (attack bonus already applied above)
    }

    // ── Modifier ID helpers ──────────────────────────────────────────────
    private static final String SA = SavaruAffixesMod.MOD_ID;
    static final class_2960 ATTACK_BONUS_ID = class_2960.method_60655(SA, "rarity_attack_bonus");

    private static boolean isOurModifier(class_2960 id) {
        return id.method_12836().equals(SA);
    }

    private static class_9274 getArmorSlotFor(class_1799 stack) {
        if (stack.method_7909() instanceof class_1738 ai) {
            return switch (ai.method_48398()) {
                case field_41934     -> class_9274.field_49223;
                case field_41935 -> class_9274.field_49222;
                case field_41936   -> class_9274.field_49221;
                case field_41937      -> class_9274.field_49220;
                default         -> class_9274.field_49224;
            };
        }
        return class_9274.field_49224;
    }

    /** Slot suffix for unique modifier IDs per equipment slot. */
    private static String slotSuffix(class_9274 slot) {
        return switch (slot) {
            case field_49223  -> "_head";
            case field_49222 -> "_chest";
            case field_49221  -> "_legs";
            case field_49220  -> "_feet";
            default    -> "_armor";
        };
    }

    /** Create a slot-specific modifier Identifier. */
    private static class_2960 slotId(String base, class_9274 slot) {
        return class_2960.method_60655(SA, base + slotSuffix(slot));
    }

    /**
     * Add armor affix values as item-level attribute modifiers.
     * Each modifier uses a SLOT-SPECIFIC ID so multiple armor pieces stack.
     */
    private static void addArmorAffixModifiers(class_1799 stack, class_9285.class_9286 b,
                                                class_9274 slot) {
        // Protection (flat + pct)
        double protFlat = getAffixValue(stack, "armor_protection_flat");
        if (protFlat > 0) {
            b.method_57487(class_5134.field_23724,
                    new class_1322(slotId("affix_prot_flat", slot), protFlat,
                            class_1322.class_1323.field_6328), slot);
        }
        double protPct = getAffixValue(stack, "armor_protection_pct");
        if (protPct > 0) {
            b.method_57487(class_5134.field_23724,
                    new class_1322(slotId("affix_prot_pct", slot), protPct / 100.0,
                            class_1322.class_1323.field_6330), slot);
        }

        // Toughness (flat + pct)
        double toughFlat = getAffixValue(stack, "armor_toughness_flat");
        if (toughFlat > 0) {
            b.method_57487(class_5134.field_23725,
                    new class_1322(slotId("affix_tough_flat", slot), toughFlat,
                            class_1322.class_1323.field_6328), slot);
        }
        double toughPct = getAffixValue(stack, "armor_toughness_pct");
        if (toughPct > 0) {
            b.method_57487(class_5134.field_23725,
                    new class_1322(slotId("affix_tough_pct", slot), toughPct / 100.0,
                            class_1322.class_1323.field_6330), slot);
        }

        // Heavy (knockback resistance)
        double heavyPct = getAffixValue(stack, "armor_heavy");
        if (heavyPct > 0) {
            b.method_57487(class_5134.field_23718,
                    new class_1322(slotId("affix_heavy", slot), heavyPct / 100.0,
                            class_1322.class_1323.field_6328), slot);
        }

        // Warrior (attack damage %)
        double warriorPct = getAffixValue(stack, "armor_warrior");
        if (warriorPct > 0) {
            b.method_57487(class_5134.field_23721,
                    new class_1322(slotId("affix_warrior", slot), warriorPct / 100.0,
                            class_1322.class_1323.field_6331), slot);
        }

        // Berserker crit chance (same attribute as weapon 弱點命中率)
        double berserkCC = getAffixValue(stack, "armor_berserker_crit_chance");
        if (berserkCC > 0 && SavaruAttributes.CRIT_CHANCE_ENTRY != null) {
            b.method_57487(SavaruAttributes.CRIT_CHANCE_ENTRY,
                    new class_1322(slotId("affix_berserk_cc", slot), berserkCC / 100.0,
                            class_1322.class_1323.field_6328), slot);
        }

        // Berserker crit damage (same attribute as weapon 弱點傷害)
        double berserkCD = getAffixValue(stack, "armor_berserker_crit_dmg");
        if (berserkCD > 0 && SavaruAttributes.CRIT_DAMAGE_ENTRY != null) {
            b.method_57487(SavaruAttributes.CRIT_DAMAGE_ENTRY,
                    new class_1322(slotId("affix_berserk_cd", slot), berserkCD / 100.0,
                            class_1322.class_1323.field_6328), slot);
        }

        // CS Crit Chance % (Critical Strike mod, soft-depend)
        // NBT stores 750-3000; modifier value = NBT / 100.0 = 7.5-30.0
        double csCCpct = getAffixValue(stack, "armor_cs_crit_chance_pct");
        if (csCCpct > 0) {
            try {
                var opt = net.minecraft.class_7923.field_41190.method_55841(
                        class_2960.method_60655("critical_strike", "chance"));
                if (opt.isPresent()) {
                    b.method_57487(opt.get(),
                            new class_1322(slotId("affix_cs_cc_pct", slot), csCCpct / 100.0,
                                    class_1322.class_1323.field_6328), slot);
                }
            } catch (Exception ignored) {}
        }

        // CS Crit Chance flat (Critical Strike mod, soft-depend)
        // NBT stores 10-25; modifier value = raw
        double csCCflat = getAffixValue(stack, "armor_cs_crit_chance_flat");
        if (csCCflat > 0) {
            try {
                var opt = net.minecraft.class_7923.field_41190.method_55841(
                        class_2960.method_60655("critical_strike", "chance"));
                if (opt.isPresent()) {
                    b.method_57487(opt.get(),
                            new class_1322(slotId("affix_cs_cc_flat", slot), csCCflat,
                                    class_1322.class_1323.field_6328), slot);
                }
            } catch (Exception ignored) {}
        }

        // CS Crit Damage (Critical Strike mod, soft-depend)
        // NBT stores 500-5000; modifier value = NBT / 100.0 = 5.0-50.0
        double csCD = getAffixValue(stack, "armor_cs_crit_dmg");
        if (csCD > 0) {
            try {
                var opt = net.minecraft.class_7923.field_41190.method_55841(
                        class_2960.method_60655("critical_strike", "damage"));
                if (opt.isPresent()) {
                    b.method_57487(opt.get(),
                            new class_1322(slotId("affix_cs_cd", slot), csCD / 100.0,
                                    class_1322.class_1323.field_6328), slot);
                }
            } catch (Exception ignored) {}
        }

        // Saint flat (max health)
        double saintFlat = getAffixValue(stack, "armor_saint_flat");
        if (saintFlat > 0) {
            b.method_57487(class_5134.field_23716,
                    new class_1322(slotId("affix_saint_flat", slot), saintFlat,
                            class_1322.class_1323.field_6328), slot);
        }

        // Saint pct (max health %)
        double saintPct = getAffixValue(stack, "armor_saint_pct");
        if (saintPct > 0) {
            b.method_57487(class_5134.field_23716,
                    new class_1322(slotId("affix_saint_pct", slot), saintPct / 100.0,
                            class_1322.class_1323.field_6330), slot);
        }
    }

    /**
     * Rebuilds the item's ATTRIBUTE_MODIFIERS component with:
     *  1. Vanilla base values (GUARANTEED from fresh item stack — never lost)
     *  2. Other-mod entries from current stack
     *  3. Our rarity bonus + armor affix modifiers (slot-specific IDs)
     */
    private static void applyRarityAttackModifier(class_1799 stack, Rarity rarity) {
        if (stack == null || rarity == null) return;

        final boolean isArmor  = isArmorItem(stack);
        final boolean isRanged = isRangedWeaponItem(stack);

        // ── GUARANTEED vanilla defaults from a fresh stack ────────────────
        // This is the definitive fix: `new ItemStack(item)` always creates a stack
        // with the item's default components, including ArmorItem's built-in
        // +armor, +toughness, +knockback_resistance modifiers.
        // Even if our stack's component was corrupted by an older mod version,
        // the fresh stack will always have the correct vanilla values.
        class_9285 vanillaDefaults =
                new class_1799(stack.method_7909()).method_57824(class_9334.field_49636);
        class_9285 stackCurrent = stack.method_57824(class_9334.field_49636);

        class_9285.class_9286 b = class_9285.method_57480();
        Set<class_2960> addedIds = new HashSet<>();

        // STEP 1: ALWAYS add vanilla defaults first (guaranteed base values)
        if (vanillaDefaults != null) {
            for (class_9285.class_9287 e : vanillaDefaults.comp_2393()) {
                b.method_57487(e.comp_2395(), e.comp_2396(), e.comp_2397());
                addedIds.add(e.comp_2396().comp_2447());
            }
        }

        // STEP 2: Add other-mod entries from current stack (not vanilla, not ours)
        if (stackCurrent != null) {
            for (class_9285.class_9287 e : stackCurrent.comp_2393()) {
                class_2960 eid = e.comp_2396().comp_2447();
                if (addedIds.contains(eid)) continue;              // already from vanilla
                if (isOurModifier(eid)) continue;                   // strip old savaru entries
                b.method_57487(e.comp_2395(), e.comp_2396(), e.comp_2397());
                addedIds.add(eid);
            }
        }

        // STEP 3: Add our modifiers
        boolean hide = false;
        try { hide = UnidentifiedHandler.isUnidentified(stack) || isPendingRoll(stack); }
        catch (Exception ignored) {}

        if (!hide) {
            if (isArmor) {
                class_9274 slot = getArmorSlotFor(stack);

                // Rarity armor bonus — slot-specific ID so all 4 pieces stack
                double armorBonus = rarity.armorBonus();
                if (armorBonus != 0.0) {
                    b.method_57487(class_5134.field_23724,
                            new class_1322(slotId("rarity_armor", slot), armorBonus,
                                    class_1322.class_1323.field_6328),
                            slot);
                }

                // All armor affix attribute modifiers — slot-specific IDs
                addArmorAffixModifiers(stack, b, slot);

            } else if (isRanged) {
                // Ranged: rarity bonus applied at runtime in RangedAffixProcessor.
                // Tooltip patching in TooltipHooks.
            } else {
                // Melee: GENERIC_ATTACK_DAMAGE
                double bonus = rarity.attackBonus();
                if (bonus != 0.0) {
                    b.method_57487(class_5134.field_23721,
                            new class_1322(ATTACK_BONUS_ID, bonus,
                                    class_1322.class_1323.field_6328),
                            class_9274.field_49217);
                }
            }
        }

        stack.method_57379(class_9334.field_49636, b.method_57486());
    }

    /**
     * Wenwu: adds a flat +0.2 attack damage per TOTAL enchantment levels on the weapon.
     * This is applied as a vanilla attribute modifier line on the item (MAINHAND) so it shows on the panel/tooltip.
     * Hidden while Unidentified / pending roll.
     */
    public static void applyWenwuAttackModifier(class_1799 stack) {
        if (stack == null) return;

        // only if the item has our affix and rarity data (i.e. is part of the system)
        if (getRarity(stack) == null) return;
        if (getAffixValue(stack, "wenwu") <= 0.0) return;

        final class_2960 id = class_2960.method_60655(SavaruAffixesMod.MOD_ID, "wenwu_attack_bonus");

        class_9285 existing = stack.method_57824(class_9334.field_49636);
        class_9285.class_9286 b = class_9285.method_57480();

        if (existing != null) {
            for (class_9285.class_9287 e : existing.comp_2393()) {
                // remove our old modifier, keep everything else
                if (e.comp_2396().comp_2447().equals(id)) continue;
                b.method_57487(e.comp_2395(), e.comp_2396(), e.comp_2397());
            }
        }

        boolean hide = false;
        try { hide = com.savaru.savaru_affixes.UnidentifiedHandler.isUnidentified(stack) || isPendingRoll(stack); } catch (Exception ignored) {}

        double bonus = 0.0;
        if (!hide) {
            try {
                Object enchObj = net.minecraft.class_1890.method_57532(stack);
int total = 0;
if (enchObj != null) {
    if (enchObj instanceof java.util.Map<?, ?> m) {
        for (java.util.Map.Entry<?, ?> e : m.entrySet()) {
            Object v = e.getValue();
            int lvl = (v instanceof Integer i) ? i : (v == null ? 0 : Integer.parseInt(v.toString()));
            if (lvl > 0) total += lvl;
        }
    } else {
        // 1.21+ returns ItemEnchantmentsComponent; use reflection to sum levels
        try {
            java.lang.reflect.Method method = enchObj.getClass().getMethod("getEnchantments");
            Object mapLike = method.invoke(enchObj);
            if (mapLike instanceof java.util.Map<?, ?> m2) {
                for (java.util.Map.Entry<?, ?> e : m2.entrySet()) {
                    Object v = e.getValue();
                    int lvl = (v instanceof Integer i) ? i : (v == null ? 0 : Integer.parseInt(v.toString()));
                    if (lvl > 0) total += lvl;
                }
            } else if (mapLike instanceof Iterable<?> it) {
                for (Object entry : it) {
                    try {
                        Object v = entry.getClass().getMethod("getIntValue").invoke(entry);
                        int lvl = (v instanceof Integer i) ? i : (v == null ? 0 : Integer.parseInt(v.toString()));
                        if (lvl > 0) total += lvl;
                    } catch (Throwable ignored3) {}
                }
            }
        } catch (Throwable ignored2) {}
    }
}

                bonus = 0.2 * total;
            } catch (Throwable t) {
                bonus = 0.0;
            }
        }

        if (bonus != 0.0) {
            b.method_57487(net.minecraft.class_5134.field_23721,
                    new class_1322(id, bonus, class_1322.class_1323.field_6328),
                    class_9274.field_49217);
        }

        stack.method_57379(class_9334.field_49636, b.method_57486());
    }


    public static boolean isEligibleWeapon(class_1799 stack) {
        return isEligibleItem(stack);
    }

    /** Returns true if the item can participate in the affix system (weapons, armor, arrows). */
    public static boolean isEligibleItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;

        // Armor items always eligible
        if (isArmorItem(stack)) return true;

        // Arrow items always eligible
        if (isArrowItem(stack)) return true;

        // Explicit custom additions (by item id)
        try {
            net.minecraft.class_2960 id = net.minecraft.class_7923.field_41178.method_10221(stack.method_7909());
            if (id != null) {
                Double w = com.savaru.savaru_affixes.config.ConfigManager.get().customWeaponRates.get(id.toString());
                if (w != null && w > 0.0) return true;
            }
        } catch (Exception ignored) {}

        // Must be in any configured weapon tag
        try {
            for (String tagId : com.savaru.savaru_affixes.config.ConfigManager.get().weaponTags) {
                net.minecraft.class_6862<net.minecraft.class_1792> tag =
                        net.minecraft.class_6862.method_40092(net.minecraft.class_7924.field_41197, net.minecraft.class_2960.method_60654(tagId));
                if (stack.method_31573(tag)) return true;
            }
        } catch (Exception ignored) {}
        // fallback: allow vanilla weapon types if enabled
        if (com.savaru.savaru_affixes.config.ConfigManager.get().includeVanillaWeapons) {
            return isWeaponItem(stack);
        }
        return false;
    }

    private static boolean isWeaponItem(class_1799 stack) {
        class_1792 item = stack.method_7909();
        return (item instanceof class_1829)
                || (item instanceof class_1743)
                || (item instanceof class_1835)
                || (item instanceof class_1753)
                || (item instanceof class_1764);
    }

    private static boolean isRangedWeaponItem(class_1799 stack) {
        class_1792 item = stack.method_7909();
        return (item instanceof class_1753) || (item instanceof class_1764);
    }

    public static boolean isArmorItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        return stack.method_7909() instanceof class_1738;
    }

    public static boolean isArrowItem(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        return stack.method_7909() instanceof class_1744;
    }


    /**
     * Root compound stored inside {@link net.minecraft.class_9334#field_49628}.
     * Exposed so other helpers (e.g. unidentified / anvil flows) can share the same storage.
     */
    public static class_2487 getRoot(class_1799 stack) {
        class_9279 comp = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
        class_2487 all = comp.method_57461();
        if (!all.method_10573(ROOT_KEY, 10)) return new class_2487();
        return all.method_10562(ROOT_KEY);
    }

    public static void setRoot(class_1799 stack, class_2487 root) {
        class_9279 comp = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
        class_2487 all = comp.method_57461();
        all.method_10566(ROOT_KEY, root);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(all));
    }

    public static boolean isPendingRoll(class_1799 stack) {
        class_2487 root = getRoot(stack);
        return root.method_10577(KEY_PENDING_ROLL);
    }

    public static void markPendingRoll(class_1799 stack, Rarity rarity) {
        class_2487 root = getRoot(stack);
        root.method_10556(KEY_PENDING_ROLL, true);
        if (rarity != null) root.method_10582(KEY_PENDING_RARITY, rarity.name());
        setRoot(stack, root);
    }

    public static Rarity consumePendingRarity(class_1799 stack) {
        class_2487 root = getRoot(stack);
        Rarity rarity = null;
        if (root.method_10573(KEY_PENDING_RARITY, 8)) {
            try { rarity = Rarity.valueOf(root.method_10558(KEY_PENDING_RARITY)); } catch (Exception ignored) {}
        }
        root.method_10551(KEY_PENDING_RARITY);
        root.method_10551(KEY_PENDING_ROLL);
        setRoot(stack, root);
        return rarity;
    }


    // --- Convenience helpers used by mixins (anvil/unidentified flows) ---
    public static boolean isWeapon(net.minecraft.class_1799 s){
        return s.method_7909() instanceof net.minecraft.class_1829
            || s.method_7909() instanceof net.minecraft.class_1743
            || s.method_7909() instanceof net.minecraft.class_1810
            || s.method_7909() instanceof net.minecraft.class_1821
            || s.method_7909() instanceof net.minecraft.class_1794
            || s.method_7909() instanceof net.minecraft.class_1835
            || s.method_7909() instanceof net.minecraft.class_9362
            || s.method_7909() instanceof net.minecraft.class_1753
            || s.method_7909() instanceof net.minecraft.class_1764;
    }

    /** Force an explicit rarity onto the item, stored in our CUSTOM_DATA root. */
    public static void setRarity(net.minecraft.class_1799 s, Rarity r){
        // Arrow rarity cap: up to RARE.
        if (isArrowItem(s) && (r == Rarity.EPIC || r == Rarity.LEGENDARY || r == Rarity.MYTHIC || r == Rarity.BEYOND || r == Rarity.UNRIVALED)) {
            r = Rarity.RARE;
        }
        class_2487 root = getRoot(s);
        root.method_10582(KEY_RARITY, r.name());
        root.method_10551(KEY_PENDING_RARITY);
        root.method_10551(KEY_PENDING_ROLL);
        setRoot(s, root);
    }



/** Add an affix to the stack (or replace existing id) in CUSTOM_DATA. */
public static void addOrReplaceAffix(class_1799 stack, String id, double value) {
    if (stack == null || stack.method_7960() || id == null || id.isEmpty()) return;

    class_2487 root = getRoot(stack);
    class_2499 list = root.method_10554(KEY_AFFIXES, 10);

    for (int i = list.size() - 1; i >= 0; i--) {
        if (id.equals(list.method_10602(i).method_10558("id"))) list.method_10536(i);
    }

    class_2487 tag = new class_2487();
    tag.method_10582("id", id);
    tag.method_10549("value", value);
    list.add(tag);

    root.method_10566(KEY_AFFIXES, list);
    setRoot(stack, root);
}

}
