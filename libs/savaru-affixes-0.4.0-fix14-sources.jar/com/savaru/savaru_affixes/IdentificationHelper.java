package com.savaru.savaru_affixes;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_5819;
import net.minecraft.class_9334;

public final class IdentificationHelper {
    public static final String KEY_ID_TICKET = "savaru_identification_ticket";

    private IdentificationHelper() {}

    public static class_1799 makeTicket(int count) {
        class_1799 out = new class_1799(class_1802.field_8407, Math.max(1, count));
        out.method_57379(class_9334.field_49631, class_2561.method_43470("鑑定券"));
        class_2487 root = AffixHelper.getRoot(out);
        root.method_10556(KEY_ID_TICKET, true);
        AffixHelper.setRoot(out, root);
        return out;
    }

    public static class_1799 makeTicket() {
        return makeTicket(1);
    }

    public static boolean isTicket(class_1799 stack) {
        if (stack == null || stack.method_7960() || !stack.method_31574(class_1802.field_8407)) return false;
        class_2487 root = AffixHelper.getRoot(stack);
        return root != null && root.method_10577(KEY_ID_TICKET);
    }

    public static boolean canIdentifyWeapon(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (!AffixHelper.isWeapon(stack) && !AffixHelper.isArrowItem(stack) && !AffixHelper.isArmorItem(stack)) return false;
        return UnidentifiedHandler.isUnidentified(stack);
    }

    public static class_1799 identify(class_1799 base) {
        if (base == null || base.method_7960()) return class_1799.field_8037;
        class_1799 out = base.method_7972();

        if (AffixHelper.getRarity(out) == null) {
            class_5819 rnd = class_5819.method_43047();
            Rarity rarity = RarityRoller.rollFirstTime(rnd);
            if (AffixHelper.isArrowItem(out)) {
                // Arrow rarity cap is enforced by setRarity, but keep allowed tiers readable.
                if (rarity.ordinal() > Rarity.RARE.ordinal()) rarity = Rarity.RARE;
            }
            AffixHelper.setRarity(out, rarity);
            AffixHelper.rollAffixes(out, rarity);
            AffixHelper.applyRarityNameColor(out, rarity);
        } else if (!AffixHelper.getAffixes(out).isEmpty()) {
            // Existing rolled preview/final item: ensure visible rarity name styling exists.
            AffixHelper.applyRarityNameColor(out, AffixHelper.getRarity(out));
        }

        UnidentifiedHandler.clearUnidentified(out);
        PreviewHelper.clearPreviewName(out);
        return out;
    }
}
