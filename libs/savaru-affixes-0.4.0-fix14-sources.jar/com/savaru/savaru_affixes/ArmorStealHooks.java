package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Tracks the "armor steal" debuff on targets and removes it when expired.
 *
 * Implementation notes:
 * - We use a per-world map keyed by entityId for fast lookups.
 * - The debuff is applied as an EntityAttributeModifier on GENERIC_ARMOR.
 */
public final class ArmorStealHooks {
    private ArmorStealHooks() {}

    private record State(class_2960 modifierId, double pct01, long expiresAt) {}

    private static final Map<class_5321<net.minecraft.class_1937>, Map<Integer, State>> STATES = new HashMap<>();

    public static void init() {
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (!(world instanceof class_3218 sw)) return;
            tickWorld(sw);
        });
    }

    private static void tickWorld(class_3218 world) {
        Map<Integer, State> map = STATES.get(world.method_27983());
        if (map == null || map.isEmpty()) return;

        long now = world.method_8510();
        Iterator<Map.Entry<Integer, State>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, State> e = it.next();
            State s = e.getValue();
            if (now < s.expiresAt) continue;

            var ent = world.method_8469(e.getKey());
            if (ent instanceof class_1309 living) {
                var inst = living.method_5996(class_5134.field_23724);
                if (inst != null && inst.method_6199(s.modifierId) != null) {
                    inst.method_6200(s.modifierId);
                }
            }
            it.remove();
        }
    }

    /**
     * Apply or refresh armor steal on a target.
     *
     * @param target living entity being hit
     * @param perHitPctPoints percent points to add per hit (e.g. 3.0 for 3%)
     * @param capPctPoints cap percent points (e.g. 10.0 for 10%)
     * @param durationTicks refresh duration (e.g. 60 ticks for 3s)
     * @param attackerKey stable key to avoid players overwriting each other
     */
    public static void apply(class_3218 world, class_1309 target, double perHitPctPoints, double capPctPoints, int durationTicks, String attackerKey) {
        if (perHitPctPoints <= 0.0 || capPctPoints <= 0.0) return;

        double add01 = perHitPctPoints / 100.0;
        double cap01 = capPctPoints / 100.0;

        class_2960 modId = class_2960.method_60655(SavaruAffixesMod.MOD_ID, "armor_steal_" + attackerKey);

        Map<Integer, State> map = STATES.computeIfAbsent(world.method_27983(), k -> new HashMap<>());
        State prev = map.get(target.method_5628());
        double next01 = add01;
        if (prev != null && prev.modifierId.equals(modId)) {
            next01 = Math.min(cap01, prev.pct01 + add01);
        } else if (prev != null) {
            // another player/instance already applied; don't override it, just respect it
            next01 = prev.pct01;
        }

        var inst = target.method_5996(class_5134.field_23724);
        if (inst == null) return;

        if (inst.method_6199(modId) != null) inst.method_6200(modId);

        // Multiply total by (1 - pct). Negative reduces armor.
        inst.method_26837(new class_1322(modId, -next01, class_1322.class_1323.field_6331));

        long expiresAt = world.method_8510() + durationTicks;
        map.put(target.method_5628(), new State(modId, next01, expiresAt));
    }
}
