package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_5819;


public final class AutoRollHandler {
    private AutoRollHandler() {}

    public static void tick(class_1657 player) {
        if (player.method_37908().method_8608()) return;

        int scan = Math.max(1, ConfigManager.get().scanPerTick);
        class_5819 random = player.method_59922();

        // Scan main inventory + offhand + armor
        int scanned = 0;
        for (int i = 0; i < player.method_31548().method_5439() && scanned < scan; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            scanned += tryRoll(player, stack, random) ? 1 : 1;
        }
        // cursor stack
        if (player.field_7512 != null) {
            class_1799 cursor = player.field_7512.method_34255();
            tryRoll(player, cursor, random);
        }
    }

    private static boolean tryRoll(class_1657 player, class_1799 stack, class_5819 random) {
        if (stack == null || stack.method_7960()) return false;

        // only roll weapons in our tag (and optionally vanilla weapons)
        if (!AffixHelper.isEligibleWeapon(stack)) return false;

        // already has rarity => do nothing
        if (AffixHelper.getRarity(stack) != null) return false;

        // consume pending rarity if present
        Rarity pending = null;
        if (AffixHelper.isPendingRoll(stack)) pending = AffixHelper.consumePendingRarity(stack);

        Rarity rarity = pending != null ? pending : RarityRoller.rollFirstTime(random);
        if (rarity == null) return false;

        // rollAffixes() writes the rarity + affixes into the stack
        AffixHelper.rollAffixes(stack, rarity);
        AffixHelper.applyRarityNameColor(stack, rarity);
        return true;
    }
}
