package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;

/**
 * Unidentified items keep their hidden state until they are explicitly resolved by the mod flow.
 *
 * Current behavior:
 * - Mob/loot drops stay unidentified; they are NOT auto-rolled/auto-identified when entering inventory.
 * - Anvil preview outputs still use the same flag to hide details; once the taken output already contains
 *   rolled data (rarity / affixes), the preview flag is cleared on the next server tick.
 * - Affix books also use the same preview-hiding flag and are cleared once taken.
 */
public final class UnidentifiedHandler {

    private static final String KEY_UNIDENTIFIED = "unidentified";

    private UnidentifiedHandler() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_1657 player : server.method_3760().method_14571()) {
                for (class_1799 stack : player.method_31548().field_7547) {
                    if (stack.method_7960()) continue;
                    if (!isUnidentified(stack)) continue;
                    if (UnidentifiedHelper.isResolvedPreviewOutput(stack)) {
                        clearUnidentified(stack);
                    }
                }

                class_1799 offhand = player.method_6079();
                if (!offhand.method_7960() && isUnidentified(offhand) && UnidentifiedHelper.isResolvedPreviewOutput(offhand)) {
                    clearUnidentified(offhand);
                }

                for (class_1799 stack : player.method_31548().field_7548) {
                    if (stack.method_7960()) continue;
                    if (!isUnidentified(stack)) continue;
                    if (UnidentifiedHelper.isResolvedPreviewOutput(stack)) {
                        clearUnidentified(stack);
                    }
                }

                if (player.field_7512 != null) {
                    class_1799 cursor = player.field_7512.method_34255();
                    if (!cursor.method_7960() && isUnidentified(cursor) && UnidentifiedHelper.isResolvedPreviewOutput(cursor)) {
                        clearUnidentified(cursor);
                    }
                }
            }
        });
    }

    public static boolean isUnidentified(class_1799 stack) {
        class_2487 root = AffixHelper.getRoot(stack);
        return root != null && root.method_10577(KEY_UNIDENTIFIED);
    }

    public static void markUnidentified(class_1799 stack) {
        class_2487 root = AffixHelper.getRoot(stack);
        if (root == null) root = new class_2487();
        root.method_10556(KEY_UNIDENTIFIED, true);
        AffixHelper.setRoot(stack, root);
    }

    public static void clearUnidentified(class_1799 stack) {
        class_2487 root = AffixHelper.getRoot(stack);
        if (root == null) return;
        root.method_10551(KEY_UNIDENTIFIED);
        root.method_10551(PreviewHelper.KEY_PREVIEW_NAME);
        root.method_10551(AffixHelper.KEY_PENDING_ROLL);
        AffixHelper.setRoot(stack, root);
    }

    /**
     * Returns a scrambled placeholder string for unidentified display.
     */
    public static String scramble(String s) {
        if (s == null) return "";
        final String glyphs = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
        java.util.Random r = new java.util.Random();
        StringBuilder sb = new StringBuilder();
        int n = s.length();
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c)) { sb.append(c); continue; }
            sb.append(glyphs.charAt(r.nextInt(glyphs.length())));
        }
        return sb.toString();
    }
}
