package com.savaru.savaru_affixes;

import net.minecraft.class_1320;
import net.minecraft.class_1329;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

/**
 * Custom attributes used by Savaru Affixes.
 *
 * crit_chance: stored as 0..1 (e.g., 0.15 = 15%)
 * crit_damage: stored as 0..1 bonus multiplier (e.g., 0.45 = +45% => 1.45x damage)
 * lifesteal: stored as 0..1 (e.g., 0.08 = 8% of damage dealt healed)
 * true_damage: stored as 0..1 (e.g., 0.03 = 3% of dealt damage applied as armor/resistance-bypassing)
 *
 * UIs such as Kev's Attributes Panel can display these once they exist on the player's default attributes.
 */
public final class SavaruAttributes {

    private SavaruAttributes() {}

    public static final class_2960 CRIT_CHANCE_ID = SavaruAffixesMod.id("crit_chance");
    public static final class_2960 CRIT_DAMAGE_ID = SavaruAffixesMod.id("crit_damage");
    public static final class_2960 LIFESTEAL_ID = SavaruAffixesMod.id("lifesteal");
    public static final class_2960 TRUE_DAMAGE_ID = SavaruAffixesMod.id("true_damage");

    public static final class_1320 CRIT_CHANCE = new class_1329(
            "attribute.name.savaru_affixes.crit_chance",
            0.0,
            0.0,
            1.0
    );

    public static final class_1320 CRIT_DAMAGE = new class_1329(
            "attribute.name.savaru_affixes.crit_damage",
            0.0,
            0.0,
            1.0E9
    );

    public static final class_1320 LIFESTEAL = new class_1329(
            "attribute.name.savaru_affixes.lifesteal",
            0.0,
            0.0,
            1.0
    );

    public static final class_1320 TRUE_DAMAGE = new class_1329(
            "attribute.name.savaru_affixes.true_damage",
            0.0,
            0.0,
            1.0
    );

    // Cached entries for DefaultAttributeContainer.Builder.add(RegistryEntry, base) in 1.21.1
    public static class_6880<class_1320> CRIT_CHANCE_ENTRY;
    public static class_6880<class_1320> CRIT_DAMAGE_ENTRY;
    public static class_6880<class_1320> LIFESTEAL_ENTRY;
    public static class_6880<class_1320> TRUE_DAMAGE_ENTRY;

    /**
     * Ensure our attributes are registered and RegistryEntry handles are cached.
     * Safe to call multiple times after bootstrap.
     */
    public static void ensureRegistered() {
        if (CRIT_CHANCE_ENTRY != null && CRIT_DAMAGE_ENTRY != null && LIFESTEAL_ENTRY != null && TRUE_DAMAGE_ENTRY != null) {
            return;
        }

        if (!class_7923.field_41190.method_10250(CRIT_CHANCE_ID)) {
            class_2378.method_10230(class_7923.field_41190, CRIT_CHANCE_ID, CRIT_CHANCE);
        }
        if (!class_7923.field_41190.method_10250(CRIT_DAMAGE_ID)) {
            class_2378.method_10230(class_7923.field_41190, CRIT_DAMAGE_ID, CRIT_DAMAGE);
        }
        if (!class_7923.field_41190.method_10250(LIFESTEAL_ID)) {
            class_2378.method_10230(class_7923.field_41190, LIFESTEAL_ID, LIFESTEAL);
        }
        if (!class_7923.field_41190.method_10250(TRUE_DAMAGE_ID)) {
            class_2378.method_10230(class_7923.field_41190, TRUE_DAMAGE_ID, TRUE_DAMAGE);
        }

        CRIT_CHANCE_ENTRY = class_7923.field_41190.method_55841(CRIT_CHANCE_ID)
                .orElseThrow(() -> new IllegalStateException("Missing attribute entry: " + CRIT_CHANCE_ID));
        CRIT_DAMAGE_ENTRY = class_7923.field_41190.method_55841(CRIT_DAMAGE_ID)
                .orElseThrow(() -> new IllegalStateException("Missing attribute entry: " + CRIT_DAMAGE_ID));

        LIFESTEAL_ENTRY = class_7923.field_41190.method_55841(LIFESTEAL_ID)
                .orElseThrow(() -> new IllegalStateException("Missing attribute entry: " + LIFESTEAL_ID));
        TRUE_DAMAGE_ENTRY = class_7923.field_41190.method_55841(TRUE_DAMAGE_ID)
                .orElseThrow(() -> new IllegalStateException("Missing attribute entry: " + TRUE_DAMAGE_ID));
    }

    /** Called from ModInitializer; delegates to {@link #ensureRegistered()}. */
    public static void register() {
        ensureRegistered();
    }
}
