package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1722;
import net.minecraft.class_1733;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public final class LootContainerTransformHooks {
    private LootContainerTransformHooks() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_1657 player : server.method_3760().method_14571()) {
                if (player.field_7512 == null) continue;
                if (!(player.field_7512 instanceof class_1707
                        || player.field_7512 instanceof class_1733
                        || player.field_7512 instanceof class_1722)) {
                    continue;
                }
                class_1263 playerInv = player.method_31548();
                for (class_1735 slot : player.field_7512.field_7761) {
                    if (slot == null || slot.field_7871 == playerInv) continue;
                    class_1799 stack = slot.method_7677();
                    if (stack == null || stack.method_7960()) continue;
                    if (!AffixHelper.isEligibleWeapon(stack)) continue;
                    if (UnidentifiedHandler.isUnidentified(stack)) continue;
                    if (AffixHelper.getRarity(stack) != null) continue;
                    if (!AffixHelper.getAffixes(stack).isEmpty()) continue;

                    class_1799 converted = new class_1799(stack.method_7909(), stack.method_7947());
                    UnidentifiedHandler.markUnidentified(converted);
                    slot.method_53512(converted);
                    slot.method_7668();
                }
            }
        });
    }
}
