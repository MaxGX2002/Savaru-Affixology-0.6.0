package com.savaru.savaru_affixes;

import net.minecraft.class_1799;
import net.minecraft.class_2487;

public final class PreviewHelper {
    public static final String KEY_PREVIEW_NAME = "savaru_preview_name";

    private PreviewHelper() {}

    public static boolean isPreview(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_2487 root = AffixHelper.getRoot(stack);
        return root != null && (root.method_10545(KEY_PREVIEW_NAME) || root.method_10577(AffixHelper.KEY_PENDING_ROLL));
    }

    public static String getPreviewName(class_1799 stack) {
        class_2487 root = AffixHelper.getRoot(stack);
        if (root == null || !root.method_10545(KEY_PREVIEW_NAME)) return "";
        return root.method_10558(KEY_PREVIEW_NAME);
    }

    public static void setPreviewName(class_1799 stack, String name) {
        if (stack == null || stack.method_7960() || name == null || name.isBlank()) return;
        class_2487 root = AffixHelper.getRoot(stack);
        root.method_10582(KEY_PREVIEW_NAME, name);
        AffixHelper.setRoot(stack, root);
    }

    public static void clearPreviewName(class_1799 stack) {
        if (stack == null || stack.method_7960()) return;
        class_2487 root = AffixHelper.getRoot(stack);
        if (root == null) return;
        root.method_10551(KEY_PREVIEW_NAME);
        AffixHelper.setRoot(stack, root);
    }
}
