package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.UnidentifiedHandler;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_6880;

/**
 * Keeps player attributes in sync with held weapon affixes, so attribute panels can display crit stats.
 */
public final class CritAttributeApplier {

    private static final class_2960 MOD_CHANCE = class_2960.method_60655(SavaruAffixesMod.MOD_ID, "weapon_crit_chance");
    private static final class_2960 MOD_DAMAGE = class_2960.method_60655(SavaruAffixesMod.MOD_ID, "weapon_crit_damage");
    private static final class_2960 MOD_LIFESTEAL = class_2960.method_60655(SavaruAffixesMod.MOD_ID, "weapon_lifesteal");
    private static final class_2960 MOD_TRUE_DAMAGE = class_2960.method_60655(SavaruAffixesMod.MOD_ID, "weapon_true_damage");
    private static final class_2960 MOD_ATTACK_SPEED = class_2960.method_60655(SavaruAffixesMod.MOD_ID, "weapon_attack_speed");

    private CritAttributeApplier() {}


public static void tick(class_1657 player) {
    if (player.method_37908().method_8608()) return;

    class_6880<class_1320> chanceAttr = SavaruAttributes.CRIT_CHANCE_ENTRY;
    class_6880<class_1320> damageAttr = SavaruAttributes.CRIT_DAMAGE_ENTRY;
    class_6880<class_1320> lifestealAttr = SavaruAttributes.LIFESTEAL_ENTRY;
    class_6880<class_1320> trueDamageAttr = SavaruAttributes.TRUE_DAMAGE_ENTRY;
    if (chanceAttr == null || damageAttr == null || lifestealAttr == null || trueDamageAttr == null) return;

    // always clean slate
    remove(player, chanceAttr, MOD_CHANCE);
    remove(player, damageAttr, MOD_DAMAGE);
    remove(player, lifestealAttr, MOD_LIFESTEAL);
    remove(player, trueDamageAttr, MOD_TRUE_DAMAGE);
    removeVanilla(player, class_5134.field_23723, MOD_ATTACK_SPEED);

    var stack = player.method_6047();
    if (stack.method_7960()) return;
    if (AffixHelper.getRarity(stack) == null) return;

    // do not reveal stats on unidentified items
    if (UnidentifiedHandler.isUnidentified(stack)) return;

    // Stored as percent points in NBT; convert to 0-1 range for attribute
    double cc = AffixHelper.getAffixValue(stack, "crit_chance") / 100.0;
    double cd = AffixHelper.getAffixValue(stack, "crit_damage") / 100.0;
    double ls = AffixHelper.getAffixValue(stack, "lifesteal") / 100.0;
    double td = AffixHelper.getAffixValue(stack, "true_damage") / 100.0;
    double asp = AffixHelper.getAffixValue(stack, "attack_speed") / 100.0;

    if (cc != 0.0) add(player, chanceAttr, MOD_CHANCE, cc);
    if (cd != 0.0) add(player, damageAttr, MOD_DAMAGE, cd);
    if (ls != 0.0) add(player, lifestealAttr, MOD_LIFESTEAL, ls);
    if (td != 0.0) add(player, trueDamageAttr, MOD_TRUE_DAMAGE, td);

    // vanilla attack speed is multiplicative total
    if (asp != 0.0) addVanilla(player, class_5134.field_23723, MOD_ATTACK_SPEED, asp);
}
    private static void add(class_1657 player, class_6880<class_1320> attr, class_2960 id, double value) {
        class_1324 inst = player.method_5996(attr);
        if (inst == null) return;
        // persistent -> visible to client UI; we remove/re-add each tick
        inst.method_26837(new class_1322(id, value, class_1322.class_1323.field_6328));
    }

    private static void remove(class_1657 player, class_6880<class_1320> attr, class_2960 id) {
        class_1324 inst = player.method_5996(attr);
        if (inst == null) return;
        if (inst.method_6199(id) != null) inst.method_6200(id);
    }


private static void addVanilla(class_1657 player, class_6880<class_1320> attr, class_2960 id, double value) {
    class_1324 inst = player.method_5996(attr);
    if (inst == null) return;
    inst.method_26837(new class_1322(id, value, class_1322.class_1323.field_6331));
}

private static void removeVanilla(class_1657 player, class_6880<class_1320> attr, class_2960 id) {
    class_1324 inst = player.method_5996(attr);
    if (inst == null) return;
    if (inst.method_6199(id) != null) inst.method_6200(id);
}

}