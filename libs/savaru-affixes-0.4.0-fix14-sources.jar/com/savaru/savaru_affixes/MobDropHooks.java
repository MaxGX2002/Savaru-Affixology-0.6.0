
package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import com.savaru.savaru_affixes.config.MobDropRule;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;

public final class MobDropHooks {
    private MobDropHooks() {}

    public static void init() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity.method_37908() instanceof class_3218 world)) return;
            if (!(entity instanceof class_1309 living)) return;
            if (living.method_31747()) return;

            class_1799 extra = rollConfiguredDrop(living);
            if (extra.method_7960()) return;

            class_1542 item = new class_1542(world, living.method_23317(), living.method_23318(), living.method_23321(), extra);
            world.method_8649(item);
        });
    }

    public static class_1799 rollConfiguredDrop(class_1309 living) {
        class_5819 random = living.method_59922();
        String entityId = class_7923.field_41177.method_10221(living.method_5864()).toString();

        List<MobDropRule> rules = new ArrayList<>();
        for (MobDropRule rule : ConfigManager.get().mobDropRules) {
            if (rule == null) continue;
            if (entityId.equals(rule.entityId) && rule.itemId != null && !rule.itemId.isBlank() && rule.weight > 0.0D) {
                rules.add(rule);
            }
        }
        if (rules.isEmpty()) return class_1799.field_8037;

        MobDropRule selected = weightedPick(rules, random);
        if (selected == null) return class_1799.field_8037;
        if (selected.chance <= 0.0D || random.method_43058() > Math.min(1.0D, selected.chance)) {
            return class_1799.field_8037;
        }

        class_2960 itemId;
        try {
            itemId = class_2960.method_60654(selected.itemId);
        } catch (Exception ignored) {
            return class_1799.field_8037;
        }

        class_1792 item = class_7923.field_41178.method_10223(itemId);
        if (item == null) return class_1799.field_8037;

        class_1799 stack = new class_1799(item);
        if (stack.method_7960()) return class_1799.field_8037;

        if (selected.useSavaruRoll && AffixHelper.isEligibleWeapon(stack)) {
            Rarity min = parseRarity(selected.minRarity, Rarity.COMMON);
            Rarity max = parseRarity(selected.maxRarity, Rarity.UNRIVALED);
            Rarity rarity = rollBoundedRarity(random, min, max);
            if (rarity == null) rarity = RarityRoller.rollFirstTime(random);
            AffixHelper.rollAffixes(stack, rarity);
            AffixHelper.applyRarityNameColor(stack, rarity);
            UnidentifiedHandler.markUnidentified(stack);
        } else if (selected.customName != null && !selected.customName.isBlank()) {
            stack.method_57379(class_9334.field_49631, class_2561.method_43470(selected.customName));
        }

        return stack;
    }

    private static MobDropRule weightedPick(List<MobDropRule> rules, class_5819 random) {
        double total = 0.0D;
        for (MobDropRule rule : rules) total += Math.max(0.0D, rule.weight);
        if (total <= 0.0D) return null;

        double p = random.method_43058() * total;
        for (MobDropRule rule : rules) {
            p -= Math.max(0.0D, rule.weight);
            if (p <= 0.0D) return rule;
        }
        return rules.get(rules.size() - 1);
    }

    private static Rarity parseRarity(String s, Rarity fallback) {
        if (s == null || s.isBlank()) return fallback;
        try {
            return Rarity.valueOf(s.toUpperCase());
        } catch (Exception ignored) {
            return fallback;
        }
    }

    public static Rarity rollBoundedRarity(class_5819 random, Rarity min, Rarity max) {
        if (min == null) min = Rarity.COMMON;
        if (max == null) max = Rarity.UNRIVALED;
        if (min.ordinal() > max.ordinal()) {
            Rarity t = min;
            min = max;
            max = t;
        }

        double[] weights = new double[] {
                Math.max(0.0, ConfigManager.get().rollCommon),
                Math.max(0.0, ConfigManager.get().rollUncommon),
                Math.max(0.0, ConfigManager.get().rollRare),
                Math.max(0.0, ConfigManager.get().rollEpic),
                Math.max(0.0, ConfigManager.get().rollLegendary),
                Math.max(0.0, ConfigManager.get().rollMythic),
                Math.max(0.0, ConfigManager.get().rollBeyond),
                Math.max(0.0, ConfigManager.get().rollUnrivaled)
        };

        for (int i = 0; i < weights.length; i++) {
            if (i < min.ordinal() || i > max.ordinal()) {
                weights[i] = 0.0D;
            }
        }
        return RarityRoller.rollByWeights(random, weights);
    }
}
