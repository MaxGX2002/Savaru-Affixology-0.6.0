package com.savaru.savaru_affixes;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1299;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2232;
import net.minecraft.class_2287;
import net.minecraft.class_2290;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_5819;
import net.minecraft.class_7157;
import net.minecraft.class_7923;
import com.savaru.savaru_affixes.config.ConfigManager;
import com.savaru.savaru_affixes.config.MobDropRule;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import java.util.List;
import java.util.Map.Entry;

public final class CommandHooks {
    

private static final SuggestionProvider<class_2168> SUGGEST_AFFIX_IDS = (ctx, builder) -> {
    for (Affix a : AffixRegistry.getAll()) builder.suggest(a.id());
    return builder.buildFuture();
};

private static final SuggestionProvider<class_2168> SUGGEST_ANY_IDS = (ctx, builder) -> {
    for (Affix a : AffixRegistry.getAll()) builder.suggest(a.id());
    for (String id : InscriptionHelper.OUTLAND_POOL) builder.suggest(id);
    for (String id : InscriptionHelper.SECRET_POOL) builder.suggest(id);
    return builder.buildFuture();
};


private static final SuggestionProvider<class_2168> SUGGEST_ENTITY_IDS = (ctx, builder) -> {
    for (var e : class_7923.field_41177) {
        try {
            class_2960 id = class_7923.field_41177.method_10221(e);
            if (id != null) builder.suggest(id.toString());
        } catch (Exception ignored) {}
    }
    return builder.buildFuture();
};

private static final SuggestionProvider<class_2168> SUGGEST_RARITIES = (ctx, builder) -> {
    for (Rarity r : Rarity.values()) builder.suggest(r.name().toLowerCase());
    return builder.buildFuture();
};

private CommandHooks() {}

public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                registerCommands(dispatcher, registryAccess)
        );
    }

    private static void registerCommands(CommandDispatcher<class_2168> dispatcher, class_7157 access) {

        // Existing helper command group
        dispatcher.register(
                class_2170.method_9247("savaru_affixes")
                        .requires(src -> src.method_9259(2))
                        .then(class_2170.method_9247("give")
                                .then(class_2170.method_9244("rarity", com.mojang.brigadier.arguments.StringArgumentType.word())
                                        .suggests((ctx, builder) -> {
                                            for (Rarity r : Rarity.values()) builder.suggest(r.name().toLowerCase());
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> {
                                            class_3222 player = ctx.getSource().method_9207();
                                            String rName = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "rarity");
                                            Rarity rarity;
                                            try {
                                                rarity = Rarity.valueOf(rName.toUpperCase());
                                            } catch (Exception e) {
                                                ctx.getSource().method_9213(class_2561.method_43469("command.savaru_affixes.give.bad_rarity", rName));
                                                return 0;
                                            }

                                            class_1799 base = player.method_6047();
                                            if (base.method_7960()) {
                                                ctx.getSource().method_9213(class_2561.method_43471("command.savaru_affixes.give.hold_item"));
                                                return 0;
                                            }

                                            class_1799 stack = base.method_7972();
                                            stack.method_7939(1);
                                            AffixHelper.rollAffixes(stack, rarity);

                                            boolean ok = player.method_31548().method_7394(stack);
                                            if (!ok) player.method_7328(stack, false);

                                            ctx.getSource().method_9226(
                                                    () -> class_2561.method_43469("command.savaru_affixes.give.ok",
                                                            class_2561.method_43471("rarity.savaru_affixes." + rarity.name().toLowerCase())),
                                                    false
                                            );
                                            return 1;
                                        })
                                        .then(class_2170.method_9244("item", class_2287.method_9776(access))
                                                .executes(ctx -> {
                                                    class_3222 player = ctx.getSource().method_9207();
                                                    String rName = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "rarity");
                                                    Rarity rarity;
                                                    try {
                                                        rarity = Rarity.valueOf(rName.toUpperCase());
                                                    } catch (Exception e) {
                                                        ctx.getSource().method_9213(class_2561.method_43469("command.savaru_affixes.give.bad_rarity", rName));
                                                        return 0;
                                                    }

                                                    class_2290 arg = class_2287.method_9777(ctx, "item");
                                                    class_1799 stack = arg.method_9781(1, false);
                                                    AffixHelper.rollAffixes(stack, rarity);

                                                    boolean ok = player.method_31548().method_7394(stack);
                                                    if (!ok) player.method_7328(stack, false);

                                                    ctx.getSource().method_9226(
                                                            () -> class_2561.method_43469("command.savaru_affixes.give.ok",
                                                                    class_2561.method_43471("rarity.savaru_affixes." + rarity.name().toLowerCase())),
                                                            false
                                                    );
                                                    return 1;
                                                }))))
                        .then(class_2170.method_9247("reroll")
                                .executes(ctx -> {
                                    class_3222 player = ctx.getSource().method_9207();
                                    class_1799 stack = player.method_6047();
                                    if (stack.method_7960()) {
                                        ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                        return 0;
                                    }

                                    Rarity rarity = AffixHelper.getRarity(stack);
                                    if (rarity == null) rarity = Rarity.roll(new java.util.Random());
                                    AffixHelper.rollAffixes(stack, rarity);

                                    final String msg = "Rerolled affixes (" + rarity.name() + ").";
            ctx.getSource().method_9226(() -> class_2561.method_43470(msg), false);
                                    return 1;
                                }))
        );

        // New inscription + testing command group
        dispatcher.register(
                class_2170.method_9247("savaru")
                        .requires(src -> src.method_9259(2))
                        .then(class_2170.method_9247("pool")
                                .then(class_2170.method_9247("add")
                                        .executes(ctx -> {
                                            class_3222 player = ctx.getSource().method_9207();
                                            class_1799 stack = player.method_6047();
                                            if (stack.method_7960()) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                                            ConfigManager.get().customWeaponRates.putIfAbsent(id, 1.0D);
                                            ConfigManager.save();
                                            final var msgT = class_2561.method_43470("Added weapon to drop pool: " + id + " (weight 1.0)");
                                            ctx.getSource().method_9226(() -> msgT, false);
                                            return 1;
                                        })
                                        .then(class_2170.method_9244("weight", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D))
                                                .executes(ctx -> {
                                                    class_3222 player = ctx.getSource().method_9207();
                                                    class_1799 stack = player.method_6047();
                                                    if (stack.method_7960()) {
                                                        ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                        return 0;
                                                    }
                                                    double weight = com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight");
                                                    String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                                                    ConfigManager.get().customWeaponRates.put(id, weight);
                                                    ConfigManager.save();
                                                    final var msgT = class_2561.method_43470("Added weapon to drop pool: " + id + " (weight " + weight + ")");
                                                    ctx.getSource().method_9226(() -> msgT, false);
                                                    return 1;
                                                })))
                                .then(class_2170.method_9247("remove")
                                        .executes(ctx -> {
                                            class_3222 player = ctx.getSource().method_9207();
                                            class_1799 stack = player.method_6047();
                                            if (stack.method_7960()) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                                            boolean removed = ConfigManager.get().customWeaponRates.remove(id) != null;
                                            ConfigManager.save();
                                            if (!removed) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Weapon not found in drop pool: " + id));
                                                return 0;
                                            }
                                            final var msgT = class_2561.method_43470("Removed weapon from drop pool: " + id);
                                            ctx.getSource().method_9226(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(class_2170.method_9247("weight")
                                        .then(class_2170.method_9244("weight", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D))
                                                .executes(ctx -> {
                                                    class_3222 player = ctx.getSource().method_9207();
                                                    class_1799 stack = player.method_6047();
                                                    if (stack.method_7960()) {
                                                        ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                        return 0;
                                                    }
                                                    double weight = com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight");
                                                    String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                                                    if (!ConfigManager.get().customWeaponRates.containsKey(id)) {
                                                        ctx.getSource().method_9213(class_2561.method_43470("Weapon is not in drop pool yet: " + id));
                                                        return 0;
                                                    }
                                                    ConfigManager.get().customWeaponRates.put(id, weight);
                                                    ConfigManager.save();
                                                    final var msgT = class_2561.method_43470("Updated weapon pool weight: " + id + " -> " + weight);
                                                    ctx.getSource().method_9226(() -> msgT, false);
                                                    return 1;
                                                })))
                                .then(class_2170.method_9247("list")
                                        .executes(ctx -> {
                                            if (ConfigManager.get().customWeaponRates.isEmpty()) {
                                                final var msgT = class_2561.method_43470("Custom drop pool is empty.");
                                                ctx.getSource().method_9226(() -> msgT, false);
                                                return 1;
                                            }
                                            StringBuilder sb = new StringBuilder();
                                            for (var e : ConfigManager.get().customWeaponRates.entrySet()) {
                                                if (sb.length() > 0) sb.append(", ");
                                                sb.append(e.getKey()).append("=").append(e.getValue());
                                            }
                                            final var msgT = class_2561.method_43470("Custom drop pool: " + sb);
                                            ctx.getSource().method_9226(() -> msgT, false);
                                            return 1;
                                        })))
                        .then(class_2170.method_9247("tag")
                                .then(class_2170.method_9247("add")
                                        .executes(ctx -> {
                                            class_3222 player = ctx.getSource().method_9207();
                                            class_1799 stack = player.method_6047();
                                            if (stack.method_7960()) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                                            ConfigManager.get().customWeaponRates.putIfAbsent(id, 1.0D);
                                            ConfigManager.save();
                                            final var msgT = class_2561.method_43470("Tagged weapon for drop pool: " + id);
                                            ctx.getSource().method_9226(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(class_2170.method_9247("remove")
                                        .executes(ctx -> {
                                            class_3222 player = ctx.getSource().method_9207();
                                            class_1799 stack = player.method_6047();
                                            if (stack.method_7960()) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                                            ConfigManager.get().customWeaponRates.remove(id);
                                            ConfigManager.save();
                                            final var msgT = class_2561.method_43470("Removed weapon tag from drop pool: " + id);
                                            ctx.getSource().method_9226(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(class_2170.method_9247("list")
                                        .executes(ctx -> {
                                            if (ConfigManager.get().customWeaponRates.isEmpty()) {
                                                final var msgT = class_2561.method_43470("Custom drop pool is empty.");
                                                ctx.getSource().method_9226(() -> msgT, false);
                                                return 1;
                                            }
                                            StringBuilder sb = new StringBuilder();
                                            for (String id : ConfigManager.get().customWeaponRates.keySet()) {
                                                if (sb.length() > 0) sb.append(", ");
                                                sb.append(id);
                                            }
                                            final var msgT = class_2561.method_43470("Tagged weapons: " + sb);
                                            ctx.getSource().method_9226(() -> msgT, false);
                                            return 1;
                                        })))
                        
.then(class_2170.method_9247("mobdrop")
        .then(class_2170.method_9247("add")
                .then(class_2170.method_9244("entity", class_2232.method_9441()).suggests(SUGGEST_ENTITY_IDS)
                        .then(class_2170.method_9244("weight", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D))
                                .then(class_2170.method_9244("chance", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D, 1.0D))
                                        .executes(ctx -> addMobDrop(ctx.getSource(),
                                                class_2232.method_9443(ctx, "entity").toString(),
                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight"),
                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "chance"),
                                                true, null, null))
                                        .then(class_2170.method_9244("min_rarity", com.mojang.brigadier.arguments.StringArgumentType.word()).suggests(SUGGEST_RARITIES)
                                                .then(class_2170.method_9244("max_rarity", com.mojang.brigadier.arguments.StringArgumentType.word()).suggests(SUGGEST_RARITIES)
                                                        .executes(ctx -> addMobDrop(ctx.getSource(),
                                                                class_2232.method_9443(ctx, "entity").toString(),
                                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight"),
                                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "chance"),
                                                                true,
                                                                com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "min_rarity"),
                                                                com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "max_rarity")))))))))
        .then(class_2170.method_9247("addraw")
                .then(class_2170.method_9244("entity", class_2232.method_9441()).suggests(SUGGEST_ENTITY_IDS)
                        .then(class_2170.method_9244("weight", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D))
                                .then(class_2170.method_9244("chance", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D, 1.0D))
                                        .executes(ctx -> addMobDrop(ctx.getSource(),
                                                class_2232.method_9443(ctx, "entity").toString(),
                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight"),
                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "chance"),
                                                false, null, null))))))
        .then(class_2170.method_9247("list")
                .executes(ctx -> listMobDrops(ctx.getSource(), null))
                .then(class_2170.method_9244("entity", class_2232.method_9441()).suggests(SUGGEST_ENTITY_IDS)
                        .executes(ctx -> listMobDrops(ctx.getSource(),
                                class_2232.method_9443(ctx, "entity").toString()))))
        .then(class_2170.method_9247("remove")
                .then(class_2170.method_9244("entity", class_2232.method_9441()).suggests(SUGGEST_ENTITY_IDS)
                        .then(class_2170.method_9244("index", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0))
                                .executes(ctx -> removeMobDrop(ctx.getSource(),
                                        class_2232.method_9443(ctx, "entity").toString(),
                                        com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "index"))))))
        .then(class_2170.method_9247("clear")
                .then(class_2170.method_9244("entity", class_2232.method_9441()).suggests(SUGGEST_ENTITY_IDS)
                        .executes(ctx -> clearMobDrops(ctx.getSource(),
                                class_2232.method_9443(ctx, "entity").toString()))))
        .then(class_2170.method_9247("reload")
                .executes(ctx -> {
                    ConfigManager.load();
                    final var msgT = class_2561.method_43470("Reloaded mob drop rules.");
                    ctx.getSource().method_9226(() -> msgT, false);
                    return 1;
                })))

                        .then(class_2170.method_9247("whitelist")
                                .then(class_2170.method_9247("add")
                                        .executes(ctx -> {
                                            class_3222 player = ctx.getSource().method_9207();
                                            class_1799 stack = player.method_6047();
                                            if (stack.method_7960()) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                                            if (!ConfigManager.get().inscriptionWhitelist.contains(id)) {
                                                ConfigManager.get().inscriptionWhitelist.add(id);
                                                ConfigManager.save();
                                            }
                                            final var msgT = class_2561.method_43469("command.savaru.whitelist.add", id);
            ctx.getSource().method_9226(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(class_2170.method_9247("remove")
                                        .executes(ctx -> {
                                            class_3222 player = ctx.getSource().method_9207();
                                            class_1799 stack = player.method_6047();
                                            if (stack.method_7960()) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                                            ConfigManager.get().inscriptionWhitelist.remove(id);
                                            ConfigManager.save();
                                            final var msgT = class_2561.method_43469("command.savaru.whitelist.remove", id);
            ctx.getSource().method_9226(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(class_2170.method_9247("list")
                                        .executes(ctx -> {
                                            String joined = String.join(", ", ConfigManager.get().inscriptionWhitelist);
                                            final var msgT = class_2561.method_43469("command.savaru.whitelist.list",
                                                    joined.isEmpty() ? "(empty)" : joined);
            ctx.getSource().method_9226(() -> msgT, false);
                                            return 1;
                                        })))
                        // Add a normal affix (roll value from registry)
                        .then(class_2170.method_9247("give_affix")
                                .then(class_2170.method_9244("id", com.mojang.brigadier.arguments.StringArgumentType.word()).suggests(SUGGEST_AFFIX_IDS)
                                        .executes(ctx -> {
                                            class_3222 player = ctx.getSource().method_9207();
                                            class_1799 stack = player.method_6047();
                                            if (stack.method_7960()) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "id");
                                            if (id.contains(":")) id = id.substring(id.indexOf(':') + 1);

                                            var def = findAffixDef(id);
                                            if (def == null) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Unknown affix: " + id));
                                                return 0;
                                            }

                                            double v = rollAffix(def, class_5819.method_43047());
                                            AffixHelper.addOrReplaceAffix(stack, id, v);
                                            UnidentifiedHandler.markUnidentified(stack);
                                            final String msg = "Added affix: " + id + " (" + String.format("%.2f", v) + ")";
            ctx.getSource().method_9226(() -> class_2561.method_43470(msg), false);
                                            return 1;
                                        })))
                        // Give effect: if it's an inscription id -> set inscription, else treat as normal affix id
                        .then(class_2170.method_9247("give_effect")
                                .then(class_2170.method_9244("id", com.mojang.brigadier.arguments.StringArgumentType.word()).suggests(SUGGEST_ANY_IDS)
                                        .suggests((ctx, builder) -> {
                                            // All inscription IDs from both pools
                                            for (String id : InscriptionHelper.OUTLAND_POOL) builder.suggest(id);
                                            for (String id : InscriptionHelper.SECRET_POOL) builder.suggest(id);
                                            // Also suggest all affix IDs
                                            for (Affix a : AffixRegistry.getAll()) builder.suggest(a.id());
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> {
                                            class_3222 player = ctx.getSource().method_9207();
                                            class_1799 stack = player.method_6047();
                                            if (stack.method_7960()) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Hold an item in main hand."));
                                                return 0;
                                            }

                                            String id = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "id");
                                            if (id.contains(":")) id = id.substring(id.indexOf(':') + 1);

                                            // inscription ids
                                            String inscriptionType = InscriptionHelper.getTypeForId(id);
                                            if (inscriptionType != null) {
                                                if (!InscriptionHelper.isIdCompatibleWithWeapon(id, stack)) {
                                                    ctx.getSource().method_9213(class_2561.method_43469("command.savaru.give_effect.bad_target", id));
                                                    return 0;
                                                }
                                                InscriptionHelper.setInscription(stack, inscriptionType, id);
                                                final var msgT = class_2561.method_43469("command.savaru.give_effect.ok", id);
            ctx.getSource().method_9226(() -> msgT, false);
                                                return 1;
                                            }

                                            // fall back: normal affix by id
                                            var def = findAffixDef(id);
                                            if (def == null) {
                                                ctx.getSource().method_9213(class_2561.method_43470("Unknown id: " + id));
                                                return 0;
                                            }
                                            double v = rollAffix(def, class_5819.method_43047());
                                            AffixHelper.addOrReplaceAffix(stack, id, v);
                                            UnidentifiedHandler.markUnidentified(stack);
                                            final String msg = "Added affix: " + id + " (" + String.format("%.2f", v) + ")";
            ctx.getSource().method_9226(() -> class_2561.method_43470(msg), false);
                                            return 1;
                                        })))
        );
    }


private static int addMobDrop(class_2168 source, String entityId, double weight, double chance,
                              boolean useSavaruRoll, String minRarity, String maxRarity) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
    class_3222 player = source.method_9207();
    class_1799 stack = player.method_6047();
    if (stack.method_7960()) {
        source.method_9213(class_2561.method_43470("Hold an item in main hand."));
        return 0;
    }

    class_2960 entityKey;
    try {
        entityKey = class_2960.method_60654(entityId);
    } catch (Exception e) {
        source.method_9213(class_2561.method_43470("Invalid entity id: " + entityId));
        return 0;
    }
    if (!class_7923.field_41177.method_10250(entityKey)) {
        source.method_9213(class_2561.method_43470("Unknown entity id: " + entityId));
        return 0;
    }

    String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
    String customName = stack.method_7964().getString();
    String min = minRarity == null ? Rarity.COMMON.name() : minRarity.toUpperCase();
    String max = maxRarity == null ? Rarity.UNRIVALED.name() : maxRarity.toUpperCase();

    if (useSavaruRoll) {
        try { Rarity.valueOf(min); } catch (Exception e) {
            source.method_9213(class_2561.method_43470("Invalid min rarity: " + minRarity));
            return 0;
        }
        try { Rarity.valueOf(max); } catch (Exception e) {
            source.method_9213(class_2561.method_43470("Invalid max rarity: " + maxRarity));
            return 0;
        }
    }

    ConfigManager.get().mobDropRules.add(new MobDropRule(entityId, itemId, weight, chance, useSavaruRoll, min, max, customName));
    ConfigManager.save();

    final var msgT = class_2561.method_43470("Added mob drop: " + entityId + " -> " + itemId
            + " (weight " + weight + ", chance " + chance
            + (useSavaruRoll ? ", rarity " + min + "~" + max : ", raw") + ")");
    source.method_9226(() -> msgT, false);
    return 1;
}

private static int listMobDrops(class_2168 source, String entityId) {
    var rules = ConfigManager.get().mobDropRules;
    if (rules.isEmpty()) {
        final var msgT = class_2561.method_43470("Mob drop rules are empty.");
        source.method_9226(() -> msgT, false);
        return 1;
    }

    StringBuilder sb = new StringBuilder();
    int shown = 0;
    for (int i = 0; i < rules.size(); i++) {
        MobDropRule rule = rules.get(i);
        if (rule == null) continue;
        if (entityId != null && !entityId.equals(rule.entityId)) continue;
        if (shown++ > 0) sb.append(" | ");
        sb.append("#").append(i)
                .append(" ").append(rule.entityId)
                .append(" -> ").append(rule.itemId)
                .append(" w=").append(rule.weight)
                .append(" c=").append(rule.chance);
        if (rule.useSavaruRoll) {
            sb.append(" ").append(rule.minRarity).append("~").append(rule.maxRarity);
        } else {
            sb.append(" raw");
        }
    }

    if (shown == 0) {
        final var msgT = class_2561.method_43470("No mob drop rules for " + entityId);
        source.method_9226(() -> msgT, false);
        return 1;
    }

    final var msgT = class_2561.method_43470(sb.toString());
    source.method_9226(() -> msgT, false);
    return 1;
}

private static int removeMobDrop(class_2168 source, String entityId, int index) {
    if (index < 0 || index >= ConfigManager.get().mobDropRules.size()) {
        source.method_9213(class_2561.method_43470("Rule index out of range: " + index));
        return 0;
    }
    MobDropRule rule = ConfigManager.get().mobDropRules.get(index);
    if (rule == null || !entityId.equals(rule.entityId)) {
        source.method_9213(class_2561.method_43470("Rule #" + index + " is not bound to " + entityId));
        return 0;
    }
    ConfigManager.get().mobDropRules.remove(index);
    ConfigManager.save();
    final var msgT = class_2561.method_43470("Removed mob drop rule #" + index + " for " + entityId);
    source.method_9226(() -> msgT, false);
    return 1;
}

private static int clearMobDrops(class_2168 source, String entityId) {
    int before = ConfigManager.get().mobDropRules.size();
    ConfigManager.get().mobDropRules.removeIf(rule -> rule != null && entityId.equals(rule.entityId));
    int removed = before - ConfigManager.get().mobDropRules.size();
    ConfigManager.save();
    final var msgT = class_2561.method_43470("Cleared " + removed + " mob drop rules for " + entityId);
    source.method_9226(() -> msgT, false);
    return 1;
}


private static com.savaru.savaru_affixes.Affix findAffixDef(String id){
    if (id == null) return null;
    String plain = id;
    if (plain.contains(":")) plain = plain.substring(plain.indexOf(':')+1);
    for (var a : com.savaru.savaru_affixes.AffixRegistry.getAll()){
        if (a.id().equals(plain)) return a;
    }
    return null;
}



private static double rollAffix(Affix def, net.minecraft.class_5819 rnd) {
    if (def == null) return 0.0;
    double min = def.min();
    double max = def.max();
    if (max < min) { double t = min; min = max; max = t; }
    if (min == max) return min;
    return min + rnd.method_43058() * (max - min);
}


}