package com.savaru.savaru_affixes.ranged;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

/**
 * "彈射": After hitting a target, spawn a new projectile that seeks the next nearby target.
 * - Up to 5 bounces per original shot
 * - Each bounce deals 70% damage of the previous projectile
 */
public final class RicochetHooks {

    private static final int MAX_BOUNCES = 5;
    private static final double DAMAGE_FACTOR = 0.70;
    private static final double SEARCH_RADIUS = 16.0;

    private static final class State {
        int bouncesLeft;
        double damage;
        Set<UUID> alreadyHit;
    }

    private static final Map<UUID, State> STATE = new Object2ObjectOpenHashMap<>();

    private RicochetHooks() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(RicochetHooks::tickCleanup);
    }

    public static void onHit(class_1665 proj, class_1309 hitTarget) {
        if (!(proj.method_37908() instanceof class_3218 world)) return;
        if (proj.method_31481()) return;

        State s = STATE.get(proj.method_5667());
        if (s == null) {
            s = new State();
            s.bouncesLeft = MAX_BOUNCES;
            s.damage = proj.method_7448();
            s.alreadyHit = new HashSet<>();
            STATE.put(proj.method_5667(), s);
        }

        s.alreadyHit.add(hitTarget.method_5667());

        if (s.bouncesLeft <= 0) return;

        class_1309 next = findNextTarget(world, proj, hitTarget, s.alreadyHit);
        if (next == null) return;

        // Spawn a new projectile that continues the chain.
        class_1297 created = proj.method_5864().method_5883(world);
        if (!(created instanceof class_1665 nextProj)) return;

        nextProj.method_7432(proj.method_24921());
        nextProj.method_23327(proj.method_23317(), proj.method_23318(), proj.method_23321());

        class_243 from = proj.method_19538();
        class_243 to = next.method_19538().method_1031(0, next.method_5751() * 0.5, 0);
        class_243 dir = to.method_1020(from).method_1029();

        double speed = Math.max(0.6, proj.method_18798().method_1033());
        nextProj.method_18800(dir.field_1352 * speed, dir.field_1351 * speed, dir.field_1350 * speed);

        double newDamage = s.damage * DAMAGE_FACTOR;
        nextProj.method_7438(newDamage);

        // Carry state to the new projectile.
        State ns = new State();
        ns.bouncesLeft = s.bouncesLeft - 1;
        ns.damage = newDamage;
        ns.alreadyHit = new HashSet<>(s.alreadyHit);
        STATE.put(nextProj.method_5667(), ns);

        world.method_8649(nextProj);

        // Remove the old projectile to avoid double-hits.
        proj.method_31472();
        STATE.remove(proj.method_5667());
    }

    private static class_1309 findNextTarget(class_3218 world, class_1665 proj, class_1309 current, Set<UUID> alreadyHit) {
        class_238 box = new class_238(proj.method_23317() - SEARCH_RADIUS, proj.method_23318() - SEARCH_RADIUS, proj.method_23321() - SEARCH_RADIUS,
                proj.method_23317() + SEARCH_RADIUS, proj.method_23318() + SEARCH_RADIUS, proj.method_23321() + SEARCH_RADIUS);

        class_1309 best = null;
        double bestDist = Double.MAX_VALUE;
        for (class_1309 e : world.method_8390(class_1309.class, box, le -> {
            if (le == null || le.method_29504() || le.method_6032() <= 0) return false;
            if (le == current) return false;
            if (alreadyHit.contains(le.method_5667())) return false;
            if (proj.method_24921() != null && le == proj.method_24921()) return false;
            return true;
        })) {
            double d = e.method_5858(proj);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    private static void tickCleanup(MinecraftServer server) {
        if (STATE.isEmpty()) return;
        // Remove entries for projectiles that no longer exist.
        var it = STATE.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            UUID projId = e.getKey();
            boolean exists = false;
            for (class_3218 w : server.method_3738()) {
                if (w.method_14190(projId) != null) {
                    exists = true;
                    break;
                }
            }
            if (!exists) it.remove();
        }
    }
}
