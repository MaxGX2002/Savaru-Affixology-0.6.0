package com.savaru.savaru_affixes.ranged;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2378;
import net.minecraft.class_3218;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_7924;
import net.minecraft.class_8111;
import net.minecraft.server.MinecraftServer;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

/**
 * "釘箭": true-damage DoT that ignores armor/resistance.
 * - Every 10 ticks (0.5s) deal N damage (scaled 1..5)
 * - Base duration 200 ticks (10s)
 * - Duration stacks by adding more ticks
 */
public final class PinArrowHooks {

    private static final int PERIOD_TICKS = 10;
    private static final int BASE_DURATION_TICKS = 200;

    private static final class Active {
        int ticksLeft;
        int periodCounter;
        float dmgPerTick;
        UUID attacker;
    }

    private static final Map<UUID, Active> ACTIVE = new Object2ObjectOpenHashMap<>();

    private PinArrowHooks() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(PinArrowHooks::tick);
    }

    public static void applyOrExtend(class_1309 target, UUID attackerUuid, float dmgPerTick) {
        if (!(target.method_37908() instanceof class_3218)) return;
        UUID id = target.method_5667();
        Active a = ACTIVE.get(id);
        if (a == null) {
            a = new Active();
            a.periodCounter = PERIOD_TICKS;
            a.ticksLeft = 0;
            ACTIVE.put(id, a);
        }
        a.attacker = attackerUuid;
        a.dmgPerTick = Math.max(a.dmgPerTick, dmgPerTick);
        a.ticksLeft += BASE_DURATION_TICKS; // stack duration
    }

    private static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) return;

        // We can safely iterate and remove via iterator semantics.
        var it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            UUID targetId = e.getKey();
            Active a = e.getValue();

            class_1309 target = null;
            class_3218 foundWorld = null;
            for (class_3218 w : server.method_3738()) {
                var ent = w.method_14190(targetId);
                if (ent instanceof class_1309 le) {
                    target = le;
                    foundWorld = w;
                    break;
                }
            }

            if (target == null || target.method_29504() || target.method_6032() <= 0.0f) {
                it.remove();
                continue;
            }

            a.ticksLeft--;
            a.periodCounter--;

            if (a.periodCounter <= 0) {
                a.periodCounter = PERIOD_TICKS;

                class_1282 src;
                if (foundWorld != null) {
                    var reg = foundWorld.method_30349().method_30530(class_7924.field_42534);
                // OUT_OF_WORLD bypasses armor and most reductions; good fit for "無視抗性與防禦".
                var entry = reg.method_40290(class_8111.field_42347);
                    src = new class_1282(entry);
                } else {
                    // Fallback (should not happen)
                src = target.method_48923().method_48829();
                }

                target.method_5643(src, a.dmgPerTick);
            }

            if (a.ticksLeft <= 0) {
                it.remove();
            }
        }
    }
}
