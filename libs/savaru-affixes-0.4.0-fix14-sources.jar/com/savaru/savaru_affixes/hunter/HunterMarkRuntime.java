package com.savaru.savaru_affixes.hunter;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_3222;

/**
 * Spec:
 * - Hit marks target for 10s.
 * - While marked: +150% damage (2.5x total).
 * - Same target mark cooldown: 5s.
 */
public final class HunterMarkRuntime {
    private HunterMarkRuntime() {}

    private static final long MARK_TICKS = 20L * 10L;
    private static final long CD_TICKS   = 20L * 5L;

    private static final Map<UUID, Long> markedUntil = new HashMap<>();
    private static final Map<UUID, Long> cdUntil = new HashMap<>();

    public static double applyAndComputeMultiplier(class_3222 shooter, class_1309 target) {
        long now = shooter.method_37908().method_8510();
        UUID id = target.method_5667();

        // cleanup
        Long mu = markedUntil.get(id);
        if (mu != null && mu <= now) markedUntil.remove(id);
        Long cu = cdUntil.get(id);
        if (cu != null && cu <= now) cdUntil.remove(id);

        boolean alreadyMarked = markedUntil.containsKey(id);

        // If not marked (or expired), apply mark if not on cooldown — but do NOT grant the bonus on the marking hit.
        if (!alreadyMarked) {
            if (!cdUntil.containsKey(id)) {
                markedUntil.put(id, now + MARK_TICKS);
                cdUntil.put(id, now + CD_TICKS);
                // Visual marker: glowing 10s.
                target.method_6092(new class_1293(class_1294.field_5912, (int) MARK_TICKS, 0, false, false, true));
                // 1.21+ uses command tags (formerly "scoreboard tags").
                target.method_5780("savaru_hunter_mark");
            }
            return 1.0;
        }

        // Marked: +150% damage (2.5x). Refresh visual marker.
        target.method_6092(new class_1293(class_1294.field_5912, (int) MARK_TICKS, 0, false, false, true));
        target.method_5780("savaru_hunter_mark");
        return 2.5;
    }
}
