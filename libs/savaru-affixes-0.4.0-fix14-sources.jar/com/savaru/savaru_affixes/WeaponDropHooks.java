package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

public final class WeaponDropHooks {
    private WeaponDropHooks(){}

    public static void init() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity.method_37908() instanceof class_3218 world)) return;
            if (!(entity instanceof class_1309 living)) return;
            // Only mobs (exclude players)
            if (living.method_31747()) return;

            var random = living.method_59922();
            if (!RarityRoller.shouldDropAnyWeapon(random)) return;

            class_1799 stack = WeaponPool.randomWeapon(random);
            if (stack.method_7960()) return;

            // Mark as unidentified. The actual quality/affixes will be rolled when the player picks it up.
            UnidentifiedHandler.markUnidentified(stack);

            class_1542 item = new class_1542(world, living.method_23317(), living.method_23318(), living.method_23321(), stack);
            world.method_8649(item);
        });
    }
}
