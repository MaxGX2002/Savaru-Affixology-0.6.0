package com.savaru.savaru_affixes;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_3222;
import java.util.Map;
import java.util.UUID;

/**
 * "超量治療"：擊中目標時 5% 機率獲得 +2 額外生命（吸收值 / absorption），可疊到 +10，持續 2 秒。
 *
 * 實作方式：以 absorptionAmount 作為「額外生命」；用 tick 定時把我們加上的那一段扣回。
 */
public final class OverhealHooks {
    private static final class State {
        double ourAmount;
        long expiresAt;

        State(double ourAmount, long expiresAt) {
            this.ourAmount = ourAmount;
            this.expiresAt = expiresAt;
        }
    }

    private static final Map<UUID, State> STATES = new Object2ObjectOpenHashMap<>();

    private OverhealHooks() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            long now = server.method_30002().method_8510();
            // Iterate online players only.
            for (class_3222 p : server.method_3760().method_14571()) {
                State st = STATES.get(p.method_5667());
                if (st == null) continue;
                if (now <= st.expiresAt) continue;

                // Remove only our portion, keep any other absorption from other sources.
                double current = p.method_6067();
                double other = Math.max(0.0, current - st.ourAmount);
                p.method_6073((float) other);
                STATES.remove(p.method_5667());
            }
        });
    }

    public static void proc(class_3222 player) {
        long now = player.method_37908().method_8510();
        UUID id = player.method_5667();

        State st = STATES.get(id);
        double current = player.method_6067();
        double ourPrev = st == null ? 0.0 : st.ourAmount;
        double other = Math.max(0.0, current - ourPrev);

        double ourNew = Math.min(10.0, ourPrev + 2.0);
        player.method_6073((float) (other + ourNew));
        STATES.put(id, new State(ourNew, now + 40)); // 2s
    }
}
