
package com.savaru.savaru_affixes;

import net.minecraft.class_124;
import net.minecraft.class_2583;
import net.minecraft.class_5819;

public enum Rarity {
    COMMON, UNCOMMON, RARE, EPIC, LEGENDARY, MYTHIC, BEYOND, UNRIVALED;

    /**
     * Flat attack damage bonus per rarity (your spec).
     * Applied server-side in PlayerEntityAttackMixin so it works consistently on 1.21.1.
     */
    public double attackBonus() {
        return switch (this) {
            case COMMON -> 0.0;
            case UNCOMMON -> 0.5;
            case RARE -> 0.7;
            case EPIC -> 1.0;
            case LEGENDARY -> 2.0;
            case MYTHIC -> 3.0;
            case BEYOND -> 4.0;
            case UNRIVALED -> 5.0;
        };
    }

    /**
     * Flat armor value bonus per rarity (armor items only).
     */
    public double armorBonus() {
        return switch (this) {
            case COMMON    -> 0.0;
            case UNCOMMON  -> 1.0;
            case RARE      -> 2.0;
            case EPIC      -> 3.0;
            case LEGENDARY -> 4.0;
            case MYTHIC    -> 5.0;
            case BEYOND    -> 7.0;
            case UNRIVALED -> 10.0;
        };
    }

    public class_2583 style() {
        return switch (this) {
            case COMMON -> class_2583.field_24360.method_10977(class_124.field_1068);
            case UNCOMMON -> class_2583.field_24360.method_10977(class_124.field_1060);
            case RARE -> class_2583.field_24360.method_10977(class_124.field_1078);
            case EPIC -> class_2583.field_24360.method_10977(class_124.field_1076);
            case LEGENDARY -> class_2583.field_24360.method_10977(class_124.field_1065);
            case MYTHIC -> class_2583.field_24360.method_10977(class_124.field_1061).method_10982(true);
            case BEYOND -> class_2583.field_24360.method_10977(class_124.field_1054).method_10982(true);
            case UNRIVALED -> class_2583.field_24360.method_10977(class_124.field_1068).method_10982(true);
        };
    }

    /**
     * Optional dynamic styling for the highest tier.
     * Keeps lower tiers stable, while allowing a "rainbow" effect for UNRIVALED.
     */
    public class_2583 style(class_5819 rng) {
        // kept for compatibility; dynamic color is handled client-side for UNRIVALED
        return style();
    }

    public static Rarity roll(java.util.Random rng) {
        int x = rng.nextInt(1_000_000);
        if (x < 520_000) return COMMON;
        if (x < 760_000) return UNCOMMON;
        if (x < 900_000) return RARE;
        if (x < 970_000) return EPIC;
        if (x < 995_000) return LEGENDARY;
        if (x < 999_900) return MYTHIC;
        if (x < 999_990) return BEYOND;
        return UNRIVALED;
    }

    
    // Simple rainbow text helper for UNRIVALED visuals.
    
    public static net.minecraft.class_5250 rainbowText(String s) {
        // legacy (static rainbow)
        return rainbowTextDynamic(s, 0L);
    }

    public static net.minecraft.class_5250 rainbowTextDynamic(String s, long timeMs) {
        int[] colors = new int[] {
                0xFF5555, 0xFFAA00, 0xFFFF55, 0x55FF55, 0x55FFFF, 0x5555FF, 0xFF55FF
        };
        int shift = (int)((timeMs / 150L) % colors.length); // 150ms per step -> "flashing" rainbow
        net.minecraft.class_5250 out = net.minecraft.class_2561.method_43473();
        for (int i = 0; i < s.length(); i++) {
            int rgb = colors[(i + shift) % colors.length];
            out.method_10852(net.minecraft.class_2561.method_43470(String.valueOf(s.charAt(i)))
                    .method_10862(net.minecraft.class_2583.field_24360
                            .method_27703(net.minecraft.class_5251.method_27717(rgb))
                            .method_10982(true)));
        }
        return out;
    }

public static Rarity roll(class_5819 rng) {
        return roll(new java.util.Random(rng.method_43054()));
    }
}
