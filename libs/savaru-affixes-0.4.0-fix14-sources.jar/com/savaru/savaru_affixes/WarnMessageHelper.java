package com.savaru.savaru_affixes;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1657;
import net.minecraft.class_2561;

public final class WarnMessageHelper {
    private static final long COOLDOWN_MS = 900L;
    private static final Map<UUID, Long> LAST_SENT = new ConcurrentHashMap<>();

    private WarnMessageHelper() {}

    public static void send(class_1657 player, class_2561 text) {
        if (player == null) return;
        long now = System.currentTimeMillis();
        UUID id = player.method_5667();
        Long last = LAST_SENT.get(id);
        if (last != null && now - last < COOLDOWN_MS) return;
        LAST_SENT.put(id, now);
        player.method_7353(text, false);
    }
}
