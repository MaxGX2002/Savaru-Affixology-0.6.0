package com.savaru.savaru_affixes;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.server.MinecraftServer;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * "灼傷"：為了避開 vanilla 受傷無敵幀（hurtTime），不在同一 tick 追加第二段傷害，
 * 而是延遲 N ticks 後再打一次 magic 類型的傷害。
 *
 * 目標：呈現與 RPG class 類魔法武器接近的「魔法傷害性質」（不吃護甲，吃魔法相關減免）。
 */
public final class BurnHooks {

    private static final class Task {
        final UUID attacker;
        final int targetId;
        final class_3218 world;
        int delay;
        final float damage;

        Task(UUID attacker, class_3218 world, int targetId, int delay, float damage) {
            this.attacker = attacker;
            this.world = world;
            this.targetId = targetId;
            this.delay = delay;
            this.damage = damage;
        }
    }

    private static final List<Task> TASKS = new ObjectArrayList<>();

    private BurnHooks() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(BurnHooks::tick);
    }

    public static void queue(class_3218 world, class_1309 target, class_1657 attacker, int damage, int delayTicks) {
        if (world == null || target == null || attacker == null) return;
        if (damage <= 0) return;
        int dt = class_3532.method_15340(delayTicks, 1, 200);
        TASKS.add(new Task(attacker.method_5667(), world, target.method_5628(), dt, (float) damage));
    }
    /**
     * Queue a 2-second burn DOT that hits 4 times (every 10 ticks).
     * We start at +1 tick to avoid the melee hit's hurtTime eating the first tick.
     */
    public static void queueDot2s4Hits(class_3218 world, class_1309 target, class_1657 attacker, int damagePerHit) {
        if (world == null || target == null || attacker == null) return;
        if (damagePerHit <= 0) return;
        // 2 seconds = 40 ticks, 4 hits => every 10 ticks.
        int[] delays = new int[]{1, 11, 21, 31};
        for (int d : delays) {
            TASKS.add(new Task(attacker.method_5667(), world, target.method_5628(), d, (float) damagePerHit));
        }
    }


    private static void tick(MinecraftServer server) {
        if (TASKS.isEmpty()) return;

        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();

            // Drop tasks for worlds that are no longer loaded
            if (t.world == null) {
                it.remove();
                continue;
            }

            if (t.delay > 0) {
                t.delay--;
                continue;
            }

            class_1297 e = t.world.method_8469(t.targetId);
            if (!(e instanceof class_1309 living) || !living.method_5805()) {
                it.remove();
                continue;
            }

            class_1657 attacker = t.world.method_18470(t.attacker);
            if (attacker == null) {
                // Fallback: generic magic without attacker attribution.
                living.method_5643(t.world.method_48963().method_48831(), t.damage);
            } else {
                // Attribute the attacker while keeping magic nature.
                living.method_5643(attacker.method_48923().method_48815(attacker, attacker), t.damage);
            }

            it.remove();
        }
    }
}
