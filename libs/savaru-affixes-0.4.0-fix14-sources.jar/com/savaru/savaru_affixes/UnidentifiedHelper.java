package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_2487;
import net.minecraft.class_9362;

public final class UnidentifiedHelper {
    private UnidentifiedHelper() {}

    public static boolean hasFlag(class_1799 stack) {
        return UnidentifiedHandler.isUnidentified(stack);
    }

    public static boolean isAffixBook(class_1799 stack) {
        if (stack == null || stack.method_7960() || !stack.method_31574(class_1802.field_8529)) return false;
        try {
            class_2487 root = AffixHelper.getRoot(stack);
            return root != null && root.method_10545(AffixHelper.KEY_AFFIXES);
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isEquipment(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_1792 item = stack.method_7909();
        return item instanceof class_1738 || isWeaponOrTool(stack);
    }

    public static boolean isWeaponOrTool(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        class_1792 item = stack.method_7909();
        return item instanceof class_1829
                || item instanceof class_1743
                || item instanceof class_1810
                || item instanceof class_1821
                || item instanceof class_1794
                || item instanceof class_1835
                || item instanceof class_9362
                || item instanceof class_1753
                || item instanceof class_1764;
    }

    public static boolean shouldPrefixName(class_1799 stack) {
        return hasFlag(stack)
                && !isAffixBook(stack)
                && isEquipment(stack)
                && AffixHelper.getRarity(stack) == null;
    }

    public static boolean shouldBlockUse(class_1799 stack) {
        return hasFlag(stack)
                && !isAffixBook(stack)
                && isEquipment(stack)
                && AffixHelper.getRarity(stack) == null;
    }

    public static boolean isResolvedPreviewOutput(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (!hasFlag(stack)) return false;
        if (isAffixBook(stack)) return true;

        // 銘刻之証本身要保持未鑑定狀態，只在刻印到武器後才揭露內容。
        if (stack.method_31574(class_1802.field_8894) && InscriptionHelper.getInscription(stack) != null) {
            return false;
        }

        // 已經有品質 / 詞綴 / 銘刻資料的預覽輸出，拿到手後都應清掉 preview 狀態。
        if (AffixHelper.getRarity(stack) != null || !AffixHelper.getAffixes(stack).isEmpty()) {
            return true;
        }

        return InscriptionHelper.getInscription(stack) != null;
    }
}
