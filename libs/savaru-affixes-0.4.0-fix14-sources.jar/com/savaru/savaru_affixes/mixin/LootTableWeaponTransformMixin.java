package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.LootWeaponTransformer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_52;

@Mixin(class_52.class)
public abstract class LootTableWeaponTransformMixin {

    @SuppressWarnings("unchecked")
    @ModifyVariable(
            method = "generateUnprocessedLoot(Lnet/minecraft/loot/context/LootContext;Ljava/util/function/Consumer;)V",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private Consumer<class_1799> savaru$wrapLootConsumer(Consumer<class_1799> lootConsumer) {
        return stack -> lootConsumer.accept(LootWeaponTransformer.convertIfEligible(stack));
    }
}
