package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.inscription.InscriptionArrowRuntime;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import com.savaru.savaru_affixes.inscription.KagushimeiHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.class_1297;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_6089;

/**
 * Ensures projectile-side effects are applied during flight (not only after hit).
 * - Luminous arrow: glowing projectile
 */
@Mixin(class_1665.class)
public abstract class PersistentProjectileEntityTickMixin {

    /**
     * In newer versions PersistentProjectileEntity keeps track of the fired weapon.
     * Using it avoids effects breaking when the player swaps items after shooting.
     */
    @Shadow private class_1799 weapon;

    @Unique private final Deque<class_2338> savaru_affixes$lightTrail = new ArrayDeque<>();

    @Unique private static final int savaru_affixes$MAX_LIGHT_TRAIL = 12;


    @Inject(method = "tick", at = @At("HEAD"))
    private void savaru_affixes$applyProjectileFlightEffects(CallbackInfo ci) {
        class_1665 proj = (class_1665) (Object) this;

        // Only care on server (glowing gets synced); client-only doesn't need to decide.
        if (proj.method_37908().method_8608()) return;
        if (InscriptionArrowRuntime.shouldExpire(proj)) {
            InscriptionArrowRuntime.forget(proj);
            proj.method_31472();
            return;
        }

        class_1297 owner = proj.method_24921();
        if (!(owner instanceof class_3222 shooter)) return;

        class_1799 weapon = (this.weapon != null && !this.weapon.method_7960()) ? this.weapon : shooter.method_6047();
        if (!com.savaru.savaru_affixes.ranged.RangedAffixProcessor.isRangedWeapon(weapon)) return;

        if (AffixHelper.getRarity(weapon) == null) return;
        if (UnidentifiedHandler.isUnidentified(weapon)) return;

        if (AffixHelper.getAffixValue(weapon, "luminous_arrow") > 0.0) {
            proj.method_5834(true);
            savaru_affixes$placeLightAlongPath((class_3218) proj.method_37908(), proj.method_24515());
        }

        // ── Kagushimei: claim charge + soul-particle trail ──────────────
        if (InscriptionHelper.hasInscriptionId(weapon, "kagushimei")
                && owner instanceof class_3222 sp) {
            long now = ((class_3218) proj.method_37908()).method_8510();
            KagushimeiHooks.tryClaimCharge(sp, proj, now);
        }
        if (KagushimeiHooks.isChargedArrow(proj)) {
            ((class_3218) proj.method_37908()).method_14199(
                    net.minecraft.class_2398.field_23114,
                    proj.method_23317(), proj.method_23318(), proj.method_23321(),
                    2, 0.06, 0.06, 0.06, 0.0);
        }
    }

    /**
     * Cleanup hook for when the projectile is removed.
     *
     * Entity removal method names/signatures can shift across MC versions.
     * Keep these injections optional (require=0) so the mod won't hard-crash
     * if the target method doesn't exist at runtime.
     */
    @Inject(method = "remove(Lnet/minecraft/entity/Entity$RemovalReason;)V", at = @At("HEAD"), require = 0)
    private void savaru_affixes$cleanupLightTrail_onRemove(class_1297.class_5529 reason, CallbackInfo ci) {
        savaru_affixes$cleanupLightTrailCommon();
    }

    @Inject(method = "discard()V", at = @At("HEAD"), require = 0)
    private void savaru_affixes$cleanupLightTrail_onDiscard(CallbackInfo ci) {
        savaru_affixes$cleanupLightTrailCommon();
    }

    @Unique
    private void savaru_affixes$cleanupLightTrailCommon() {
        class_1665 proj = (class_1665) (Object) this;
        if (!(proj.method_37908() instanceof class_3218 sw)) return;

        while (!savaru_affixes$lightTrail.isEmpty()) {
            savaru_affixes$removeLightIfPresent(sw, savaru_affixes$lightTrail.removeFirst());
        }
    }

    @Unique
    private void savaru_affixes$placeLightAlongPath(class_3218 world, class_2338 pos) {
        // Only place on air; never overwrite real blocks.
        class_2680 existing = world.method_8320(pos);
        if (!existing.method_26215()) return;

        class_2680 light = class_2246.field_31037.method_9564();
        // Some mappings expose the LEVEL property on the LightBlock; set level=15 safely if present.
        if (light.method_28498(class_6089.field_31187)) {
            light = light.method_11657(class_6089.field_31187, 15);
        }

        world.method_8652(pos, light, class_2248.field_31028);
        savaru_affixes$lightTrail.addLast(pos.method_10062());

        // Keep a short trail; remove oldest to avoid littering the world.
        while (savaru_affixes$lightTrail.size() > savaru_affixes$MAX_LIGHT_TRAIL) {
            class_2338 old = savaru_affixes$lightTrail.removeFirst();
            savaru_affixes$removeLightIfPresent(world, old);
        }
    }

    @Unique
    private void savaru_affixes$removeLightIfPresent(class_3218 world, class_2338 pos) {
        class_2680 st = world.method_8320(pos);
        if (st.method_27852(class_2246.field_31037)) {
            world.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31028);
        }
    }
}
