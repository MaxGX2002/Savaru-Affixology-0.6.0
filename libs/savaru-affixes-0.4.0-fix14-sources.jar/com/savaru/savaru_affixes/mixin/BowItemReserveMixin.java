package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.ranged.RangedAffixProcessor;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_3218;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * "儲備": chance to refund an arrow after a shot.
 * Implementation note: we refund a normal arrow item. This avoids fragile local-capture across versions.
 */
@Mixin(class_1753.class)
public abstract class BowItemReserveMixin {

    @Inject(method = "onStoppedUsing", at = @At("TAIL"))
    private void savaru_affixes$refundArrow(class_1799 stack, net.minecraft.class_1937 world, class_1309 user, int remainingUseTicks, CallbackInfo ci) {
        if (!(world instanceof class_3218 sw)) return;
        if (!(user instanceof class_1657 player)) return;
        if (player.method_31549().field_7477) return;

        if (!RangedAffixProcessor.isRangedWeapon(stack)) return;
        if (AffixHelper.getRarity(stack) == null) return;
        if (UnidentifiedHandler.isUnidentified(stack)) return;

	    // Avoid duplication with Infinity.
	    // 1.21.1: use the world's registry manager to resolve the enchantment entry.
	    class_6880<class_1887> infinity = sw.method_30349()
	            .method_30530(class_7924.field_41265)
	            .method_40290(class_1893.field_9125);
	    if (class_1890.method_8225(infinity, stack) > 0) return;

        double pct = AffixHelper.getAffixValue(stack, "reserve"); // 10..30
        if (pct <= 0.0) return;

        double roll = sw.field_9229.method_43058() * 100.0;
        if (roll >= pct) return;

        class_1799 arrow = new class_1799(class_1802.field_8107, 1);
        if (!player.method_31548().method_7394(arrow)) {
            player.method_7328(arrow, false);
        }
    }
}
