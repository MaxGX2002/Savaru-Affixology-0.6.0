package com.savaru.savaru_affixes.mixin;

import net.minecraft.class_1665;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Exposes {@code PersistentProjectileEntity#asItemStack()} which is protected.
 * Used to read arrow ItemStack NBT for the arrow affix system.
 */
@Mixin(class_1665.class)
public interface PersistentProjectileEntityAccessor {

    @Invoker("asItemStack")
    class_1799 savaru$asItemStack();
}
