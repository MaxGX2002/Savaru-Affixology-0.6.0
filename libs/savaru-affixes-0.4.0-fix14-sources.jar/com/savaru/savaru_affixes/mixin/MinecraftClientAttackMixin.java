package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.UnidentifiedHelper;
import com.savaru.savaru_affixes.WarnMessageHelper;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class MinecraftClientAttackMixin {

    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$blockInvalidAttack(CallbackInfoReturnable<Boolean> cir) {
        class_310 client = (class_310) (Object) this;
        if (client.field_1724 == null) return;

        class_1799 stack = client.field_1724.method_6047();

        if (stack.method_7960()) {
            WarnMessageHelper.send(client.field_1724, class_2561.method_43470("請先裝備武器或工具").method_27692(class_124.field_1061));
            cir.setReturnValue(false);
            return;
        }

        if (UnidentifiedHelper.shouldBlockUse(stack)) {
            WarnMessageHelper.send(client.field_1724, class_2561.method_43470("這把武器尚未鑑定，無法使用").method_27692(class_124.field_1061));
            cir.setReturnValue(false);
        }
    }
}
