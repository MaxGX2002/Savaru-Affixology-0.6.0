package com.savaru.savaru_affixes.mixin;

import net.minecraft.class_1665;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1665.class)
public interface PersistentProjectileEntityInvoker {
    @Invoker("setPierceLevel")
    void savaru_affixes$invokeSetPierceLevel(byte level);
}
