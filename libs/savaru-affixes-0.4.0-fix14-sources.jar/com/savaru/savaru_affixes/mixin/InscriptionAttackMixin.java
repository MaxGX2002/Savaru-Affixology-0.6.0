package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.api.SoulbindAccess;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import com.savaru.savaru_affixes.inscription.JingtinFistHooks;
import com.savaru.savaru_affixes.inscription.InscriptionRuntime;
import com.savaru.savaru_affixes.inscription.StarflowHooks;
import com.savaru.savaru_affixes.BurnHooks;
import com.savaru.savaru_affixes.AffixHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5134;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

@Mixin(class_1657.class)
public abstract class InscriptionAttackMixin {

    private static final double INV_SQRT2 = 1.0 / class_3532.field_15724;
    private static final class_243[] BAFENG_DIRECTIONS = new class_243[]{
            new class_243(0,0,-1),
            new class_243(0,0,1),
            new class_243(1,0,0),
            new class_243(-1,0,0),
            new class_243(INV_SQRT2,0,-INV_SQRT2),
            new class_243(-INV_SQRT2,0,-INV_SQRT2),
            new class_243(INV_SQRT2,0,INV_SQRT2),
            new class_243(-INV_SQRT2,0,INV_SQRT2)
    };

    private static class_2487 getOrCreateCustomData(class_1799 stack) {
        class_9279 comp = stack.method_57824(class_9334.field_49628);
        if (comp != null && comp.method_57463() != null) return comp.method_57463().method_10553();
        return new class_2487();
    }

    private static void setCustomData(class_1799 stack, class_2487 root) {
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(root));
    }

    private static class_2487 getOrCreateInsState(class_2487 root) {
        if (!root.method_10545("savaru_ins_state")) root.method_10566("savaru_ins_state", new class_2487());
        return root.method_10562("savaru_ins_state");
    }

    private static boolean cdReady(class_2487 state, String key, long now) {
        long next = state.method_10537(key);
        return now >= next;
    }

    private static void setCd(class_2487 state, String key, long next) {
        state.method_10544(key, next);
    }

    @Inject(method = "attack(Lnet/minecraft/entity/Entity;)V", at = @At("TAIL"))
    private void savaru$inscriptionPostHit(class_1297 target, CallbackInfo ci) {
        class_1657 self = (class_1657) (Object) this;
        if (!(target instanceof class_1309 living)) return;

        // Apply game effects only on server.
        if (self.method_37908().field_9236) return;

        class_1799 weapon = self.method_6047();
        if (weapon.method_7960()) return;

        class_2487 ins = InscriptionHelper.getInscription(weapon);
        if (ins == null) return;

        String id = ins.method_10558("id");
        if (id == null || id.isEmpty()) return;

        long now = self.method_37908().method_8510();

        class_2487 root = getOrCreateCustomData(weapon);
        class_2487 state = getOrCreateInsState(root);

        switch (id) {
            case "blossom" -> {
                if (!cdReady(state, "blossom_cd", now)) break;
                if (self.method_37908().field_9229.method_43057() < 0.50f) {
                    self.method_6092(new class_1293(class_1294.field_5926, 20 * 5, 1));
                    self.method_6092(new class_1293(class_1294.field_5907, 20 * 5, 2));
                    self.method_6092(new class_1293(class_1294.field_5914, 20 * 5, 1));
                    setCd(state, "blossom_cd", now + 20 * 10);
                }
            }
            case "blackflash" -> {
                if (!cdReady(state, "blackflash_cd", now)) break;
                if (self.method_37908().field_9229.method_43057() < 0.001f) {
                    // /kill-like: force death, then apply after-effects.
                    living.method_6033(0.0f);
                    living.method_5643(living.method_48923().method_48829(), 9999.0f);
                    if (!living.method_29504()) living.method_5768();

                    self.method_6092(new class_1293(class_1294.field_5910, 20 * 60, 1));
                    self.method_6033(self.method_6063());

                    // +100% damage for 60s (stack duration)
                    if (self instanceof net.minecraft.class_3222 sp) {
                        InscriptionRuntime.extendBlackflashBuff(sp, sp.method_51469().method_8510(), 60 * 20);
                    }
                    setCd(state, "blackflash_cd", now + 20 * 10);
                }
            }
            case "truefocus" -> {
                int tid = living.method_5628();
                int lastTid = state.method_10550("tf_tid");
                int cnt = state.method_10550("tf_cnt");
                if (tid != lastTid) cnt = 0;
                cnt++;
                if (cnt >= 4) {
                    cnt = 0;
                    float base = (float) self.method_45325(class_5134.field_23721);
                    float dmg = base * 5.0f;
                    // "True" magic damage (RPG style)
                    InscriptionRuntime.magicTrueDamage(living, dmg);
                    if (self.method_37908() instanceof class_3218 sw) {
                        sw.method_14199(class_2398.field_11205, living.method_23317(), living.method_23323(0.5), living.method_23321(), 12, 0.25, 0.25, 0.25, 0.1);
                    }
                }
                state.method_10569("tf_tid", tid);
                state.method_10569("tf_cnt", cnt);
            }
            case "jingtin_fist" -> {
                // 逕庭拳：目標具備任一負面狀態時，啟動每 0.5 秒一次的固定魔法傷害（忽略護甲/抗性）
                if (living.method_6059(class_1294.field_5899)
                        || living.method_6059(class_1294.field_5920)
                        || living.method_6059(class_1294.field_5909)
                        || living.method_6059(class_1294.field_38092)
                        || living.method_6059(class_1294.field_5916)
                        || living.method_6059(class_1294.field_5911)) {
                    JingtinFistHooks.activate(living);
                }
            }
            case "soulbind" -> {
                // 定魂：20% 機率定身 5 秒（用極高緩速模擬），冷卻 10 秒
                if (cdReady(state, "soulbind_cd", now)) {
                    if (self.method_37908().field_9229.method_43057() < 0.20f) {
                        living.method_6092(new class_1293(class_1294.field_5909, 20 * 5, 255, false, true, true));
                        // 移速直接變 0：比只有緩速更接近「定身」
                        if ((Object) living instanceof SoulbindAccess acc) {
                            acc.savaru$setSoulbindUntil(living.method_37908().method_8510() + (20L * 5L));
                        }
                        setCd(state, "soulbind_cd", now + 20 * 10);
                    }
                }
            }
            case "senlingpoison" -> {
                if (self.method_37908().field_9229.method_43057() < 0.20f) {
                    int dur = 20 * 20;
                    class_1293 cur = living.method_6112(class_1294.field_5899);
                    if (cur != null) dur += cur.method_5584();
                    living.method_6092(new class_1293(class_1294.field_5899, dur, 2));
                    if (living.method_6112(class_1294.field_5899) == null) {
                        living.method_6092(new class_1293(class_1294.field_5924, dur, 2));
                        if (living.method_6112(class_1294.field_5924) == null) {
                            living.method_6092(new class_1293(class_1294.field_5920, dur, 2));
                            if (living.method_6112(class_1294.field_5920) == null) {
                                living.method_6092(new class_1293(class_1294.field_5921, 1, 2));
                            }
                        }
                    }
                }
            }
            case "bafengshen" -> {
    // 八風神：每兩下觸發一次（風爆 + 世界固定八向）
    int cnt = state.method_10550("bafeng_cnt") + 1;
    if (cnt < 2) {
        state.method_10569("bafeng_cnt", cnt);
        break;
    }
    state.method_10569("bafeng_cnt", 0);

    // 風爆：擊退主目標
    class_243 away = living.method_19538().method_1020(self.method_19538());
    if (away.method_1027() > 1.0e-6) {
        away = away.method_1029();
        living.method_5762(away.field_1352 * 0.6, 0.15, away.field_1350 * 0.6);
        living.field_6037 = true;
    }

    if (self.method_37908() instanceof class_3218 sw) {
        final double range = 16.0;
        final double radius = 1.25;

        for (class_243 baseDir : BAFENG_DIRECTIONS) {
            class_243 dir = baseDir.method_1029();
            class_1309 hit = findFirstLivingInRay(sw, self, dir, range, radius);
            if (hit == null) continue;

            sw.method_8437(self, hit.method_23317(), hit.method_23323(0.5), hit.method_23321(), 0.0f, class_3218.ExplosionSourceType.field_40888);
            hit.method_5643(sw.method_48963().method_48819(self, self), 50.0f);
            sw.method_14199(class_2398.field_47494, hit.method_23317(), hit.method_23323(0.5), hit.method_23321(), 6, 0.2, 0.2, 0.2, 0.01);
        }
    }
}

            case "charge" -> {
                // 充能（重製）：常駐 75%，每2秒+75%（最多450%）；任意命中後重置
                int pct = InscriptionRuntime.getChargePct(self.method_5667());
                if (pct < 0) pct = 0;

                float base = (float) self.method_45325(class_5134.field_23721);
                float extra = base * (pct / 100.0f);

                boolean ok = living.method_5643(self.method_48923().method_48802(self), extra);
                if (!ok) {
                    InscriptionRuntime.magicTrueDamage(living, extra);
                }

                // reset after dealing damage
                InscriptionRuntime.setChargeState(self.method_5667(), InscriptionRuntime.getChargeFingerprint(self.method_5667()), 0, now + 40);
            }
            case "sunmoon_corridor" -> {
                // 日月迴廊：每第二下攻擊追加 150%（魔法）傷害；若有魔劍詞綴則改為 150% 無視抗性防禦傷害
                int hits = state.method_10550("sm_hits") + 1;

                if (hits >= 2) {
                    hits = 0;

                    float base = (float) self.method_45325(class_5134.field_23721);
                    float dmg = base * 1.50f;

                    boolean hasArcblade = AffixHelper.getAffixValue(weapon, "arcblade") > 0.0;
                    if (hasArcblade) {
                        InscriptionRuntime.magicTrueDamage(living, dmg);
                    } else {
                        // RPGCLASS-like magic hit
                        boolean ok = living.method_5643(self.method_48923().method_48815(self, self), dmg);
                        if (!ok) {
                            // ensure visibility if invulnerability frames eat it
                            InscriptionRuntime.magicTrueDamage(living, dmg);
                        }
                    }
                }

                state.method_10569("sm_hits", hits);
            }
            case "starflow" -> {
                // 星流七連：不受傷情況下連續擊殺 5 個目標啟動；後續由 tick 狀態機推進
                if (self instanceof class_3222 sp) {
                    UUID pid = sp.method_5667();
                    long lastHurt = InscriptionRuntime.getStarLastHurt(pid);
                    if (lastHurt + 1 >= now) {
                        InscriptionRuntime.resetStarflow(pid);
                        break;
                    }

                    int stage = InscriptionRuntime.getStarStage(pid);

                    // Stage-specific on-hit / next-hit actions
                    if (stage == 1 && InscriptionRuntime.consumeStarNextDot(pid)) {
                        // Apply DOT to target and schedule stage2 transition at (dot end +10s)
                        StarflowHooks.startDot((class_3218) self.method_37908(), living, sp);
                        InscriptionRuntime.setStarTransitionAt(pid, now + (15 * 20) + (10 * 20));
                        InscriptionRuntime.sendTitle(sp, "星流：一連");
                        sp.method_7353(net.minecraft.class_2561.method_43470("星流：一連"), false);
                    } else if (stage == 2 && InscriptionRuntime.consumeStarNext350(pid)) {
                        float base = (float) self.method_45325(class_5134.field_23721);
                        float dmg = base * 3.50f;
                        living.method_5643(sp.method_48923().method_48815(sp, sp), dmg);
                        // After 10s -> Stage3 (next-hit arrows)
                        InscriptionRuntime.setStarStage(pid, 3);
                        InscriptionRuntime.setStarNextArrows(pid, true);
                        InscriptionRuntime.setStarTransitionAt(pid, 0);
                        // schedule nothing; stage3 is next hit, but requires 10s wait per spec
                        class_2487 s = state;
                        long readyAt = now + 10 * 20;
                        s.method_10544("star3_readyAt", readyAt);
                    } else if (stage == 3) {
                        long readyAt = state.method_10537("star3_readyAt");
                        if (readyAt > 0 && now < readyAt) break;
                        if (InscriptionRuntime.consumeStarNextArrows(pid)) {
                            // Fire 70 arrows in 360 degrees, damage ~2
                            if (self.method_37908() instanceof class_3218 sw) {
                                for (int i = 0; i < 70; i++) {
                                    double yaw = (i / 70.0) * (Math.PI * 2.0);
                                    class_243 dir = new class_243(Math.cos(yaw), 0.02, Math.sin(yaw)).method_1029();
                                    class_1667 arrow = net.minecraft.class_1299.field_6122.method_5883(sw);
                                    if (arrow == null) continue;
                                    arrow.method_7432(sp);
                                    arrow.method_23327(sp.method_23317(), sp.method_23320() - 0.1, sp.method_23321());
                                    arrow.method_18800(dir.field_1352 * 1.6, dir.field_1351 * 1.6, dir.field_1350 * 1.6);
                                    arrow.method_7438(2.0);
                                    arrow.method_7439(true);
                                    sw.method_8649(arrow);
                                }
                                sw.method_8396(null, sp.method_24515(), class_3417.field_14600, class_3419.field_15248, 1.0f, 1.0f);
                            }
                            // Immediately enter stage4 (20s resistance + levitate on hit)
                            InscriptionRuntime.setStarStage(pid, 4);
                            sp.method_6092(new class_1293(class_1294.field_5907, 20 * 20, 2, false, true, true));
                            InscriptionRuntime.setStarLevitateUntil(pid, now + 20 * 20);
                            InscriptionRuntime.setStarTransitionAt(pid, now + 20 * 20);
                            InscriptionRuntime.sendTitle(sp, "星矢：三連");
                        sp.method_7353(net.minecraft.class_2561.method_43470("星矢：三連"), false);
                            InscriptionRuntime.sendTitle(sp, "星沉：四連");
                        sp.method_7353(net.minecraft.class_2561.method_43470("星沉：四連"), false);
                            state.method_10544("star3_readyAt", 0L);
                        }
                    } else if (stage == 4) {
                        // levitate on hit while active
                        if (now <= InscriptionRuntime.getStarLevitateUntil(pid)) {
                            living.method_6092(new class_1293(class_1294.field_5902, 20 * 2, 0, false, true, true));
                        }
                    } else if (stage == 6) {
                        // burn on hit for 10s
                        if (self.method_37908() instanceof class_3218 sw) {
                            if (now <= InscriptionRuntime.getStarBurnUntil(pid)) {
                                int burnDmg = AffixHelper.getAffixLevel(weapon, "burn");
                                if (burnDmg <= 0) burnDmg = 3;
                                BurnHooks.queueDot2s4Hits(sw, living, self, burnDmg);
                                living.method_5639(2);
                            }
                        }
                    } else if (stage == 7 && InscriptionRuntime.consumeStarNextFinal(pid)) {
                        InscriptionRuntime.magicTrueDamage(living, 200.0);
                        InscriptionRuntime.resetStarflow(pid);
                    }

                    // Kill detection to START chain (stage==0)
                    if (!living.method_5805()) {
                        if (stage == 0) {
                            int k = InscriptionRuntime.addStarKill(pid);
                            if (k >= 5) {
                                InscriptionRuntime.resetStarKills(pid);
                                InscriptionRuntime.setStarStage(pid, 1);
                                InscriptionRuntime.setStarNextDot(pid, true);
                                InscriptionRuntime.setStarTransitionAt(pid, 0);
                                InscriptionRuntime.sendTitle(sp, "星流：一連");
                        sp.method_7353(net.minecraft.class_2561.method_43470("星流：一連"), false);
                            }
                        }
                    }
                }
            }
            case "heaven_inverted_spear" -> {
                // 天逆鉾：攻擊目標清除其身上所有效果（正負皆清）
                living.method_6012();
            }

            default -> { }
        }

        root.method_10566("savaru_ins_state", state);
        setCustomData(weapon, root);
    }

    private static class_1309 findFirstLivingInRay(class_3218 world, class_1657 player, class_243 dir, double range, double radius) {
        class_243 start = player.method_33571();
        class_238 box = new class_238(start, start).method_1009(range, 3.0, range);

        class_1309 best = null;
        double bestT = range + 1.0;

        for (class_1297 e : world.method_8335(player, box)) {
            if (!(e instanceof class_1309 le)) continue;
            if (!le.method_5805()) continue;

            class_243 to = le.method_33571().method_1020(start);
            double t = to.method_1026(dir);
            if (t <= 0.0 || t > range) continue;

            class_243 perp = to.method_1020(dir.method_1021(t));
            if (perp.method_1027() > radius * radius) continue;

            if (t < bestT) {
                bestT = t;
                best = le;
            }
        }
        return best;
    }
}