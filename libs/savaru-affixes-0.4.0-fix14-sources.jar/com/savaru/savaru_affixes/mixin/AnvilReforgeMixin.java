package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.Affix;
import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.AffixRegistry;
import com.savaru.savaru_affixes.Rarity;
import com.savaru.savaru_affixes.RarityRoller;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.PreviewHelper;
import com.savaru.savaru_affixes.IdentificationHelper;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;
import net.minecraft.class_1657;
import net.minecraft.class_1706;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_3915;
import net.minecraft.class_5819;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * Anvil reforging rules (per your latest spec):
 * - Anvil + (affixed weapon) + Nether Star: reroll ONE random affix, keep the rest.
 *   Costs 100 levels. Also consumes 100 durability on the weapon. Rarity & durability buffs remain.
 * - Anvil + (affixed weapon) + Dragon's Breath: reroll rarity.
 *   Costs 200 levels. Weapon durability loses 30% of max. Keep 1-2 affixes, reroll the rest.
 */
@Mixin(class_1706.class)
public abstract class AnvilReforgeMixin {

    @Shadow @Final private class_3915 levelCost;

    // In vanilla, the anvil consumes the right item by repairItemUsage when taking output.
    @Shadow private int repairItemUsage;

    @Inject(method = "updateResult", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$updateResult(CallbackInfo ci) {
        class_1706 self = (class_1706) (Object) this;

        class_1799 left = self.method_7611(0).method_7677();
        class_1799 right = self.method_7611(1).method_7677();

        if (left.method_7960() || right.method_7960()) return;

        // allow PAPER (鑑定券), BOOK (affix book), WEAPON, ARMOR, and BLAZE_ROD (inscription proofs)
        if (!left.method_31574(class_1802.field_8407) && !left.method_31574(class_1802.field_8529) && !left.method_31574(class_1802.field_8894) && !AffixHelper.isWeapon(left) && !AffixHelper.isArrowItem(left) && !AffixHelper.isArmorItem(left)) return;

        class_1799 out = class_1799.field_8037;
        int cost = 0;

        // ---- Identification Ticket (鑑定券) ----
        if (left.method_31574(class_1802.field_8407) && right.method_31574(class_1802.field_8687)) {
            int craftCount = Math.min(left.method_7947(), right.method_7947());
            out = IdentificationHelper.makeTicket(craftCount);
            cost = craftCount;
        }
        // ---- Identify weapon without rerolling via ticket ----
        else if (IdentificationHelper.canIdentifyWeapon(left) && IdentificationHelper.isTicket(right)) {
            out = IdentificationHelper.identify(left);
            UnidentifiedHandler.markUnidentified(out);
            setPreviewName(out, buildPreviewName(out, AffixHelper.getRarity(out)));
            cost = 15;
        }

        // ---- Inscription Proofs (銘刻之証) ----
// Blaze Rod + Dragon's Breath -> Outland proof (cost 1000 levels)
if (left.method_31574(class_1802.field_8894) && right.method_31574(class_1802.field_8613)) {
    out = makeInscriptionProof(InscriptionHelper.TYPE_OUTLAND, left);
    cost = 1000;
}
// Blaze Rod + Ghast Tear -> Secret proof (cost 500 levels)
else if (left.method_31574(class_1802.field_8894) && right.method_31574(class_1802.field_8070)) {
    out = makeInscriptionProof(InscriptionHelper.TYPE_SECRET, left);
    cost = 500;
}
// Weapon + proof -> apply inscription (cost depends on type)
else if (!left.method_31574(class_1802.field_8529) && isInscriptionProof(right)) {
    String type = getProofType(right);
    Rarity r = AffixHelper.getRarity(left);
    if (r == null) return;
    if (!InscriptionHelper.isAllowedWeapon(left)) return;
    out = left.method_7972();
    String insId = getProofId(right);

    // If the proof was rolled from the wrong weapon family (old generic proof behavior),
    // reroll it into a compatible inscription from the same type pool for the target weapon.
    if (!InscriptionHelper.isIdCompatibleWithWeapon(insId, left)) {
        java.util.List<String> compatiblePool = InscriptionHelper.getPoolFor(type, left);
        if (compatiblePool.isEmpty()) return;
        insId = compatiblePool.get(new java.util.Random().nextInt(compatiblePool.size()));
    }

    if (!InscriptionHelper.canApplyToWeapon(type, r, left, insId)) return;

    InscriptionHelper.setInscription(out, type, insId);
    UnidentifiedHandler.markUnidentified(out);
    setPreviewName(out, buildInscriptionPreviewName(out, insId));
    cost = InscriptionHelper.TYPE_OUTLAND.equals(type) ? 1000 : 500;
}

// ---- Affix Transfer (詞綴轉移) ----

        // Step A: Book + Ghast Tear -> "詞綴之書" with 1-2 random affixes. Cost 30 levels.
        if (left.method_31574(class_1802.field_8529) && right.method_31574(class_1802.field_8070)) {
            out = makeAffixBook();
            cost = 30;
        }
        // Step B: Legendary+ weapon/armor + "詞綴之書" -> write affixes into item. Cost 30 levels.
        else if (!left.method_31574(class_1802.field_8529) && isAffixBook(right)) {
            Rarity r = AffixHelper.getRarity(left);
            if (r == null) return;
            if (r.ordinal() < Rarity.LEGENDARY.ordinal()) return;

            out = applyAffixBook(left, right);
            if (!out.method_7960()) UnidentifiedHandler.markUnidentified(out);
            cost = 30;
        }

        if (out.method_7960()) {
        // Only actual weapons/arrows/armor can use reroll materials. Books must use the dedicated affix-book recipe.
        if (!AffixHelper.isWeapon(left) && !AffixHelper.isArrowItem(left) && !AffixHelper.isArmorItem(left)) {
            return;
        }
        if (right.method_31574(class_1802.field_8137)) {
            // needs existing Savaru data
            if (AffixHelper.getRarity(left) == null) return;
            if (AffixHelper.getAffixes(left).isEmpty()) return;
            out = makeReforgeOneAffix(left);
            cost = 100;
        } else if (right.method_31574(class_1802.field_8301)) {
            // reroll quality for any weapon
            out = makeRerollRarity(left, false);
            cost = 200;
        } else if (right.method_31574(class_1802.field_8613)) {
            // reroll quality (epic+ guaranteed)
            out = makeRerollRarity(left, true);
            cost = 200;
        } else {
            return;
        }
        }

        if (out.method_7960()) {
            self.method_7611(2).method_53512(class_1799.field_8037);
            this.levelCost.method_17404(0);
            this.repairItemUsage = 0;
            ci.cancel();
            return;
        }

        self.method_7611(2).method_53512(out);
        this.levelCost.method_17404(cost);
        this.repairItemUsage = 1;
        ci.cancel();
    }


    @Inject(method = "onTakeOutput", at = @At("HEAD"))
    private void savaru_affixes$finalizeInscriptionTake(class_1657 player, class_1799 stack, CallbackInfo ci) {
        if (stack == null || stack.method_7960()) return;

        class_1706 self = (class_1706) (Object) this;
        class_1799 left = self.method_7611(0).method_7677();
        class_1799 right = self.method_7611(1).method_7677();

        if (left.method_7960() || right.method_7960()) return;
        if (!AffixHelper.isWeapon(left)) return;
        if (!isInscriptionProof(right)) return;
        if (InscriptionHelper.getInscription(stack) == null) return;

        // Preview in slot 2 should stay obfuscated, but once taken the inscription must be visible immediately.
        UnidentifiedHandler.clearUnidentified(stack);
        PreviewHelper.clearPreviewName(stack);
    }

    @Inject(method = "onTakeOutput", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$consumeTicketRecipe(class_1657 player, class_1799 stack, CallbackInfo ci) {
        if (!IdentificationHelper.isTicket(stack)) return;

        class_1706 self = (class_1706) (Object) this;
        class_1799 left = self.method_7611(0).method_7677();
        class_1799 right = self.method_7611(1).method_7677();

        if (!left.method_31574(class_1802.field_8407) || !right.method_31574(class_1802.field_8687)) return;

        int craftCount = Math.min(left.method_7947(), right.method_7947());
        if (craftCount <= 0) return;

        class_1799 out = stack.method_7972();
        out.method_7939(craftCount);

        self.method_7611(2).method_53512(class_1799.field_8037);
        left.method_7934(craftCount);
        right.method_7934(craftCount);
        if (left.method_7960()) self.method_7611(0).method_53512(class_1799.field_8037);
        if (right.method_7960()) self.method_7611(1).method_53512(class_1799.field_8037);

        player.method_7316(-this.levelCost.method_17407());

        if (!player.method_31548().method_7394(out)) {
            player.method_7328(out, false);
        }

        this.levelCost.method_17404(0);
        this.repairItemUsage = 0;
        self.method_24928();
        ci.cancel();
    }

    // ---- helpers (ported from previous smithing implementation) ----

    private static class_1799 makeReforgeOneAffix(class_1799 base) {
        if (base.method_7963() && base.method_7936() > 0) {
            int newDamage = base.method_7919() + 100;
            if (newDamage >= base.method_7936()) return class_1799.field_8037;
        }

        class_1799 out = base.method_7972();
        if (out.method_7963() && out.method_7936() > 0) {
            out.method_7974(out.method_7919() + 100);
        }

        class_5819 rnd = class_5819.method_43047();
        reforgeSingleAffixInPlace(out, rnd);

        Rarity r = AffixHelper.getRarity(out);
        if (r != null) AffixHelper.applyRarityNameColor(out, r);

        // Hide result in preview until taken
        UnidentifiedHandler.markUnidentified(out);
        setPreviewName(out, buildPreviewName(out, r));
        return out;
    }

    private static class_1799 makeRerollRarity(class_1799 base, boolean epicPlusOnly) {
        if (base.method_7963() && base.method_7936() > 0) {
            int cost = Math.max(1, (int) Math.round(base.method_7936() * 0.30));
            int newDamage = base.method_7919() + cost;
            if (newDamage >= base.method_7936()) return class_1799.field_8037;
        }

        class_1799 out = base.method_7972();
        if (out.method_7963() && out.method_7936() > 0) {
            int cost = Math.max(1, (int) Math.round(out.method_7936() * 0.30));
            out.method_7974(out.method_7919() + cost);
        }

        class_5819 rnd = class_5819.method_43047();
        Rarity newR;
        if (epicPlusOnly) {
            // Epic 74%, Legendary 25%, Beyond 0.99%, Unrivaled 0.01%
            newR = RarityRoller.rollByWeights(rnd, new double[]{0.0, 0.0, 0.0, 74.0, 25.0, 0.0, 0.99, 0.01});
        } else {
            // Common 50%, Uncommon 40%, Rare 8%, Epic 1.9%, Legendary 0.09%, Beyond 0.009%, Unrivaled 0.001%
            newR = RarityRoller.rollByWeights(rnd, new double[]{50.0, 40.0, 8.0, 1.9, 0.09, 0.0, 0.009, 0.001});
        }

        // If no affixes exist yet, generate them. Otherwise keep 1-2 and reroll the rest.
        if (AffixHelper.getAffixes(out).isEmpty()) {
            AffixHelper.setRarity(out, newR);
            AffixHelper.rollAffixes(out, newR);
        } else {
            rerollAffixesKeepSome(out, newR, rnd);
        }
        AffixHelper.applyRarityNameColor(out, newR);
        forceSetRarityName(out, newR);

        // Hide result in preview until taken
        UnidentifiedHandler.markUnidentified(out);
        setPreviewName(out, buildPreviewName(out, newR));
        return out;
    }

    private static void forceSetRarityName(class_1799 stack, Rarity rarity) {
        if (stack == null || rarity == null) return;
        String prefix = switch (rarity) {
            case COMMON -> "普通";
            case UNCOMMON -> "罕見";
            case RARE -> "稀有";
            case EPIC -> "史詩";
            case LEGENDARY -> "傳說";
            case MYTHIC -> "神話";
            case BEYOND -> "超乎想像";
            case UNRIVALED -> "無與倫比";
        };

        String name = stack.method_7964().getString();
        for (String p : new String[]{"普通", "罕見", "稀有", "史詩", "傳說", "神話", "超乎想像", "無與倫比"}) {
            String head = p + "的 ";
            if (name.startsWith(head)) {
                name = name.substring(head.length());
                break;
            }
        }

        String full = prefix + "的 " + name;
        stack.method_57379(class_9334.field_49631, class_2561.method_43470(full).method_10862(rarity.style()));
    }

    private static void rerollAffixesKeepSome(class_1799 stack, Rarity newR, class_5819 rnd) {
        class_2499 existing = AffixHelper.getAffixes(stack);
        List<class_2487> old = new ArrayList<>();
        for (int i = 0; i < existing.size(); i++) old.add(existing.method_10602(i).method_10553());

        int keepCount = Math.min(old.size(), 1 + rnd.method_43048(2));
        Collections.shuffle(old, new java.util.Random(rnd.method_43055()));

        List<class_2487> kept = old.subList(0, keepCount);

        int target = getAffixCountForRarity(newR, rnd);
        if (target < kept.size()) {
            kept = kept.subList(0, target);
        }

        Set<String> used = new HashSet<>();
        class_2499 outList = new class_2499();
        for (class_2487 c : kept) {
            used.add(c.method_10558("id"));
            outList.add(c);
        }

        List<Affix> pool = filteredPoolForStack(stack, used);

        int guard = 0;
        while (outList.size() < target && !pool.isEmpty() && guard++ < 512) {
            Affix pick = weightedPick(pool, rnd);
            pool.remove(pick);
            if (used.contains(pick.id())) continue;
            if (!passesMutualExclusion(pick.id(), used)) continue;

            double value = invokeRollValueByRarity(pick, newR, rnd);
            class_2487 entry = new class_2487();
            entry.method_10582("id", pick.id());
            entry.method_10549("value", value);

            if ("wither".equals(pick.id()) || "weakness".equals(pick.id()) || "frailty".equals(pick.id())) {
                entry.method_10569("level", 1 + rnd.method_43048(2));
            }
            if ("res_pen_flat".equals(pick.id()) || "res_pen_pct".equals(pick.id())) {
                entry.method_10569("level", 1 + rnd.method_43048(3));
            }
            if ("durability_bonus".equals(pick.id())) {
                int extra = Math.max(1, (int) Math.round(stack.method_7936() * (value / 100.0)));
                entry.method_10569("buf", extra);
            }

            used.add(pick.id());
            outList.add(entry);
        }

        // Use AffixHelper to initialize/normalize root then overwrite
        AffixHelper.rollAffixes(stack, newR);
        class_2487 root2 = getRootDirect(stack);
        if (root2 != null) {
            root2.method_10582("rarity", newR.name());
            root2.method_10566("affixes", outList);
            setRootDirect(stack, root2);
        }
    }

    private static void reforgeSingleAffixInPlace(class_1799 stack, class_5819 rnd) {
        Rarity rarity = AffixHelper.getRarity(stack);
        if (rarity == null) return;
        class_2499 list = AffixHelper.getAffixes(stack);
        if (list.isEmpty()) return;

        int idx = rnd.method_43048(list.size());
        Set<String> used = new HashSet<>();
        for (int i = 0; i < list.size(); i++) {
            if (i == idx) continue;
            used.add(list.method_10602(i).method_10558("id"));
        }

        List<Affix> pool = filteredPoolForStack(stack, used);

        Affix pick = null;
        int guard = 0;
        while (pick == null && guard++ < 512 && !pool.isEmpty()) {
            Affix cand = weightedPick(pool, rnd);
            pool.remove(cand);
            if (!passesMutualExclusion(cand.id(), used)) continue;
            pick = cand;
        }
        if (pick == null) return;

        double value = invokeRollValueByRarity(pick, rarity, rnd);
        class_2487 entry = new class_2487();
        entry.method_10582("id", pick.id());
        entry.method_10549("value", value);

        if ("wither".equals(pick.id()) || "weakness".equals(pick.id()) || "frailty".equals(pick.id())) {
            entry.method_10569("level", 1 + rnd.method_43048(2));
        }
        if ("res_pen_flat".equals(pick.id()) || "res_pen_pct".equals(pick.id())) {
            entry.method_10569("level", 1 + rnd.method_43048(3));
        }
        if ("durability_bonus".equals(pick.id())) {
            int extra = Math.max(1, (int) Math.round(stack.method_7936() * (value / 100.0)));
            entry.method_10569("buf", extra);
        }

        list.method_10606(idx, entry);

        class_2487 root = getRootDirect(stack);
        if (root == null) root = new class_2487();
        root.method_10582("rarity", rarity.name());
        root.method_10566("affixes", list);
        setRootDirect(stack, root);
    }

    private static boolean passesMutualExclusion(String pickId, Set<String> used) {
        Set<String> armorPen = Set.of("armor_pen_flat", "armor_pen_pct");
        Set<String> resPen = Set.of("res_pen_flat", "res_pen_pct");
        Set<String> health = Set.of("max_hp_pct", "cur_hp_pct", "execute_flat", "execute_pct");
        Set<String> dot = Set.of("wither", "weakness", "frailty", "lifesteal");
        Set<String> healing = Set.of("lifesteal", "overheal");
        Set<String> durability = Set.of("durability_bonus", "durability_nocost");

        if ("true_damage".equals(pickId) && used.stream().anyMatch(armorPen::contains)) return false;
        if (armorPen.contains(pickId) && used.contains("true_damage")) return false;

        if (resPen.contains(pickId)) {
            if (used.contains("true_damage") || used.stream().anyMatch(armorPen::contains) || used.stream().anyMatch(resPen::contains)) return false;
        }
        if (armorPen.contains(pickId) && used.stream().anyMatch(resPen::contains)) return false;
        if ("true_damage".equals(pickId) && used.stream().anyMatch(resPen::contains)) return false;

        if (health.contains(pickId)) {
            for (String g : health) {
                if (!g.equals(pickId) && used.contains(g)) return false;
            }
        }
        if (("max_hp_pct".equals(pickId) || "cur_hp_pct".equals(pickId)) && used.contains("bonus_damage")) return false;
        if ("bonus_damage".equals(pickId) && (used.contains("max_hp_pct") || used.contains("cur_hp_pct"))) return false;

        if (dot.contains(pickId)) {
            for (String g : dot) {
                if (!g.equals(pickId) && used.contains(g)) return false;
            }
        }
        if (healing.contains(pickId)) {
            for (String g : healing) {
                if (!g.equals(pickId) && used.contains(g)) return false;
            }
        }
        if (durability.contains(pickId)) {
            for (String g : durability) {
                if (!g.equals(pickId) && used.contains(g)) return false;
            }
        }
        return true;
    }

    private static int getAffixCountForRarity(Rarity rarity, class_5819 rnd) {
        int min, max;
        switch (rarity) {
            case COMMON -> { min = 0; max = 1; }
            case UNCOMMON -> { min = 1; max = 2; }
            case RARE -> { min = 1; max = 2; }
            case EPIC -> { min = 2; max = 3; }
            case LEGENDARY -> { min = 3; max = 4; }
            case MYTHIC -> { min = 4; max = 5; }
            case BEYOND -> { min = 6; max = 7; }
            case UNRIVALED -> { min = 6; max = 7; }
            default -> { min = 1; max = 1; }
        }
        return min + rnd.method_43048(max - min + 1);
    }

    private static Affix weightedPick(List<Affix> pool, class_5819 rnd) {
        int total = 0;
        for (Affix a : pool) total += Math.max(1, a.weight());
        int roll = rnd.method_43048(Math.max(1, total));
        int acc = 0;
        for (Affix a : pool) {
            acc += Math.max(1, a.weight());
            if (roll < acc) return a;
        }
        return pool.get(pool.size() - 1);
    }

    private static double invokeRollValueByRarity(Affix affix, Rarity rarity, class_5819 rnd) {
        double base = affix.min() + (affix.max() - affix.min()) * rnd.method_43058();
        if ("max_hp_pct".equals(affix.id()) || "poison_aoe".equals(affix.id())) return base;

        double mult;
        switch (rarity) {
            case COMMON -> mult = 0.35;
            case UNCOMMON -> mult = 0.55;
            case RARE -> mult = 0.75;
            case EPIC -> mult = 0.90;
            default -> mult = 1.00;
        }
        return base * mult;
    }

    private static class_2487 getRootDirect(class_1799 stack) {
        try {
            var comp = stack.method_57825(class_9334.field_49628, net.minecraft.class_9279.field_49302);
            class_2487 all = comp.method_57461();
            return all.method_10573("savaru_affixes", 10) ? all.method_10562("savaru_affixes") : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static void setRootDirect(class_1799 stack, class_2487 root) {
        var comp = stack.method_57825(class_9334.field_49628, net.minecraft.class_9279.field_49302);
        class_2487 all = comp.method_57461();
        all.method_10566("savaru_affixes", root);
        stack.method_57379(class_9334.field_49628, net.minecraft.class_9279.method_57456(all));
    }
    // ---- Affix Book helpers ----

    private static final String BOOK_TYPE_KEY = "book_type";

    private static String stackAffixTypeKey(class_1799 stack) {
        if (stack == null || stack.method_7960()) return "weapon";
        if (AffixHelper.isArrowItem(stack)) return "arrow";
        if (AffixHelper.isArmorItem(stack)) return "armor";
        if (stack.method_7909() instanceof class_1753 || stack.method_7909() instanceof class_1764) return "ranged";
        return "weapon";
    }

    private static List<Affix> filteredPoolForStack(class_1799 stack, Set<String> used) {
        String type = stackAffixTypeKey(stack);
        List<Affix> pool = new ArrayList<>(AffixRegistry.getAll());
        pool.removeIf(a -> !affixBookTypeKey(a.id()).equals(type));
        if (used != null && !used.isEmpty()) {
            pool.removeIf(a -> used.contains(a.id()));
        }
        return pool;
    }


    private static String affixBookTypeKey(String affixId) {
        // Armor affixes
        if (affixId.startsWith("armor_")) return "armor";
        return switch (affixId) {
            case "magic_arrow", "luminous_arrow", "piercing_path", "draw_speed", "lifeshot", "hunter_mark", "finisher_shot", "ricochet", "pin_arrow", "reserve" -> "ranged";
            case "arrow_damage_boost", "arrow_effect_level_boost", "arrow_effect_duration_boost" -> "arrow";
            default -> "weapon";
        };
    }

    private static class_2561 affixBookName(String type) {
        return switch (type) {
            case "ranged" -> class_2561.method_43471("item.savaru_affixes.affix_book_ranged");
            case "arrow" -> class_2561.method_43471("item.savaru_affixes.affix_book_arrow");
            case "armor" -> class_2561.method_43471("item.savaru_affixes.affix_book_armor");
            default -> class_2561.method_43471("item.savaru_affixes.affix_book_weapon");
        };
    }

    private static boolean isAffixBook(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (!stack.method_31574(class_1802.field_8529)) return false;

        try {
            if (stack.method_57826(class_9334.field_49631)) {
                class_2561 t = stack.method_57824(class_9334.field_49631);
                if (t != null && (t.getString().startsWith("詞綴之書") || t.getString().equals(class_2561.method_43471("item.savaru_affixes.affix_book_weapon").getString()) || t.getString().equals(class_2561.method_43471("item.savaru_affixes.affix_book_ranged").getString()) || t.getString().equals(class_2561.method_43471("item.savaru_affixes.affix_book_arrow").getString()) || t.getString().equals(class_2561.method_43471("item.savaru_affixes.affix_book_armor").getString()))) return true;
            }
        } catch (Exception ignored) {}

        try {
            class_2487 root = AffixHelper.getRoot(stack);
            return root != null && root.method_10545(AffixHelper.KEY_AFFIXES);
        } catch (Exception ignored) {}

        return false;
    }

    private static class_1799 makeAffixBook() {
        class_5819 rnd = class_5819.method_43047();
        AffixRegistry.init();

        class_1799 book = new class_1799(class_1802.field_8529);

        String bookType = switch (rnd.method_43048(4)) {
            case 1 -> "ranged";
            case 2 -> "arrow";
            case 3 -> "armor";
            default -> "weapon";
        };

        List<Affix> pool = new ArrayList<>(AffixRegistry.getAll());
        pool.removeIf(a -> !affixBookTypeKey(a.id()).equals(bookType));
        Collections.shuffle(pool, new java.util.Random(rnd.method_43055()));

        int count = "arrow".equals(bookType) ? 1 : (1 + rnd.method_43048(2));
        Set<String> used = new HashSet<>();

        class_2499 affixes = new class_2499();
        for (Affix a : pool) {
            if (affixes.size() >= count) break;
            if (used.contains(a.id())) continue;

            // basic mutual exclusions for book pick
            if (("berserk".equals(a.id()) && used.contains("greedlife")) || ("greedlife".equals(a.id()) && used.contains("berserk"))) continue;
            if (("arcblade".equals(a.id()) && used.contains("berserk")) || ("berserk".equals(a.id()) && used.contains("arcblade"))) continue;
            if (("burn".equals(a.id()) && (used.contains("poison_aoe") || used.contains("wither")))) continue;
            if (("poison_aoe".equals(a.id()) && (used.contains("burn") || used.contains("wither")))) continue;
            if (("wither".equals(a.id()) && (used.contains("burn") || used.contains("poison_aoe")))) continue;
            if (("devour".equals(a.id()) && used.contains("lifesteal")) || ("lifesteal".equals(a.id()) && used.contains("devour"))) continue;

            used.add(a.id());

            double value = a.min();
            double max = a.max();
            if (max > value) value = value + (rnd.method_43058() * (max - value));

            class_2487 entry = new class_2487();
            entry.method_10582(AffixHelper.KEY_ID, a.id());
            entry.method_10549(AffixHelper.KEY_VALUE, value);

            if ("wither".equals(a.id()) || "weakness".equals(a.id()) || "frailty".equals(a.id())) {
                entry.method_10569(AffixHelper.KEY_LEVEL, 1 + rnd.method_43048(3));
            } else if ("burn".equals(a.id()) || "devour".equals(a.id())) {
                entry.method_10569(AffixHelper.KEY_LEVEL, 1 + rnd.method_43048(5));
            } else {
                entry.method_10569(AffixHelper.KEY_LEVEL, 0);
            }

            affixes.add(entry);
        }

        class_2487 root = new class_2487();
        if (affixes.isEmpty()) {
            List<Affix> fallbackPool = new ArrayList<>(AffixRegistry.getAll());
            fallbackPool.removeIf(a -> !affixBookTypeKey(a.id()).equals(bookType));
            if (fallbackPool.isEmpty()) return class_1799.field_8037;

            Affix pick = fallbackPool.get(rnd.method_43048(fallbackPool.size()));
            class_2487 aff = new class_2487();
            aff.method_10582(AffixHelper.KEY_ID, pick.id());
            aff.method_10549(AffixHelper.KEY_VALUE, pick.min());
            aff.method_10569(AffixHelper.KEY_LEVEL, 0);
            affixes.add(aff);
        }

        root.method_10566(AffixHelper.KEY_AFFIXES, affixes);
        root.method_10582(BOOK_TYPE_KEY, bookType);

        AffixHelper.setRoot(book, root);
        book.method_57379(class_9334.field_49631, affixBookName(bookType));
        UnidentifiedHandler.markUnidentified(book);
        return book;
    }

    private static boolean isBookTypeCompatible(String bookType, class_1799 stack) {
        return switch (bookType) {
            case "ranged" -> "ranged".equals(stackAffixTypeKey(stack));
            case "arrow" -> "arrow".equals(stackAffixTypeKey(stack));
            case "armor" -> "armor".equals(stackAffixTypeKey(stack));
            default -> "weapon".equals(stackAffixTypeKey(stack));
        };
    }

    private static boolean affixMatchesBookType(String bookType, String affixId) {
        return affixBookTypeKey(affixId).equals(bookType);
    }

private static class_1799 applyAffixBook(class_1799 weapon, class_1799 book) {
    if (weapon == null || weapon.method_7960()) return class_1799.field_8037;

    class_2487 rootBook = AffixHelper.getRoot(book);
    if (rootBook == null || !rootBook.method_10545(AffixHelper.KEY_AFFIXES)) return class_1799.field_8037;
    class_2499 bookAffixes = rootBook.method_10554(AffixHelper.KEY_AFFIXES, 10);
    if (bookAffixes.isEmpty()) return class_1799.field_8037;

    String bookType = rootBook.method_10545(BOOK_TYPE_KEY) ? rootBook.method_10558(BOOK_TYPE_KEY) : "weapon";
    if (!isBookTypeCompatible(bookType, weapon)) return class_1799.field_8037;

    class_1799 out = weapon.method_7972();
    Rarity r = AffixHelper.getRarity(out);
    if (r == null) return class_1799.field_8037;

    // Prepare weapon affix list
    class_2499 weaponAffixes = AffixHelper.getAffixes(out);

    final boolean overwriteMode = (r == Rarity.LEGENDARY || r == Rarity.MYTHIC);
    // LEGENDARY / MYTHIC: overwrite only N affixes (N = book affix count), keep the rest
    // BEYOND (超乎想像 / 無與倫比): append/merge by id
    if (overwriteMode) {
        // Ensure list has at least N slots
        for (int i = 0; i < bookAffixes.size(); i++) {
            class_2487 e = bookAffixes.method_10602(i);
            String id = e.method_10558(AffixHelper.KEY_ID);
            if (!affixMatchesBookType(bookType, id)) continue;
            double v = e.method_10574(AffixHelper.KEY_VALUE);
            int lvl = e.method_10545(AffixHelper.KEY_LEVEL) ? e.method_10550(AffixHelper.KEY_LEVEL) : 0;

            // enforce mutual exclusions at write-time (skip if conflicts)
            if ("berserk".equals(id) && AffixHelper.getAffixValue(out, "greedlife") > 0.0) continue;
            if ("greedlife".equals(id) && AffixHelper.getAffixValue(out, "berserk") > 0.0) continue;
            if ("arcblade".equals(id) && AffixHelper.getAffixValue(out, "berserk") > 0.0) continue;
            if ("berserk".equals(id) && AffixHelper.getAffixValue(out, "arcblade") > 0.0) continue;

            if ("burn".equals(id) && (AffixHelper.getAffixValue(out, "poison_aoe") > 0.0 || AffixHelper.getAffixValue(out, "wither") > 0.0)) continue;
            if ("wither".equals(id) && (AffixHelper.getAffixValue(out, "burn") > 0.0 || AffixHelper.getAffixValue(out, "poison_aoe") > 0.0)) continue;
            if ("poison_aoe".equals(id) && (AffixHelper.getAffixValue(out, "burn") > 0.0 || AffixHelper.getAffixValue(out, "wither") > 0.0)) continue;

            if ("devour".equals(id) && AffixHelper.getAffixValue(out, "lifesteal") > 0.0) continue;
            if ("lifesteal".equals(id) && AffixHelper.getAffixValue(out, "devour") > 0.0) continue;

            class_2487 entry = new class_2487();
            entry.method_10582(AffixHelper.KEY_ID, id);
            entry.method_10549(AffixHelper.KEY_VALUE, v);
            entry.method_10569(AffixHelper.KEY_LEVEL, lvl);

            if (i < weaponAffixes.size()) {
                weaponAffixes.method_10606(i, entry);
            } else {
                weaponAffixes.add(entry);
            }
        }

        class_2487 rootW = AffixHelper.getRoot(out);
        if (rootW == null) rootW = new class_2487();
        rootW.method_10566(AffixHelper.KEY_AFFIXES, weaponAffixes);
        AffixHelper.setRoot(out, rootW);

    } else {
        // BEYOND: merge by id (append/replace)
        for (int i = 0; i < bookAffixes.size(); i++) {
            class_2487 e = bookAffixes.method_10602(i);
            String id = e.method_10558(AffixHelper.KEY_ID);
            if (!affixMatchesBookType(bookType, id)) continue;
            double v = e.method_10574(AffixHelper.KEY_VALUE);
            int lvl = e.method_10545(AffixHelper.KEY_LEVEL) ? e.method_10550(AffixHelper.KEY_LEVEL) : 0;

            // enforce mutual exclusions at write-time
            if ("berserk".equals(id) && AffixHelper.getAffixValue(out, "greedlife") > 0.0) continue;
            if ("greedlife".equals(id) && AffixHelper.getAffixValue(out, "berserk") > 0.0) continue;
            if ("arcblade".equals(id) && AffixHelper.getAffixValue(out, "berserk") > 0.0) continue;
            if ("berserk".equals(id) && AffixHelper.getAffixValue(out, "arcblade") > 0.0) continue;

            if ("burn".equals(id) && (AffixHelper.getAffixValue(out, "poison_aoe") > 0.0 || AffixHelper.getAffixValue(out, "wither") > 0.0)) continue;
            if ("wither".equals(id) && (AffixHelper.getAffixValue(out, "burn") > 0.0 || AffixHelper.getAffixValue(out, "poison_aoe") > 0.0)) continue;
            if ("poison_aoe".equals(id) && (AffixHelper.getAffixValue(out, "burn") > 0.0 || AffixHelper.getAffixValue(out, "wither") > 0.0)) continue;

            if ("devour".equals(id) && AffixHelper.getAffixValue(out, "lifesteal") > 0.0) continue;
            if ("lifesteal".equals(id) && AffixHelper.getAffixValue(out, "devour") > 0.0) continue;

            AffixHelper.putOrReplaceAffix(out, id, v, lvl);
        }
    }

    AffixHelper.applyRarityNameColor(out, r);
    UnidentifiedHandler.markUnidentified(out);
    setPreviewName(out, buildPreviewName(out, r));
    return out;
}




// ---- Inscription helper methods (銘刻之証) ----
private static class_1799 makeInscriptionProof(String type, class_1799 previewWeapon) {
    class_1799 out = new class_1799(class_1802.field_8894);
    java.util.Random rnd = new java.util.Random();
    java.util.List<String> pool = InscriptionHelper.TYPE_SECRET.equals(type)
            ? InscriptionHelper.SECRET_POOL
            : InscriptionHelper.OUTLAND_POOL;
    if (pool.isEmpty()) return class_1799.field_8037;
    String id = pool.get(rnd.nextInt(pool.size()));
    String target = InscriptionHelper.getTargetForId(id);
    if (id == null || id.isEmpty() || target == null) return class_1799.field_8037;

    if (InscriptionHelper.TYPE_OUTLAND.equals(type)) {
        if (InscriptionHelper.TARGET_RANGED.equals(target)) {
            out.method_57379(class_9334.field_49631, class_2561.method_43471("item.savaru_affixes.inscription_proof_outland_ranged").method_27692(net.minecraft.class_124.field_1076));
        } else {
            out.method_57379(class_9334.field_49631, class_2561.method_43471("item.savaru_affixes.inscription_proof_outland_melee").method_27692(net.minecraft.class_124.field_1076));
        }
    } else {
        if (InscriptionHelper.TARGET_RANGED.equals(target)) {
            out.method_57379(class_9334.field_49631, class_2561.method_43471("item.savaru_affixes.inscription_proof_secret_ranged").method_27692(net.minecraft.class_124.field_1075));
        } else {
            out.method_57379(class_9334.field_49631, class_2561.method_43471("item.savaru_affixes.inscription_proof_secret_melee").method_27692(net.minecraft.class_124.field_1075));
        }
    }

    // store inscription on the rod itself
    InscriptionHelper.setInscription(out, type, id);

    // 預覽階段就要是亂碼（與武器未鑑定規則一致）
    UnidentifiedHandler.markUnidentified(out);
    return out;
}

private static boolean isInscriptionProof(class_1799 stack) {
    if (stack == null || stack.method_7960()) return false;
    if (!stack.method_31574(class_1802.field_8894)) return false;
    var ins = InscriptionHelper.getInscription(stack);
    return ins != null && ins.method_10545("type") && ins.method_10545("id");
}

private static String getProofType(class_1799 stack) {
    var ins = InscriptionHelper.getInscription(stack);
    return ins == null ? "" : ins.method_10558("type");
}

private static String getProofId(class_1799 stack) {
    var ins = InscriptionHelper.getInscription(stack);
    return ins == null ? "" : ins.method_10558("id");
}

private static void setPreviewName(class_1799 stack, String name) {
    PreviewHelper.setPreviewName(stack, name);
}

private static String cleanBaseName(class_1799 stack) {
    if (stack == null || stack.method_7960()) return "";
    class_2561 custom = stack.method_57824(class_9334.field_49631);
    if (custom != null) return custom.getString();
    return stack.method_7909().method_7864(stack).getString();
}

private static String rarityPrefix(Rarity rarity) {
    if (rarity == null) return "";
    return switch (rarity) {
        case COMMON -> "普通";
        case UNCOMMON -> "罕見";
        case RARE -> "稀有";
        case EPIC -> "史詩";
        case LEGENDARY -> "傳說";
        case MYTHIC -> "神話";
        case BEYOND -> "超乎想像";
        case UNRIVALED -> "無與倫比";
    };
}

private static String buildPreviewName(class_1799 stack, Rarity rarity) {
    String prefix = rarityPrefix(rarity);
    String base = cleanBaseName(stack);
    if (prefix.isBlank()) return base;
    return prefix + " " + base;
}

private static String buildInscriptionPreviewName(class_1799 stack, String inscriptionId) {
    String insName;
    try {
        insName = class_2561.method_43471("inscription.savaru_affixes." + inscriptionId).getString();
    } catch (Exception e) {
        insName = inscriptionId;
    }
    if (insName == null || insName.isBlank() || insName.startsWith("inscription.savaru_affixes.")) {
        insName = inscriptionId;
    }
    return "銘刻：" + insName + " " + cleanBaseName(stack);
}


}
