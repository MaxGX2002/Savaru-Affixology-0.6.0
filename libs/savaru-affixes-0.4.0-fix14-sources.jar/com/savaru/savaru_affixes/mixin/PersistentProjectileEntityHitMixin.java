package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.arrow.ArrowAffixProcessor;
import com.savaru.savaru_affixes.ranged.PinArrowHooks;
import com.savaru.savaru_affixes.ranged.RicochetHooks;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3966;
import com.savaru.savaru_affixes.ranged.RangedAffixProcessor;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import com.savaru.savaru_affixes.inscription.SpringRainHooks;
import com.savaru.savaru_affixes.inscription.HundredBlossomsHooks;
import com.savaru.savaru_affixes.inscription.DistantThunderHooks;
import com.savaru.savaru_affixes.inscription.MimicArrowHooks;
import com.savaru.savaru_affixes.inscription.DetonationHooks;
import com.savaru.savaru_affixes.inscription.ThunderfireCannonHooks;
import com.savaru.savaru_affixes.inscription.KagushimeiHooks;
import com.savaru.savaru_affixes.inscription.ChidoriHooks;
import com.savaru.savaru_affixes.inscription.InscriptionArrowRuntime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_1665.class)
public abstract class PersistentProjectileEntityHitMixin {

    @Shadow private class_1799 weapon;

    @Unique private class_243 savaru_affixes$preHitVelocity;

    @Inject(method = "onEntityHit(Lnet/minecraft/util/hit/EntityHitResult;)V", at = @At("HEAD"))
    private void savaru_affixes$captureVelocity(class_3966 hitResult, CallbackInfo ci) {
        class_1665 proj = (class_1665) (Object) this;
        savaru_affixes$preHitVelocity = proj.method_18798();
    }

    @ModifyArgs(
            method = "onEntityHit(Lnet/minecraft/util/hit/EntityHitResult;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/Entity;damage(Lnet/minecraft/entity/damage/DamageSource;F)Z"
            )
    )
    private void savaru_affixes$modifyRangedDamage(Args args, class_3966 hitResult) {
        class_1665 proj = (class_1665) (Object) this;

        if (SpringRainHooks.isManagedProjectile(proj) || HundredBlossomsHooks.isManagedProjectile(proj) || InscriptionArrowRuntime.isManaged(proj)) return;
        if (!(args.get(0) instanceof class_1282 src)) return;
        class_1297 attacker = src.method_5529();
        if (!(attacker instanceof class_3222 shooter)) return;

        class_1297 hit = hitResult.method_17782();
        if (!(hit instanceof class_1309 target)) return;

        class_1799 weapon = (this.weapon != null && !this.weapon.method_7960()) ? this.weapon : shooter.method_6047();
        if (!RangedAffixProcessor.isRangedWeapon(weapon)) return;

        if (AffixHelper.getRarity(weapon) == null) return;
        if (UnidentifiedHandler.isUnidentified(weapon)) return;

        // Luminous arrow: make projectile glow
        if (AffixHelper.getAffixValue(weapon, "luminous_arrow") > 0.0) {
            proj.method_5834(true);
        }

        // Piercing path: ensure piercing is enabled
        if (AffixHelper.getAffixValue(weapon, "piercing_path") > 0.0) {
            ((PersistentProjectileEntityInvoker) (Object) proj).savaru_affixes$invokeSetPierceLevel((byte) 127);
        }

        float original = (float) args.get(1);
        if (original <= 0f) return;

        RangedAffixProcessor.Result r0 = RangedAffixProcessor.apply(shooter, target, weapon, original);

        // Arrow-only damage boost: read from projectile stack (separate pool from weapon).
        double arrowMult = 1.0;
        try {
            class_1799 arrowStack = ((PersistentProjectileEntityAccessor) (Object) proj).savaru$asItemStack();
            arrowMult = ArrowAffixProcessor.getArrowDamageMultiplier(arrowStack);
        } catch (Throwable ignored) {}

        RangedAffixProcessor.Result r = new RangedAffixProcessor.Result(
                (float) (r0.damage() * arrowMult),
                r0.overrideSource()
        );

        if (r.overrideSource() != null) {
            args.set(0, r.overrideSource());
        }
        args.set(1, r.damage());

        // Magic arrow: force the hit to count as magic damage (match Arcblade's "indirectMagic" behavior).
        if (AffixHelper.getAffixValue(weapon, "magic_arrow") > 0.0 || InscriptionHelper.hasInscriptionId(weapon, "mimic_arrow")) {
            args.set(0, shooter.method_48923().method_48815(proj, shooter));
            if (shooter.method_37908() instanceof class_3218 sw) { MimicArrowHooks.prepareProjectile(sw, proj); }
        }

        // Hunter mark: make the target easy to track (glowing) when it gets marked.
        // (The damage multiplier is handled inside RangedAffixProcessor.)
        if (AffixHelper.getAffixValue(weapon, "hunter_mark") > 0.0 && shooter.method_37908() instanceof class_3218) {
            target.method_6092(new class_1293(class_1294.field_5912, 20 * 10, 0, true, false, true));
        }

        // Piercing path: decay next-hit damage by 15-30%
        double decayPct = AffixHelper.getAffixValue(weapon, "piercing_path");
        if (decayPct > 0.0) {
            double decay01 = Math.min(0.30, Math.max(0.15, decayPct / 100.0));
            proj.method_7438(proj.method_7448() * (1.0 - decay01));

            // Prevent unwanted "rebound" / reflection behavior by restoring the pre-hit velocity.
            if (savaru_affixes$preHitVelocity != null) {
                proj.method_18799(savaru_affixes$preHitVelocity);
                proj.field_6037 = true;
            }
        }
    }

    @Inject(method = "onEntityHit(Lnet/minecraft/util/hit/EntityHitResult;)V", at = @At("TAIL"))
    private void savaru_affixes$afterEntityHit(class_3966 hitResult, CallbackInfo ci) {
        class_1665 proj = (class_1665) (Object) this;
        class_1297 hit = hitResult.method_17782();
        if (!(hit instanceof class_1309 target)) return;

        class_1297 ownerE = proj.method_24921();
        class_1309 owner = ownerE instanceof class_1309 le ? le : null;

        if (SpringRainHooks.handleSpecialArrowHit(proj, target) || HundredBlossomsHooks.handleSpecialArrowHit(proj, target)) {
            return;
        }

        if (!(target.method_37908() instanceof class_3218 sw)) return;

        class_1799 weapon = (this.weapon != null && !this.weapon.method_7960()) ? this.weapon : (owner != null ? owner.method_6047() : class_1799.field_8037);
        if (!RangedAffixProcessor.isRangedWeapon(weapon)) return;
        if (AffixHelper.getRarity(weapon) == null) return;
        if (UnidentifiedHandler.isUnidentified(weapon)) return;

        // ---- Pin Arrow (釘箭) ----
        double pinPct = AffixHelper.getAffixValue(weapon, "pin_arrow"); // 5..15
        if (pinPct > 0.0) {
            double roll = sw.field_9229.method_43058() * 100.0;
            if (roll < pinPct) {
                double t = (pinPct - 5.0) / 10.0;
                if (t < 0.0) t = 0.0;
                if (t > 1.0) t = 1.0;
                float dmgPerTick = (float) (1.0 + t * 4.0);
                PinArrowHooks.applyOrExtend(target, owner != null ? owner.method_5667() : null, dmgPerTick);
            }
        }

        // ---- Ricochet (彈射) ----
        if (AffixHelper.getAffixValue(weapon, "ricochet") > 0.0) {
            RicochetHooks.onHit(proj, target);
        }

        if (InscriptionHelper.hasInscriptionId(weapon, "spring_rain") && owner instanceof class_3222) {
            SpringRainHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "hundred_blossoms") && owner instanceof class_3222) {
            HundredBlossomsHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "detonation") && owner instanceof class_3222) {
            DetonationHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "mimic_arrow") && owner instanceof class_3222) {
            MimicArrowHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "distant_thunder") && owner instanceof class_3222) {
            DistantThunderHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "thunderfire_cannon") && owner instanceof class_3222) {
            ThunderfireCannonHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "kagushimei") && owner instanceof class_3222) {
            KagushimeiHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "chidori") && owner instanceof class_3222) {
            ChidoriHooks.onBowHit(sw, proj, target, weapon, owner);
        }
    }
}
