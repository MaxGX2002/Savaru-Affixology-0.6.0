package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.inscription.InscriptionArrowRuntime;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1665.class)
public abstract class PersistentProjectileEntityPickupMixin {
    @Inject(method = "onPlayerCollision", at = @At("HEAD"), cancellable = true, require = 0)
    private void savaru$blockInscriptionArrowPickup(class_1657 player, CallbackInfo ci) {
        class_1665 proj = (class_1665) (Object) this;
        if (InscriptionArrowRuntime.shouldBlockPickup(proj, player)) {
            ci.cancel();
        }
    }
}
