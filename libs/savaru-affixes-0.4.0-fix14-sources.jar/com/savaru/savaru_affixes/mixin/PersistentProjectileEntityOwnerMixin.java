package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.ranged.RangedAffixProcessor;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ensure ranged projectiles remember the weapon used to fire them.
 * This fixes cases where the shooter swaps items before the arrow hits.
 */
@Mixin(class_1665.class)
public abstract class PersistentProjectileEntityOwnerMixin {

    @Shadow private class_1799 weapon;

    @Inject(method = "setOwner", at = @At("HEAD"))
    private void savaru_affixes$captureWeapon(class_1297 owner, CallbackInfo ci) {
        if (this.weapon != null && !this.weapon.method_7960()) return;
        if (!(owner instanceof class_1309 le)) return;

        class_1799 main = le.method_6047();
        class_1799 off = le.method_6079();
        if (RangedAffixProcessor.isRangedWeapon(main)) {
            this.weapon = main.method_7972();
        } else if (RangedAffixProcessor.isRangedWeapon(off)) {
            this.weapon = off.method_7972();
        }
    }
}
