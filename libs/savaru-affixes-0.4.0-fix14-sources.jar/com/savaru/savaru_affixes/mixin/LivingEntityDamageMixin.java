package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.armor.ArmorAffixProcessor;
import com.savaru.savaru_affixes.armor.ArmorEffectRuntime;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1677;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityDamageMixin {

    private static final ThreadLocal<Boolean> SAVARU_REDUCING = ThreadLocal.withInitial(() -> false);

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$applyArmorAffixReductions(
            class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {

        if (SAVARU_REDUCING.get()) return;

        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().method_8608()) return;
        if (!(self.method_37908() instanceof class_3218 sw)) return;
        if (amount <= 0f) return;

        // ── Standard armor reductions (hardened/bulletproof/fire/adapt) ──
        float reduced = ArmorAffixProcessor.applyReductions(self, source, amount);

        // ── Only apply advanced armor affixes to players ──────────────────
        if (self instanceof class_1657 player) {
            long now = sw.method_8510();

            // Mark combat for regen out-of-combat tracking
            ArmorEffectRuntime.markCombat(player.method_5667(), now);

            // ── 護盾: phase 1 (ready) → absorb hit, transition to phase 2 ──
            if (ArmorAffixProcessor.getChestAffix(player, ArmorAffixProcessor.CHEST_SHIELD) > 0) {
                int phase = ArmorEffectRuntime.getShieldPhase(player.method_5667());
                if (phase == 1) {
                    // Absorb the hit completely
                    ArmorEffectRuntime.setShieldPhase(player.method_5667(), 2);
                    ArmorEffectRuntime.setShieldTriggeredUntil(player.method_5667(), now + 100); // 5 seconds
                    player.method_6092(new class_1293(
                            class_1294.field_5898, 100, 5, false, false, true)); // 12 absorption (amp5 = 6 hearts = 12hp)
                    cir.setReturnValue(false);
                    cir.cancel();
                    return;
                }
            }

            // ── 限制器: threshold check + damage cap ──────────────────────
            double limiterFlat = ArmorAffixProcessor.getTotal(player, ArmorAffixProcessor.LIMITER_FLAT);
            double limiterPct  = ArmorAffixProcessor.getTotal(player, ArmorAffixProcessor.LIMITER_PCT);
            if (limiterFlat > 0 || limiterPct > 0) {
                double threshold = 0;
                if (limiterFlat > 0) threshold = limiterFlat;
                if (limiterPct > 0) threshold = Math.max(threshold, player.method_6063() * (limiterPct / 100.0));

                if (reduced >= threshold) {
                    // Trigger: regen 2 for 5s
                    player.method_6092(new class_1293(
                            class_1294.field_5924, 100, 1, false, true, true));
                    // Activate damage cap for 5s
                    ArmorEffectRuntime.activateLimiter(player.method_5667(), now + 100);
                }

                // If limiter active, cap damage to 50%
                if (ArmorEffectRuntime.isLimiterActive(player.method_5667(), now)) {
                    reduced = Math.min(reduced, amount * 0.5f);
                }
            }

            // ── 承量: count hits ────────────────────────────────────────
            if (ArmorAffixProcessor.getChestAffix(player, ArmorAffixProcessor.CHEST_CHARGED_BURST) > 0) {
                int count = ArmorEffectRuntime.incrementBurstCounter(player.method_5667());
                if (count >= 5) {
                    ArmorEffectRuntime.resetBurstCounter(player.method_5667());
                    // Fire 20 fireballs in 360 degrees
                    double totalArmor = player.method_6096();
                    float burstDmg = (float) (totalArmor + 20.0);
                    for (int i = 0; i < 20; i++) {
                        double angle = Math.toRadians(360.0 / 20.0 * i);
                        double vx = Math.cos(angle) * 0.5;
                        double vz = Math.sin(angle) * 0.5;
                        class_1677 fb = new class_1677(sw, player, new class_243(vx, 0.05, vz));
                        fb.method_5814(player.method_23317(), player.method_23318() + 1.0, player.method_23321());
                        sw.method_8649(fb);
                    }
                    // Spawn particles (handled client-side by fireball visuals)
                }
            }

            // ── 尖刺甲冑: reflect damage to attacker ──────────────────────
            double thornsPct = ArmorAffixProcessor.getChestAffix(player, ArmorAffixProcessor.CHEST_THORNS);
            if (thornsPct > 0 && source.method_5529() instanceof class_1309 attacker) {
                float reflectDmg = (float) (reduced * (thornsPct / 100.0));
                if (reflectDmg > 0.5f) {
                    SAVARU_REDUCING.set(true);
                    try {
                        attacker.method_5643(player.method_48923().method_48818(player), reflectDmg);
                    } finally {
                        SAVARU_REDUCING.set(false);
                    }
                }
            }
        }

        // ── Apply final reduced damage ──────────────────────────────────
        if (reduced == amount) return; // no change, let vanilla proceed

        if (reduced <= 0f) {
            cir.setReturnValue(false);
            cir.cancel();
            return;
        }

        SAVARU_REDUCING.set(true);
        try {
            boolean result = self.method_5643(source, reduced);
            cir.setReturnValue(result);
            cir.cancel();
        } finally {
            SAVARU_REDUCING.set(false);
        }
    }
}
