package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.SavaruAffixesMod;
import com.savaru.savaru_affixes.api.SoulbindAccess;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntitySoulbindMixin implements SoulbindAccess {

    @Unique private static final class_2960 SAVARU_SOULBIND_ZERO_ID = class_2960.method_60655(SavaruAffixesMod.MOD_ID, "soulbind_zero");
    @Unique private long savaru$soulbindUntilTick = 0L;

    @Override
    public void savaru$setSoulbindUntil(long untilTick) {
        this.savaru$soulbindUntilTick = Math.max(this.savaru$soulbindUntilTick, untilTick);
    }

    @Override
    public long savaru$getSoulbindUntil() {
        return this.savaru$soulbindUntilTick;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void savaru$applySoulbindEveryTick(CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().field_9236) return;

        long now = self.method_37908().method_8510();
        boolean active = this.savaru$soulbindUntilTick > now;

        class_1324 inst = self.method_5996(class_5134.field_23719);
        if (inst == null) return;

        if (active) {
            // 移速 = 0：1.21+ 用 ADD_MULTIPLIED_TOTAL -1 把基礎移速乘成 0
            if (inst.method_6199(SAVARU_SOULBIND_ZERO_ID) == null) {
                inst.method_26835(new class_1322(
                        SAVARU_SOULBIND_ZERO_ID,
                        -1.0,
                        class_1322.class_1323.field_6331
                ));
            }

            // 保險：把速度向量清 0，避免慣性滑動
            self.method_18799(class_243.field_1353);
        } else {
            if (inst.method_6199(SAVARU_SOULBIND_ZERO_ID) != null) {
                inst.method_6200(SAVARU_SOULBIND_ZERO_ID);
            }
        }
    }
}
