package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.UnidentifiedHelper;
import com.savaru.savaru_affixes.WarnMessageHelper;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1764.class)
public abstract class CrossbowItemUseMixin {

    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$blockUnidentifiedCrossbow(class_1937 world, class_1657 user, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
        class_1799 stack = user.method_5998(hand);
        if (!UnidentifiedHelper.shouldBlockUse(stack)) return;
        WarnMessageHelper.send(user, class_2561.method_43470("這把武器尚未鑑定，無法使用").method_27692(class_124.field_1061));
        cir.setReturnValue(class_1269.field_5814);
    }
}
