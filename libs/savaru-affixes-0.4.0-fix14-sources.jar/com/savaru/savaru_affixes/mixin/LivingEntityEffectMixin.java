package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.armor.ArmorAffixProcessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_6880;

@Mixin(class_1309.class)
public abstract class LivingEntityEffectMixin {

    /**
     * Intercept addStatusEffect to apply 適性(時間/等級) reductions.
     * If duration or level would reach 0, cancel the effect entirely.
     */
    @Inject(
            method = "addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z",
            at = @At("HEAD"),
            cancellable = true,
            require = 0
    )
    private void savaru_affixes$adaptEffectReduction(
            class_1293 effect, class_1297 source,
            CallbackInfoReturnable<Boolean> cir) {

        if (effect == null) return;
        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().method_8608()) return;

        String effectId = getEffectId(effect.method_5579());
        if (effectId == null) return;

        List<ArmorAffixProcessor.AdaptEntry> adapts = ArmorAffixProcessor.getAllAdapts(self);
        if (adapts.isEmpty()) return;

        int duration  = effect.method_5584();
        int amplifier = effect.method_5578();
        boolean modified = false;

        for (ArmorAffixProcessor.AdaptEntry adapt : adapts) {
            if (adapt.effectId == null || adapt.effectId.isEmpty()) continue;
            if (!effectMatches(adapt.effectId, effectId)) continue;

            switch (adapt.affixId) {
                case ArmorAffixProcessor.ADAPT_DUR -> {
                    // duration reduction 50% or 100%
                    if (adapt.value >= 100.0) {
                        cir.setReturnValue(false);
                        cir.cancel();
                        return;
                    }
                    duration = (int)(duration * (1.0 - adapt.value / 100.0));
                    modified = true;
                }
                case ArmorAffixProcessor.ADAPT_LVL -> {
                    // level reduction 1 or 2
                    int reduce = (int) Math.round(adapt.value);
                    amplifier = amplifier - reduce;
                    modified = true;
                    if (amplifier < 0) {
                        cir.setReturnValue(false);
                        cir.cancel();
                        return;
                    }
                }
            }
        }

        if (!modified) return;
        if (duration <= 0) {
            cir.setReturnValue(false);
            cir.cancel();
            return;
        }

        // Re-apply with modified values
        class_1293 modified_effect = new class_1293(
                effect.method_5579(), duration, amplifier,
                effect.method_5591(), effect.method_5581(), effect.method_5592()
        );
        self.method_37222(modified_effect, source);
        cir.setReturnValue(true);
        cir.cancel();
    }

    private static String getEffectId(class_6880<class_1291> effectType) {
        var key = effectType.method_40230();
        return key.map(k -> k.method_29177().toString()).orElse(null);
    }

    private static boolean effectMatches(String stored, String current) {
        if (stored.equals(current)) return true;
        // Allow both "minecraft:poison" and "poison" forms
        if (stored.contains(":")) {
            return stored.equals(current) || stored.endsWith(":" + current);
        }
        return current.endsWith(":" + stored);
    }
}
