package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.PreviewHelper;
import com.savaru.savaru_affixes.Rarity;
import com.savaru.savaru_affixes.UnidentifiedHelper;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Client-side display name adjustments:
 * - anvil preview stacks always show garbled/obfuscated title
 * - unresolved unidentified equipment -> prefix with 「未鑑定的 」
 * - UNRIVALED -> keep animated rainbow name
 */
@Mixin(class_1799.class)
public abstract class ItemStackNameMixin {

    @Inject(method = "getName", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$decorateName(CallbackInfoReturnable<class_2561> cir) {
        class_1799 self = (class_1799) (Object) this;

        if (PreviewHelper.isPreview(self)) {
            String source = PreviewHelper.getPreviewName(self);
            if (source == null || source.isBlank()) {
                source = self.method_7909().method_7864(self).getString();
            }
            cir.setReturnValue(class_2561.method_43470(source).method_27695(class_124.field_1063, class_124.field_1051));
            return;
        }

        class_2561 baseName = self.method_57826(class_9334.field_49631)
                ? self.method_57824(class_9334.field_49631)
                : self.method_7909().method_7864(self);

        if (UnidentifiedHelper.shouldPrefixName(self)) {
            cir.setReturnValue(class_2561.method_43470("未鑑定的 ").method_27692(class_124.field_1080).method_10852(baseName));
            return;
        }

        Rarity rarity = AffixHelper.getRarity(self);
        if (rarity != Rarity.UNRIVALED) return;

        String s = baseName.getString();
        cir.setReturnValue(Rarity.rainbowTextDynamic(s, System.currentTimeMillis()));
    }
}
