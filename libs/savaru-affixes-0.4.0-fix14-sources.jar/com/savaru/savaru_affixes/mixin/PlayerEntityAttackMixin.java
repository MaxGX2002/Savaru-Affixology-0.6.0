package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.CritHelper;
import com.savaru.savaru_affixes.OverhealHooks;
import com.savaru.savaru_affixes.Rarity;
import com.savaru.savaru_affixes.SavaruAttributes;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import com.savaru.savaru_affixes.inscription.InscriptionRuntime;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import com.savaru.savaru_affixes.BurnHooks;

/**
 * Route A: modify the ORIGINAL melee hit damage in PlayerEntity#attack.
 * Our crit system is fully independent and uses Savaru's affix values.
 */
@Mixin(class_1657.class)
public abstract class PlayerEntityAttackMixin {

    private static final ThreadLocal<Integer> PRE_WEAPON_DAMAGE = ThreadLocal.withInitial(() -> 0);


    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$blockUnidentifiedAttack(class_1297 target, CallbackInfo ci) {
        class_1657 self = (class_1657) (Object) this;
        class_1799 weapon = self.method_6047();
        if (weapon.method_7960()) {
            ci.cancel();
            return;
        }
        if (com.savaru.savaru_affixes.UnidentifiedHelper.shouldBlockUse(weapon)) {
            ci.cancel();
        }
    }

    @Inject(method = "attack", at = @At("HEAD"))
    private void savaru_affixes$storePreDamage(class_1297 target, CallbackInfo ci) {
        class_1657 self = (class_1657) (Object) this;
        class_1799 weapon = self.method_6047();
        PRE_WEAPON_DAMAGE.set(weapon.method_7960() ? 0 : weapon.method_7919());
        // Mark combat for armor regen out-of-combat tracking
        if (!self.method_37908().method_8608() && self.method_37908() instanceof class_3218 sw) {
            com.savaru.savaru_affixes.armor.ArmorEffectRuntime.markCombat(self.method_5667(), sw.method_8510());
        }
    }

    @Unique private boolean savaru$lastCrit = false;
    @Unique private int savaru$lastTargetId = -1;
    @Unique private float savaru$lastTargetHealthBefore = 0f;

    @ModifyArgs(
            method = "attack(Lnet/minecraft/entity/Entity;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/Entity;damage(Lnet/minecraft/entity/damage/DamageSource;F)Z"
            )
    )
    private void savaru$modifyDamage(Args args, class_1297 target) {
        class_1657 self = (class_1657) (Object) this;
        if (self.method_37908().method_8608()) return;
        if (!(target instanceof class_1309)) return;
        class_1309 livingTarget = (class_1309) target;

        class_1799 weapon = self.method_6047();
        if (weapon.method_7960()) return;

        // Only apply if the item has our rarity tag (i.e. is affixed)
        Rarity rarity = AffixHelper.getRarity(weapon);
        if (rarity == null) {
            savaru$lastCrit = false;
            return;
        }

        if (UnidentifiedHandler.isUnidentified(weapon)) {
            savaru$lastCrit = false;
            return;
        }

        float original = args.get(1);
        if (original <= 0f) {
            savaru$lastCrit = false;
            return;
        }

        // Record pre-hit health so we can compute post-hit effects (lifesteal / true damage).
        savaru$lastTargetId = livingTarget.method_5628();
        savaru$lastTargetHealthBefore = livingTarget.method_6032();

        SavaruAttributes.ensureRegistered();

        boolean arcblade = AffixHelper.getAffixValue(weapon, "arcblade") > 0.0;
        boolean berserk = AffixHelper.getAffixValue(weapon, "berserk") > 0.0;
        boolean greedlife = AffixHelper.getAffixValue(weapon, "greedlife") > 0.0;
        boolean wenwu = AffixHelper.getAffixValue(weapon, "wenwu") > 0.0;

        if (arcblade) {
            // Convert the main hit to magic damage (armor-bypass). Keep all existing damage math.
            args.set(0, self.method_48923().method_48815(self, self));
        }


        // We now drive combat from ATTRIBUTES so commands like /attribute can affect behavior.
        // Equipment affixes contribute via CritAttributeApplier (server tick), while base values remain editable.
        double bonusDamage = AffixHelper.getAffixValue(weapon, "bonus_damage"); // flat (Mythic-only)
        double armorPenFlat = AffixHelper.getAffixValue(weapon, "armor_pen_flat");
        double armorPenPct01 = AffixHelper.getAffixValue(weapon, "armor_pen_pct") / 100.0;
        double resPenFlat = AffixHelper.getAffixValue(weapon, "res_pen_flat");
        double resPenPct01 = AffixHelper.getAffixValue(weapon, "res_pen_pct") / 100.0;
        // Unified crit: merges SavaruAttributes + Critical Strike mod (soft-depend via CritHelper)
        double critChance01 = CritHelper.getCritChance(self);
        double critBonus01  = CritHelper.getCritDamage(self);  // +0.45 => 1.45x

        savaru$lastCrit = false;
        float modified = original;

        double mul = 1.0 + critBonus01;
        if (mul < 1.0) mul = 1.0;

        if (critChance01 > 0.0 && self.method_37908() instanceof class_3218 sw) {
            savaru$lastCrit = sw.field_9229.method_43058() < critChance01;
        }
        if (savaru$lastCrit) {
            modified = (float) (modified * mul);
        }

        // Flat bonus damage always applies
        if (bonusDamage > 0.0) {
            modified += (float) bonusDamage;
        }

        // Armor penetration: approximate by scaling raw damage to match a reduced-armor model.
        // This avoids touching target attributes (better compatibility).
        if ((armorPenFlat > 0.0 || armorPenPct01 > 0.0) && modified > 0f) {
            double armor = livingTarget.method_6096();
            double effArmor = armor;
            if (armorPenFlat > 0.0) effArmor = Math.max(0.0, armor - armorPenFlat);
            if (armorPenPct01 > 0.0) effArmor = Math.max(0.0, armor * (1.0 - armorPenPct01));

            double baseKeep = 1.0 - approxArmorReduction01(armor);
            double effKeep = 1.0 - approxArmorReduction01(effArmor);
            if (baseKeep < 0.05) baseKeep = 0.05; // avoid insane scaling at high armor
            float scaled = (float) (modified * (effKeep / baseKeep));
            if (scaled > modified) modified = scaled;
        }

        // Resistance penetration: compensate for target Resistance effect reduction.
        if ((resPenFlat > 0.0 || resPenPct01 > 0.0) && modified > 0f) {
            class_1293 res = livingTarget.method_6112(class_1294.field_5907);
            if (res != null) {
                int lvl = res.method_5578() + 1;
                double baseRed = Math.min(0.80, 0.20 * lvl);
                double penRed = 0.0;
                if (resPenFlat > 0.0) penRed = Math.max(penRed, 0.20 * resPenFlat);
                if (resPenPct01 > 0.0) penRed = Math.max(penRed, resPenPct01);
                double effRed = Math.max(0.0, baseRed - penRed);
                double baseKeep = 1.0 - baseRed;
                double effKeep = 1.0 - effRed;
                if (baseKeep < 0.05) baseKeep = 0.05;
                float scaled = (float) (modified * (effKeep / baseKeep));
                if (scaled > modified) modified = scaled;
            }
        }

        
        // Berserk: below 50% HP deal 250% damage (mutually exclusive with arcblade by roll rules)
        if (berserk && self.method_6032() <= (self.method_6063() * 0.5f)) {
            modified = modified * 2.5f;
        }


        // Greedlife: HP >= 80% => +150% damage, else -50% damage (mutually exclusive with berserk by roll rules)
        if (greedlife) {
            if (self.method_6032() >= (self.method_6063() * 0.8f)) {
                modified = modified * 2.5f;
            } else {
                modified = modified * 0.5f;
            }
        }

        // Wenwu: enchantment-based scaling
        if (wenwu) {
            // Keep item attribute line up-to-date (flat +0.2 per enchant level) when possible.
            try { AffixHelper.applyWenwuAttackModifier(weapon); } catch (Exception ignored) {}

            int enchCount = 0;
            int enchLevels = 0;
            try {
                Object enchObj = net.minecraft.class_1890.method_57532(weapon);
if (enchObj != null) {
    if (enchObj instanceof java.util.Map<?, ?> m) {
        for (java.util.Map.Entry<?, ?> e : m.entrySet()) {
            Object v = e.getValue();
            int lvl = (v instanceof Integer i) ? i : (v == null ? 0 : Integer.parseInt(v.toString()));
            if (lvl > 0) { enchCount++; enchLevels += lvl; }
        }
    } else {
        // 1.21+ ItemEnchantmentsComponent
        try {
            java.lang.reflect.Method method = enchObj.getClass().getMethod("getEnchantments");
            Object mapLike = method.invoke(enchObj);
            if (mapLike instanceof java.util.Map<?, ?> m2) {
                for (java.util.Map.Entry<?, ?> e : m2.entrySet()) {
                    Object v = e.getValue();
                    int lvl = (v instanceof Integer i) ? i : (v == null ? 0 : Integer.parseInt(v.toString()));
                    if (lvl > 0) { enchCount++; enchLevels += lvl; }
                }
            } else if (mapLike instanceof Iterable<?> it) {
                for (Object entry : it) {
                    try {
                        Object v = entry.getClass().getMethod("getIntValue").invoke(entry);
                        int lvl = (v instanceof Integer i) ? i : (v == null ? 0 : Integer.parseInt(v.toString()));
                        if (lvl > 0) { enchCount++; enchLevels += lvl; }
                    } catch (Throwable ignored3) {}
                }
            }
        } catch (Throwable ignored2) {}
    }
}
} catch (Throwable t) {
                enchCount = 0;
                enchLevels = 0;
            }

            if (enchCount <= 0) {
                modified = modified * 0.5f;
            } else {
                modified = (float) (modified * (1.0 + 0.15 * enchCount));
                modified = (float) (modified + (0.2 * enchLevels));
            }
        }

// NOTE: Health-based damage and execute are applied in post-attack (server-side).

        if (modified < 0f) modified = 0f;
        args.set(1, modified);
    }

    @Inject(method = "attack(Lnet/minecraft/entity/Entity;)V", at = @At("TAIL"))
    private void savaru$postAttack(class_1297 target, CallbackInfo ci) {
        class_1657 self = (class_1657) (Object) this;
        if (self.method_37908().method_8608()) return;
        if (!(target instanceof class_1309 living)) return;

        class_1799 weapon = self.method_6047();
        if (weapon.method_7960()) return;
        if (AffixHelper.getRarity(weapon) == null) return;
        if (UnidentifiedHandler.isUnidentified(weapon)) return;

        // Crit FX (vanilla)
        if (savaru$lastCrit && self.method_37908() instanceof class_3218 sw) {
            sw.method_14199(class_2398.field_11205, living.method_23317(), living.method_23323(0.5), living.method_23321(),
                    18, 0.35, 0.35, 0.35, 0.12);
            sw.method_8396(null, living.method_24515(), class_3417.field_15016, class_3419.field_15248,
                    0.8f, 1.0f);
        }

        // Post-hit effects are driven by ATTRIBUTES so commands can affect them too.
        if (living.method_5628() == savaru$lastTargetId) {
            float after = living.method_6032();
            float dealt = savaru$lastTargetHealthBefore - after;
            if (dealt < 0f) dealt = 0f;

            SavaruAttributes.ensureRegistered();

            double lifesteal01 = self.method_45325(SavaruAttributes.LIFESTEAL_ENTRY);
            if (lifesteal01 > 0.0 && dealt > 0f) {
                float heal = (float) (dealt * lifesteal01);
                if (heal > 0f) self.method_6025(heal);
            }

            double trueDamage01 = self.method_45325(SavaruAttributes.TRUE_DAMAGE_ENTRY);
            if (trueDamage01 > 0.0 && dealt > 0f) {
                float extra = (float) (dealt * trueDamage01);
                if (extra > 0f) {
                    // Armor/resistance-bypass "true" damage.
                    living.method_5643(self.method_48923().method_48829(), extra);
                }
            }
        }

        // Chance-based debuffs (weapon NBT driven)
        if (self.method_37908() instanceof class_3218 sw) {
            // v0.4: Burn and Devour procs (weapon NBT driven)
            double burnChance01 = AffixHelper.getAffixValue(weapon, "burn") / 100.0;
            int burnDmg = AffixHelper.getAffixLevel(weapon, "burn"); // 1-5
            if (burnChance01 > 0.0 && burnDmg > 0 && sw.field_9229.method_43058() < burnChance01) {
                // NOTE: implemented as an instant extra magic hit + short fire visual (2s).
                BurnHooks.queueDot2s4Hits(sw, living, self, burnDmg);
                living.method_5639(2);
            }

            double devourChance01 = AffixHelper.getAffixValue(weapon, "devour") / 100.0;
            int devourFood = AffixHelper.getAffixLevel(weapon, "devour"); // 1-5
            if (devourChance01 > 0.0 && devourFood > 0 && sw.field_9229.method_43058() < devourChance01) {
                if (self instanceof class_3222 sp) {
                    sp.method_7344().method_7585(devourFood, 0.0f);
                }
            }


            double witherChance01 = AffixHelper.getAffixValue(weapon, "wither") / 100.0;
            int witherLevel = AffixHelper.getAffixLevel(weapon, "wither");
            if (witherChance01 > 0.0 && witherLevel > 0 && sw.field_9229.method_43058() < witherChance01) {
                living.method_6092(new class_1293(class_1294.field_5920, 40, Math.max(0, witherLevel - 1), false, true, true));
            }

            double weakChance01 = AffixHelper.getAffixValue(weapon, "weakness") / 100.0;
            int weakLevel = AffixHelper.getAffixLevel(weapon, "weakness");
            if (weakChance01 > 0.0 && weakLevel > 0 && sw.field_9229.method_43058() < weakChance01) {
                living.method_6092(new class_1293(class_1294.field_5911, 40, Math.max(0, weakLevel - 1), false, true, true));
                // Stronger visual/audio feedback for Weakness proc
                sw.method_14199(class_2398.field_11231, living.method_23317(), living.method_23323(0.6), living.method_23321(), 18, 0.45, 0.45, 0.45, 0.0);
                sw.method_14199(class_2398.field_11251, living.method_23317(), living.method_23323(0.6), living.method_23321(), 10, 0.35, 0.25, 0.35, 0.01);
                sw.method_43128(null, living.method_23317(), living.method_23318(), living.method_23321(), class_3417.field_14986, class_3419.field_15248, 0.9f, 1.2f);
            }

            // Frailty (Slowness)
            double frailChance01 = AffixHelper.getAffixValue(weapon, "frailty") / 100.0;
            int frailLevel = AffixHelper.getAffixLevel(weapon, "frailty");
            if (frailChance01 > 0.0 && frailLevel > 0 && sw.field_9229.method_43058() < frailChance01) {
                living.method_6092(new class_1293(class_1294.field_5909, 40, Math.max(0, frailLevel - 1), false, true, true));
            }

            // Overheal (Absorption on attacker)
            double overhealChance01 = AffixHelper.getAffixValue(weapon, "overheal") / 100.0;
            if (overhealChance01 > 0.0 && sw.field_9229.method_43058() < overhealChance01 && self instanceof class_3222 sp) {
                OverhealHooks.proc(sp);
            }

            // Armor steal stacking (weapon NBT driven)
            double perHitPct = AffixHelper.getAffixValue(weapon, "armor_steal");
            if (perHitPct > 0.0) {
                String attackerKey = self.method_5845().replace("-", "");
                if (attackerKey.length() > 16) attackerKey = attackerKey.substring(0, 16);
                com.savaru.savaru_affixes.ArmorStealHooks.apply(sw, living, perHitPct, 10.0, 60, attackerKey);
            }

            // Durability-affixes: post-process durability loss on the weapon
            if (!weapon.method_7960() && weapon.method_7963()) {
                int pre = PRE_WEAPON_DAMAGE.get();
                int post = weapon.method_7919();
                int delta = Math.max(0, post - pre);
                if (delta > 0) {
                    // 5% chance: no durability consumed
                    double noCostChance01 = AffixHelper.getAffixValue(weapon, "durability_nocost") / 100.0;
                    if (noCostChance01 > 0.0 && sw.field_9229.method_43058() < noCostChance01) {
                        weapon.method_7974(pre);
                    } else {
                        // virtual extra durability buffer
                        int buf = AffixHelper.getAffixInt(weapon, "durability_bonus", "buf", 0);
                        if (buf > 0) {
                            int refund = Math.min(delta, buf);
                            weapon.method_7974(post - refund);
                            AffixHelper.setAffixInt(weapon, "durability_bonus", "buf", buf - refund);
                        }
                    }
                }
            }
        }

        // Health-scaling damage (true damage)
        if (self.method_37908() instanceof class_3218 sw2) {
            double maxHpPct = AffixHelper.getAffixValue(weapon, "max_hp_pct");
            if (maxHpPct > 0.0 && living.method_5805()) {
                float extra = (float) (living.method_6063() * (maxHpPct / 100.0));
                if (extra > 0f) living.method_5643(self.method_48923().method_48829(), extra);
            }

            double curHpPct = AffixHelper.getAffixValue(weapon, "cur_hp_pct");
            if (curHpPct > 0.0 && living.method_5805()) {
                float extra = (float) (savaru$lastTargetHealthBefore * (curHpPct / 100.0));
                if (extra > 0f) living.method_5643(self.method_48923().method_48829(), extra);
            }

            // Execute
            double exFlat = AffixHelper.getAffixValue(weapon, "execute_flat");
            double exPct = AffixHelper.getAffixValue(weapon, "execute_pct");
            if ((exFlat > 0.0 || exPct > 0.0) && living.method_5805()) {
                float th = 0f;
                if (exPct > 0.0) th = (float) (living.method_6063() * (exPct / 100.0));
                else th = (float) exFlat;
                if (living.method_6032() > 0f && living.method_6032() <= th) {
                    living.method_5643(self.method_48923().method_48829(), 999999f);
                }
            }

            // AoE Poison with cooldown
            double poisonChance01 = AffixHelper.getAffixValue(weapon, "poison_aoe") / 100.0;
            if (poisonChance01 > 0.0) {
                int now = (int) sw2.method_8510();
                int next = AffixHelper.getAffixInt(weapon, "poison_aoe", "cd", 0);
                if (now >= next && sw2.field_9229.method_43058() < poisonChance01) {
                    class_238 box = living.method_5829().method_1014(5.0);
                    for (class_1309 e : sw2.method_8390(class_1309.class, box, ent -> ent.method_5805() && ent != self)) {
                        e.method_6092(new class_1293(class_1294.field_5899, 60, 0, false, true, true));
                    }
                    AffixHelper.setAffixInt(weapon, "poison_aoe", "cd", now + 200);
                }
            }
        }

        savaru$lastTargetId = -1;
        savaru$lastTargetHealthBefore = 0f;
    }

    @Unique
    private static double approxArmorReduction01(double armorPoints) {
        // Simple approximation: each armor point ~4% reduction, capped at 80%
        double r = armorPoints * 0.04;
        if (r < 0.0) r = 0.0;
        if (r > 0.80) r = 0.80;
        return r;
    }
}