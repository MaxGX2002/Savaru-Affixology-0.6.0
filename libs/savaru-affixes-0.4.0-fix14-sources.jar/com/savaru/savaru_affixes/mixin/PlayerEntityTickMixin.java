package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.CritAttributeApplier;
import com.savaru.savaru_affixes.Rarity;
import com.savaru.savaru_affixes.armor.ArmorAffixProcessor;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import com.savaru.savaru_affixes.SavaruAttributes;
import com.savaru.savaru_affixes.inscription.InscriptionRuntime;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_6880.class_6883;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9285;
import net.minecraft.class_9285.class_9287;
import net.minecraft.class_9334;

@Mixin(class_1657.class)
public abstract class PlayerEntityTickMixin {

    private static final class_2960 BLACKFLASH_BOOST_ID        = class_2960.method_60655("savaru_affixes", "blackflash_boost");
    private static final class_2960 ARMOR_PROT_ID              = class_2960.method_60655("savaru_affixes", "armor_protection");
    private static final class_2960 ARMOR_TOUGH_ID             = class_2960.method_60655("savaru_affixes", "armor_toughness");
    private static final class_2960 ARMOR_HEAVY_ID             = class_2960.method_60655("savaru_affixes", "armor_heavy");
    private static final class_2960 ARMOR_WARRIOR_ID           = class_2960.method_60655("savaru_affixes", "armor_warrior");
    private static final class_2960 ARMOR_BERSERKER_CHANCE_ID  = class_2960.method_60655("savaru_affixes", "armor_berserker_chance");
    private static final class_2960 ARMOR_BERSERKER_DMG_ID     = class_2960.method_60655("savaru_affixes", "armor_berserker_dmg");
    private static final class_2960 ARMOR_SAINT_ID             = class_2960.method_60655("savaru_affixes", "armor_saint");
    // CS Critical Strike mod (soft-depend)
    private static final class_2960 ARMOR_CS_CC_PCT_ID         = class_2960.method_60655("savaru_affixes", "armor_cs_cc_pct");
    private static final class_2960 ARMOR_CS_CC_FLAT_ID        = class_2960.method_60655("savaru_affixes", "armor_cs_cc_flat");
    private static final class_2960 ARMOR_CS_CD_ID             = class_2960.method_60655("savaru_affixes", "armor_cs_cd");

    @Inject(method = "tick", at = @At("TAIL"))
    private void savaru_affixes$onTick(CallbackInfo ci) {
        class_1657 self = (class_1657) (Object) this;
        CritAttributeApplier.tick(self);

        // Server-only
        if (self.method_37908().field_9236) return;
        if (!(self.method_37908() instanceof class_3218 sw)) return;

        long now = sw.method_8510();

        // Blackflash: +100% damage for the buff duration.
        boolean active = InscriptionRuntime.isBlackflashBuffActive(self.method_5667(), now);
        var inst = self.method_5996(class_5134.field_23721);
        if (inst == null) return;

        class_1322 existing = inst.method_6199(BLACKFLASH_BOOST_ID);
        if (active) {
            if (existing == null) {
                inst.method_26837(new class_1322(
                        BLACKFLASH_BOOST_ID, 1.0, class_1322.class_1323.field_6331
                ));
            }
        } else {
            if (existing != null) inst.method_6200(BLACKFLASH_BOOST_ID);
        }

        // --- Starflow: track last hurt tick (best-effort) ---
        if (self.field_6235 > 0) {
            InscriptionRuntime.setStarLastHurt(self.method_5667(), now);
        }

        // ── Armor affix tick-based effects (status effects only) ──────────
        // All attribute-based affixes (protection, toughness, heavy, warrior, berserker,
        // saint, CS crit) are now ITEM-LEVEL modifiers via AffixHelper.addArmorAffixModifiers.
        // Only fire_resist (status effect) and grace (absorption) need tick updates.
        if (now % 5 == 0) {
            // ── 防火100%: permanent fire resistance ────────────────────────
            double fireResist = ArmorAffixProcessor.getTotal(self, ArmorAffixProcessor.FIRE_RESIST);
            if (fireResist >= 100.0) {
                if (!self.method_6059(class_1294.field_5918)) {
                    self.method_6092(new class_1293(
                            class_1294.field_5918, 200, 0, false, false, false));
                }
            }

            // ── 恩賜: absorption refresh every 60s ─────────────────────────
            double graceVal = ArmorAffixProcessor.getTotal(self, "armor_grace");
            if (graceVal > 0.0) {
                int graceAmp = Math.max(0, (int) Math.round(graceVal) - 1);
                class_1293 graceEffect = self.method_6112(class_1294.field_5898);
                if (graceEffect == null || graceEffect.method_5584() < 20) {
                    self.method_6092(new class_1293(
                            class_1294.field_5898, 1200, graceAmp, false, false, false));
                }
            }

            // ── 自然回血: every 5s heal (in-combat), every 1.2s (out-of-combat) ──
            double regenFlat = ArmorAffixProcessor.getTotal(self, ArmorAffixProcessor.REGEN_FLAT);
            double regenPct  = ArmorAffixProcessor.getTotal(self, ArmorAffixProcessor.REGEN_PCT);
            if (regenFlat > 0 || regenPct > 0) {
                java.util.UUID pid = self.method_5667();
                boolean ooc = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.isOutOfCombat(pid, now);
                if (ooc) {
                    // Out of combat: heal 5% max HP every 1.2s (24 ticks)
                    long lastOoc = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getLastOocRegenTick(pid);
                    if (now - lastOoc >= 24) {
                        float heal = self.method_6063() * 0.05f;
                        self.method_6025(heal);
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setLastOocRegenTick(pid, now);
                    }
                } else {
                    // In combat: heal every 5s (100 ticks)
                    long lastRegen = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getLastRegenTick(pid);
                    if (now - lastRegen >= 100) {
                        float heal = 0;
                        if (regenFlat > 0) heal += (float) regenFlat;
                        if (regenPct > 0) heal += self.method_6063() * (float)(regenPct / 100.0);
                        self.method_6025(heal);
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setLastRegenTick(pid, now);
                    }
                }
            }

            // ── 火炎鋼: AoE fire damage every 1s (20 ticks) ────────────────
            if (ArmorAffixProcessor.getChestAffix(self, ArmorAffixProcessor.CHEST_FLAME_STEEL) > 0 && now % 20 == 0) {
                double armorVal = self.method_6096();
                float fireDmg = (float)(2.0 + armorVal * 0.10);
                double radius = 1.5;
                var box = self.method_5829().method_1014(radius);
                for (var entity : sw.method_8390(net.minecraft.class_1309.class, box,
                        e -> e != self && !(e instanceof class_1657) && e.method_5805())) {
                    entity.method_5639(1);
                    entity.method_5643(self.method_48923().method_48813(), fireDmg);
                }
            }

            // ── 護盾: timer management ──────────────────────────────────────
            if (ArmorAffixProcessor.getChestAffix(self, ArmorAffixProcessor.CHEST_SHIELD) > 0) {
                java.util.UUID pid = self.method_5667();
                var rt = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.class;
                int phase = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getShieldPhase(pid);

                if (phase == 0) {
                    // Charging: wait 15s
                    long nextReady = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getShieldNextReady(pid);
                    if (nextReady == 0) {
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setShieldNextReady(pid, now + 300);
                    } else if (now >= nextReady) {
                        // Ready: give 6 absorption, enter phase 1
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setShieldPhase(pid, 1);
                        self.method_6092(new class_1293(
                                class_1294.field_5898, 400, 2, false, false, true)); // amp2 = 3 hearts = 6hp
                    }
                } else if (phase == 2) {
                    // Triggered: after 5s, remove absorption and reset
                    long until = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getShieldTriggeredUntil(pid);
                    if (now >= until) {
                        self.method_6016(class_1294.field_5898);
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setShieldPhase(pid, 0);
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setShieldNextReady(pid, now + 300);
                    }
                }
            }

            // ── Cleanup ALL legacy tick-based modifiers ────────────────────
            // These are now item-level (in AffixHelper.addArmorAffixModifiers).
            cleanupLegacyModifier(self, class_5134.field_23724, ARMOR_PROT_ID);
            cleanupLegacyModifier(self, class_5134.field_23725, ARMOR_TOUGH_ID);
            cleanupLegacyModifier(self, class_5134.field_23718, ARMOR_HEAVY_ID);
            cleanupLegacyModifier(self, class_5134.field_23721, ARMOR_WARRIOR_ID);
            if (SavaruAttributes.CRIT_CHANCE_ENTRY != null) {
                cleanupLegacyModifier(self, SavaruAttributes.CRIT_CHANCE_ENTRY, ARMOR_BERSERKER_CHANCE_ID);
                nukeStaleFromEntry(self, SavaruAttributes.CRIT_CHANCE_ENTRY);
            }
            if (SavaruAttributes.CRIT_DAMAGE_ENTRY != null) {
                cleanupLegacyModifier(self, SavaruAttributes.CRIT_DAMAGE_ENTRY, ARMOR_BERSERKER_DMG_ID);
                nukeStaleFromEntry(self, SavaruAttributes.CRIT_DAMAGE_ENTRY);
            }
            cleanupLegacyModifier(self, class_5134.field_23716, ARMOR_SAINT_ID);
            // CS crit: NUCLEAR cleanup — remove ALL savaru_affixes modifiers from CS attributes.
            // Old versions used various IDs (affix_cs_cc, armor_cs_cc_pct, etc.) and some are
            // baked as persistent player-level modifiers that specific-ID cleanup can't catch.
            nukeAllSavaruModsFrom(self, "critical_strike", "chance");
            nukeAllSavaruModsFrom(self, "critical_strike", "damage");

            // ── Auto-migrate old armor items to new item-level system ──────
            migrateArmorIfNeeded(self);
        }

        // --- Charge / Starflow per-tick state machines ---
        class_1799 weapon = self.method_6047();
        boolean weaponIdentified = !weapon.method_7960(); // allow charge/starflow to run even if Unidentified

        // Build a lightweight fingerprint to detect item switching (switch => reset).
        String fp = null;
        if (weaponIdentified) {
            String itemId = class_7923.field_41178.method_10221(weapon.method_7909()).toString();
            var comp = weapon.method_57824(class_9334.field_49628);
            int nbtHash = (comp == null || comp.method_57463() == null) ? 0 : comp.method_57463().hashCode();
            fp = itemId + "|" + weapon.method_7919() + "|" + nbtHash;
        }

        // Determine inscription id (if any)
        String insId = null;
        if (weaponIdentified) {
            var ins = InscriptionHelper.getInscription(weapon);
            if (ins != null) insId = ins.method_10558("id");
        }

        // ---- Charge (rework): always 75%, every 2s +75% (cap 450%); any hit resets ----
        if ("charge".equals(insId)) {
            String lastFp = InscriptionRuntime.getChargeFingerprint(self.method_5667());
            if (lastFp == null || fp == null || !lastFp.equals(fp)) {
                // equip / switch: start at 75%
                InscriptionRuntime.setChargeState(self.method_5667(), fp, 0, now + 40);
            } else {
                long next = InscriptionRuntime.getChargeNextTick(self.method_5667());
                if (now >= next) {
                    int pct = InscriptionRuntime.getChargePct(self.method_5667());
                    int nextPct = switch (pct) {
                        case 0 -> 100;
                        case 100 -> 200;
                        case 200 -> 400;
                        case 400 -> 800;
                        case 800 -> 1500;
                        default -> 1500;
                    };
                    InscriptionRuntime.setChargeState(self.method_5667(), fp, nextPct, now + 40);
                }
            }

            // persistent indicator (actionbar)
            if (self instanceof class_3222 sp) {
                int pct = InscriptionRuntime.getChargePct(self.method_5667());
                String bar = switch (pct) {
                    case 0 -> "<=====>";
                    case 100 -> "<O====>";
                    case 200 -> "<OO===>";
                    case 400 -> "<OOO==>";
                    case 800 -> "<OOOO=>";
                    case 1500 -> "<充能完畢>";
                    default -> "<=====>";
                };
                InscriptionRuntime.sendActionbar(sp, bar + " " + pct + "%");
            }
        } else {
            InscriptionRuntime.resetCharge(self.method_5667());
        }

        // ---- Starflow: switching away resets chain; timed transitions advance stages ----
        if (!"starflow".equals(insId)) {
            InscriptionRuntime.resetStarflow(self.method_5667());
        } else {
            int stage = InscriptionRuntime.getStarStage(self.method_5667());
            long transAt = InscriptionRuntime.getStarTransitionAt(self.method_5667());
            if (stage > 0 && transAt > 0 && now >= transAt && self instanceof class_3222 sp) {
                advanceStarflowStage(sp, now);
            }
        }
    }

    private static void advanceStarflowStage(class_3222 player, long now) {
        UUID pid = player.method_5667();

        // If hurt recently, cancel chain
        long lastHurt = InscriptionRuntime.getStarLastHurt(pid);
        if (lastHurt + 1 >= now) {
            InscriptionRuntime.resetStarflow(pid);
            return;
        }

        int stage = InscriptionRuntime.getStarStage(pid);

        switch (stage) {
            case 1 -> {
                // After DOT(15s) + 10s => Stage2
                InscriptionRuntime.setStarStage(pid, 2);
                player.method_6092(new class_1293(class_1294.field_5910, 10 * 20, 0, false, true, true));
                player.method_6092(new class_1293(class_1294.field_5904, 10 * 20, 1, false, true, true));
                InscriptionRuntime.setStarNext350(pid, true);
                InscriptionRuntime.setStarTransitionAt(pid, 0);
                InscriptionRuntime.sendTitle(player, "星擊：二連");
                player.method_7353(net.minecraft.class_2561.method_43470("星擊：二連"), false);
            }
            case 4 -> {
                // Stage4 ended -> Stage5
                InscriptionRuntime.setStarStage(pid, 5);
                player.method_6092(new class_1293(class_1294.field_5914, 15 * 20, 4, false, true, true)); // +20 HP
                player.method_6092(new class_1293(class_1294.field_5926, 10 * 20, 2, false, true, true)); // Luck III
                InscriptionRuntime.setStarTransitionAt(pid, now + 15 * 20);
                InscriptionRuntime.sendTitle(player, "星復：五連");
                player.method_7353(net.minecraft.class_2561.method_43470("星復：五連"), false);
            }
            case 5 -> {
                // Stage5 ended -> Stage6
                InscriptionRuntime.setStarStage(pid, 6);
                InscriptionRuntime.setStarBurnUntil(pid, now + 10 * 20);
                InscriptionRuntime.setStarTransitionAt(pid, now + 10 * 20);
                InscriptionRuntime.sendTitle(player, "星火：六連");
                player.method_7353(net.minecraft.class_2561.method_43470("星火：六連"), false);
            }
            case 6 -> {
                // Stage6 ended -> Stage7
                InscriptionRuntime.setStarStage(pid, 7);
                InscriptionRuntime.setStarNextFinal(pid, true);
                InscriptionRuntime.setStarBurnUntil(pid, 0);
                InscriptionRuntime.setStarTransitionAt(pid, 0);
                InscriptionRuntime.sendTitle(player, "星殞：終連");
                player.method_7353(net.minecraft.class_2561.method_43470("星殞：終連"), false);
            }
            default -> InscriptionRuntime.resetStarflow(pid);
        }
    }

    /**
     * Soft-depend: try to apply a modifier to a modded attribute (e.g. critical_strike:chance).
     * Silently does nothing if the attribute is not registered.
     */
    private static void tryApplyModdedAttr(class_1657 player, String namespace, String path,
                                            class_2960 modId, double flatValue) {
        try {
            var attrId = net.minecraft.class_2960.method_60655(namespace, path);
            var entryOpt = net.minecraft.class_7923.field_41190.method_55841(attrId);
            if (entryOpt.isEmpty()) return;
            var entry = entryOpt.get();
            var inst = player.method_5996(entry);
            if (inst == null) return;
            if (flatValue > 0.0) {
                var existing = inst.method_6199(modId);
                if (existing == null || Math.abs(existing.comp_2449() - flatValue) > 0.0001) {
                    if (existing != null) inst.method_6200(modId);
                    inst.method_26837(new class_1322(
                            modId, flatValue, class_1322.class_1323.field_6328));
                }
            } else {
                if (inst.method_6199(modId) != null) inst.method_6200(modId);
            }
        } catch (Exception ignored) {}
    }

    /**
     * Same as tryApplyModdedAttr but uses ADD_MULTIPLIED_BASE operation.
     * Used for CS crit percentage bonuses (e.g. 0.75 = +75% of base).
     */
    private static void tryApplyModdedAttrMultBase(class_1657 player, String namespace, String path,
                                                    class_2960 modId, double multBaseValue) {
        try {
            var attrId = net.minecraft.class_2960.method_60655(namespace, path);
            var entryOpt = net.minecraft.class_7923.field_41190.method_55841(attrId);
            if (entryOpt.isEmpty()) return;
            var entry = entryOpt.get();
            var inst = player.method_5996(entry);
            if (inst == null) return;
            if (multBaseValue > 0.0) {
                var existing = inst.method_6199(modId);
                if (existing == null || Math.abs(existing.comp_2449() - multBaseValue) > 0.0001) {
                    if (existing != null) inst.method_6200(modId);
                    inst.method_26837(new class_1322(
                            modId, multBaseValue, class_1322.class_1323.field_6330));
                }
            } else {
                if (inst.method_6199(modId) != null) inst.method_6200(modId);
            }
        } catch (Exception ignored) {}
    }

    /**
     * Flat uses ADD, pct uses ADD_MULTIPLIED_BASE (applied to the item base value).
     * We combine both into one modifier using ADD for simplicity, converting pct to a
     * flat equivalent based on the attribute's base value.
     */
    private static void applyArmorModifier(
            class_1657 player,
            net.minecraft.class_6880<net.minecraft.class_1320> attribute,
            class_2960 modId,
            double flat, double pctOf100) {

        var attrInst = player.method_5996(attribute);
        if (attrInst == null) return;

        boolean hasBonus = (flat > 0.0 || pctOf100 > 0.0);
        class_1322 existing = attrInst.method_6199(modId);

        if (hasBonus) {
            // For flat: direct ADD. For pct: ADD_MULTIPLIED_BASE on base value.
            // We use two separate modifiers via a combined Identifier scheme.
            class_2960 flatId = class_2960.method_60655(modId.method_12836(), modId.method_12832() + "_flat");
            class_2960 pctId  = class_2960.method_60655(modId.method_12836(), modId.method_12832() + "_pct");

            var flatExist = attrInst.method_6199(flatId);
            var pctExist  = attrInst.method_6199(pctId);

            if (flat > 0.0) {
                if (flatExist == null || Math.abs(flatExist.comp_2449() - flat) > 0.001) {
                    if (flatExist != null) attrInst.method_6200(flatId);
                    attrInst.method_26837(new class_1322(
                            flatId, flat, class_1322.class_1323.field_6328));
                }
            } else if (flatExist != null) {
                attrInst.method_6200(flatId);
            }

            if (pctOf100 > 0.0) {
                double pctDecimal = pctOf100 / 100.0;
                if (pctExist == null || Math.abs(pctExist.comp_2449() - pctDecimal) > 0.0001) {
                    if (pctExist != null) attrInst.method_6200(pctId);
                    attrInst.method_26837(new class_1322(
                            pctId, pctDecimal, class_1322.class_1323.field_6330));
                }
            } else if (pctExist != null) {
                attrInst.method_6200(pctId);
            }
        } else {
            // No bonus: clean up modifiers
            class_2960 flatId = class_2960.method_60655(modId.method_12836(), modId.method_12832() + "_flat");
            class_2960 pctId  = class_2960.method_60655(modId.method_12836(), modId.method_12832() + "_pct");
            if (attrInst.method_6199(flatId) != null) attrInst.method_6200(flatId);
            if (attrInst.method_6199(pctId)  != null) attrInst.method_6200(pctId);
        }
    }

    /** Remove legacy tick-based modifier from a vanilla attribute. */
    private static void cleanupLegacyModifier(
            class_1657 player,
            net.minecraft.class_6880<net.minecraft.class_1320> attribute,
            class_2960 modId) {
        try {
            var attrInst = player.method_5996(attribute);
            if (attrInst == null) return;
            if (attrInst.method_6199(modId) != null) attrInst.method_6200(modId);
            class_2960 flatId = class_2960.method_60655(modId.method_12836(), modId.method_12832() + "_flat");
            class_2960 pctId  = class_2960.method_60655(modId.method_12836(), modId.method_12832() + "_pct");
            if (attrInst.method_6199(flatId) != null) attrInst.method_6200(flatId);
            if (attrInst.method_6199(pctId)  != null) attrInst.method_6200(pctId);
        } catch (Exception ignored) {}
    }

    /** Remove legacy tick-based modifier from a modded attribute (e.g. critical_strike:chance). */
    private static void cleanupModdedAttr(class_1657 player, String namespace, String path, class_2960 modId) {
        try {
            var attrId = class_2960.method_60655(namespace, path);
            var entryOpt = net.minecraft.class_7923.field_41190.method_55841(attrId);
            if (entryOpt.isEmpty()) return;
            var inst = player.method_5996(entryOpt.get());
            if (inst == null) return;
            if (inst.method_6199(modId) != null) inst.method_6200(modId);
        } catch (Exception ignored) {}
    }

    /**
     * NUCLEAR cleanup: remove STALE modifiers from our namespace on a modded attribute.
     * Keeps valid current-format modifiers:
     *   - weapon_* (from CritAttributeApplier for held weapon)
     *   - *_head / *_chest / *_legs / *_feet (item-level from armor pieces)
     * Removes everything else from our namespace (old formats without slot suffix).
     */
    private static void nukeAllSavaruModsFrom(class_1657 player, String namespace, String path) {
        try {
            var attrId = class_2960.method_60655(namespace, path);
            var entryOpt = net.minecraft.class_7923.field_41190.method_55841(attrId);
            if (entryOpt.isEmpty()) return;
            var inst = player.method_5996(entryOpt.get());
            if (inst == null) return;

            java.util.List<class_2960> toRemove = new java.util.ArrayList<>();
            for (var mod : inst.method_6195()) {
                if (!"savaru_affixes".equals(mod.comp_2447().method_12836())) continue;
                String p = mod.comp_2447().method_12832();
                // Keep valid current-format modifiers
                if (p.startsWith("weapon_")) continue;                       // weapon crit from CritAttributeApplier
                if (p.endsWith("_head") || p.endsWith("_chest")
                        || p.endsWith("_legs") || p.endsWith("_feet")) continue; // item-level armor
                // Everything else is stale
                toRemove.add(mod.comp_2447());
            }
            for (class_2960 id : toRemove) {
                inst.method_6200(id);
            }
        } catch (Exception ignored) {}
    }

    /**
     * NUCLEAR cleanup for RegistryEntry-based attributes (e.g. SavaruAttributes).
     * Same logic as nukeAllSavaruModsFrom but takes a RegistryEntry directly.
     */
    private static void nukeStaleFromEntry(class_1657 player,
            net.minecraft.class_6880<net.minecraft.class_1320> attr) {
        try {
            var inst = player.method_5996(attr);
            if (inst == null) return;
            java.util.List<class_2960> toRemove = new java.util.ArrayList<>();
            for (var mod : inst.method_6195()) {
                if (!"savaru_affixes".equals(mod.comp_2447().method_12836())) continue;
                String p = mod.comp_2447().method_12832();
                if (p.startsWith("weapon_")) continue;
                if (p.endsWith("_head") || p.endsWith("_chest")
                        || p.endsWith("_legs") || p.endsWith("_feet")) continue;
                toRemove.add(mod.comp_2447());
            }
            for (class_2960 id : toRemove) {
                inst.method_6200(id);
            }
        } catch (Exception ignored) {}
    }

    /** Migrate old armor items to new item-level attribute system (slot-specific IDs). */
    private static void migrateArmorIfNeeded(class_1657 player) {
        try {
            for (net.minecraft.class_1304 slot : new net.minecraft.class_1304[]{
                    net.minecraft.class_1304.field_6169, net.minecraft.class_1304.field_6174,
                    net.minecraft.class_1304.field_6172, net.minecraft.class_1304.field_6166}) {
                class_1799 piece = player.method_6118(slot);
                if (piece.method_7960()) continue;
                if (!com.savaru.savaru_affixes.AffixHelper.isArmorItem(piece)) continue;
                var rarity = com.savaru.savaru_affixes.AffixHelper.getRarity(piece);
                if (rarity == null) continue;
                if (com.savaru.savaru_affixes.UnidentifiedHandler.isUnidentified(piece)) continue;

                var comp = piece.method_57824(net.minecraft.class_9334.field_49636);
                boolean hasNewFormat = false;
                if (comp != null) {
                    for (var e : comp.comp_2393()) {
                        String p = e.comp_2396().comp_2447().method_12832();
                        if (e.comp_2396().comp_2447().method_12836().equals("savaru_affixes")
                                && (p.endsWith("_head") || p.endsWith("_chest")
                                    || p.endsWith("_legs") || p.endsWith("_feet"))) {
                            hasNewFormat = true;
                            break;
                        }
                    }
                }
                if (!hasNewFormat) {
                    com.savaru.savaru_affixes.AffixHelper.applyRarityNameColor(piece, rarity);
                }
            }
        } catch (Exception ignored) {}
    }
}
