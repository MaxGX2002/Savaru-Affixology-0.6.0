package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.arrow.ArrowAffixProcessor;
import net.minecraft.class_1293;
import net.minecraft.class_1667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * Scales vanilla tipped-arrow potion effects based on arrow-item affixes.
 */
@Mixin(class_1667.class)
public abstract class ArrowEntityEffectMixin {

    /**
     * Yarn has changed the "entity hit" hook name across versions.
     * We apply the same ModifyArg against several likely names and mark them optional
     * (require = 0) so the game won't crash if a method name doesn't exist.
     */
    @ModifyArg(
            method = "onEntityHit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z"
            ),
            index = 0,
            require = 0
    )
    private class_1293 savaru$scaleArrowEffects_onEntityHit(class_1293 original) {
        return savaru$scaleArrowEffectsImpl(original);
    }

    @ModifyArg(
            method = "onHit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z"
            ),
            index = 0,
            require = 0
    )
    private class_1293 savaru$scaleArrowEffects_onHit(class_1293 original) {
        return savaru$scaleArrowEffectsImpl(original);
    }

    @ModifyArg(
            method = "onHit(Lnet/minecraft/util/hit/EntityHitResult;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z"
            ),
            index = 0,
            require = 0
    )
    private class_1293 savaru$scaleArrowEffects_onHitDesc(class_1293 original) {
        return savaru$scaleArrowEffectsImpl(original);
    }

    private class_1293 savaru$scaleArrowEffectsImpl(class_1293 original) {
        if (original == null) return null;

        net.minecraft.class_1799 arrowStack;
        try {
            arrowStack = ((PersistentProjectileEntityAccessor) (Object) this).savaru$asItemStack();
        } catch (Throwable t) {
            return original;
        }

        double levelMult = ArrowAffixProcessor.getEffectLevelMultiplier(arrowStack);
        double durMult = ArrowAffixProcessor.getEffectDurationMultiplier(arrowStack);
        if (levelMult == 1.0 && durMult == 1.0) return original;

        int oldAmp = original.method_5578();
        int newAmp = oldAmp;
        if (levelMult != 1.0) {
            // Use ceil so even small % boosts can increase level (e.g., 10% turns level 1 into 2).
            newAmp = Math.max(oldAmp, (int) Math.ceil((oldAmp + 1) * levelMult) - 1);
        }

        int oldDur = original.method_5584();
        int newDur = oldDur;
        if (durMult != 1.0) {
            newDur = (int) Math.ceil(oldDur * durMult);
        }

        return new class_1293(
                original.method_5579(),
                newDur,
                newAmp,
                original.method_5591(),
                original.method_5581(),
                original.method_5592()
        );
    }
}
