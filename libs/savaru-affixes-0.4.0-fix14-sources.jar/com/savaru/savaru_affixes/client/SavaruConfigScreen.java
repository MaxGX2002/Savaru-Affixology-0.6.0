package com.savaru.savaru_affixes.client;

import com.savaru.savaru_affixes.config.ConfigManager;
import com.savaru.savaru_affixes.config.SavaruConfig;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * ModMenu config screen (Fabric 1.21.1 compatible).
 *
 * IMPORTANT:
 * Some 1.21.1 Yarn variants do not reliably forward input events to
 * AlwaysSelectedEntryListWidget entries, causing TextFields to be "view only".
 * This screen uses a simple manual scroll layout to guarantee fields are editable.
 */
public class SavaruConfigScreen extends class_437 {
    private final class_437 parent;

    // Rows (label + desc + optional widget)
    private final List<Row> rows = new ArrayList<>();

    // Widgets
    private class_4185 includeVanillaWeapons;
    private class_342 weaponTags;
    private class_342 chestWeaponChance;
    private class_342 scanPerTick;

    private class_342 dropCommon, dropUncommon, dropRare, dropEpic, dropLegendary, dropMythic, dropBeyond, dropUnrivaled;
    private class_342 rollCommon, rollUncommon, rollRare, rollEpic, rollLegendary, rollMythic, rollBeyond, rollUnrivaled;

    private class_4185 saveBtn;
    private class_4185 cancelBtn;

    private double scrollY = 0.0;
    private class_2561 errorMsg = null;
    private int contentHeight = 0;

    private static final int TOP = 28;
    private static final int BOTTOM_PAD = 48;
    private static final int ROW_H = 36;

    private static final DecimalFormat PCT_FMT = new DecimalFormat("0.########");

    public SavaruConfigScreen(class_437 parent) {
        super(class_2561.method_43471("screen.savaru_affixes.config.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        this.method_37067();
        this.rows.clear();

        SavaruConfig c = ConfigManager.get();

        // Build widgets first (added as drawable children so Screen handles focus/typing)
        includeVanillaWeapons = class_4185.method_46430(
                class_2561.method_43469("screen.savaru_affixes.config.toggle",
                        class_2561.method_43471("screen.savaru_affixes.config.include_vanilla"),
                        c.includeVanillaWeapons ? class_2561.method_43471("screen.savaru_affixes.config.on") : class_2561.method_43471("screen.savaru_affixes.config.off")),
                b -> {
                    boolean now = !c.includeVanillaWeapons;
                    c.includeVanillaWeapons = now;
                    b.method_25355(class_2561.method_43469("screen.savaru_affixes.config.toggle",
                            class_2561.method_43471("screen.savaru_affixes.config.include_vanilla"),
                            now ? class_2561.method_43471("screen.savaru_affixes.config.on") : class_2561.method_43471("screen.savaru_affixes.config.off")));
                }
        ).method_46434(0, 0, 180, 20).method_46431();
        this.method_37063(includeVanillaWeapons);

        weaponTags = new class_342(this.field_22793, 0, 0, 260, 20, class_2561.method_43471("screen.savaru_affixes.config.weapon_tags"));
        weaponTags.method_1852(String.join(",", c.weaponTags));
        weaponTags.method_1880(4096);
        weaponTags.method_1888(true);
        this.method_37063(weaponTags);

        chestWeaponChance = new class_342(this.field_22793, 0, 0, 110, 20, class_2561.method_43471("screen.savaru_affixes.config.chest_weapon_chance"));
        chestWeaponChance.method_1852(pct(c.chestWeaponChance));
        chestWeaponChance.method_1880(64);
        chestWeaponChance.method_1888(true);
        this.method_37063(chestWeaponChance);

        scanPerTick = new class_342(this.field_22793, 0, 0, 110, 20, class_2561.method_43471("screen.savaru_affixes.config.scan_per_tick"));
        scanPerTick.method_1852(String.valueOf(c.scanPerTick));
        scanPerTick.method_1880(32);
        scanPerTick.method_1888(true);
        this.method_37063(scanPerTick);

        // Drop fields
        dropCommon = numberField(pct(c.dropCommon));
        dropUncommon = numberField(pct(c.dropUncommon));
        dropRare = numberField(pct(c.dropRare));
        dropEpic = numberField(pct(c.dropEpic));
        dropLegendary = numberField(pct(c.dropLegendary));
        dropMythic = numberField(pct(c.dropMythic));
        dropBeyond = numberField(pct(c.dropBeyond));
        dropUnrivaled = numberField(pct(c.dropUnrivaled));

        // Roll fields
        rollCommon = numberField(pct(c.rollCommon));
        rollUncommon = numberField(pct(c.rollUncommon));
        rollRare = numberField(pct(c.rollRare));
        rollEpic = numberField(pct(c.rollEpic));
        rollLegendary = numberField(pct(c.rollLegendary));
        rollMythic = numberField(pct(c.rollMythic));
        rollBeyond = numberField(pct(c.rollBeyond));
        rollUnrivaled = numberField(pct(c.rollUnrivaled));

        // Build rows (labels + desc + widget)
        addSection("screen.savaru_affixes.config.section.mob_drop", "screen.savaru_affixes.config.section.mob_drop.desc");
        addNumberRow("screen.savaru_affixes.config.drop.common", "screen.savaru_affixes.config.drop.base", dropCommon);
        addNumberRow("screen.savaru_affixes.config.drop.uncommon", "screen.savaru_affixes.config.drop.base", dropUncommon);
        addNumberRow("screen.savaru_affixes.config.drop.rare", "screen.savaru_affixes.config.drop.base", dropRare);
        addNumberRow("screen.savaru_affixes.config.drop.epic", "screen.savaru_affixes.config.drop.base", dropEpic);
        addNumberRow("screen.savaru_affixes.config.drop.legendary", "screen.savaru_affixes.config.drop.base", dropLegendary);
        addNumberRow("screen.savaru_affixes.config.drop.mythic", "screen.savaru_affixes.config.drop.ultra", dropMythic);
        addNumberRow("screen.savaru_affixes.config.drop.beyond", "screen.savaru_affixes.config.drop.ultra", dropBeyond);
        addNumberRow("screen.savaru_affixes.config.drop.unrivaled", "screen.savaru_affixes.config.drop.ultra", dropUnrivaled);

        addSection("screen.savaru_affixes.config.section.roll", "screen.savaru_affixes.config.section.roll.desc");
        addNumberRow("screen.savaru_affixes.config.roll.common", "screen.savaru_affixes.config.roll.weight", rollCommon);
        addNumberRow("screen.savaru_affixes.config.roll.uncommon", "screen.savaru_affixes.config.roll.weight", rollUncommon);
        addNumberRow("screen.savaru_affixes.config.roll.rare", "screen.savaru_affixes.config.roll.weight", rollRare);
        addNumberRow("screen.savaru_affixes.config.roll.epic", "screen.savaru_affixes.config.roll.weight", rollEpic);
        addNumberRow("screen.savaru_affixes.config.roll.legendary", "screen.savaru_affixes.config.roll.weight", rollLegendary);
        addNumberRow("screen.savaru_affixes.config.roll.mythic", "screen.savaru_affixes.config.roll.ultra", rollMythic);
        addNumberRow("screen.savaru_affixes.config.roll.beyond", "screen.savaru_affixes.config.roll.ultra", rollBeyond);
        addNumberRow("screen.savaru_affixes.config.roll.unrivaled", "screen.savaru_affixes.config.roll.ultra", rollUnrivaled);

        addSection("screen.savaru_affixes.config.section.weapons", "screen.savaru_affixes.config.section.weapons.desc");
        addButtonRow("screen.savaru_affixes.config.include_vanilla", "screen.savaru_affixes.config.include_vanilla.desc", includeVanillaWeapons);
        addTextRow("screen.savaru_affixes.config.weapon_tags", "screen.savaru_affixes.config.weapon_tags.desc", weaponTags);
        addNumberRow("screen.savaru_affixes.config.chest_weapon_chance", "screen.savaru_affixes.config.chest_weapon_chance.desc", chestWeaponChance);
        addNumberRow("screen.savaru_affixes.config.scan_per_tick", "screen.savaru_affixes.config.scan_per_tick.desc", scanPerTick);

        // Bottom buttons (fixed)
        int btnW = 120;
        int y = this.field_22790 - 28;
        saveBtn = class_4185.method_46430(class_2561.method_43471("screen.savaru_affixes.config.save"), b -> onSave()).method_46434(this.field_22789 / 2 - btnW - 6, y, btnW, 20).method_46431();
        cancelBtn = class_4185.method_46430(class_2561.method_43471("screen.savaru_affixes.config.cancel"), b -> method_25419()).method_46434(this.field_22789 / 2 + 6, y, btnW, 20).method_46431();
        this.method_37063(saveBtn);
        this.method_37063(cancelBtn);

        recalcContentHeight();
        clampScroll();
        layoutRows();
    }

    private class_342 numberField(String value) {
        class_342 tf = new class_342(this.field_22793, 0, 0, 110, 20, class_2561.method_43473());
        tf.method_1852(value);
        tf.method_1880(64);
        tf.method_1888(true);
        this.method_37063(tf);
        return tf;
    }

    private void addSection(String titleKey, String descKey) {
        rows.add(Row.section(class_2561.method_43471(titleKey), class_2561.method_43471(descKey)));
    }

    private void addNumberRow(String labelKey, String descKey, class_342 field) {
        rows.add(Row.withWidget(class_2561.method_43471(labelKey), class_2561.method_43471(descKey), field));
    }

    private void addTextRow(String labelKey, String descKey, class_342 field) {
        rows.add(Row.withWidget(class_2561.method_43471(labelKey), class_2561.method_43471(descKey), field));
    }

    private void addButtonRow(String labelKey, String descKey, class_4185 button) {
        rows.add(Row.withWidget(class_2561.method_43471(labelKey), class_2561.method_43471(descKey), button));
    }

    private void recalcContentHeight() {
        contentHeight = rows.size() * ROW_H;
    }

    private int viewTop() {
        return TOP;
    }

    private int viewBottom() {
        return this.field_22790 - BOTTOM_PAD;
    }

    private int viewHeight() {
        return Math.max(32, viewBottom() - viewTop());
    }

    private void clampScroll() {
        int max = Math.max(0, contentHeight - viewHeight());
        if (scrollY < 0) scrollY = 0;
        if (scrollY > max) scrollY = max;
    }

    private void layoutRows() {
        int rowLeft = Math.max(20, (this.field_22789 - 520) / 2);
        int rowWidth = Math.min(520, this.field_22789 - 40);

        int y = viewTop() - (int) scrollY;

        for (Row r : rows) {
            r.x = rowLeft;
            r.y = y;
            r.w = rowWidth;

            if (r.widget instanceof class_342 tf) {
                tf.method_46421(rowLeft + rowWidth - tf.method_25368() - 10);
                tf.method_46419(y + 10);
            } else if (r.widget instanceof class_4185 btn) {
                btn.method_46421(rowLeft + rowWidth - btn.method_25368() - 10);
                btn.method_46419(y + 10);
            }

            y += ROW_H;
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);

        layoutRows();

        // Let Screen draw children first (TextFields/Buttons). This avoids some resource-pack z-order oddities.
        super.method_25394(context, mouseX, mouseY, delta);

        // Title on top
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 10, 0xFFFFFF);

        // Render labels/descriptions on top of widgets.
        // Use loose visibility bounds so text doesn't disappear when UI scale / resource packs affect viewTop/viewBottom.
        for (Row r : rows) {
            if (r == null) continue;
            if (r.y + ROW_H < -ROW_H || r.y > this.field_22790 + ROW_H) continue;

            int labelColor = r.isSection ? 0xFFFFFF : 0xFFFFFF;
            int descColor  = r.isSection ? 0xAAAAAA : 0x888888;

            context.method_27535(this.field_22793, r.label, r.x + 6, r.y + (r.isSection ? 6 : 4), labelColor);
            context.method_27535(this.field_22793, r.desc,  r.x + 6, r.y + 18, descColor);
        }

        drawScrollbar(context);

        if (this.errorMsg != null) {
            context.method_27534(this.field_22793, this.errorMsg, this.field_22789 / 2, this.field_22790 - 52, 0xFF5555);
        }
    }


    private void drawScrollbar(class_332 context) {
        int top = viewTop();
        int bottom = viewBottom();
        int left = this.field_22789 - 16;
        int right = this.field_22789 - 12;

        int vh = viewHeight();
        int ch = Math.max(vh, contentHeight);
        if (ch <= vh) return;

        int barH = Math.max(20, (int) ((double) vh * (double) vh / (double) ch));
        int maxScroll = Math.max(1, contentHeight - vh);
        int barY = top + (int) ((scrollY / (double) maxScroll) * (vh - barH));

        context.method_25294(left, top, right, bottom, 0x33000000);
        context.method_25294(left, barY, right, barY + barH, 0xAAFFFFFF);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        // Scroll when inside config area
        if (mouseY >= viewTop() && mouseY <= viewBottom()) {
            scrollY -= verticalAmount * 18.0;
            clampScroll();
            layoutRows();
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        layoutRows();
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        layoutRows();
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }

    private void onSave() {
        SavaruConfig c = ConfigManager.get();
        this.errorMsg = null;

        // Parse tags
        c.weaponTags = Arrays.stream(weaponTags.method_1882().split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .distinct()
                .collect(java.util.stream.Collectors.toList());

        // Validate numeric fields first (show a readable error instead of silently falling back).
        List<String> bad = new ArrayList<>();

        // Drop
        Double v;
        v = tryParsePct(dropCommon.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.drop.common").getString()); else c.dropCommon = v;
        v = tryParsePct(dropUncommon.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.drop.uncommon").getString()); else c.dropUncommon = v;
        v = tryParsePct(dropRare.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.drop.rare").getString()); else c.dropRare = v;
        v = tryParsePct(dropEpic.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.drop.epic").getString()); else c.dropEpic = v;
        v = tryParsePct(dropLegendary.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.drop.legendary").getString()); else c.dropLegendary = v;
        v = tryParsePct(dropMythic.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.drop.mythic").getString()); else c.dropMythic = v;
        v = tryParsePct(dropBeyond.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.drop.beyond").getString()); else c.dropBeyond = v;
        v = tryParsePct(dropUnrivaled.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.drop.unrivaled").getString()); else c.dropUnrivaled = v;

        // Roll
        v = tryParsePct(rollCommon.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.roll.common").getString()); else c.rollCommon = v;
        v = tryParsePct(rollUncommon.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.roll.uncommon").getString()); else c.rollUncommon = v;
        v = tryParsePct(rollRare.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.roll.rare").getString()); else c.rollRare = v;
        v = tryParsePct(rollEpic.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.roll.epic").getString()); else c.rollEpic = v;
        v = tryParsePct(rollLegendary.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.roll.legendary").getString()); else c.rollLegendary = v;
        v = tryParsePct(rollMythic.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.roll.mythic").getString()); else c.rollMythic = v;
        v = tryParsePct(rollBeyond.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.roll.beyond").getString()); else c.rollBeyond = v;
        v = tryParsePct(rollUnrivaled.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.roll.unrivaled").getString()); else c.rollUnrivaled = v;

        // Others
        v = tryParsePct(chestWeaponChance.method_1882()); if (v == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.chest_weapon_chance").getString()); else c.chestWeaponChance = v;
        Integer iv = tryParseInt(scanPerTick.method_1882()); if (iv == null) bad.add(class_2561.method_43471("screen.savaru_affixes.config.scan_per_tick").getString()); else c.scanPerTick = iv;

        if (!bad.isEmpty()) {
            this.errorMsg = class_2561.method_43469("screen.savaru_affixes.config.error_numbers", String.join("、", bad));
            return;
        }

        ConfigManager.save();
        method_25419();
    }

    private static Double tryParsePct(String s) {
        try {
            double v = Double.parseDouble(s.trim());
            return v / 100.0;
        } catch (Exception e) {
            return null;
        }
    }

    private Integer tryParseInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return null;
        }
    }

double parsePct(String s, double fallback) {
        try {
            double v = Double.parseDouble(s.trim());
            // UI uses percent: 2 = 2% => 0.02
            return v / 100.0;
        } catch (Exception e) {
            return fallback;
        }
    }

    private static int parseInt(String s, int fallback) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    private static String pct(double v) {
        return PCT_FMT.format(v * 100.0);
    }

    private static final class Row {
        final class_2561 label;
        final class_2561 desc;
        final boolean isSection;
        final Object widget; // TextFieldWidget or ButtonWidget, or null

        int x, y, w;

        private Row(class_2561 label, class_2561 desc, boolean isSection, Object widget) {
            this.label = label;
            this.desc = desc;
            this.isSection = isSection;
            this.widget = widget;
        }

        static Row section(class_2561 label, class_2561 desc) {
            return new Row(label, desc, true, null);
        }

        static Row withWidget(class_2561 label, class_2561 desc, Object widget) {
            return new Row(label, desc, false, widget);
        }
    }
}
