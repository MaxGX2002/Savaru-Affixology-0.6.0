package com.savaru.savaru_affixes;

import net.minecraft.class_1282;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

/**
 * Helpers for creating damage sources.
 *
 * We use a custom DamageType (data-driven JSON) to emulate "RPG magic":
 * bypass armor + bypass resistance.
 */
public final class DamageUtil {
    private DamageUtil() {}

    public static final class_5321<class_8110> SAVARU_MAGIC = class_5321.method_29179(
            class_7924.field_42534,
            class_2960.method_60655("savaru_affixes", "savaru_magic")
    );

    /** Create our magic damage source if the registry key exists, otherwise fall back to vanilla magic. */
    public static class_1282 savaruMagic(class_1937 world) {
        try {
            return world.method_48963().method_48795(SAVARU_MAGIC);
        } catch (Throwable ignored) {
            return world.method_48963().method_48831();
        }
    }
}
