package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

public final class WeaponPool {
    private WeaponPool(){}

    public static List<class_1792> buildEligibleItems() {
        List<class_1792> out = new ArrayList<>();

        // Tags from config
        for (String tagId : ConfigManager.get().weaponTags) {
            try {
                class_6862<class_1792> tag = class_6862.method_40092(net.minecraft.class_7924.field_41197, class_2960.method_60654(tagId));
                for (class_1792 item : class_7923.field_41178) {
                    if (class_7923.field_41178.method_47983(item).method_40220(tag)) out.add(item);
                }
            } catch (Exception ignored) {}
        }

        if (ConfigManager.get().includeVanillaWeapons) {
            addIfMissing(out, class_1802.field_8091);
            addIfMissing(out, class_1802.field_8528);
            addIfMissing(out, class_1802.field_8371);
            addIfMissing(out, class_1802.field_8845);
            addIfMissing(out, class_1802.field_8802);
            addIfMissing(out, class_1802.field_22022);
            addIfMissing(out, class_1802.field_8406);
            addIfMissing(out, class_1802.field_8062);
            addIfMissing(out, class_1802.field_8475);
            addIfMissing(out, class_1802.field_8825);
            addIfMissing(out, class_1802.field_8556);
            addIfMissing(out, class_1802.field_22025);
            addIfMissing(out, class_1802.field_8102);
            addIfMissing(out, class_1802.field_8399);
            addIfMissing(out, class_1802.field_8547);
        }

        // Custom additions (by item id)
        for (String idStr : ConfigManager.get().customWeaponRates.keySet()) {
            try {
                class_2960 id = class_2960.method_60654(idStr);
                class_1792 item = class_7923.field_41178.method_10223(id);
                if (item != null && item != net.minecraft.class_1802.field_8162) {
                    addIfMissing(out, item);
                }
            } catch (Exception ignored) {}
        }

        return out;
    }

    private static void addIfMissing(List<class_1792> list, class_1792 item) {
        if (!list.contains(item)) list.add(item);
    }

    public static class_1799 randomWeapon(class_5819 random) {
        List<class_1792> items = buildEligibleItems();
        if (items.isEmpty()) return class_1799.field_8037;

        // Weighted pick: custom items can be tuned via customWeaponRates.
        Map<String, Double> rates = ConfigManager.get().customWeaponRates;
        double total = 0.0;
        double[] w = new double[items.size()];
        for (int i = 0; i < items.size(); i++) {
            class_1792 it = items.get(i);
            class_2960 id = class_7923.field_41178.method_10221(it);
            double weight = 1.0;
            if (id != null) {
                Double v = rates.get(id.toString());
                if (v != null) weight = Math.max(0.0, v);
            }
            w[i] = weight;
            total += weight;
        }
        if (total <= 0.0) return class_1799.field_8037;

        double r = random.method_43058() * total;
        for (int i = 0; i < items.size(); i++) {
            r -= w[i];
            if (r <= 0) return new class_1799(items.get(i));
        }
        return new class_1799(items.get(items.size() - 1));
    }
}
