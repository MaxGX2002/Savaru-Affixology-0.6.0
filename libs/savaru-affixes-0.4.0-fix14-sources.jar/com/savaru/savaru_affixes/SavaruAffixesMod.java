package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import com.savaru.savaru_affixes.inscription.BladeSongHooks;
import com.savaru.savaru_affixes.inscription.JingtinFistHooks;
import com.savaru.savaru_affixes.inscription.StarflowHooks;
import com.savaru.savaru_affixes.inscription.SpringRainHooks;
import com.savaru.savaru_affixes.inscription.HundredBlossomsHooks;
import com.savaru.savaru_affixes.inscription.DistantThunderHooks;
import com.savaru.savaru_affixes.inscription.KagushimeiHooks;
import com.savaru.savaru_affixes.inscription.ChidoriHooks;
import com.savaru.savaru_affixes.inscription.MimicArrowHooks;
import com.savaru.savaru_affixes.inscription.DetonationHooks;
import com.savaru.savaru_affixes.inscription.ThunderfireCannonHooks;
import com.savaru.savaru_affixes.ranged.PinArrowHooks;
import com.savaru.savaru_affixes.ranged.RicochetHooks;
// Project keeps most hook/registry classes in the base package.
// Avoid importing non-existent subpackages (e.g. ".effects" / ".registry").
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Main initializer.
 *
 * Keep this class minimal: register content & init hooks only.
 * Runtime combat logic lives in dedicated hook classes / mixins.
 */
public class SavaruAffixesMod implements ModInitializer {
    public static final String MOD_ID = "savaru_affixes";

    /** Convenience: create identifiers under this mod id. */
    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
    public static final class_2960 ITEM_GROUP_KEY = class_2960.method_60655(MOD_ID, "item_group");

    public static final class_1761 ITEM_GROUP = FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("itemGroup." + MOD_ID))
            .method_47320(() -> new class_1799(class_1802.field_22022))
            .method_47317((ctx, entries) -> {
                // Intentionally empty.
            })
            .method_47324();

    @Override
    public void onInitialize() {
        // Config & utilities
        UnidentifiedHandler.init();
        ConfigManager.load();

        // Registries
        AffixRegistry.init();
        SavaruAttributes.register();

        // Loot / drop
        WeaponDropHooks.init();
        MobDropHooks.init();
        ChestLootHooks.init();
        LootContainerTransformHooks.init();

        // Effects
        ArmorStealHooks.init();
        OverhealHooks.init();
        BurnHooks.init();
        PinArrowHooks.init();
        RicochetHooks.init();

        // UI / commands
        TooltipHooks.init();
        CommandHooks.register();

        // Inscription
        BladeSongHooks.init();
        JingtinFistHooks.init();
        StarflowHooks.init();
        SpringRainHooks.init();
        HundredBlossomsHooks.init();
        DetonationHooks.init();
        ThunderfireCannonHooks.init();
        KagushimeiHooks.init();
        ChidoriHooks.init();

        // Creative tab
        class_2378.method_10230(class_7923.field_44687, ITEM_GROUP_KEY, ITEM_GROUP);
    }
}