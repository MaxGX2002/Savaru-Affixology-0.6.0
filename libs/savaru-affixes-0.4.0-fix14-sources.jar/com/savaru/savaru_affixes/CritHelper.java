package com.savaru.savaru_affixes;

import java.util.Optional;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Unified critical hit value resolver.
 *
 * Merges our own SavaruAttributes crit values with Critical Strike mod
 * (critical_strike:chance / critical_strike:damage) via soft-depend.
 * If Critical Strike is not installed the soft-read returns 0 and nothing breaks.
 *
 * Scale conventions (same as SavaruAttributes):
 *   chance : 0..1  (e.g. 0.15 = 15%)
 *   damage : 0..∞  bonus multiplier added to 1.0  (e.g. 0.45 → final ×1.45)
 *
 * Critical Strike stores its values in the same scale (it lists base +5% / +50%).
 */
public final class CritHelper {

    private CritHelper() {}

    private static final class_2960 CS_CHANCE_ID = class_2960.method_60655("critical_strike", "chance");
    private static final class_2960 CS_DAMAGE_ID = class_2960.method_60655("critical_strike", "damage");

    /**
     * Combined crit chance (0-1).
     * = savaru_affixes:crit_chance  +  critical_strike:chance (if mod present)
     */
    public static double getCritChance(class_1657 player) {
        double base = player.method_45325(SavaruAttributes.CRIT_CHANCE_ENTRY);
        base += readModdedAttr(player, CS_CHANCE_ID);
        return Math.min(1.0, Math.max(0.0, base));
    }

    /**
     * Combined crit damage bonus (≥0).
     * = savaru_affixes:crit_damage  +  critical_strike:damage (if mod present)
     * Final multiplier = 1.0 + result.
     */
    public static double getCritDamage(class_1657 player) {
        double base = player.method_45325(SavaruAttributes.CRIT_DAMAGE_ENTRY);
        base += readModdedAttr(player, CS_DAMAGE_ID);
        return Math.max(0.0, base);
    }

    // ── soft-read helper ─────────────────────────────────────────────────────
    private static double readModdedAttr(class_1657 player, class_2960 id) {
        try {
            var entryOpt = class_7923.field_41190.method_55841(id);
            if (entryOpt.isEmpty()) return 0.0;
            var inst = player.method_5996(entryOpt.get());
            if (inst == null) return 0.0;
            return inst.method_6194();
        } catch (Exception e) {
            return 0.0;
        }
    }
}
