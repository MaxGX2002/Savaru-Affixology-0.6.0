package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.class_1792;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_77;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Loot-table based chest injection.
 *
 * This stays friendly with instanced-container mods such as Lootr because it only modifies the loot
 * tables themselves instead of trying to write directly into container inventories.
 */
public final class ChestLootHooks {
    private ChestLootHooks(){}

    public static void init() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source) -> {
            class_2960 id = key.method_29177();
            if (!isInjectableChestTable(id)) return;

            double chance = ConfigManager.get().chestWeaponChance;
            if (chance <= 0.0D) return;

            List<class_1792> items = WeaponPool.buildEligibleItems();
            if (items.isEmpty()) return;

            class_55.class_56 pool = class_55.method_347()
                    .method_352(class_44.method_32448(1))
                    .method_356(class_219.method_932((float) chance));

            for (class_1792 item : buildWeightedChestCandidates(items)) {
                pool.method_351(class_77.method_411(item));
            }

            tableBuilder.method_336(pool);
        });
    }

    /**
     * Accept loot tables from any namespace so modded structures are included as well.
     * This is important for Lootr because it mirrors vanilla loot-table generation for many modded containers.
     */
    private static boolean isInjectableChestTable(class_2960 id) {
        if (id == null) return false;
        String path = id.method_12832();
        if (path == null || path.isBlank()) return false;

        // Ignore non-container/system tables.
        if (!path.startsWith("chests/")) return false;

        // Avoid touching Lootr's own support/system tables if any are present.
        if ("lootr".equals(id.method_12836())) return false;

        return true;
    }

    /**
     * Convert the configured weapon pool into a small weighted candidate list. Repeating entries keeps the code
     * simple and compatible across mappings while still allowing custom weapon weights to influence chest rolls.
     */
    private static List<class_1792> buildWeightedChestCandidates(List<class_1792> items) {
        Map<String, Double> rates = ConfigManager.get().customWeaponRates;
        List<class_1792> out = new ArrayList<>();

        // Keep injected tables compact.
        final int hardCap = 48;

        for (class_1792 item : items) {
            String id = net.minecraft.class_7923.field_41178.method_10221(item).toString();
            double weight = Math.max(0.0D, rates.getOrDefault(id, 1.0D));
            int copies = toCopies(weight);
            for (int i = 0; i < copies && out.size() < hardCap; i++) {
                out.add(item);
            }
            if (out.size() >= hardCap) break;
        }

        if (out.isEmpty()) {
            int limit = Math.min(items.size(), 16);
            for (int i = 0; i < limit; i++) out.add(items.get(i));
        }

        return out;
    }

    private static int toCopies(double weight) {
        if (weight <= 0.0D) return 0;
        if (weight < 0.75D) return 1;
        if (weight < 1.5D) return 2;
        if (weight < 3.0D) return 3;
        if (weight < 6.0D) return 4;
        return 5;
    }
}
