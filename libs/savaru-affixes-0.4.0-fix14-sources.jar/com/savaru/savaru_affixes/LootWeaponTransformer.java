package com.savaru.savaru_affixes;

import net.minecraft.class_1799;

/**
 * Converts generated loot-table weapons into clean Savaru unidentified bases.
 * This strips vanilla enchantments / names / extra components by rebuilding the stack from its item type.
 */
public final class LootWeaponTransformer {
    private LootWeaponTransformer() {}

    public static class_1799 convertIfEligible(class_1799 original) {
        if (original == null || original.method_7960()) return original;

        // Do not touch items that are already part of the Savaru flow.
        if (UnidentifiedHandler.isUnidentified(original)) return original;
        if (AffixHelper.getRarity(original) != null) return original;
        if (!AffixHelper.getAffixes(original).isEmpty()) return original;

        if (!AffixHelper.isEligibleWeapon(original)) return original;

        class_1799 converted = new class_1799(original.method_7909(), original.method_7947());
        UnidentifiedHandler.markUnidentified(converted);
        return converted;
    }
}
