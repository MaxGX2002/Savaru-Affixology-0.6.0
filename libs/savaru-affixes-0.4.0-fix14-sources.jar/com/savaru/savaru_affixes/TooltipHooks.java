package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_124;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1744;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1766;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1825;
import net.minecraft.class_1829;
import net.minecraft.class_1833;
import net.minecraft.class_1835;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_5250;
import net.minecraft.class_7417;
import net.minecraft.item.*;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;


public final class TooltipHooks {


    private TooltipHooks() {}

    private static final String BOOK_TYPE_KEY = "book_type";

    private static String getBookType(class_1799 stack) {
        try {
            class_2487 root = AffixHelper.getRoot(stack);
            if (root != null && root.method_10545(BOOK_TYPE_KEY)) return root.method_10558(BOOK_TYPE_KEY);
        } catch (Exception ignored) {}
        return "weapon";
    }

    private static class_2561 getBookTitleText(class_1799 stack) {
        return switch (getBookType(stack)) {
            case "ranged" -> class_2561.method_43471("item.savaru_affixes.affix_book_ranged");
            case "arrow" -> class_2561.method_43471("item.savaru_affixes.affix_book_arrow");
            case "armor" -> class_2561.method_43471("item.savaru_affixes.affix_book_armor");
            default -> class_2561.method_43471("item.savaru_affixes.affix_book_weapon");
        };
    }

    private static class_2561 getTypeLabel(class_1799 stack) {
        if (isAffixBook(stack)) {
            return switch (getBookType(stack)) {
                case "ranged" -> class_2561.method_43471("savaru.affix.type.ranged");
                case "arrow" -> class_2561.method_43471("savaru.affix.type.arrow");
                case "armor" -> class_2561.method_43471("savaru.affix.type.armor");
                default -> class_2561.method_43471("savaru.affix.type.weapon");
            };
        }
        if (stack.method_7909() instanceof class_1744 || stack.method_7909() instanceof class_1825 || stack.method_7909() instanceof class_1833) {
            return class_2561.method_43471("savaru.affix.type.arrow");
        }
        if (stack.method_7909() instanceof class_1753 || stack.method_7909() instanceof class_1764) {
            return class_2561.method_43471("savaru.affix.type.ranged");
        }
        if (stack.method_7909() instanceof net.minecraft.class_1738) {
            return class_2561.method_43471("savaru.affix.type.armor");
        }
        if (isWeaponLike(stack.method_7909())) {
            return class_2561.method_43471("savaru.affix.type.weapon");
        }
        return class_2561.method_43473();
    }


    /**
     * Vanilla tooltip attack damage line is item-based (attribute modifiers),
     * but our rarity bonus is applied to the player attribute (server-side).
     * Patch the tooltip line so the green number also includes the rarity bonus.
     */
    private static void applyRarityBonusToVanillaAttackLine(java.util.List<class_2561> lines, double rarityAtk) {
        if (rarityAtk == 0.0) return;

        for (int i = 0; i < lines.size(); i++) {
            class_2561 t = lines.get(i);
            class_7417 content = t.method_10851();
            if (!(content instanceof class_2588 tr)) continue;

            String key = tr.method_11022();
            if (key == null || !key.startsWith("attribute.modifier.")) continue;

            Object[] args = tr.method_11023();
            if (args == null || args.length < 2) continue;

            // arg[1] should be the attribute name
            if (!(args[1] instanceof class_2561 attrText)) continue;
            class_7417 attrContent = attrText.method_10851();
            if (!(attrContent instanceof class_2588 attrTr)) continue;
            if (!"attribute.name.generic.attack_damage".equals(attrTr.method_11022())) continue;

            // arg[0] is the amount (usually a Double)
            double base;
            try {
                if (args[0] instanceof Number n) base = n.doubleValue();
                else base = Double.parseDouble(String.valueOf(args[0]));
            } catch (Exception ignored) {
                continue;
            }

            double patched = base + rarityAtk;
            class_2561 replacement = class_2561.method_43469(key, patched, attrText).method_10862(t.method_10866());
            lines.set(i, replacement);
            return;
        }
    }

    /**
     * Patch the "遠程傷害" line from the 戰鬥 mod to include our quality bonus.
     * Matches any attribute.modifier.* line whose attribute name Text contains "遠程".
     * Fallback: also matches any numeric line whose whole string contains "遠程".
     */
    private static void applyRarityBonusToRangedLine(java.util.List<class_2561> lines, double rarityAtk) {
        if (rarityAtk == 0.0) return;

        for (int i = 0; i < lines.size(); i++) {
            class_2561 t = lines.get(i);
            class_7417 content = t.method_10851();
            if (!(content instanceof class_2588 tr)) continue;

            String key = tr.method_11022();
            if (key == null || !key.startsWith("attribute.modifier.")) continue;

            Object[] args = tr.method_11023();
            if (args == null || args.length < 2) continue;

            if (!(args[1] instanceof class_2561 attrText)) continue;

            // Match if attribute name contains "遠程" (zh_tw) or key contains "ranged"
            String attrStr = attrText.getString();
            String attrKey = "";
            class_7417 ac = attrText.method_10851();
            if (ac instanceof class_2588 atc) attrKey = atc.method_11022();

            boolean isRangedLine = attrStr.contains("遠程")
                    || attrKey.contains("ranged")
                    || attrKey.contains("projectile");
            if (!isRangedLine) continue;

            double base;
            try {
                if (args[0] instanceof Number n) base = n.doubleValue();
                else base = Double.parseDouble(String.valueOf(args[0]));
            } catch (Exception ignored) {
                continue;
            }

            double patched = base + rarityAtk;
            class_2561 replacement = class_2561.method_43469(key, patched, attrText).method_10862(t.method_10866());
            lines.set(i, replacement);
            return;
        }
    }

    
    private static class_124 colorForAffix(String path) {
        // Damage-type (yellow)
        switch (path) {
            case "crit_chance", "crit_damage", "bonus_damage", "true_damage",
                 "armor_pen_flat", "armor_pen_pct", "res_pen_flat", "res_pen_pct",
                 "max_hp_pct", "cur_hp_pct", "execute_flat", "execute_pct",
                 "attack_speed", "burn", "arcblade", "berserk", "greedlife", "wenwu",
                 "armor_warrior",
                 "armor_berserker_crit_chance", "armor_berserker_crit_dmg",
                 "armor_cs_crit_chance_pct", "armor_cs_crit_chance_flat", "armor_cs_crit_dmg":
                return class_124.field_1054;
        }
        // Support-type (blue)
        switch (path) {
            case "lifesteal", "devour", "durability_bonus", "durability_nocost", "overheal", "armor_steal",
                 "armor_regen_flat", "armor_regen_pct", "armor_limiter_flat", "armor_limiter_pct":
                return class_124.field_1075;
        }
        // ★ Chest-exclusive affixes (light purple — stands out)
        switch (path) {
            case "armor_chest_thorns", "armor_chest_flame_steel",
                 "armor_chest_charged_burst", "armor_chest_shield":
                return class_124.field_1076;
        }
        // Effect-type (green) — default for all armor defensive affixes
        return class_124.field_1060;
    }

    private static class_5250 buildValueText(String valueStr, class_124 mainColor) {
        int idx = valueStr.indexOf('(');
        if (idx < 0) {
            return class_2561.method_43470(valueStr).method_27692(mainColor);
        }
        String mainPart = valueStr.substring(0, idx).trim();
        String notePart = valueStr.substring(idx).trim();
        class_5250 out = class_2561.method_43470(mainPart).method_27692(mainColor);
        if (!notePart.isEmpty()) {
            out.method_10852(class_2561.method_43470(" "))
               .method_10852(class_2561.method_43470(notePart).method_27661().method_27694(style -> style.method_10977(class_124.field_1063)));
        }
        return out;
    }

    private static class_5250 affixLine(String nameKey, String valueStr, class_124 mainColor) {
        return class_2561.method_43469(
                "tooltip.savaru_affixes.affix_line",
                class_2561.method_43471(nameKey).method_27692(mainColor),
                buildValueText(valueStr, mainColor)
        );
    }


    
    private static boolean isAffixBook(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (!stack.method_31574(net.minecraft.class_1802.field_8529)) return false;
        try {
            if (stack.method_57826(net.minecraft.class_9334.field_49631)) {
                class_2561 t = stack.method_57824(net.minecraft.class_9334.field_49631);
                if (t != null && (t.getString().startsWith("詞綴之書") || t.getString().equals(class_2561.method_43471("item.savaru_affixes.affix_book_weapon").getString()) || t.getString().equals(class_2561.method_43471("item.savaru_affixes.affix_book_ranged").getString()) || t.getString().equals(class_2561.method_43471("item.savaru_affixes.affix_book_arrow").getString()) || t.getString().equals(class_2561.method_43471("item.savaru_affixes.affix_book_armor").getString()))) return true;
            }
        } catch (Exception ignored) {}

        try {
            var root = AffixHelper.getRoot(stack);
            return root != null && root.method_10545(AffixHelper.KEY_AFFIXES);
        } catch (Exception ignored) {}

        return false;
    }

private static boolean isWeaponLike(class_1792 item) {
        return item instanceof class_1829
                || item instanceof class_1743
                || item instanceof class_1753
                || item instanceof class_1764
                || item instanceof class_1835
                || item instanceof class_1766;
    }

    private static boolean isInscriptionProof(class_1799 stack) {
        return stack != null && !stack.method_7960()
                && stack.method_31574(class_1802.field_8894)
                && InscriptionHelper.getInscription(stack) != null;
    }

    private static class_2561 unknownInscriptionLine() {
        return class_2561.method_43470("[未知的銘刻，刻印在武器上揭露其效果]")
                .method_27695(class_124.field_1080, class_124.field_1056);
    }


public static void init() {
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            // Unidentified equipment keeps its real title (e.g. 「未鑑定的 獄髓劍」),
            // but still hides rarity / affixes. Affix-book preview outputs remain fully scrambled.
            if (UnidentifiedHandler.isUnidentified(stack)) {
                if (isAffixBook(stack)) {
                    if (!lines.isEmpty()) {
                        lines.set(0, class_2561.method_43470(lines.get(0).getString())
                                .method_27695(net.minecraft.class_124.field_1063, net.minecraft.class_124.field_1051));
                    }
                    lines.add(class_2561.method_43473());
                    lines.add(class_2561.method_43470("????????").method_27695(class_124.field_1063, class_124.field_1051));
                    lines.add(class_2561.method_43470("????????").method_27695(class_124.field_1063, class_124.field_1051));
                    lines.add(class_2561.method_43470("????????").method_27695(class_124.field_1063, class_124.field_1051));
                    lines.add(class_2561.method_43470("????????").method_27695(class_124.field_1063, class_124.field_1051));
                    return;
                }

                class_2561 title = lines.isEmpty() ? stack.method_7964() : lines.get(0);
                lines.clear();
                lines.add(title);

                class_2561 typeLabel = getTypeLabel(stack);
                if (!typeLabel.getString().isEmpty()) {
                    lines.add(typeLabel.method_27661().method_27694(style -> style.method_10977(class_124.field_1063)));
                }

                lines.add(class_2561.method_43473());
                lines.add(class_2561.method_43470("【未鑑定】").method_27695(class_124.field_1063, class_124.field_1067, class_124.field_1056));
                lines.add(class_2561.method_43470("[鑑定該武器，使武器獲得完整效果]").method_27692(class_124.field_1063));

                if (InscriptionHelper.getInscription(stack) != null || isInscriptionProof(stack)) {
                    lines.add(unknownInscriptionLine());
                    return;
                }

                lines.add(class_2561.method_43470("?? 未知詞綴").method_27695(class_124.field_1080, class_124.field_1056));
                lines.add(class_2561.method_43470("?? 未知詞綴").method_27695(class_124.field_1080, class_124.field_1056));
                return;
            }

            if (isAffixBook(stack)) {
                if (!lines.isEmpty()) lines.set(0, getBookTitleText(stack));
                class_2561 typeLabel = getTypeLabel(stack);
                if (!typeLabel.getString().isEmpty()) lines.add(1, typeLabel.method_27661().method_27661().method_27694(style -> style.method_10977(class_124.field_1063)));
            }

            class_2499 affixes = AffixHelper.getAffixes(stack);

            // Show quality line above the affix list.
            Rarity rarity = AffixHelper.getRarity(stack);

            // Items without rarity: weapons show 未鑑定, but affix books still need to show their own affix list after identification.
            boolean isBook = isAffixBook(stack);
            if (rarity == null && !isBook) {
                if (isWeaponLike(stack.method_7909())) {
                    lines.add(class_2561.method_43470("【未鑑定】").method_27695(class_124.field_1063, class_124.field_1067, class_124.field_1056));
                }
                return;
            }

            // Patch vanilla attack damage tooltip so the green number matches our rarity bonus.
            // Do NOT patch for bows/crossbows here; they get patched via applyRarityBonusToRangedLine below.
            // Do NOT patch for armor; armor uses GENERIC_ARMOR which vanilla shows correctly.
            if (rarity != null) {
                boolean isRanged = (stack.method_7909() instanceof class_1753) || (stack.method_7909() instanceof class_1764);
                boolean isArmor  = (stack.method_7909() instanceof class_1738);
                if (!isRanged && !isArmor) {
                    double atk = rarity.attackBonus();
                    if (atk != 0.0) applyRarityBonusToVanillaAttackLine(lines, atk);
                }
                if (isRanged) {
                    double atk = rarity.attackBonus();
                    if (atk != 0.0) applyRarityBonusToRangedLine(lines, atk);
                }
            }

            lines.add(class_2561.method_43473());
            if (rarity != null) {
                String rKey = "rarity.savaru_affixes." + rarity.name().toLowerCase();
                lines.add(rarity == Rarity.UNRIVALED ? Rarity.rainbowTextDynamic(class_2561.method_43471(rKey).getString(), System.currentTimeMillis()) : class_2561.method_43471(rKey).method_10862(rarity.style()));

                // Rarity bonus line
                boolean isRanged = (stack.method_7909() instanceof class_1753) || (stack.method_7909() instanceof class_1764);
                boolean isArmor  = (stack.method_7909() instanceof class_1738);
                if (isArmor) {
                    double arm = rarity.armorBonus();
                    if (arm > 0.0) {
                        lines.add(class_2561.method_43469("tooltip.savaru_affixes.rarity_armor",
                                String.format("+%.0f", arm)));
                    }
                } else {
                    double atk = rarity.attackBonus();
                    if (atk > 0.0) {
                        lines.add(class_2561.method_43469(
                                isRanged ? "tooltip.savaru_affixes.rarity_ranged_damage" : "tooltip.savaru_affixes.rarity_attack",
                                String.format("+%.1f", atk)));
                    }
                }
            }


            class_2561 typeLabel = getTypeLabel(stack);
            if (!typeLabel.getString().isEmpty()) {
                lines.add(typeLabel.method_27661().method_27661().method_27694(style -> style.method_10977(class_124.field_1063)));
            }

            // Do not show the "詞綴" header; keep the list itself.







            for (class_2520 el : affixes) {
                if (!(el instanceof class_2487 tag)) continue;

                String idStr = tag.method_10558("id"); // e.g. "savaru_affixes:crit_damage"
                double value = tag.method_10574("value"); // stored in "percent points" for % affixes

                String path = idStr;
                String ns = "savaru_affixes";
                int colon = idStr.indexOf(':');
                if (colon >= 0) {
                    ns = idStr.substring(0, colon);
                    path = idStr.substring(colon + 1);
                }

                class_124 fmt = colorForAffix(path);

                Affix meta = null;
                for (Affix a : AffixRegistry.getAll()) {
                    if (a.id().equals(path)) { meta = a; break; }
                }

                // Special formatting for multi-param affixes
                if ("wither".equals(path) || "weakness".equals(path) || "frailty".equals(path)) {
                    int level = tag.method_10550("level");
                    String chance = String.format("%.0f%%", value);
                    String key = "affix." + ns + "." + path;
                    lines.add(affixLine(key, "Lv." + level + " (" + chance + ")", fmt));
                    continue;
                }

                if ("overheal".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    // value is percent points (5)
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470(String.format("%.0f%% (額外生命+2，可疊到+10，2秒)", value))
                    ));
                    continue;
                }

                if ("durability_bonus".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470(String.format("+%.0f%% 耐久度", value))
                    ));
                    continue;
                }

                if ("durability_nocost".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470(String.format("%.0f%% 不消耗耐久", value))
                    ));
                    continue;
                }


                if ("attack_speed".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470(String.format("+%.0f%% 攻擊速度", value))
                    ));
                    continue;
                }

                if ("burn".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    int level = tag.method_10550("level"); // 1-5 extra magic dmg
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470(String.format("%.0f%%", value))
                                    .method_10852(class_2561.method_43470(String.format("（額外%d點魔法傷害，2秒）", level)).method_27661().method_27694(style -> style.method_10977(class_124.field_1063)))
                    ));
                    continue;
                }

                if ("devour".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    int level = tag.method_10550("level"); // 1-5 hunger
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470(String.format("%.0f%%", value))
                                    .method_10852(class_2561.method_43470(String.format("（回復%d飽食度）", level)).method_27661().method_27694(style -> style.method_10977(class_124.field_1063)))
                    ));
                    continue;
                }

                if ("arcblade".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470("攻擊轉為等值魔法傷害")
                    ));
                    continue;
                }

                // ---- Ranged affix short descriptions (keep it simple) ----
                if ("magic_arrow".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43471("affixdesc.savaru_affixes.magic_arrow").method_27661().method_27694(style -> style.method_10977(class_124.field_1063))));
                    continue;
                }
                if ("luminous_arrow".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43471("affixdesc.savaru_affixes.luminous_arrow").method_27661().method_27694(style -> style.method_10977(class_124.field_1063))));
                    continue;
                }
                if ("hunter_mark".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43471("affixdesc.savaru_affixes.hunter_mark").method_27661().method_27694(style -> style.method_10977(class_124.field_1063))));
                    continue;
                }
                if ("piercing_path".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470(String.format("%.0f%% ", value)).method_10852(class_2561.method_43471("affixdesc.savaru_affixes.piercing_path").method_27661().method_27694(style -> style.method_10977(class_124.field_1063)))
                    ));
                    continue;
                }
                if ("draw_speed".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470(String.format("+%.2fs ", value)).method_10852(class_2561.method_43471("affixdesc.savaru_affixes.draw_speed").method_27661().method_27694(style -> style.method_10977(class_124.field_1063)))
                    ));
                    continue;
                }
                if ("lifeshot".equals(path) || "finisher_shot".equals(path) || "crit_chance".equals(path) || "crit_damage".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    String pct = String.format("%.0f%% ", value);
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470(pct).method_10852(class_2561.method_43471("affixdesc.savaru_affixes." + path).method_27661().method_27694(style -> style.method_10977(class_124.field_1063)))
                    ));
                    continue;
                }

                if ("berserk".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469(
                            "tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key),
                            class_2561.method_43470("生命≤50%時造成250%傷害")
                    ));
                    continue;
                }

                if ("armor_pen_flat".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43470("+" + String.format("%.0f", value))).method_27692(fmt));
                    continue;
                }

                if ("armor_pen_pct".equals(path) || "armor_steal".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43470(String.format("%.0f%%", value))).method_27692(fmt));
                    continue;
                }

                if ("res_pen_flat".equals(path) || "res_pen_pct".equals(path)) {
                    int level = tag.method_10550("level");
                    String key = "affix." + ns + "." + path;
                    String val = ("res_pen_flat".equals(path)) ? ("+" + String.format("%.0f", value)) : (String.format("%.0f%%", value));
                    lines.add(affixLine(key, "Lv." + level + " (" + val + ")", fmt));
                    continue;
                }

                if ("max_hp_pct".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43470(String.format("%.0f%%", value))).method_27692(fmt));
                    continue;
                }

                if ("cur_hp_pct".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43470(String.format("%.0f%%", value))).method_27692(fmt));
                    continue;
                }

                if ("execute_flat".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43470(String.format("≤%.0f", value))).method_27692(fmt));
                    continue;
                }

                if ("execute_pct".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43470(String.format("≤%.0f%%", value))).method_27692(fmt));
                    continue;
                }

                if ("poison_aoe".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(affixLine(key, String.format("%.0f%% (半徑5格，中毒I 3秒，冷卻10秒)", value), fmt));
                    continue;
                }

                // ── CS爆擊 affixes: display value ÷ 100 ────────────────────
                if ("armor_cs_crit_chance_pct".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    String pct = String.format("+%.1f%%", value / 100.0);
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key).method_27692(fmt),
                            class_2561.method_43470(pct + " ").method_27692(fmt)
                                    .method_10852(class_2561.method_43471("affixdesc.savaru_affixes.armor_cs_crit_chance_pct")
                                            .method_27661().method_27694(s -> s.method_10977(class_124.field_1063)))
                    ));
                    continue;
                }
                if ("armor_cs_crit_chance_flat".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    String val = String.format("+%.0f", value);
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key).method_27692(fmt),
                            class_2561.method_43470(val + " ").method_27692(fmt)
                                    .method_10852(class_2561.method_43471("affixdesc.savaru_affixes.armor_cs_crit_chance_flat")
                                            .method_27661().method_27694(s -> s.method_10977(class_124.field_1063)))
                    ));
                    continue;
                }
                if ("armor_cs_crit_dmg".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    String pct = String.format("+%.1f%%", value / 100.0);
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key).method_27692(fmt),
                            class_2561.method_43470(pct + " ").method_27692(fmt)
                                    .method_10852(class_2561.method_43471("affixdesc.savaru_affixes.armor_cs_crit_dmg")
                                            .method_27661().method_27694(s -> s.method_10977(class_124.field_1063)))
                    ));
                    continue;
                }

                // ── Armor affixes with descriptions ─────────────────────────
                if (path.startsWith("armor_")) {
                    String key = "affix." + ns + "." + path;
                    String descKey = "affixdesc.savaru_affixes." + path;
                    boolean pctAffix = meta != null && meta.percent();

                    // ★ Chest-exclusive affixes: special header + light purple
                    if (path.startsWith("armor_chest_")) {
                        lines.add(class_2561.method_43470("  ────────────").method_27694(s -> s.method_10977(class_124.field_1064)));
                        lines.add(class_2561.method_43470("  ★ ").method_27692(class_124.field_1076)
                                .method_10852(class_2561.method_43471("tooltip.savaru_affixes.chest_exclusive").method_27692(class_124.field_1076)));
                        String valStr;
                        if ("armor_chest_thorns".equals(path)) {
                            valStr = String.format("%.0f%%", value);
                        } else {
                            valStr = ""; // binary affixes
                        }
                        lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line",
                                class_2561.method_43471(key).method_27692(class_124.field_1076),
                                class_2561.method_43470(valStr.isEmpty() ? "" : valStr + " ").method_27692(class_124.field_1076)
                                        .method_10852(class_2561.method_43471(descKey).method_27661().method_27694(s -> s.method_10977(class_124.field_1064)))
                        ));
                        lines.add(class_2561.method_43470("  ────────────").method_27694(s -> s.method_10977(class_124.field_1064)));
                        continue;
                    }

                    // Special: adapt affixes show the target effect name
                    if ("armor_adapt_dmg".equals(path) || "armor_adapt_dur".equals(path) || "armor_adapt_lvl".equals(path)) {
                        String effectId = tag.method_10558(com.savaru.savaru_affixes.armor.ArmorAffixProcessor.KEY_ADAPT_EFFECT);
                        String effectName = effectId;
                        try {
                            if (effectId.contains(":")) effectName = effectId.substring(effectId.indexOf(':') + 1);
                            effectName = net.minecraft.class_2561.method_43471("effect.minecraft." + effectName).getString();
                        } catch (Exception ignored) {}
                        String valStr = pctAffix ? String.format("+%.0f%%", value) : String.format("+%.0f", value);
                        lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line",
                                class_2561.method_43471(key).method_27692(fmt),
                                class_2561.method_43470(valStr + " ").method_27692(fmt)
                                        .method_10852(class_2561.method_43470("(" + effectName + ")").method_27661().method_27694(s -> s.method_10977(class_124.field_1063)))
                        ));
                        continue;
                    }

                    String valStr = pctAffix ? String.format("+%.2f%%", value) : String.format("+%.2f", value);
                    lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line",
                            class_2561.method_43471(key).method_27692(fmt),
                            class_2561.method_43470(valStr + " ").method_27692(fmt)
                                    .method_10852(class_2561.method_43471(descKey)
                                            .method_27661().method_27694(s -> s.method_10977(class_124.field_1063)))
                    ));
                    continue;
                }

                boolean percent = meta != null && meta.percent();
                String display = percent
                        ? String.format("+%.2f%%", value)
                        : String.format("+%.2f", value);

                String key = "affix." + ns + "." + path;
                lines.add(class_2561.method_43469("tooltip.savaru_affixes.affix_line", class_2561.method_43471(key), class_2561.method_43470(display)).method_27692(fmt));
            }

            // ---- Inscription (銘刻) block ----
            // Spec: show above ALL attribute lines; normal affixes remain below.
            class_2487 ins = InscriptionHelper.getInscription(stack);
            if (ins != null) {
                String typeStr = ins.method_10558("type");
                String idStr2 = ins.method_10558("id");

                class_124 nameColor = InscriptionHelper.TYPE_OUTLAND.equals(typeStr) ? class_124.field_1076
                        : (InscriptionHelper.TYPE_SECRET.equals(typeStr) ? class_124.field_1075 : class_124.field_1068);

                java.util.List<class_2561> block = new java.util.ArrayList<>();
                block.add(class_2561.method_43473());
                block.add(class_2561.method_43470("==========").method_27661().method_27694(style -> style.method_10977(class_124.field_1063)));
                // Content is inside the box (per spec)
                block.add(class_2561.method_43470("銘刻").method_27695(nameColor, class_124.field_1067));
                String targetStr = ins.method_10545("target") ? ins.method_10558("target") : InscriptionHelper.getTargetForId(idStr2);
                if (targetStr != null && !targetStr.isEmpty()) {
                    block.add(class_2561.method_43471("tooltip.savaru_affixes.inscription.target." + targetStr).method_27692(class_124.field_1063));
                }
                block.add(InscriptionHelper.displayName(typeStr, idStr2).method_27661().method_27692(nameColor));
                for (class_2561 desc : InscriptionHelper.descriptionLines(typeStr, idStr2)) {
                    block.add(desc.method_27661().method_27692(nameColor));
                }
                block.add(class_2561.method_43470("==========").method_27661().method_27694(style -> style.method_10977(class_124.field_1063)));

                int insertAt = Math.min(1, lines.size());
                lines.addAll(insertAt, block);
            }
        });
    }
}