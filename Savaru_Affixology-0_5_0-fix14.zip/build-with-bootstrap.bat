@echo off
setlocal

echo === Savaru Bootstrap Build (NO WRAPPER) ===

set GRADLE_VERSION=8.6
set GRADLE_DIR=.gradle-bootstrap
set GRADLE_ZIP=gradle-%GRADLE_VERSION%-bin.zip
set GRADLE_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip

java -version >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Java not found. Please check JAVA_HOME.
  pause
  exit /b 1
)

if not exist "%GRADLE_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat" (
  echo [INFO] Downloading Gradle %GRADLE_VERSION%...
  if not exist "%GRADLE_DIR%" mkdir "%GRADLE_DIR%"
  powershell -Command "Invoke-WebRequest -Uri '%GRADLE_URL%' -OutFile '%GRADLE_DIR%\%GRADLE_ZIP%'"
  if errorlevel 1 (
    echo [ERROR] Failed to download Gradle.
    pause
    exit /b 1
  )
  powershell -Command "Expand-Archive -Force '%GRADLE_DIR%\%GRADLE_ZIP%' '%GRADLE_DIR%'"
  if errorlevel 1 (
    echo [ERROR] Failed to extract Gradle zip.
    pause
    exit /b 1
  )
)

call "%GRADLE_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat" build

if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)

echo.
echo === BUILD SUCCESS ===
echo Output: build\libs\
pause
