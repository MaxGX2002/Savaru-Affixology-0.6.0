# Savaru Affixology — AI Developer Handoff Document
# Version: 0.5.0 | Fabric 1.21.1 | Yarn Mappings

> **用途**：提供給接手開發的 AI（Claude / ChatGPT / Copilot）的完整技術參考。
> 包含：專案架構、已知陷阱、核心設計模式、已修復的 bug 及其根因分析。

---

## 1. 專案概覽

| 項目 | 值 |
|---|---|
| Mod ID | `savaru_affixes` |
| Minecraft | 1.21.1 |
| Loader | Fabric 0.18.4 |
| Mappings | **Yarn**（不是 Mojang！所有代碼用 Yarn 命名如 `NbtCompound`、`getEquippedStack`） |
| Java | 21 |
| 套件管理 | `com.savaru.savaru_affixes` |
| 核心功能 | 裝備品質系統（8 階 Rarity）+ 詞綴系統（武器/弓箭/盔甲各有獨立池）+ 銘刻系統 |
| 總行數 | ~10,500 行 Java / 82 個檔案 / 27 個 Mixin |

### 目錄結構
```
com.savaru.savaru_affixes/
├── SavaruAffixesMod.java          # ModInitializer 主進入點
├── Affix.java                     # record(id, min, max, weight, percent, weaponOnly)
├── AffixHelper.java               # ★ 核心：NBT 讀寫、Roll 詞綴、物品屬性修改器重建
├── AffixRegistry.java             # 所有詞綴定義（武器/弓箭/盔甲）
├── Rarity.java                    # enum: COMMON→UNRIVALED（8階）
├── RarityRoller.java              # 品質機率表
├── CritHelper.java                # 統合弱點命中率+CS爆擊率（soft-depend）
├── CritAttributeApplier.java      # 每 tick 同步武器詞綴到玩家屬性
├── SavaruAttributes.java          # 自訂屬性註冊（crit_chance/crit_damage/lifesteal/true_damage）
├── TooltipHooks.java              # ★ 客戶端 tooltip 渲染（注意：使用 client-only API）
├── UnidentifiedHandler.java       # 未鑑定物品邏輯
├── armor/
│   └── ArmorAffixProcessor.java   # 盔甲詞綴加總器（getTotal 跨 4 部位）
├── ranged/
│   ├── RangedAffixProcessor.java  # 弓箭傷害計算
│   ├── PinArrowHooks.java         # 釘箭效果
│   └── RicochetHooks.java         # 彈射效果
├── arrow/
│   └── ArrowAffixProcessor.java   # 箭矢詞綴處理
├── inscription/                   # 銘刻系統（13 個銘刻效果）
├── mixin/                         # 27 個 Mixin
├── client/                        # ModMenu 設定畫面
└── config/                        # JSON 設定檔管理
```

---

## 2. ★ 最重要的架構決策：盔甲屬性修改器

### 2.1 設計原則

盔甲詞綴的屬性加成（護甲值、韌性、抗擊退、攻擊力、弱點、CS爆擊、最大生命值）
**全部作為 ITEM-LEVEL 屬性修改器**寫入物品的 `ATTRIBUTE_MODIFIERS` 元件。

**不是**每 tick 修改玩家屬性（player attribute modifier）。

理由：
- Item-level modifier 會自動顯示在「裝備於頭部時：」tooltip 區段
- 穿脫裝備時 Minecraft 自動加減，不需要 tick 邏輯
- 與原版屬性修改器完美共存

### 2.2 ★★★ CRITICAL：Modifier ID 必須部位專屬

```java
// ❌ 致命錯誤 — 所有盔甲共用同一 ID
Identifier id = Identifier.of("savaru_affixes", "affix_cs_cc");
// → EntityAttributeInstance 同一 ID 只能存一個
// → 四件盔甲只有最後一件生效

// ✅ 正確做法 — 每個部位有獨立 ID
Identifier id = slotId("affix_cs_cc", slot);
// → "savaru_affixes:affix_cs_cc_head"
// → "savaru_affixes:affix_cs_cc_chest"
// → "savaru_affixes:affix_cs_cc_legs"
// → "savaru_affixes:affix_cs_cc_feet"
```

工具方法：
```java
private static String slotSuffix(AttributeModifierSlot slot) {
    return switch (slot) {
        case HEAD  -> "_head";
        case CHEST -> "_chest";
        case LEGS  -> "_legs";
        case FEET  -> "_feet";
        default    -> "_armor";
    };
}

private static Identifier slotId(String base, AttributeModifierSlot slot) {
    return Identifier.of("savaru_affixes", base + slotSuffix(slot));
}
```

### 2.3 ★★★ CRITICAL：原版基礎值保護

```java
// ❌ 致命錯誤 — 從 stack 讀取（可能已被舊版覆寫）
AttributeModifiersComponent current = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
// 如果任何先前版本的 mod 曾 set() 過，原版 +3 盔甲就永遠丟失

// ✅ 正確做法 — 從新建的同類型物品讀取（保證原版值）
AttributeModifiersComponent vanillaDefaults =
    new ItemStack(stack.getItem()).get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
```

完整建構順序：
```
STEP 1: new ItemStack(item) → 讀取原版預設值（+3 armor, +3 toughness 等）
STEP 2: 從 stack 讀取其他 mod 的 entry（跳過 vanilla 和我們的）
STEP 3: 加入我們的 slot-specific modifier
STEP 4: stack.set(ATTRIBUTE_MODIFIERS, builder.build())
```

### 2.4 PlayerEntityTickMixin 中的盔甲邏輯

**只有以下兩個效果需要 tick 處理**（因為是藥水效果，不是屬性修改器）：
- 防火 ≥100% → 給予 `FIRE_RESISTANCE` 藥水效果
- 恩賜 → 給予 `ABSORPTION` 藥水效果（每 60 秒刷新）

**所有其他盔甲詞綴（護甲/韌性/重裝/戰士/狂徒/聖徒/CS爆擊）
都不應該在 tick 中用 `applyArmorModifier()` 或 `tryApplyModdedAttr()` 施加。**

Tick 中只做：
- 清除舊版 tick-based modifier（`cleanupLegacyModifier`）
- 偵測並遷移舊格式物品（`migrateArmorIfNeeded`）

---

## 3. NBT 儲存結構

所有詞綴資料存在 `CUSTOM_DATA` 元件中：

```
custom_data: {
  savaru_affixes: {
    rarity: "UNRIVALED",
    affixes: [
      { id: "armor_protection_flat", value: 3.5 },
      { id: "armor_cs_crit_chance_pct", value: 2347.0 },
      { id: "armor_adapt_dmg", value: 100.0, adapt_effect: "minecraft:wither" },
      { id: "wither", value: 8.0, level: 2 },
      { id: "burn", value: 15.0, level: 3 }
    ]
  }
}
```

### 讀寫 API
```java
AffixHelper.getRoot(stack)              // 取得 savaru_affixes compound
AffixHelper.setRoot(stack, nbt)         // 寫回
AffixHelper.getRarity(stack)            // Rarity enum or null
AffixHelper.getAffixes(stack)           // NbtList
AffixHelper.getAffixValue(stack, "id")  // double
AffixHelper.getAffixLevel(stack, "id")  // int (wither/burn/devour 的等級)
```

---

## 4. CS 爆擊系統（Critical Strike 模組 soft-depend）

### 4.1 屬性 ID
- `critical_strike:chance` — 爆擊率
- `critical_strike:damage` — 爆擊傷害

### 4.2 盔甲 CS 爆擊詞綴

| 詞綴 ID | NBT 儲存範圍 | Modifier 值 | Tooltip 顯示 | Operation |
|---|---|---|---|---|
| `armor_cs_crit_chance_pct` | 750-3000 | NBT÷100 = 7.5-30.0 | NBT÷100 = 7.5-30.0% | ADD_VALUE |
| `armor_cs_crit_chance_flat` | 10-25 | 原值 | 原值 | ADD_VALUE |
| `armor_cs_crit_dmg` | 500-5000 | NBT÷100 = 5.0-50.0 | NBT÷100 = 5.0-50.0% | ADD_VALUE |

### 4.3 武器 CS 爆擊詞綴
| 詞綴 ID | NBT 儲存 | Modifier 值 | 適用 |
|---|---|---|---|
| `cs_crit_chance` | 5-20 (%) | ÷100 = 0.05-0.20 | 近戰+遠程 |
| `cs_crit_dmg` | 100-350 (%) | ÷100 = 1.0-3.5 | 近戰+遠程 |

武器的 CS 爆擊透過 `CritAttributeApplier.tick()` 以玩家屬性修改器施加。

### 4.4 弱點 vs CS 爆擊

| 系統 | 屬性 | 來源 | Scale |
|---|---|---|---|
| 弱點命中率 | `savaru_affixes:crit_chance` | 武器詞綴 `crit_chance` + 盔甲 `armor_berserker_crit_chance` | 0-1 (0.15 = 15%) |
| 弱點傷害 | `savaru_affixes:crit_damage` | 武器詞綴 `crit_damage` + 盔甲 `armor_berserker_crit_dmg` | 0-∞ (0.45 = +45%) |
| CS 爆擊率 | `critical_strike:chance` | 武器 `cs_crit_chance` + 盔甲 `armor_cs_crit_chance_*` | 由 CS 模組定義 |
| CS 爆擊傷害 | `critical_strike:damage` | 武器 `cs_crit_dmg` + 盔甲 `armor_cs_crit_dmg` | 由 CS 模組定義 |

弱點和 CS 爆擊是**完全獨立的系統**，各自使用不同屬性。
`CritHelper.java` 統合兩者用於傷害計算。

---

## 5. 詞綴池與互斥規則

### 5.1 池分類
| 類型 | 觸發條件 | 詞綴來源 |
|---|---|---|
| 近戰武器 | `SwordItem/AxeItem/TridentItem` | `weaponOnly=true` 且非 `RANGED_ONLY` |
| 遠程武器 | `BowItem/CrossbowItem` | `RANGED_ONLY` + `SHARED_WEAPON` |
| 箭矢 | `ArrowItem` | `ARROW_ONLY` |
| 盔甲 | `ArmorItem` | `ARMOR_ONLY` |

### 5.2 互斥群組（AffixHelper 中定義）
```
ARMOR_PEN ←→ true_damage
RES_PEN ←→ ARMOR_PEN, true_damage
DOT_OR_DEBUFF: wither ←→ weakness ←→ frailty ←→ lifesteal
HEALING: lifesteal ←→ overheal
DURABILITY: durability_bonus ←→ durability_nocost
BURN_GROUP: burn ←→ poison_aoe ←→ wither
DEVOUR_GROUP: devour ←→ lifesteal
BLADE_MODE: arcblade ←→ berserk
GREEDLIFE_GROUP: greedlife ←→ berserk
ADAPT_GROUP ←→ TOUGHNESS_GROUP
BERSERKER_GROUP: armor_berserker_crit_chance ←→ armor_berserker_crit_dmg
CS_CRIT_CHANCE_GROUP: armor_cs_crit_chance_pct ←→ armor_cs_crit_chance_flat
SAINT_GROUP: armor_saint_flat ←→ armor_saint_pct
```

---

## 6. 品質系統

### Rarity 等級
```
COMMON → UNCOMMON → RARE → EPIC → LEGENDARY → MYTHIC → BEYOND → UNRIVALED
```

### 品質加成
| Rarity | 攻擊力加成 | 盔甲值加成 | 詞綴數量 |
|---|---|---|---|
| COMMON | 0 | 0 | 0-1 |
| UNCOMMON | +0.5 | +1 | 1-2 |
| RARE | +0.7 | +2 | 1-2 |
| EPIC | +1.0 | +3 | 2-3 |
| LEGENDARY | +2.0 | +4 | 3-4 |
| MYTHIC | +3.0 | +5 | 4-5 |
| BEYOND | +4.0 | +7 | 6-7 |
| UNRIVALED | +5.0 | +10 | 6-7 |

UNRIVALED 使用彩虹漸變名稱動畫。

---

## 7. 已知陷阱與歷史 Bug

### 7.1 ❌ 不要在 tick 中施加盔甲屬性
**每修一次**都會復發的 bug。根因：開發者忘記哪些屬性是 item-level、哪些是 tick-based。

**規則**：
- 如果屬性會反映在「裝備於 X 時：」tooltip → **item-level**（在 `addArmorAffixModifiers` 中）
- 如果是藥水效果 → **tick-based**（在 `PlayerEntityTickMixin` 中）

### 7.2 ❌ 不要信任 stack.get(ATTRIBUTE_MODIFIERS) 作為原版基礎值來源
一旦任何 mod 版本曾經 `stack.set(ATTRIBUTE_MODIFIERS, ...)` 覆寫過元件，
原版的 +3 armor 等基礎修改器就永遠消失了。

**必須用** `new ItemStack(stack.getItem()).get(ATTRIBUTE_MODIFIERS)` 讀取。

### 7.3 ❌ str_replace 靜默失敗
`str_replace` 工具在找不到 `old_str` 時不會報錯。
**修改後必須用 `grep -n` 驗證**關鍵方法/變數確實存在。

### 7.4 ⚠️ TooltipHooks 是 client-only
`TooltipHooks.init()` 使用 `net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback`。
目前在 `SavaruAffixesMod.onInitialize()`（common）中呼叫。
在 Dedicated Server 上會 `NoClassDefFoundError`。

**應該**拆出 `ClientModInitializer`。

### 7.5 ⚠️ PersistentProjectileEntityAccessor 註冊
此 Mixin Accessor 被 `ArrowEntityEffectMixin` 和 `PersistentProjectileEntityHitMixin` 使用，
必須在 `savaru_affixes.mixins.json` 中註冊。

### 7.6 ⚠️ 版本號
`fabric.mod.json` 的 version 欄位應使用 `${version}` 佔位符，
實際版本由 `gradle.properties` 的 `mod_version` 控制。

---

## 8. 物品屬性修改器重建流程圖

```
applyRarityNameColor(stack, rarity)
  │
  ├─ applyRarityAttackModifier(stack, rarity)    ← 核心方法
  │    │
  │    ├─ vanillaDefaults = new ItemStack(item).get(ATTRIBUTE_MODIFIERS)
  │    │   └─ STEP1: 複製所有原版修改器到 builder
  │    │
  │    ├─ stackCurrent = stack.get(ATTRIBUTE_MODIFIERS)
  │    │   └─ STEP2: 複製非原版、非我們的修改器（其他 mod）
  │    │
  │    ├─ if (isArmor)
  │    │   ├─ 加入 rarity_armor_{slot} (ADD_VALUE)
  │    │   └─ addArmorAffixModifiers(stack, builder, slot)
  │    │       ├─ affix_prot_flat_{slot}     → GENERIC_ARMOR (ADD_VALUE)
  │    │       ├─ affix_prot_pct_{slot}      → GENERIC_ARMOR (ADD_MULTIPLIED_BASE)
  │    │       ├─ affix_tough_flat_{slot}     → GENERIC_ARMOR_TOUGHNESS
  │    │       ├─ affix_tough_pct_{slot}      → GENERIC_ARMOR_TOUGHNESS
  │    │       ├─ affix_heavy_{slot}          → GENERIC_KNOCKBACK_RESISTANCE
  │    │       ├─ affix_warrior_{slot}        → GENERIC_ATTACK_DAMAGE (MULT_TOTAL)
  │    │       ├─ affix_berserk_cc_{slot}     → savaru_affixes:crit_chance
  │    │       ├─ affix_berserk_cd_{slot}     → savaru_affixes:crit_damage
  │    │       ├─ affix_cs_cc_pct_{slot}      → critical_strike:chance (soft)
  │    │       ├─ affix_cs_cc_flat_{slot}     → critical_strike:chance (soft)
  │    │       ├─ affix_cs_cd_{slot}          → critical_strike:damage (soft)
  │    │       ├─ affix_saint_flat_{slot}     → GENERIC_MAX_HEALTH
  │    │       └─ affix_saint_pct_{slot}      → GENERIC_MAX_HEALTH
  │    │
  │    ├─ if (isRanged) → 不加修改器（runtime 處理）
  │    │
  │    └─ if (isMelee) → rarity_attack_bonus (ADD_VALUE)
  │
  └─ applyWenwuAttackModifier(stack)             ← 文武附魔加成
```

---

## 9. Mixin 清單與用途

| Mixin | 目標 | 功能 |
|---|---|---|
| PlayerEntityAttackMixin | PlayerEntity | 近戰傷害計算（弱點/穿甲/吸血/真傷等） |
| PlayerEntityTickMixin | PlayerEntity | 每 tick 更新（武器屬性同步、銘刻狀態機、盔甲效果） |
| PlayerEntityAttributesMixin | PlayerEntity | 註冊自訂屬性到玩家預設列表 |
| BowItemUseMixin/CrossbowItemUseMixin | BowItem/CrossbowItem | 射擊時傳遞詞綴到箭矢 |
| BowItemDrawSpeedMixin/CrossbowItemDrawSpeedMixin | BowItem/CrossbowItem | 蓄力加速詞綴 |
| BowItemReserveMixin | BowItem | 儲備詞綴（不消耗箭矢） |
| PersistentProjectileEntityHitMixin | PersistentProjectileEntity | 箭矢命中時處理遠程詞綴 |
| PersistentProjectileEntityOwnerMixin | PersistentProjectileEntity | 儲存射手引用 |
| PersistentProjectileEntityTickMixin | PersistentProjectileEntity | 光箭/釘箭 tick 效果 |
| PersistentProjectileEntityPickupMixin | PersistentProjectileEntity | 阻止撿起帶詞綴箭矢 |
| PersistentProjectileEntityAccessor | PersistentProjectileEntity | 暴露 asItemStack() |
| PersistentProjectileEntityInvoker | PersistentProjectileEntity | 暴露 setPierceLevel() |
| ArrowEntityEffectMixin | ArrowEntity | 箭矢效果處理 |
| ArmorItemUseMixin | ArmorItem | 阻止穿上未鑑定盔甲 |
| AnvilReforgeMixin | AnvilScreen | 鐵砧重鑄/鑑定邏輯 |
| InscriptionAttackMixin | PlayerEntity | 銘刻攻擊觸發 |
| LivingEntityDamageMixin | LivingEntity | 盔甲傷害減免（鋼化/防彈/防火/適性） |
| LivingEntityEffectMixin | LivingEntity | 適性效果處理 |
| LivingEntitySoulbindMixin | LivingEntity | 定魂銘刻 |
| ItemStackNameMixin | ItemStack | UNRIVALED 彩虹名稱動畫（client） |
| MinecraftClientAttackMixin | MinecraftClient | 客戶端攻擊 hook（client） |

---

## 10. 開發規範

### 10.1 新增盔甲詞綴 Checklist

1. 在 `AffixRegistry.java` 註冊 `new Affix("armor_xxx", min, max, weight, percent, false)`
2. 在 `AffixHelper.ARMOR_ONLY` Set 中加入 ID
3. 如有互斥需求，建立新 Group Set 並在 `rollAffixes()` 中加入檢查
4. 在 `addArmorAffixModifiers()` 中加入 modifier（用 `slotId()`！）
5. 在 `TooltipHooks.java` 的 `armor_` 區段加入 tooltip 顯示
6. 在 `zh_tw.json` 和 `en_us.json` 加入翻譯 key：
   - `affix.savaru_affixes.armor_xxx`
   - `affixdesc.savaru_affixes.armor_xxx`
7. 如果是效果型（不是屬性）→ 加在 `PlayerEntityTickMixin` 的 tick 區段
8. 如果是傷害減免型 → 加在 `ArmorAffixProcessor` 和 `LivingEntityDamageMixin`

### 10.2 修改後驗證 Checklist

```bash
# 1. 括號平衡
for f in $(find src -name "*.java"); do
  o=$(grep -o '{' "$f" | wc -l); c=$(grep -o '}' "$f" | wc -l)
  [ $o -ne $c ] && echo "MISMATCH: $f open=$o close=$c"
done

# 2. JSON 有效性
python3 -c "import json; [json.load(open(f)) for f in ['src/main/resources/fabric.mod.json','src/main/resources/savaru_affixes.mixins.json','src/main/resources/assets/savaru_affixes/lang/zh_tw.json','src/main/resources/assets/savaru_affixes/lang/en_us.json']]"

# 3. 關鍵方法存在
grep -c "private static void addArmorAffixModifiers" src/main/java/com/savaru/savaru_affixes/AffixHelper.java
grep -c "private static Identifier slotId" src/main/java/com/savaru/savaru_affixes/AffixHelper.java
grep -c "new ItemStack(stack.getItem())" src/main/java/com/savaru/savaru_affixes/AffixHelper.java

# 4. 不應存在的 tick-based 盔甲屬性（應全部為 0）
grep -c "applyArmorModifier.*ARMOR_WARRIOR\|applyArmorModifier.*ARMOR_BERSERKER\|applyArmorModifier.*ARMOR_SAINT\|tryApplyModdedAttrMultBase.*critical_strike" src/main/java/com/savaru/savaru_affixes/mixin/PlayerEntityTickMixin.java
```

### 10.3 Mapping 注意事項

本專案使用 **Yarn Mappings**，不是 Mojang Official Mappings。

常見差異：
| Yarn | Mojang |
|---|---|
| `NbtCompound` | `CompoundTag` |
| `getEquippedStack` | `getItemBySlot` |
| `ItemStack.isOf` | `ItemStack.is` |
| `DataComponentTypes` | `DataComponents` |
| `StatusEffects` | `MobEffects` |
| `EntityAttributes` | `Attributes` |

---

## 11. 依賴與 Soft-Depend

| 模組 | 用途 | 整合方式 |
|---|---|---|
| Fabric API | 核心 | `modImplementation` |
| ModMenu | 設定畫面 | `modCompileOnly` / `modRuntimeOnly` |
| Critical Strike | CS 爆擊系統 | `Registries.ATTRIBUTE.getEntry()` soft-depend |
| 任何戰鬥模組（BetterCombat 等） | 遠程傷害屬性 | `findRangedDamageAttribute()` fallback scan |

Soft-depend 模式：
```java
try {
    var opt = Registries.ATTRIBUTE.getEntry(Identifier.of("critical_strike", "chance"));
    if (opt.isPresent()) {
        // CS mod is loaded, use attribute
    }
} catch (Exception ignored) {
    // CS mod not installed, silently skip
}
```

---

## 12. 遠程武器品質加成

遠程武器（弓/弩）的品質攻擊力加成**不寫入**物品屬性修改器。
原因：不同戰鬥模組的遠程傷害屬性名稱不同，無法通用。

處理方式：
1. **Runtime**：在 `RangedAffixProcessor.apply()` 中加入 `rarity.attackBonus()`
2. **Tooltip**：在 `TooltipHooks.applyRarityBonusToRangedLine()` 中 patch 顯示文字
3. **Tooltip info line**：顯示「品質遠程傷害 +X.X」

---

## 13. 銘刻系統概覽

銘刻存在物品的 `CUSTOM_DATA` 中（`inscription` compound），
透過「銘刻之証」在鐵砧上刻印。

銘刻分為：
- **異鄉銘刻**（紫色）：近戰/遠程各有獨立池
- **秘傳銘刻**（青色）：稀有特殊效果

銘刻效果由獨立的 Hooks 類實現（如 `StarflowHooks`、`ChidoriHooks` 等），
在 `InscriptionAttackMixin`（攻擊觸發）和 `PlayerEntityTickMixin`（狀態機 tick）中驅動。

---

## 14. 修改歷史摘要

| 版本 | 關鍵修改 |
|---|---|
| fix8 | 盔甲詞綴初版（tick-based） |
| fix9 | 嘗試遷移到 item-level（str_replace 部分失敗） |
| fix10 | slot-specific ID 概念引入（str_replace 靜默失敗，核心方法未加入） |
| fix11 | `new ItemStack()` 原版值保護、helper 方法確認加入、CS顯示÷100 |
| fix12 | 移除所有 tick-based 盔甲屬性修改器（消除雙重施加） |

**最常復發的 bug**：tick-based 盔甲屬性修改器（每次都以為「需要 tick 來讓多件裝備疊加」，
但實際上 item-level 加上 slot-specific ID 已經自動疊加了）。

---

*Last updated: 2026-03-12 | Savaru Affixology v0.5.0*
