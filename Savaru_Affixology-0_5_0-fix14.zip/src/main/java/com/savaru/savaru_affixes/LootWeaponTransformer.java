package com.savaru.savaru_affixes;

import net.minecraft.item.ItemStack;

/**
 * Converts generated loot-table weapons into clean Savaru unidentified bases.
 * This strips vanilla enchantments / names / extra components by rebuilding the stack from its item type.
 */
public final class LootWeaponTransformer {
    private LootWeaponTransformer() {}

    public static ItemStack convertIfEligible(ItemStack original) {
        if (original == null || original.isEmpty()) return original;

        // Do not touch items that are already part of the Savaru flow.
        if (UnidentifiedHandler.isUnidentified(original)) return original;
        if (AffixHelper.getRarity(original) != null) return original;
        if (!AffixHelper.getAffixes(original).isEmpty()) return original;

        if (!AffixHelper.isEligibleWeapon(original)) return original;

        ItemStack converted = new ItemStack(original.getItem(), original.getCount());
        UnidentifiedHandler.markUnidentified(converted);
        return converted;
    }
}
