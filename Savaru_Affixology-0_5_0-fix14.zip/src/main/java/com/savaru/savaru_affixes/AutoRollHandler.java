package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;


public final class AutoRollHandler {
    private AutoRollHandler() {}

    public static void tick(PlayerEntity player) {
        if (player.getWorld().isClient()) return;

        int scan = Math.max(1, ConfigManager.get().scanPerTick);
        Random random = player.getRandom();

        // Scan main inventory + offhand + armor
        int scanned = 0;
        for (int i = 0; i < player.getInventory().size() && scanned < scan; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            scanned += tryRoll(player, stack, random) ? 1 : 1;
        }
        // cursor stack
        if (player.currentScreenHandler != null) {
            ItemStack cursor = player.currentScreenHandler.getCursorStack();
            tryRoll(player, cursor, random);
        }
    }

    private static boolean tryRoll(PlayerEntity player, ItemStack stack, Random random) {
        if (stack == null || stack.isEmpty()) return false;

        // only roll weapons in our tag (and optionally vanilla weapons)
        if (!AffixHelper.isEligibleWeapon(stack)) return false;

        // already has rarity => do nothing
        if (AffixHelper.getRarity(stack) != null) return false;

        // consume pending rarity if present
        Rarity pending = null;
        if (AffixHelper.isPendingRoll(stack)) pending = AffixHelper.consumePendingRarity(stack);

        Rarity rarity = pending != null ? pending : RarityRoller.rollFirstTime(random);
        if (rarity == null) return false;

        // rollAffixes() writes the rarity + affixes into the stack
        AffixHelper.rollAffixes(stack, rarity);
        AffixHelper.applyRarityNameColor(stack, rarity);
        return true;
    }
}
