package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.inscription.InscriptionHelper;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;

public final class UnidentifiedHelper {
    private UnidentifiedHelper() {}

    public static boolean hasFlag(ItemStack stack) {
        return UnidentifiedHandler.isUnidentified(stack);
    }

    public static boolean isAffixBook(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.BOOK)) return false;
        try {
            NbtCompound root = AffixHelper.getRoot(stack);
            return root != null && root.contains(AffixHelper.KEY_AFFIXES);
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isEquipment(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        Item item = stack.getItem();
        return item instanceof ArmorItem || isWeaponOrTool(stack);
    }

    public static boolean isWeaponOrTool(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        Item item = stack.getItem();
        return item instanceof SwordItem
                || item instanceof AxeItem
                || item instanceof PickaxeItem
                || item instanceof ShovelItem
                || item instanceof HoeItem
                || item instanceof TridentItem
                || item instanceof MaceItem
                || item instanceof BowItem
                || item instanceof CrossbowItem;
    }

    public static boolean shouldPrefixName(ItemStack stack) {
        return hasFlag(stack)
                && !isAffixBook(stack)
                && isEquipment(stack)
                && AffixHelper.getRarity(stack) == null;
    }

    public static boolean shouldBlockUse(ItemStack stack) {
        return hasFlag(stack)
                && !isAffixBook(stack)
                && isEquipment(stack)
                && AffixHelper.getRarity(stack) == null;
    }

    public static boolean isResolvedPreviewOutput(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (!hasFlag(stack)) return false;
        if (isAffixBook(stack)) return true;

        // 銘刻之証本身要保持未鑑定狀態，只在刻印到武器後才揭露內容。
        if (stack.isOf(Items.BLAZE_ROD) && InscriptionHelper.getInscription(stack) != null) {
            return false;
        }

        // 已經有品質 / 詞綴 / 銘刻資料的預覽輸出，拿到手後都應清掉 preview 狀態。
        if (AffixHelper.getRarity(stack) != null || !AffixHelper.getAffixes(stack).isEmpty()) {
            return true;
        }

        return InscriptionHelper.getInscription(stack) != null;
    }
}
