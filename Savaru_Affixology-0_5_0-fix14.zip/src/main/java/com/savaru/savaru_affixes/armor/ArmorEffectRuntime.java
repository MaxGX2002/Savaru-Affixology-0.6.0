package com.savaru.savaru_affixes.armor;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks per-player runtime state for armor affixes that need tick/damage event memory.
 * All times are in server ticks (20 ticks = 1 second).
 */
public final class ArmorEffectRuntime {
    private ArmorEffectRuntime() {}

    // ── 自然回血: combat state ──────────────────────────────────────────
    private static final Map<UUID, Long> lastCombatTick = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> lastRegenTick = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> lastOocRegenTick = new ConcurrentHashMap<>();

    public static void markCombat(UUID player, long tick) { lastCombatTick.put(player, tick); }
    public static long getLastCombat(UUID player) { return lastCombatTick.getOrDefault(player, 0L); }
    public static long getLastRegenTick(UUID player) { return lastRegenTick.getOrDefault(player, 0L); }
    public static void setLastRegenTick(UUID player, long tick) { lastRegenTick.put(player, tick); }
    public static long getLastOocRegenTick(UUID player) { return lastOocRegenTick.getOrDefault(player, 0L); }
    public static void setLastOocRegenTick(UUID player, long tick) { lastOocRegenTick.put(player, tick); }

    /** Returns true if player has not attacked or been hit in the last 100 ticks (5 seconds). */
    public static boolean isOutOfCombat(UUID player, long now) {
        return (now - getLastCombat(player)) >= 100;
    }

    // ── 限制器: cooldown + damage cap ──────────────────────────────────
    private static final Map<UUID, Long> limiterActiveUntil = new ConcurrentHashMap<>();

    public static void activateLimiter(UUID player, long until) { limiterActiveUntil.put(player, until); }
    public static boolean isLimiterActive(UUID player, long now) {
        return now < limiterActiveUntil.getOrDefault(player, 0L);
    }

    // ── 承量: hit counter ──────────────────────────────────────────────
    private static final Map<UUID, Integer> chargedBurstCounter = new ConcurrentHashMap<>();

    public static int incrementBurstCounter(UUID player) {
        int count = chargedBurstCounter.getOrDefault(player, 0) + 1;
        chargedBurstCounter.put(player, count);
        return count;
    }
    public static void resetBurstCounter(UUID player) { chargedBurstCounter.put(player, 0); }

    // ── 護盾: timer + state ────────────────────────────────────────────
    /** Shield phases: 0=charging, 1=ready(6abs), 2=triggered(12abs,5s) */
    private static final Map<UUID, Integer> shieldPhase = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> shieldNextReady = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> shieldTriggeredUntil = new ConcurrentHashMap<>();

    public static int getShieldPhase(UUID player) { return shieldPhase.getOrDefault(player, 0); }
    public static void setShieldPhase(UUID player, int phase) { shieldPhase.put(player, phase); }
    public static long getShieldNextReady(UUID player) { return shieldNextReady.getOrDefault(player, 0L); }
    public static void setShieldNextReady(UUID player, long tick) { shieldNextReady.put(player, tick); }
    public static long getShieldTriggeredUntil(UUID player) { return shieldTriggeredUntil.getOrDefault(player, 0L); }
    public static void setShieldTriggeredUntil(UUID player, long tick) { shieldTriggeredUntil.put(player, tick); }

    // ── Cleanup on disconnect ──────────────────────────────────────────
    public static void cleanup(UUID player) {
        lastCombatTick.remove(player);
        lastRegenTick.remove(player);
        lastOocRegenTick.remove(player);
        limiterActiveUntil.remove(player);
        chargedBurstCounter.remove(player);
        shieldPhase.remove(player);
        shieldNextReady.remove(player);
        shieldTriggeredUntil.remove(player);
    }
}
