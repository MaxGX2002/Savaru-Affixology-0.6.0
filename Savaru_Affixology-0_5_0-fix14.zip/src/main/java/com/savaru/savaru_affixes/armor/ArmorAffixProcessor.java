package com.savaru.savaru_affixes.armor;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.entry.RegistryEntry;

import java.util.ArrayList;
import java.util.List;

/**
 * Reads armor affixes from all equipped pieces and exposes them
 * for use by damage / effect mixins.
 */
public final class ArmorAffixProcessor {
    private ArmorAffixProcessor() {}

    // ── Equipment slots to scan ──────────────────────────────────────────
    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST,
            EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    // ── Negative effect pool for 適性 ────────────────────────────────────
    public static final RegistryEntry<StatusEffect>[] ADAPT_EFFECTS = new RegistryEntry[]{
            StatusEffects.POISON,
            StatusEffects.WITHER,
            StatusEffects.SLOWNESS,
            StatusEffects.MINING_FATIGUE,
            StatusEffects.WEAKNESS,
            StatusEffects.BLINDNESS,
            StatusEffects.HUNGER,
            StatusEffects.NAUSEA,
            StatusEffects.LEVITATION,
            StatusEffects.DARKNESS
    };

    // ── Affix IDs ─────────────────────────────────────────────────────────
    public static final String PROTECTION_FLAT = "armor_protection_flat";
    public static final String PROTECTION_PCT  = "armor_protection_pct";
    public static final String TOUGHNESS_FLAT  = "armor_toughness_flat";
    public static final String TOUGHNESS_PCT   = "armor_toughness_pct";
    public static final String HARDENED        = "armor_hardened";
    public static final String BULLETPROOF     = "armor_bulletproof";
    public static final String FIRE_RESIST     = "armor_fire_resist";
    public static final String ADAPT_DMG       = "armor_adapt_dmg";
    public static final String ADAPT_DUR       = "armor_adapt_dur";
    public static final String ADAPT_LVL       = "armor_adapt_lvl";

    public static final String KEY_ADAPT_EFFECT = "adapt_effect";

    // v0.5 新增
    public static final String REGEN_FLAT          = "armor_regen_flat";
    public static final String REGEN_PCT           = "armor_regen_pct";
    public static final String LIMITER_FLAT        = "armor_limiter_flat";
    public static final String LIMITER_PCT         = "armor_limiter_pct";
    public static final String CHEST_THORNS        = "armor_chest_thorns";
    public static final String CHEST_FLAME_STEEL   = "armor_chest_flame_steel";
    public static final String CHEST_CHARGED_BURST = "armor_chest_charged_burst";
    public static final String CHEST_SHIELD        = "armor_chest_shield";

    /** Gets affix value from CHESTPLATE slot only. */
    public static double getChestAffix(LivingEntity entity, String affixId) {
        ItemStack chest = entity.getEquippedStack(EquipmentSlot.CHEST);
        if (chest.isEmpty()) return 0.0;
        if (UnidentifiedHandler.isUnidentified(chest)) return 0.0;
        if (AffixHelper.getRarity(chest) == null) return 0.0;
        return AffixHelper.getAffixValue(chest, affixId);
    }

    // ── Sums a single affix value across all equipped armor ───────────────
    public static double getTotal(LivingEntity entity, String affixId) {
        double total = 0.0;
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack piece = entity.getEquippedStack(slot);
            if (piece.isEmpty()) continue;
            if (UnidentifiedHandler.isUnidentified(piece)) continue;
            if (AffixHelper.getRarity(piece) == null) continue;
            total += AffixHelper.getAffixValue(piece, affixId);
        }
        return total;
    }

    /**
     * Returns the adapt sub-type and stored effect from the FIRST armor piece
     * that has the given adapt affix ID. Returns null if not found.
     */
    public static AdaptEntry getAdapt(LivingEntity entity, String adaptAffixId) {
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack piece = entity.getEquippedStack(slot);
            if (piece.isEmpty()) continue;
            if (UnidentifiedHandler.isUnidentified(piece)) continue;
            if (AffixHelper.getRarity(piece) == null) continue;

            double val = AffixHelper.getAffixValue(piece, adaptAffixId);
            if (val <= 0.0) continue;

            // Read stored effect ID
            NbtCompound root = AffixHelper.getRoot(piece);
            if (!root.contains(AffixHelper.KEY_AFFIXES)) continue;
            NbtList affixes = root.getList(AffixHelper.KEY_AFFIXES, 10);
            for (int i = 0; i < affixes.size(); i++) {
                NbtCompound entry = affixes.getCompound(i);
                if (adaptAffixId.equals(entry.getString(AffixHelper.KEY_ID))) {
                    String effectId = entry.getString(KEY_ADAPT_EFFECT);
                    return new AdaptEntry(adaptAffixId, val, effectId);
                }
            }
        }
        return null;
    }

    /** Collect ALL adapt entries across all pieces (one per slot max). */
    public static List<AdaptEntry> getAllAdapts(LivingEntity entity) {
        List<AdaptEntry> result = new ArrayList<>();
        for (String id : new String[]{ADAPT_DMG, ADAPT_DUR, ADAPT_LVL}) {
            AdaptEntry e = getAdapt(entity, id);
            if (e != null) result.add(e);
        }
        return result;
    }

    // ── Damage reduction (called from LivingEntityDamageMixin) ────────────

    /**
     * Apply all armor-affix-based damage reductions.
     * Returns the final (possibly reduced) damage value.
     */
    public static float applyReductions(LivingEntity victim, DamageSource source, float amount) {
        if (amount <= 0f) return amount;
        if (!(victim.getWorld() instanceof net.minecraft.server.world.ServerWorld)) return amount;

        boolean isRanged = isRangedDamage(source);
        boolean isFire   = isFireDamage(source);
        boolean isMelee  = !isRanged && !isFire && source.getAttacker() != null;

        // ── 鋼化: melee damage reduction ──────────────────────────────
        if (isMelee) {
            double pct = getTotal(victim, HARDENED);
            if (pct > 0.0) {
                pct = Math.min(pct, 80.0);
                amount *= (1.0f - (float)(pct / 100.0));
            }
        }

        // ── 防彈: ranged damage reduction ──────────────────────────────
        if (isRanged) {
            double pct = getTotal(victim, BULLETPROOF);
            if (pct > 0.0) {
                pct = Math.min(pct, 80.0);
                amount *= (1.0f - (float)(pct / 100.0));
            }
        }

        // ── 防火: fire damage reduction ────────────────────────────────
        if (isFire) {
            double pct = getTotal(victim, FIRE_RESIST);
            if (pct >= 100.0) return 0.0f;
            if (pct > 0.0) {
                amount *= (1.0f - (float)(pct / 100.0));
            }
        }

        // ── 適性(傷害減少) ─────────────────────────────────────────────
        AdaptEntry adaptDmg = getAdapt(victim, ADAPT_DMG);
        if (adaptDmg != null && adaptDmg.effectId != null && !adaptDmg.effectId.isEmpty()) {
            if (isEffectDamage(source, adaptDmg.effectId)) {
                if (adaptDmg.value >= 100.0) return 0.0f;
                amount *= (1.0f - (float)(adaptDmg.value / 100.0));
            }
        }

        return Math.max(0f, amount);
    }

    private static boolean isRangedDamage(DamageSource src) {
        return src.isIn(net.minecraft.registry.tag.DamageTypeTags.IS_PROJECTILE);
    }

    private static boolean isFireDamage(DamageSource src) {
        return src.isIn(net.minecraft.registry.tag.DamageTypeTags.IS_FIRE);
    }

    private static boolean isEffectDamage(DamageSource src, String effectId) {
        // Wither damage: DamageTypes.WITHER
        // Poison damage: DamageTypes.MAGIC (poison ticks through magic damage)
        // We match by checking the damage type registry key
        var key = src.getTypeRegistryEntry().getKey();
        if (key.isEmpty()) return false;
        String typeId = key.get().getValue().toString();
        if ("wither".equals(effectId) || "minecraft:wither".equals(effectId)) {
            return typeId.contains("wither");
        }
        if ("poison".equals(effectId) || "minecraft:poison".equals(effectId)) {
            return typeId.contains("magic") || typeId.contains("poison");
        }
        return false;
    }

    // ── Inner record ─────────────────────────────────────────────────────
    public static final class AdaptEntry {
        public final String affixId;
        public final double value;
        public final String effectId; // e.g. "minecraft:wither"

        public AdaptEntry(String affixId, double value, String effectId) {
            this.affixId  = affixId;
            this.value    = value;
            this.effectId = effectId;
        }
    }
}
