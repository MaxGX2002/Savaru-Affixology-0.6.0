package com.savaru.savaru_affixes;

/**
 * A rollable affix definition.
 *
 * @param id Internal string id (stored in NBT).
 * @param min Minimum roll value (raw number, percent points if percent==true)
 * @param max Maximum roll value (raw number, percent points if percent==true)
 * @param weight Relative weight within its pool.
 * @param percent Whether the value is displayed as percent points.
 * @param weaponOnly Whether this affix is only intended to roll on weapon items.
 */
public record Affix(String id, double min, double max, int weight, boolean percent, boolean weaponOnly) {
    public Affix(String id, double min, double max, int weight, boolean percent) {
        this(id, min, max, weight, percent, false);
    }
}
