package com.savaru.savaru_affixes.unique;

public class UniqueScaling {

    public static float effectMultiplier(String rarity){
        return switch(rarity){
            case "mythic" -> 1.25f;
            case "beyond" -> 1.5f;
            case "unrivaled" -> 2.0f;
            default -> 1.0f;
        };
    }

    public static float durationMultiplier(String rarity){
        return switch(rarity){
            case "mythic" -> 1.2f;
            case "beyond" -> 1.4f;
            case "unrivaled" -> 1.6f;
            default -> 1.0f;
        };
    }
}
