package com.savaru.savaru_affixes.unique;

public class UniqueAffixRegistry {

    public static final String BLOSSOM = "unique_blossom";
    public static final String TRUE_FOCUS = "unique_true_focus";
    public static final String BLACK_FLASH = "unique_black_flash";

}
