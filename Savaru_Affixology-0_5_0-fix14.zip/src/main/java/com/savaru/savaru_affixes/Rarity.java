
package com.savaru.savaru_affixes;

import net.minecraft.text.Style;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.random.Random;

public enum Rarity {
    COMMON, UNCOMMON, RARE, EPIC, LEGENDARY, MYTHIC, BEYOND, UNRIVALED;

    /**
     * Flat attack damage bonus per rarity (your spec).
     * Applied server-side in PlayerEntityAttackMixin so it works consistently on 1.21.1.
     */
    public double attackBonus() {
        return switch (this) {
            case COMMON -> 0.0;
            case UNCOMMON -> 0.5;
            case RARE -> 0.7;
            case EPIC -> 1.0;
            case LEGENDARY -> 2.0;
            case MYTHIC -> 3.0;
            case BEYOND -> 4.0;
            case UNRIVALED -> 5.0;
        };
    }

    /**
     * Flat armor value bonus per rarity (armor items only).
     */
    public double armorBonus() {
        return switch (this) {
            case COMMON    -> 0.0;
            case UNCOMMON  -> 1.0;
            case RARE      -> 2.0;
            case EPIC      -> 3.0;
            case LEGENDARY -> 4.0;
            case MYTHIC    -> 5.0;
            case BEYOND    -> 7.0;
            case UNRIVALED -> 10.0;
        };
    }

    public Style style() {
        return switch (this) {
            case COMMON -> Style.EMPTY.withColor(Formatting.WHITE);
            case UNCOMMON -> Style.EMPTY.withColor(Formatting.GREEN);
            case RARE -> Style.EMPTY.withColor(Formatting.BLUE);
            case EPIC -> Style.EMPTY.withColor(Formatting.LIGHT_PURPLE);
            case LEGENDARY -> Style.EMPTY.withColor(Formatting.GOLD);
            case MYTHIC -> Style.EMPTY.withColor(Formatting.RED).withBold(true);
            case BEYOND -> Style.EMPTY.withColor(Formatting.YELLOW).withBold(true);
            case UNRIVALED -> Style.EMPTY.withColor(Formatting.WHITE).withBold(true);
        };
    }

    /**
     * Optional dynamic styling for the highest tier.
     * Keeps lower tiers stable, while allowing a "rainbow" effect for UNRIVALED.
     */
    public Style style(Random rng) {
        // kept for compatibility; dynamic color is handled client-side for UNRIVALED
        return style();
    }

    public static Rarity roll(java.util.Random rng) {
        int x = rng.nextInt(1_000_000);
        if (x < 520_000) return COMMON;
        if (x < 760_000) return UNCOMMON;
        if (x < 900_000) return RARE;
        if (x < 970_000) return EPIC;
        if (x < 995_000) return LEGENDARY;
        if (x < 999_900) return MYTHIC;
        if (x < 999_990) return BEYOND;
        return UNRIVALED;
    }

    
    // Simple rainbow text helper for UNRIVALED visuals.
    
    public static net.minecraft.text.MutableText rainbowText(String s) {
        // legacy (static rainbow)
        return rainbowTextDynamic(s, 0L);
    }

    public static net.minecraft.text.MutableText rainbowTextDynamic(String s, long timeMs) {
        int[] colors = new int[] {
                0xFF5555, 0xFFAA00, 0xFFFF55, 0x55FF55, 0x55FFFF, 0x5555FF, 0xFF55FF
        };
        int shift = (int)((timeMs / 150L) % colors.length); // 150ms per step -> "flashing" rainbow
        net.minecraft.text.MutableText out = net.minecraft.text.Text.empty();
        for (int i = 0; i < s.length(); i++) {
            int rgb = colors[(i + shift) % colors.length];
            out.append(net.minecraft.text.Text.literal(String.valueOf(s.charAt(i)))
                    .setStyle(net.minecraft.text.Style.EMPTY
                            .withColor(net.minecraft.text.TextColor.fromRgb(rgb))
                            .withBold(true)));
        }
        return out;
    }

public static Rarity roll(Random rng) {
        return roll(new java.util.Random(rng.nextInt()));
    }
}
