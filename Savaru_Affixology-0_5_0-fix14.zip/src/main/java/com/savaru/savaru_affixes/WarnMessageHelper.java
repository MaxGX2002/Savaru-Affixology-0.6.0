package com.savaru.savaru_affixes;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class WarnMessageHelper {
    private static final long COOLDOWN_MS = 900L;
    private static final Map<UUID, Long> LAST_SENT = new ConcurrentHashMap<>();

    private WarnMessageHelper() {}

    public static void send(PlayerEntity player, Text text) {
        if (player == null) return;
        long now = System.currentTimeMillis();
        UUID id = player.getUuid();
        Long last = LAST_SENT.get(id);
        if (last != null && now - last < COOLDOWN_MS) return;
        LAST_SENT.put(id, now);
        player.sendMessage(text, false);
    }
}
