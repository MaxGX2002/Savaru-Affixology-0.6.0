package com.savaru.savaru_affixes;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Map;
import java.util.UUID;

/**
 * "超量治療"：擊中目標時 5% 機率獲得 +2 額外生命（吸收值 / absorption），可疊到 +10，持續 2 秒。
 *
 * 實作方式：以 absorptionAmount 作為「額外生命」；用 tick 定時把我們加上的那一段扣回。
 */
public final class OverhealHooks {
    private static final class State {
        double ourAmount;
        long expiresAt;

        State(double ourAmount, long expiresAt) {
            this.ourAmount = ourAmount;
            this.expiresAt = expiresAt;
        }
    }

    private static final Map<UUID, State> STATES = new Object2ObjectOpenHashMap<>();

    private OverhealHooks() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            long now = server.getOverworld().getTime();
            // Iterate online players only.
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                State st = STATES.get(p.getUuid());
                if (st == null) continue;
                if (now <= st.expiresAt) continue;

                // Remove only our portion, keep any other absorption from other sources.
                double current = p.getAbsorptionAmount();
                double other = Math.max(0.0, current - st.ourAmount);
                p.setAbsorptionAmount((float) other);
                STATES.remove(p.getUuid());
            }
        });
    }

    public static void proc(ServerPlayerEntity player) {
        long now = player.getWorld().getTime();
        UUID id = player.getUuid();

        State st = STATES.get(id);
        double current = player.getAbsorptionAmount();
        double ourPrev = st == null ? 0.0 : st.ourAmount;
        double other = Math.max(0.0, current - ourPrev);

        double ourNew = Math.min(10.0, ourPrev + 2.0);
        player.setAbsorptionAmount((float) (other + ourNew));
        STATES.put(id, new State(ourNew, now + 40)); // 2s
    }
}
