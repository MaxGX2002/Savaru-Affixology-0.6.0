package com.savaru.savaru_affixes.ranged;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * "彈射": After hitting a target, spawn a new projectile that seeks the next nearby target.
 * - Up to 5 bounces per original shot
 * - Each bounce deals 70% damage of the previous projectile
 */
public final class RicochetHooks {

    private static final int MAX_BOUNCES = 5;
    private static final double DAMAGE_FACTOR = 0.70;
    private static final double SEARCH_RADIUS = 16.0;

    private static final class State {
        int bouncesLeft;
        double damage;
        Set<UUID> alreadyHit;
    }

    private static final Map<UUID, State> STATE = new Object2ObjectOpenHashMap<>();

    private RicochetHooks() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(RicochetHooks::tickCleanup);
    }

    public static void onHit(PersistentProjectileEntity proj, LivingEntity hitTarget) {
        if (!(proj.getWorld() instanceof ServerWorld world)) return;
        if (proj.isRemoved()) return;

        State s = STATE.get(proj.getUuid());
        if (s == null) {
            s = new State();
            s.bouncesLeft = MAX_BOUNCES;
            s.damage = proj.getDamage();
            s.alreadyHit = new HashSet<>();
            STATE.put(proj.getUuid(), s);
        }

        s.alreadyHit.add(hitTarget.getUuid());

        if (s.bouncesLeft <= 0) return;

        LivingEntity next = findNextTarget(world, proj, hitTarget, s.alreadyHit);
        if (next == null) return;

        // Spawn a new projectile that continues the chain.
        Entity created = proj.getType().create(world);
        if (!(created instanceof PersistentProjectileEntity nextProj)) return;

        nextProj.setOwner(proj.getOwner());
        nextProj.setPos(proj.getX(), proj.getY(), proj.getZ());

        Vec3d from = proj.getPos();
        Vec3d to = next.getPos().add(0, next.getStandingEyeHeight() * 0.5, 0);
        Vec3d dir = to.subtract(from).normalize();

        double speed = Math.max(0.6, proj.getVelocity().length());
        nextProj.setVelocity(dir.x * speed, dir.y * speed, dir.z * speed);

        double newDamage = s.damage * DAMAGE_FACTOR;
        nextProj.setDamage(newDamage);

        // Carry state to the new projectile.
        State ns = new State();
        ns.bouncesLeft = s.bouncesLeft - 1;
        ns.damage = newDamage;
        ns.alreadyHit = new HashSet<>(s.alreadyHit);
        STATE.put(nextProj.getUuid(), ns);

        world.spawnEntity(nextProj);

        // Remove the old projectile to avoid double-hits.
        proj.discard();
        STATE.remove(proj.getUuid());
    }

    private static LivingEntity findNextTarget(ServerWorld world, PersistentProjectileEntity proj, LivingEntity current, Set<UUID> alreadyHit) {
        Box box = new Box(proj.getX() - SEARCH_RADIUS, proj.getY() - SEARCH_RADIUS, proj.getZ() - SEARCH_RADIUS,
                proj.getX() + SEARCH_RADIUS, proj.getY() + SEARCH_RADIUS, proj.getZ() + SEARCH_RADIUS);

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, box, le -> {
            if (le == null || le.isDead() || le.getHealth() <= 0) return false;
            if (le == current) return false;
            if (alreadyHit.contains(le.getUuid())) return false;
            if (proj.getOwner() != null && le == proj.getOwner()) return false;
            return true;
        })) {
            double d = e.squaredDistanceTo(proj);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    private static void tickCleanup(MinecraftServer server) {
        if (STATE.isEmpty()) return;
        // Remove entries for projectiles that no longer exist.
        var it = STATE.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            UUID projId = e.getKey();
            boolean exists = false;
            for (ServerWorld w : server.getWorlds()) {
                if (w.getEntity(projId) != null) {
                    exists = true;
                    break;
                }
            }
            if (!exists) it.remove();
        }
    }
}
