package com.savaru.savaru_affixes.ranged;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;

import java.util.Map;
import java.util.UUID;

/**
 * "釘箭": true-damage DoT that ignores armor/resistance.
 * - Every 10 ticks (0.5s) deal N damage (scaled 1..5)
 * - Base duration 200 ticks (10s)
 * - Duration stacks by adding more ticks
 */
public final class PinArrowHooks {

    private static final int PERIOD_TICKS = 10;
    private static final int BASE_DURATION_TICKS = 200;

    private static final class Active {
        int ticksLeft;
        int periodCounter;
        float dmgPerTick;
        UUID attacker;
    }

    private static final Map<UUID, Active> ACTIVE = new Object2ObjectOpenHashMap<>();

    private PinArrowHooks() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(PinArrowHooks::tick);
    }

    public static void applyOrExtend(LivingEntity target, UUID attackerUuid, float dmgPerTick) {
        if (!(target.getWorld() instanceof ServerWorld)) return;
        UUID id = target.getUuid();
        Active a = ACTIVE.get(id);
        if (a == null) {
            a = new Active();
            a.periodCounter = PERIOD_TICKS;
            a.ticksLeft = 0;
            ACTIVE.put(id, a);
        }
        a.attacker = attackerUuid;
        a.dmgPerTick = Math.max(a.dmgPerTick, dmgPerTick);
        a.ticksLeft += BASE_DURATION_TICKS; // stack duration
    }

    private static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) return;

        // We can safely iterate and remove via iterator semantics.
        var it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            UUID targetId = e.getKey();
            Active a = e.getValue();

            LivingEntity target = null;
            ServerWorld foundWorld = null;
            for (ServerWorld w : server.getWorlds()) {
                var ent = w.getEntity(targetId);
                if (ent instanceof LivingEntity le) {
                    target = le;
                    foundWorld = w;
                    break;
                }
            }

            if (target == null || target.isDead() || target.getHealth() <= 0.0f) {
                it.remove();
                continue;
            }

            a.ticksLeft--;
            a.periodCounter--;

            if (a.periodCounter <= 0) {
                a.periodCounter = PERIOD_TICKS;

                DamageSource src;
                if (foundWorld != null) {
                    var reg = foundWorld.getRegistryManager().get(RegistryKeys.DAMAGE_TYPE);
                // OUT_OF_WORLD bypasses armor and most reductions; good fit for "無視抗性與防禦".
                var entry = reg.entryOf(DamageTypes.OUT_OF_WORLD);
                    src = new DamageSource(entry);
                } else {
                    // Fallback (should not happen)
                src = target.getDamageSources().outOfWorld();
                }

                target.damage(src, a.dmgPerTick);
            }

            if (a.ticksLeft <= 0) {
                it.remove();
            }
        }
    }
}
