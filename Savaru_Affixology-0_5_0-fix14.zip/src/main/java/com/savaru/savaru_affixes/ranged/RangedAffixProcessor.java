package com.savaru.savaru_affixes.ranged;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.CritHelper;
import com.savaru.savaru_affixes.SavaruAttributes;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.hunter.HunterMarkRuntime;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

public final class RangedAffixProcessor {
    private RangedAffixProcessor() {}

    public static boolean isRangedWeapon(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        return (stack.getItem() instanceof BowItem) || (stack.getItem() instanceof CrossbowItem);
    }

    public record Result(float damage, net.minecraft.entity.damage.DamageSource overrideSource) {}

    public static Result apply(ServerPlayerEntity shooter, LivingEntity target, ItemStack weapon, float originalDamage) {
        if (shooter == null || target == null || weapon == null) return new Result(originalDamage, null);

        if (!isRangedWeapon(weapon)) return new Result(originalDamage, null);
        if (AffixHelper.getRarity(weapon) == null) return new Result(originalDamage, null);
        if (UnidentifiedHandler.isUnidentified(weapon)) return new Result(originalDamage, null);

        float dmg = originalDamage;

        // ---- Rarity bonus: treat attackBonus as ranged damage bonus (flat) ----
        var rarity = AffixHelper.getRarity(weapon);
        if (rarity != null && rarity.attackBonus() > 0) {
            dmg += rarity.attackBonus();
        }

        // ---- Crit (reuse attributes) ----
        // Unified crit: merges SavaruAttributes + Critical Strike mod (soft-depend via CritHelper)
        double critChance = CritHelper.getCritChance(shooter);
        double critBonus  = CritHelper.getCritDamage(shooter);
        double critMul = Math.max(1.0, 1.0 + critBonus);

        boolean crit = false;
        if (critChance > 0.0 && shooter.getWorld() instanceof ServerWorld sw) {
            crit = sw.random.nextDouble() < critChance;
        }
        if (crit) dmg = (float) (dmg * critMul);

        // ---- Bonus damage (if rolled) ----
        double bonus = AffixHelper.getAffixValue(weapon, "bonus_damage");
        if (bonus > 0.0) dmg += (float) bonus;

        // ---- Armor pen: flat + pct can co-exist ----
        double flat = AffixHelper.getAffixValue(weapon, "armor_pen_flat"); // 5-10
        double pct01 = AffixHelper.getAffixValue(weapon, "armor_pen_pct") / 100.0; // 15-50%
        if ((flat > 0.0 || pct01 > 0.0) && dmg > 0f) {
            double armor = target.getArmor();
            double eff = armor;
            if (flat > 0.0) eff = Math.max(0.0, eff - flat);
            if (pct01 > 0.0) eff = Math.max(0.0, eff * (1.0 - pct01));

            double baseKeep = 1.0 - approxArmorReduction01(armor);
            double effKeep  = 1.0 - approxArmorReduction01(eff);
            baseKeep = Math.max(0.05, baseKeep);

            float scaled = (float) (dmg * (effKeep / baseKeep));
            if (scaled > dmg) dmg = scaled;
        }

        // ---- Resistance pen: pct only ----
        double resPen01 = AffixHelper.getAffixValue(weapon, "res_pen_pct") / 100.0; // 10-30%
        if (resPen01 > 0.0 && dmg > 0f) {
            StatusEffectInstance res = target.getStatusEffect(StatusEffects.RESISTANCE);
            if (res != null) {
                int lvl = res.getAmplifier() + 1;
                double baseRed = Math.min(0.80, 0.20 * lvl);
                double effRed  = Math.max(0.0, baseRed * (1.0 - resPen01));
                double baseKeep = 1.0 - baseRed;
                double effKeep  = 1.0 - effRed;
                baseKeep = Math.max(0.05, baseKeep);

                float scaled = (float) (dmg * (effKeep / baseKeep));
                if (scaled > dmg) dmg = scaled;
            }
        }

        // ---- Finisher: target < 50% HP => +200~400% (total 3x~5x) ----
        double finPct = AffixHelper.getAffixValue(weapon, "finisher_shot"); // 200-400
        if (finPct > 0.0) {
            float r = target.getHealth() / target.getMaxHealth();
            if (r < 0.5f) {
                dmg = (float) (dmg * (1.0 + finPct / 100.0));
            }
        }

        // ---- Hunter mark: +150% while marked (2.5x), duration 10s, cooldown 5s per target ----
        if (AffixHelper.getAffixValue(weapon, "hunter_mark") > 0.0) {
            dmg = (float) (dmg * HunterMarkRuntime.applyAndComputeMultiplier(shooter, target));
        }

        // ---- Weakpoint (shared): crit_chance + crit_damage ----
        double critChancePct = AffixHelper.getAffixValue(weapon, "crit_chance");
        double critDamage = AffixHelper.getAffixValue(weapon, "crit_damage");
        if (critChancePct > 0.0 && critDamage > 0.0 && shooter.getWorld() instanceof ServerWorld sw) {
            double roll = sw.random.nextDouble() * 100.0;
            if (roll < critChancePct) {
                dmg = (float) (dmg * (1.0 + critDamage / 100.0));
            }
        }

        // ---- Lifeshot: heal 1-5 on hit ----
        double heal = AffixHelper.getAffixValue(weapon, "lifeshot");
        if (heal > 0.0) shooter.heal((float) heal);

        // ---- Magic arrow: DamageSource override is applied in the projectile hit mixin
        // so the hit can use vanilla-style indirectMagic (matching Arcblade behavior).
        if (AffixHelper.getAffixValue(weapon, "magic_arrow") > 0.0) {
            return new Result(dmg, null);
        }

        return new Result(dmg, null);
    }

    private static double approxArmorReduction01(double armor) {
        double red = armor * 0.04;
        if (red < 0.0) red = 0.0;
        if (red > 0.80) red = 0.80;
        return red;
    }
}