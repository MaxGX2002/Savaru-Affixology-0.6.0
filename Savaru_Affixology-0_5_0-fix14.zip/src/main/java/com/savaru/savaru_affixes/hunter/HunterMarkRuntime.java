package com.savaru.savaru_affixes.hunter;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Spec:
 * - Hit marks target for 10s.
 * - While marked: +150% damage (2.5x total).
 * - Same target mark cooldown: 5s.
 */
public final class HunterMarkRuntime {
    private HunterMarkRuntime() {}

    private static final long MARK_TICKS = 20L * 10L;
    private static final long CD_TICKS   = 20L * 5L;

    private static final Map<UUID, Long> markedUntil = new HashMap<>();
    private static final Map<UUID, Long> cdUntil = new HashMap<>();

    public static double applyAndComputeMultiplier(ServerPlayerEntity shooter, LivingEntity target) {
        long now = shooter.getWorld().getTime();
        UUID id = target.getUuid();

        // cleanup
        Long mu = markedUntil.get(id);
        if (mu != null && mu <= now) markedUntil.remove(id);
        Long cu = cdUntil.get(id);
        if (cu != null && cu <= now) cdUntil.remove(id);

        boolean alreadyMarked = markedUntil.containsKey(id);

        // If not marked (or expired), apply mark if not on cooldown — but do NOT grant the bonus on the marking hit.
        if (!alreadyMarked) {
            if (!cdUntil.containsKey(id)) {
                markedUntil.put(id, now + MARK_TICKS);
                cdUntil.put(id, now + CD_TICKS);
                // Visual marker: glowing 10s.
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, (int) MARK_TICKS, 0, false, false, true));
                // 1.21+ uses command tags (formerly "scoreboard tags").
                target.addCommandTag("savaru_hunter_mark");
            }
            return 1.0;
        }

        // Marked: +150% damage (2.5x). Refresh visual marker.
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, (int) MARK_TICKS, 0, false, false, true));
        target.addCommandTag("savaru_hunter_mark");
        return 2.5;
    }
}
