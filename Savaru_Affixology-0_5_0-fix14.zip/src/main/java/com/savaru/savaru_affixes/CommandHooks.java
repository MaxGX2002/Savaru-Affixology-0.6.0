package com.savaru.savaru_affixes;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.argument.ItemStackArgument;
import net.minecraft.command.argument.ItemStackArgumentType;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.text.Text;
import net.minecraft.entity.EntityType;
import net.minecraft.util.math.random.Random;

import com.savaru.savaru_affixes.config.ConfigManager;
import com.savaru.savaru_affixes.config.MobDropRule;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;

public final class CommandHooks {
    

private static final SuggestionProvider<ServerCommandSource> SUGGEST_AFFIX_IDS = (ctx, builder) -> {
    for (Affix a : AffixRegistry.getAll()) builder.suggest(a.id());
    return builder.buildFuture();
};

private static final SuggestionProvider<ServerCommandSource> SUGGEST_ANY_IDS = (ctx, builder) -> {
    for (Affix a : AffixRegistry.getAll()) builder.suggest(a.id());
    for (String id : InscriptionHelper.OUTLAND_POOL) builder.suggest(id);
    for (String id : InscriptionHelper.SECRET_POOL) builder.suggest(id);
    return builder.buildFuture();
};


private static final SuggestionProvider<ServerCommandSource> SUGGEST_ENTITY_IDS = (ctx, builder) -> {
    for (var e : Registries.ENTITY_TYPE) {
        try {
            Identifier id = Registries.ENTITY_TYPE.getId(e);
            if (id != null) builder.suggest(id.toString());
        } catch (Exception ignored) {}
    }
    return builder.buildFuture();
};

private static final SuggestionProvider<ServerCommandSource> SUGGEST_RARITIES = (ctx, builder) -> {
    for (Rarity r : Rarity.values()) builder.suggest(r.name().toLowerCase());
    return builder.buildFuture();
};

private CommandHooks() {}

public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                registerCommands(dispatcher, registryAccess)
        );
    }

    private static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess access) {

        // Existing helper command group
        dispatcher.register(
                CommandManager.literal("savaru_affixes")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("give")
                                .then(CommandManager.argument("rarity", com.mojang.brigadier.arguments.StringArgumentType.word())
                                        .suggests((ctx, builder) -> {
                                            for (Rarity r : Rarity.values()) builder.suggest(r.name().toLowerCase());
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            String rName = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "rarity");
                                            Rarity rarity;
                                            try {
                                                rarity = Rarity.valueOf(rName.toUpperCase());
                                            } catch (Exception e) {
                                                ctx.getSource().sendError(Text.translatable("command.savaru_affixes.give.bad_rarity", rName));
                                                return 0;
                                            }

                                            ItemStack base = player.getMainHandStack();
                                            if (base.isEmpty()) {
                                                ctx.getSource().sendError(Text.translatable("command.savaru_affixes.give.hold_item"));
                                                return 0;
                                            }

                                            ItemStack stack = base.copy();
                                            stack.setCount(1);
                                            AffixHelper.rollAffixes(stack, rarity);

                                            boolean ok = player.getInventory().insertStack(stack);
                                            if (!ok) player.dropItem(stack, false);

                                            ctx.getSource().sendFeedback(
                                                    () -> Text.translatable("command.savaru_affixes.give.ok",
                                                            Text.translatable("rarity.savaru_affixes." + rarity.name().toLowerCase())),
                                                    false
                                            );
                                            return 1;
                                        })
                                        .then(CommandManager.argument("item", ItemStackArgumentType.itemStack(access))
                                                .executes(ctx -> {
                                                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                                    String rName = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "rarity");
                                                    Rarity rarity;
                                                    try {
                                                        rarity = Rarity.valueOf(rName.toUpperCase());
                                                    } catch (Exception e) {
                                                        ctx.getSource().sendError(Text.translatable("command.savaru_affixes.give.bad_rarity", rName));
                                                        return 0;
                                                    }

                                                    ItemStackArgument arg = ItemStackArgumentType.getItemStackArgument(ctx, "item");
                                                    ItemStack stack = arg.createStack(1, false);
                                                    AffixHelper.rollAffixes(stack, rarity);

                                                    boolean ok = player.getInventory().insertStack(stack);
                                                    if (!ok) player.dropItem(stack, false);

                                                    ctx.getSource().sendFeedback(
                                                            () -> Text.translatable("command.savaru_affixes.give.ok",
                                                                    Text.translatable("rarity.savaru_affixes." + rarity.name().toLowerCase())),
                                                            false
                                                    );
                                                    return 1;
                                                }))))
                        .then(CommandManager.literal("reroll")
                                .executes(ctx -> {
                                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                    ItemStack stack = player.getMainHandStack();
                                    if (stack.isEmpty()) {
                                        ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                        return 0;
                                    }

                                    Rarity rarity = AffixHelper.getRarity(stack);
                                    if (rarity == null) rarity = Rarity.roll(new java.util.Random());
                                    AffixHelper.rollAffixes(stack, rarity);

                                    final String msg = "Rerolled affixes (" + rarity.name() + ").";
            ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
                                    return 1;
                                }))
        );

        // New inscription + testing command group
        dispatcher.register(
                CommandManager.literal("savaru")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("pool")
                                .then(CommandManager.literal("add")
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            ItemStack stack = player.getMainHandStack();
                                            if (stack.isEmpty()) {
                                                ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = Registries.ITEM.getId(stack.getItem()).toString();
                                            ConfigManager.get().customWeaponRates.putIfAbsent(id, 1.0D);
                                            ConfigManager.save();
                                            final var msgT = Text.literal("Added weapon to drop pool: " + id + " (weight 1.0)");
                                            ctx.getSource().sendFeedback(() -> msgT, false);
                                            return 1;
                                        })
                                        .then(CommandManager.argument("weight", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D))
                                                .executes(ctx -> {
                                                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                                    ItemStack stack = player.getMainHandStack();
                                                    if (stack.isEmpty()) {
                                                        ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                        return 0;
                                                    }
                                                    double weight = com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight");
                                                    String id = Registries.ITEM.getId(stack.getItem()).toString();
                                                    ConfigManager.get().customWeaponRates.put(id, weight);
                                                    ConfigManager.save();
                                                    final var msgT = Text.literal("Added weapon to drop pool: " + id + " (weight " + weight + ")");
                                                    ctx.getSource().sendFeedback(() -> msgT, false);
                                                    return 1;
                                                })))
                                .then(CommandManager.literal("remove")
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            ItemStack stack = player.getMainHandStack();
                                            if (stack.isEmpty()) {
                                                ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = Registries.ITEM.getId(stack.getItem()).toString();
                                            boolean removed = ConfigManager.get().customWeaponRates.remove(id) != null;
                                            ConfigManager.save();
                                            if (!removed) {
                                                ctx.getSource().sendError(Text.literal("Weapon not found in drop pool: " + id));
                                                return 0;
                                            }
                                            final var msgT = Text.literal("Removed weapon from drop pool: " + id);
                                            ctx.getSource().sendFeedback(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(CommandManager.literal("weight")
                                        .then(CommandManager.argument("weight", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D))
                                                .executes(ctx -> {
                                                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                                    ItemStack stack = player.getMainHandStack();
                                                    if (stack.isEmpty()) {
                                                        ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                        return 0;
                                                    }
                                                    double weight = com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight");
                                                    String id = Registries.ITEM.getId(stack.getItem()).toString();
                                                    if (!ConfigManager.get().customWeaponRates.containsKey(id)) {
                                                        ctx.getSource().sendError(Text.literal("Weapon is not in drop pool yet: " + id));
                                                        return 0;
                                                    }
                                                    ConfigManager.get().customWeaponRates.put(id, weight);
                                                    ConfigManager.save();
                                                    final var msgT = Text.literal("Updated weapon pool weight: " + id + " -> " + weight);
                                                    ctx.getSource().sendFeedback(() -> msgT, false);
                                                    return 1;
                                                })))
                                .then(CommandManager.literal("list")
                                        .executes(ctx -> {
                                            if (ConfigManager.get().customWeaponRates.isEmpty()) {
                                                final var msgT = Text.literal("Custom drop pool is empty.");
                                                ctx.getSource().sendFeedback(() -> msgT, false);
                                                return 1;
                                            }
                                            StringBuilder sb = new StringBuilder();
                                            for (var e : ConfigManager.get().customWeaponRates.entrySet()) {
                                                if (sb.length() > 0) sb.append(", ");
                                                sb.append(e.getKey()).append("=").append(e.getValue());
                                            }
                                            final var msgT = Text.literal("Custom drop pool: " + sb);
                                            ctx.getSource().sendFeedback(() -> msgT, false);
                                            return 1;
                                        })))
                        .then(CommandManager.literal("tag")
                                .then(CommandManager.literal("add")
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            ItemStack stack = player.getMainHandStack();
                                            if (stack.isEmpty()) {
                                                ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = Registries.ITEM.getId(stack.getItem()).toString();
                                            ConfigManager.get().customWeaponRates.putIfAbsent(id, 1.0D);
                                            ConfigManager.save();
                                            final var msgT = Text.literal("Tagged weapon for drop pool: " + id);
                                            ctx.getSource().sendFeedback(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(CommandManager.literal("remove")
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            ItemStack stack = player.getMainHandStack();
                                            if (stack.isEmpty()) {
                                                ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = Registries.ITEM.getId(stack.getItem()).toString();
                                            ConfigManager.get().customWeaponRates.remove(id);
                                            ConfigManager.save();
                                            final var msgT = Text.literal("Removed weapon tag from drop pool: " + id);
                                            ctx.getSource().sendFeedback(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(CommandManager.literal("list")
                                        .executes(ctx -> {
                                            if (ConfigManager.get().customWeaponRates.isEmpty()) {
                                                final var msgT = Text.literal("Custom drop pool is empty.");
                                                ctx.getSource().sendFeedback(() -> msgT, false);
                                                return 1;
                                            }
                                            StringBuilder sb = new StringBuilder();
                                            for (String id : ConfigManager.get().customWeaponRates.keySet()) {
                                                if (sb.length() > 0) sb.append(", ");
                                                sb.append(id);
                                            }
                                            final var msgT = Text.literal("Tagged weapons: " + sb);
                                            ctx.getSource().sendFeedback(() -> msgT, false);
                                            return 1;
                                        })))
                        
.then(CommandManager.literal("mobdrop")
        .then(CommandManager.literal("add")
                .then(CommandManager.argument("entity", IdentifierArgumentType.identifier()).suggests(SUGGEST_ENTITY_IDS)
                        .then(CommandManager.argument("weight", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D))
                                .then(CommandManager.argument("chance", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D, 1.0D))
                                        .executes(ctx -> addMobDrop(ctx.getSource(),
                                                IdentifierArgumentType.getIdentifier(ctx, "entity").toString(),
                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight"),
                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "chance"),
                                                true, null, null))
                                        .then(CommandManager.argument("min_rarity", com.mojang.brigadier.arguments.StringArgumentType.word()).suggests(SUGGEST_RARITIES)
                                                .then(CommandManager.argument("max_rarity", com.mojang.brigadier.arguments.StringArgumentType.word()).suggests(SUGGEST_RARITIES)
                                                        .executes(ctx -> addMobDrop(ctx.getSource(),
                                                                IdentifierArgumentType.getIdentifier(ctx, "entity").toString(),
                                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight"),
                                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "chance"),
                                                                true,
                                                                com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "min_rarity"),
                                                                com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "max_rarity")))))))))
        .then(CommandManager.literal("addraw")
                .then(CommandManager.argument("entity", IdentifierArgumentType.identifier()).suggests(SUGGEST_ENTITY_IDS)
                        .then(CommandManager.argument("weight", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D))
                                .then(CommandManager.argument("chance", com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg(0.0D, 1.0D))
                                        .executes(ctx -> addMobDrop(ctx.getSource(),
                                                IdentifierArgumentType.getIdentifier(ctx, "entity").toString(),
                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "weight"),
                                                com.mojang.brigadier.arguments.DoubleArgumentType.getDouble(ctx, "chance"),
                                                false, null, null))))))
        .then(CommandManager.literal("list")
                .executes(ctx -> listMobDrops(ctx.getSource(), null))
                .then(CommandManager.argument("entity", IdentifierArgumentType.identifier()).suggests(SUGGEST_ENTITY_IDS)
                        .executes(ctx -> listMobDrops(ctx.getSource(),
                                IdentifierArgumentType.getIdentifier(ctx, "entity").toString()))))
        .then(CommandManager.literal("remove")
                .then(CommandManager.argument("entity", IdentifierArgumentType.identifier()).suggests(SUGGEST_ENTITY_IDS)
                        .then(CommandManager.argument("index", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0))
                                .executes(ctx -> removeMobDrop(ctx.getSource(),
                                        IdentifierArgumentType.getIdentifier(ctx, "entity").toString(),
                                        com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "index"))))))
        .then(CommandManager.literal("clear")
                .then(CommandManager.argument("entity", IdentifierArgumentType.identifier()).suggests(SUGGEST_ENTITY_IDS)
                        .executes(ctx -> clearMobDrops(ctx.getSource(),
                                IdentifierArgumentType.getIdentifier(ctx, "entity").toString()))))
        .then(CommandManager.literal("reload")
                .executes(ctx -> {
                    ConfigManager.load();
                    final var msgT = Text.literal("Reloaded mob drop rules.");
                    ctx.getSource().sendFeedback(() -> msgT, false);
                    return 1;
                })))

                        .then(CommandManager.literal("whitelist")
                                .then(CommandManager.literal("add")
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            ItemStack stack = player.getMainHandStack();
                                            if (stack.isEmpty()) {
                                                ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = Registries.ITEM.getId(stack.getItem()).toString();
                                            if (!ConfigManager.get().inscriptionWhitelist.contains(id)) {
                                                ConfigManager.get().inscriptionWhitelist.add(id);
                                                ConfigManager.save();
                                            }
                                            final var msgT = Text.translatable("command.savaru.whitelist.add", id);
            ctx.getSource().sendFeedback(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(CommandManager.literal("remove")
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            ItemStack stack = player.getMainHandStack();
                                            if (stack.isEmpty()) {
                                                ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = Registries.ITEM.getId(stack.getItem()).toString();
                                            ConfigManager.get().inscriptionWhitelist.remove(id);
                                            ConfigManager.save();
                                            final var msgT = Text.translatable("command.savaru.whitelist.remove", id);
            ctx.getSource().sendFeedback(() -> msgT, false);
                                            return 1;
                                        }))
                                .then(CommandManager.literal("list")
                                        .executes(ctx -> {
                                            String joined = String.join(", ", ConfigManager.get().inscriptionWhitelist);
                                            final var msgT = Text.translatable("command.savaru.whitelist.list",
                                                    joined.isEmpty() ? "(empty)" : joined);
            ctx.getSource().sendFeedback(() -> msgT, false);
                                            return 1;
                                        })))
                        // Add a normal affix (roll value from registry)
                        .then(CommandManager.literal("give_affix")
                                .then(CommandManager.argument("id", com.mojang.brigadier.arguments.StringArgumentType.word()).suggests(SUGGEST_AFFIX_IDS)
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            ItemStack stack = player.getMainHandStack();
                                            if (stack.isEmpty()) {
                                                ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                return 0;
                                            }
                                            String id = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "id");
                                            if (id.contains(":")) id = id.substring(id.indexOf(':') + 1);

                                            var def = findAffixDef(id);
                                            if (def == null) {
                                                ctx.getSource().sendError(Text.literal("Unknown affix: " + id));
                                                return 0;
                                            }

                                            double v = rollAffix(def, Random.create());
                                            AffixHelper.addOrReplaceAffix(stack, id, v);
                                            UnidentifiedHandler.markUnidentified(stack);
                                            final String msg = "Added affix: " + id + " (" + String.format("%.2f", v) + ")";
            ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
                                            return 1;
                                        })))
                        // Give effect: if it's an inscription id -> set inscription, else treat as normal affix id
                        .then(CommandManager.literal("give_effect")
                                .then(CommandManager.argument("id", com.mojang.brigadier.arguments.StringArgumentType.word()).suggests(SUGGEST_ANY_IDS)
                                        .suggests((ctx, builder) -> {
                                            // All inscription IDs from both pools
                                            for (String id : InscriptionHelper.OUTLAND_POOL) builder.suggest(id);
                                            for (String id : InscriptionHelper.SECRET_POOL) builder.suggest(id);
                                            // Also suggest all affix IDs
                                            for (Affix a : AffixRegistry.getAll()) builder.suggest(a.id());
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> {
                                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                                            ItemStack stack = player.getMainHandStack();
                                            if (stack.isEmpty()) {
                                                ctx.getSource().sendError(Text.literal("Hold an item in main hand."));
                                                return 0;
                                            }

                                            String id = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "id");
                                            if (id.contains(":")) id = id.substring(id.indexOf(':') + 1);

                                            // inscription ids
                                            String inscriptionType = InscriptionHelper.getTypeForId(id);
                                            if (inscriptionType != null) {
                                                if (!InscriptionHelper.isIdCompatibleWithWeapon(id, stack)) {
                                                    ctx.getSource().sendError(Text.translatable("command.savaru.give_effect.bad_target", id));
                                                    return 0;
                                                }
                                                InscriptionHelper.setInscription(stack, inscriptionType, id);
                                                final var msgT = Text.translatable("command.savaru.give_effect.ok", id);
            ctx.getSource().sendFeedback(() -> msgT, false);
                                                return 1;
                                            }

                                            // fall back: normal affix by id
                                            var def = findAffixDef(id);
                                            if (def == null) {
                                                ctx.getSource().sendError(Text.literal("Unknown id: " + id));
                                                return 0;
                                            }
                                            double v = rollAffix(def, Random.create());
                                            AffixHelper.addOrReplaceAffix(stack, id, v);
                                            UnidentifiedHandler.markUnidentified(stack);
                                            final String msg = "Added affix: " + id + " (" + String.format("%.2f", v) + ")";
            ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
                                            return 1;
                                        })))
        );
    }


private static int addMobDrop(ServerCommandSource source, String entityId, double weight, double chance,
                              boolean useSavaruRoll, String minRarity, String maxRarity) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
    ServerPlayerEntity player = source.getPlayerOrThrow();
    ItemStack stack = player.getMainHandStack();
    if (stack.isEmpty()) {
        source.sendError(Text.literal("Hold an item in main hand."));
        return 0;
    }

    Identifier entityKey;
    try {
        entityKey = Identifier.of(entityId);
    } catch (Exception e) {
        source.sendError(Text.literal("Invalid entity id: " + entityId));
        return 0;
    }
    if (!Registries.ENTITY_TYPE.containsId(entityKey)) {
        source.sendError(Text.literal("Unknown entity id: " + entityId));
        return 0;
    }

    String itemId = Registries.ITEM.getId(stack.getItem()).toString();
    String customName = stack.getName().getString();
    String min = minRarity == null ? Rarity.COMMON.name() : minRarity.toUpperCase();
    String max = maxRarity == null ? Rarity.UNRIVALED.name() : maxRarity.toUpperCase();

    if (useSavaruRoll) {
        try { Rarity.valueOf(min); } catch (Exception e) {
            source.sendError(Text.literal("Invalid min rarity: " + minRarity));
            return 0;
        }
        try { Rarity.valueOf(max); } catch (Exception e) {
            source.sendError(Text.literal("Invalid max rarity: " + maxRarity));
            return 0;
        }
    }

    ConfigManager.get().mobDropRules.add(new MobDropRule(entityId, itemId, weight, chance, useSavaruRoll, min, max, customName));
    ConfigManager.save();

    final var msgT = Text.literal("Added mob drop: " + entityId + " -> " + itemId
            + " (weight " + weight + ", chance " + chance
            + (useSavaruRoll ? ", rarity " + min + "~" + max : ", raw") + ")");
    source.sendFeedback(() -> msgT, false);
    return 1;
}

private static int listMobDrops(ServerCommandSource source, String entityId) {
    var rules = ConfigManager.get().mobDropRules;
    if (rules.isEmpty()) {
        final var msgT = Text.literal("Mob drop rules are empty.");
        source.sendFeedback(() -> msgT, false);
        return 1;
    }

    StringBuilder sb = new StringBuilder();
    int shown = 0;
    for (int i = 0; i < rules.size(); i++) {
        MobDropRule rule = rules.get(i);
        if (rule == null) continue;
        if (entityId != null && !entityId.equals(rule.entityId)) continue;
        if (shown++ > 0) sb.append(" | ");
        sb.append("#").append(i)
                .append(" ").append(rule.entityId)
                .append(" -> ").append(rule.itemId)
                .append(" w=").append(rule.weight)
                .append(" c=").append(rule.chance);
        if (rule.useSavaruRoll) {
            sb.append(" ").append(rule.minRarity).append("~").append(rule.maxRarity);
        } else {
            sb.append(" raw");
        }
    }

    if (shown == 0) {
        final var msgT = Text.literal("No mob drop rules for " + entityId);
        source.sendFeedback(() -> msgT, false);
        return 1;
    }

    final var msgT = Text.literal(sb.toString());
    source.sendFeedback(() -> msgT, false);
    return 1;
}

private static int removeMobDrop(ServerCommandSource source, String entityId, int index) {
    if (index < 0 || index >= ConfigManager.get().mobDropRules.size()) {
        source.sendError(Text.literal("Rule index out of range: " + index));
        return 0;
    }
    MobDropRule rule = ConfigManager.get().mobDropRules.get(index);
    if (rule == null || !entityId.equals(rule.entityId)) {
        source.sendError(Text.literal("Rule #" + index + " is not bound to " + entityId));
        return 0;
    }
    ConfigManager.get().mobDropRules.remove(index);
    ConfigManager.save();
    final var msgT = Text.literal("Removed mob drop rule #" + index + " for " + entityId);
    source.sendFeedback(() -> msgT, false);
    return 1;
}

private static int clearMobDrops(ServerCommandSource source, String entityId) {
    int before = ConfigManager.get().mobDropRules.size();
    ConfigManager.get().mobDropRules.removeIf(rule -> rule != null && entityId.equals(rule.entityId));
    int removed = before - ConfigManager.get().mobDropRules.size();
    ConfigManager.save();
    final var msgT = Text.literal("Cleared " + removed + " mob drop rules for " + entityId);
    source.sendFeedback(() -> msgT, false);
    return 1;
}


private static com.savaru.savaru_affixes.Affix findAffixDef(String id){
    if (id == null) return null;
    String plain = id;
    if (plain.contains(":")) plain = plain.substring(plain.indexOf(':')+1);
    for (var a : com.savaru.savaru_affixes.AffixRegistry.getAll()){
        if (a.id().equals(plain)) return a;
    }
    return null;
}



private static double rollAffix(Affix def, net.minecraft.util.math.random.Random rnd) {
    if (def == null) return 0.0;
    double min = def.min();
    double max = def.max();
    if (max < min) { double t = min; min = max; max = t; }
    if (min == max) return min;
    return min + rnd.nextDouble() * (max - min);
}


}