package com.savaru.savaru_affixes.api;

/**
 * 由 mixin 注入到 LivingEntity，用來暫存「定魂」持續時間。
 * 不做存檔持久化，只服務於遊戲中效果。
 */
public interface SoulbindAccess {
    void savaru$setSoulbindUntil(long untilTick);
    long savaru$getSoulbindUntil();
}
