package com.savaru.savaru_affixes.arrow;

import com.savaru.savaru_affixes.AffixHelper;
import net.minecraft.item.ItemStack;

/**
 * Arrow-only affix effects.
 *
 * Notes:
 * - Arrow affixes are separate from bow/crossbow affixes.
 * - Values are numeric multipliers (percentage-based), not fixed damage.
 */
public final class ArrowAffixProcessor {

    private ArrowAffixProcessor() {}

    /** +10-30% arrow hit damage. */
    public static double getArrowDamageMultiplier(ItemStack arrowStack) {
        if (arrowStack == null || arrowStack.isEmpty()) return 1.0;
        if (!AffixHelper.isArrowItem(arrowStack)) return 1.0;
        double v = AffixHelper.getAffixValue(arrowStack, "arrow_damage_boost");
        return v <= 0 ? 1.0 : (1.0 + (v / 100.0));
    }

    /** +10-30% potion effect level scaling (applied to amplifier). */
    public static double getEffectLevelMultiplier(ItemStack arrowStack) {
        if (arrowStack == null || arrowStack.isEmpty()) return 1.0;
        if (!AffixHelper.isArrowItem(arrowStack)) return 1.0;
        double v = AffixHelper.getAffixValue(arrowStack, "arrow_effect_level_boost");
        return v <= 0 ? 1.0 : (1.0 + (v / 100.0));
    }

    /** +10-20% potion effect duration. */
    public static double getEffectDurationMultiplier(ItemStack arrowStack) {
        if (arrowStack == null || arrowStack.isEmpty()) return 1.0;
        if (!AffixHelper.isArrowItem(arrowStack)) return 1.0;
        double v = AffixHelper.getAffixValue(arrowStack, "arrow_effect_duration_boost");
        return v <= 0 ? 1.0 : (1.0 + (v / 100.0));
    }
}
