package com.savaru.savaru_affixes;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * Unified critical hit value resolver.
 *
 * Merges our own SavaruAttributes crit values with Critical Strike mod
 * (critical_strike:chance / critical_strike:damage) via soft-depend.
 * If Critical Strike is not installed the soft-read returns 0 and nothing breaks.
 *
 * Scale conventions (same as SavaruAttributes):
 *   chance : 0..1  (e.g. 0.15 = 15%)
 *   damage : 0..∞  bonus multiplier added to 1.0  (e.g. 0.45 → final ×1.45)
 *
 * Critical Strike stores its values in the same scale (it lists base +5% / +50%).
 */
public final class CritHelper {

    private CritHelper() {}

    private static final Identifier CS_CHANCE_ID = Identifier.of("critical_strike", "chance");
    private static final Identifier CS_DAMAGE_ID = Identifier.of("critical_strike", "damage");

    /**
     * Combined crit chance (0-1).
     * = savaru_affixes:crit_chance  +  critical_strike:chance (if mod present)
     */
    public static double getCritChance(PlayerEntity player) {
        double base = player.getAttributeValue(SavaruAttributes.CRIT_CHANCE_ENTRY);
        base += readModdedAttr(player, CS_CHANCE_ID);
        return Math.min(1.0, Math.max(0.0, base));
    }

    /**
     * Combined crit damage bonus (≥0).
     * = savaru_affixes:crit_damage  +  critical_strike:damage (if mod present)
     * Final multiplier = 1.0 + result.
     */
    public static double getCritDamage(PlayerEntity player) {
        double base = player.getAttributeValue(SavaruAttributes.CRIT_DAMAGE_ENTRY);
        base += readModdedAttr(player, CS_DAMAGE_ID);
        return Math.max(0.0, base);
    }

    // ── soft-read helper ─────────────────────────────────────────────────────
    private static double readModdedAttr(PlayerEntity player, Identifier id) {
        try {
            var entryOpt = Registries.ATTRIBUTE.getEntry(id);
            if (entryOpt.isEmpty()) return 0.0;
            var inst = player.getAttributeInstance(entryOpt.get());
            if (inst == null) return 0.0;
            return inst.getValue();
        } catch (Exception e) {
            return 0.0;
        }
    }
}
