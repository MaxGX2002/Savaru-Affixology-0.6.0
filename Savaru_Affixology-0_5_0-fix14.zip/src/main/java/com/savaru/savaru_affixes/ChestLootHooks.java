package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Loot-table based chest injection.
 *
 * This stays friendly with instanced-container mods such as Lootr because it only modifies the loot
 * tables themselves instead of trying to write directly into container inventories.
 */
public final class ChestLootHooks {
    private ChestLootHooks(){}

    public static void init() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source) -> {
            Identifier id = key.getValue();
            if (!isInjectableChestTable(id)) return;

            double chance = ConfigManager.get().chestWeaponChance;
            if (chance <= 0.0D) return;

            List<Item> items = WeaponPool.buildEligibleItems();
            if (items.isEmpty()) return;

            LootPool.Builder pool = LootPool.builder()
                    .rolls(ConstantLootNumberProvider.create(1))
                    .conditionally(RandomChanceLootCondition.builder((float) chance));

            for (Item item : buildWeightedChestCandidates(items)) {
                pool.with(ItemEntry.builder(item));
            }

            tableBuilder.pool(pool);
        });
    }

    /**
     * Accept loot tables from any namespace so modded structures are included as well.
     * This is important for Lootr because it mirrors vanilla loot-table generation for many modded containers.
     */
    private static boolean isInjectableChestTable(Identifier id) {
        if (id == null) return false;
        String path = id.getPath();
        if (path == null || path.isBlank()) return false;

        // Ignore non-container/system tables.
        if (!path.startsWith("chests/")) return false;

        // Avoid touching Lootr's own support/system tables if any are present.
        if ("lootr".equals(id.getNamespace())) return false;

        return true;
    }

    /**
     * Convert the configured weapon pool into a small weighted candidate list. Repeating entries keeps the code
     * simple and compatible across mappings while still allowing custom weapon weights to influence chest rolls.
     */
    private static List<Item> buildWeightedChestCandidates(List<Item> items) {
        Map<String, Double> rates = ConfigManager.get().customWeaponRates;
        List<Item> out = new ArrayList<>();

        // Keep injected tables compact.
        final int hardCap = 48;

        for (Item item : items) {
            String id = net.minecraft.registry.Registries.ITEM.getId(item).toString();
            double weight = Math.max(0.0D, rates.getOrDefault(id, 1.0D));
            int copies = toCopies(weight);
            for (int i = 0; i < copies && out.size() < hardCap; i++) {
                out.add(item);
            }
            if (out.size() >= hardCap) break;
        }

        if (out.isEmpty()) {
            int limit = Math.min(items.size(), 16);
            for (int i = 0; i < limit; i++) out.add(items.get(i));
        }

        return out;
    }

    private static int toCopies(double weight) {
        if (weight <= 0.0D) return 0;
        if (weight < 0.75D) return 1;
        if (weight < 1.5D) return 2;
        if (weight < 3.0D) return 3;
        if (weight < 6.0D) return 4;
        return 5;
    }
}
