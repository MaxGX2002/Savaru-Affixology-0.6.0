package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.arrow.ArrowAffixProcessor;
import com.savaru.savaru_affixes.ranged.PinArrowHooks;
import com.savaru.savaru_affixes.ranged.RicochetHooks;
import com.savaru.savaru_affixes.ranged.RangedAffixProcessor;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import com.savaru.savaru_affixes.inscription.SpringRainHooks;
import com.savaru.savaru_affixes.inscription.HundredBlossomsHooks;
import com.savaru.savaru_affixes.inscription.DistantThunderHooks;
import com.savaru.savaru_affixes.inscription.MimicArrowHooks;
import com.savaru.savaru_affixes.inscription.DetonationHooks;
import com.savaru.savaru_affixes.inscription.ThunderfireCannonHooks;
import com.savaru.savaru_affixes.inscription.KagushimeiHooks;
import com.savaru.savaru_affixes.inscription.ChidoriHooks;
import com.savaru.savaru_affixes.inscription.InscriptionArrowRuntime;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(PersistentProjectileEntity.class)
public abstract class PersistentProjectileEntityHitMixin {

    @Shadow private ItemStack weapon;

    @Unique private Vec3d savaru_affixes$preHitVelocity;

    @Inject(method = "onEntityHit(Lnet/minecraft/util/hit/EntityHitResult;)V", at = @At("HEAD"))
    private void savaru_affixes$captureVelocity(EntityHitResult hitResult, CallbackInfo ci) {
        PersistentProjectileEntity proj = (PersistentProjectileEntity) (Object) this;
        savaru_affixes$preHitVelocity = proj.getVelocity();
    }

    @ModifyArgs(
            method = "onEntityHit(Lnet/minecraft/util/hit/EntityHitResult;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/Entity;damage(Lnet/minecraft/entity/damage/DamageSource;F)Z"
            )
    )
    private void savaru_affixes$modifyRangedDamage(Args args, EntityHitResult hitResult) {
        PersistentProjectileEntity proj = (PersistentProjectileEntity) (Object) this;

        if (SpringRainHooks.isManagedProjectile(proj) || HundredBlossomsHooks.isManagedProjectile(proj) || InscriptionArrowRuntime.isManaged(proj)) return;
        if (!(args.get(0) instanceof DamageSource src)) return;
        Entity attacker = src.getAttacker();
        if (!(attacker instanceof ServerPlayerEntity shooter)) return;

        Entity hit = hitResult.getEntity();
        if (!(hit instanceof LivingEntity target)) return;

        ItemStack weapon = (this.weapon != null && !this.weapon.isEmpty()) ? this.weapon : shooter.getMainHandStack();
        if (!RangedAffixProcessor.isRangedWeapon(weapon)) return;

        if (AffixHelper.getRarity(weapon) == null) return;
        if (UnidentifiedHandler.isUnidentified(weapon)) return;

        // Luminous arrow: make projectile glow
        if (AffixHelper.getAffixValue(weapon, "luminous_arrow") > 0.0) {
            proj.setGlowing(true);
        }

        // Piercing path: ensure piercing is enabled
        if (AffixHelper.getAffixValue(weapon, "piercing_path") > 0.0) {
            ((PersistentProjectileEntityInvoker) (Object) proj).savaru_affixes$invokeSetPierceLevel((byte) 127);
        }

        float original = (float) args.get(1);
        if (original <= 0f) return;

        RangedAffixProcessor.Result r0 = RangedAffixProcessor.apply(shooter, target, weapon, original);

        // Arrow-only damage boost: read from projectile stack (separate pool from weapon).
        double arrowMult = 1.0;
        try {
            ItemStack arrowStack = ((PersistentProjectileEntityAccessor) (Object) proj).savaru$asItemStack();
            arrowMult = ArrowAffixProcessor.getArrowDamageMultiplier(arrowStack);
        } catch (Throwable ignored) {}

        RangedAffixProcessor.Result r = new RangedAffixProcessor.Result(
                (float) (r0.damage() * arrowMult),
                r0.overrideSource()
        );

        if (r.overrideSource() != null) {
            args.set(0, r.overrideSource());
        }
        args.set(1, r.damage());

        // Magic arrow: force the hit to count as magic damage (match Arcblade's "indirectMagic" behavior).
        if (AffixHelper.getAffixValue(weapon, "magic_arrow") > 0.0 || InscriptionHelper.hasInscriptionId(weapon, "mimic_arrow")) {
            args.set(0, shooter.getDamageSources().indirectMagic(proj, shooter));
            if (shooter.getWorld() instanceof ServerWorld sw) { MimicArrowHooks.prepareProjectile(sw, proj); }
        }

        // Hunter mark: make the target easy to track (glowing) when it gets marked.
        // (The damage multiplier is handled inside RangedAffixProcessor.)
        if (AffixHelper.getAffixValue(weapon, "hunter_mark") > 0.0 && shooter.getWorld() instanceof ServerWorld) {
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 20 * 10, 0, true, false, true));
        }

        // Piercing path: decay next-hit damage by 15-30%
        double decayPct = AffixHelper.getAffixValue(weapon, "piercing_path");
        if (decayPct > 0.0) {
            double decay01 = Math.min(0.30, Math.max(0.15, decayPct / 100.0));
            proj.setDamage(proj.getDamage() * (1.0 - decay01));

            // Prevent unwanted "rebound" / reflection behavior by restoring the pre-hit velocity.
            if (savaru_affixes$preHitVelocity != null) {
                proj.setVelocity(savaru_affixes$preHitVelocity);
                proj.velocityModified = true;
            }
        }
    }

    @Inject(method = "onEntityHit(Lnet/minecraft/util/hit/EntityHitResult;)V", at = @At("TAIL"))
    private void savaru_affixes$afterEntityHit(EntityHitResult hitResult, CallbackInfo ci) {
        PersistentProjectileEntity proj = (PersistentProjectileEntity) (Object) this;
        Entity hit = hitResult.getEntity();
        if (!(hit instanceof LivingEntity target)) return;

        Entity ownerE = proj.getOwner();
        LivingEntity owner = ownerE instanceof LivingEntity le ? le : null;

        if (SpringRainHooks.handleSpecialArrowHit(proj, target) || HundredBlossomsHooks.handleSpecialArrowHit(proj, target)) {
            return;
        }

        if (!(target.getWorld() instanceof ServerWorld sw)) return;

        ItemStack weapon = (this.weapon != null && !this.weapon.isEmpty()) ? this.weapon : (owner != null ? owner.getMainHandStack() : ItemStack.EMPTY);
        if (!RangedAffixProcessor.isRangedWeapon(weapon)) return;
        if (AffixHelper.getRarity(weapon) == null) return;
        if (UnidentifiedHandler.isUnidentified(weapon)) return;

        // ---- Pin Arrow (釘箭) ----
        double pinPct = AffixHelper.getAffixValue(weapon, "pin_arrow"); // 5..15
        if (pinPct > 0.0) {
            double roll = sw.random.nextDouble() * 100.0;
            if (roll < pinPct) {
                double t = (pinPct - 5.0) / 10.0;
                if (t < 0.0) t = 0.0;
                if (t > 1.0) t = 1.0;
                float dmgPerTick = (float) (1.0 + t * 4.0);
                PinArrowHooks.applyOrExtend(target, owner != null ? owner.getUuid() : null, dmgPerTick);
            }
        }

        // ---- Ricochet (彈射) ----
        if (AffixHelper.getAffixValue(weapon, "ricochet") > 0.0) {
            RicochetHooks.onHit(proj, target);
        }

        if (InscriptionHelper.hasInscriptionId(weapon, "spring_rain") && owner instanceof ServerPlayerEntity) {
            SpringRainHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "hundred_blossoms") && owner instanceof ServerPlayerEntity) {
            HundredBlossomsHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "detonation") && owner instanceof ServerPlayerEntity) {
            DetonationHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "mimic_arrow") && owner instanceof ServerPlayerEntity) {
            MimicArrowHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "distant_thunder") && owner instanceof ServerPlayerEntity) {
            DistantThunderHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "thunderfire_cannon") && owner instanceof ServerPlayerEntity) {
            ThunderfireCannonHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "kagushimei") && owner instanceof ServerPlayerEntity) {
            KagushimeiHooks.onBowHit(sw, proj, target, weapon, owner);
        }
        if (InscriptionHelper.hasInscriptionId(weapon, "chidori") && owner instanceof ServerPlayerEntity) {
            ChidoriHooks.onBowHit(sw, proj, target, weapon, owner);
        }
    }
}
