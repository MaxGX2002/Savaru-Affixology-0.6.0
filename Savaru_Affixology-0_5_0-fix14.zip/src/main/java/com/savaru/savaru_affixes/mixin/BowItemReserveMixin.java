package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.ranged.RangedAffixProcessor;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * "儲備": chance to refund an arrow after a shot.
 * Implementation note: we refund a normal arrow item. This avoids fragile local-capture across versions.
 */
@Mixin(BowItem.class)
public abstract class BowItemReserveMixin {

    @Inject(method = "onStoppedUsing", at = @At("TAIL"))
    private void savaru_affixes$refundArrow(ItemStack stack, net.minecraft.world.World world, LivingEntity user, int remainingUseTicks, CallbackInfo ci) {
        if (!(world instanceof ServerWorld sw)) return;
        if (!(user instanceof PlayerEntity player)) return;
        if (player.getAbilities().creativeMode) return;

        if (!RangedAffixProcessor.isRangedWeapon(stack)) return;
        if (AffixHelper.getRarity(stack) == null) return;
        if (UnidentifiedHandler.isUnidentified(stack)) return;

	    // Avoid duplication with Infinity.
	    // 1.21.1: use the world's registry manager to resolve the enchantment entry.
	    RegistryEntry<Enchantment> infinity = sw.getRegistryManager()
	            .get(RegistryKeys.ENCHANTMENT)
	            .entryOf(Enchantments.INFINITY);
	    if (EnchantmentHelper.getLevel(infinity, stack) > 0) return;

        double pct = AffixHelper.getAffixValue(stack, "reserve"); // 10..30
        if (pct <= 0.0) return;

        double roll = sw.random.nextDouble() * 100.0;
        if (roll >= pct) return;

        ItemStack arrow = new ItemStack(Items.ARROW, 1);
        if (!player.getInventory().insertStack(arrow)) {
            player.dropItem(arrow, false);
        }
    }
}
