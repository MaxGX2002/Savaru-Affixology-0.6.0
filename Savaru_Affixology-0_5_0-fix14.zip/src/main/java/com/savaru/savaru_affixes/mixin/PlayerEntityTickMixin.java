package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.CritAttributeApplier;
import com.savaru.savaru_affixes.armor.ArmorAffixProcessor;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import com.savaru.savaru_affixes.SavaruAttributes;
import com.savaru.savaru_affixes.inscription.InscriptionRuntime;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityTickMixin {

    private static final Identifier BLACKFLASH_BOOST_ID        = Identifier.of("savaru_affixes", "blackflash_boost");
    private static final Identifier ARMOR_PROT_ID              = Identifier.of("savaru_affixes", "armor_protection");
    private static final Identifier ARMOR_TOUGH_ID             = Identifier.of("savaru_affixes", "armor_toughness");
    private static final Identifier ARMOR_HEAVY_ID             = Identifier.of("savaru_affixes", "armor_heavy");
    private static final Identifier ARMOR_WARRIOR_ID           = Identifier.of("savaru_affixes", "armor_warrior");
    private static final Identifier ARMOR_BERSERKER_CHANCE_ID  = Identifier.of("savaru_affixes", "armor_berserker_chance");
    private static final Identifier ARMOR_BERSERKER_DMG_ID     = Identifier.of("savaru_affixes", "armor_berserker_dmg");
    private static final Identifier ARMOR_SAINT_ID             = Identifier.of("savaru_affixes", "armor_saint");
    // CS Critical Strike mod (soft-depend)
    private static final Identifier ARMOR_CS_CC_PCT_ID         = Identifier.of("savaru_affixes", "armor_cs_cc_pct");
    private static final Identifier ARMOR_CS_CC_FLAT_ID        = Identifier.of("savaru_affixes", "armor_cs_cc_flat");
    private static final Identifier ARMOR_CS_CD_ID             = Identifier.of("savaru_affixes", "armor_cs_cd");

    @Inject(method = "tick", at = @At("TAIL"))
    private void savaru_affixes$onTick(CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        CritAttributeApplier.tick(self);

        // Server-only
        if (self.getWorld().isClient) return;
        if (!(self.getWorld() instanceof ServerWorld sw)) return;

        long now = sw.getTime();

        // Blackflash: +100% damage for the buff duration.
        boolean active = InscriptionRuntime.isBlackflashBuffActive(self.getUuid(), now);
        var inst = self.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
        if (inst == null) return;

        EntityAttributeModifier existing = inst.getModifier(BLACKFLASH_BOOST_ID);
        if (active) {
            if (existing == null) {
                inst.addPersistentModifier(new EntityAttributeModifier(
                        BLACKFLASH_BOOST_ID, 1.0, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                ));
            }
        } else {
            if (existing != null) inst.removeModifier(BLACKFLASH_BOOST_ID);
        }

        // --- Starflow: track last hurt tick (best-effort) ---
        if (self.hurtTime > 0) {
            InscriptionRuntime.setStarLastHurt(self.getUuid(), now);
        }

        // ── Armor affix tick-based effects (status effects only) ──────────
        // All attribute-based affixes (protection, toughness, heavy, warrior, berserker,
        // saint, CS crit) are now ITEM-LEVEL modifiers via AffixHelper.addArmorAffixModifiers.
        // Only fire_resist (status effect) and grace (absorption) need tick updates.
        if (now % 5 == 0) {
            // ── 防火100%: permanent fire resistance ────────────────────────
            double fireResist = ArmorAffixProcessor.getTotal(self, ArmorAffixProcessor.FIRE_RESIST);
            if (fireResist >= 100.0) {
                if (!self.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) {
                    self.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.FIRE_RESISTANCE, 200, 0, false, false, false));
                }
            }

            // ── 恩賜: absorption refresh every 60s ─────────────────────────
            double graceVal = ArmorAffixProcessor.getTotal(self, "armor_grace");
            if (graceVal > 0.0) {
                int graceAmp = Math.max(0, (int) Math.round(graceVal) - 1);
                StatusEffectInstance graceEffect = self.getStatusEffect(StatusEffects.ABSORPTION);
                if (graceEffect == null || graceEffect.getDuration() < 20) {
                    self.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.ABSORPTION, 1200, graceAmp, false, false, false));
                }
            }

            // ── 自然回血: every 5s heal (in-combat), every 1.2s (out-of-combat) ──
            double regenFlat = ArmorAffixProcessor.getTotal(self, ArmorAffixProcessor.REGEN_FLAT);
            double regenPct  = ArmorAffixProcessor.getTotal(self, ArmorAffixProcessor.REGEN_PCT);
            if (regenFlat > 0 || regenPct > 0) {
                java.util.UUID pid = self.getUuid();
                boolean ooc = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.isOutOfCombat(pid, now);
                if (ooc) {
                    // Out of combat: heal 5% max HP every 1.2s (24 ticks)
                    long lastOoc = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getLastOocRegenTick(pid);
                    if (now - lastOoc >= 24) {
                        float heal = self.getMaxHealth() * 0.05f;
                        self.heal(heal);
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setLastOocRegenTick(pid, now);
                    }
                } else {
                    // In combat: heal every 5s (100 ticks)
                    long lastRegen = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getLastRegenTick(pid);
                    if (now - lastRegen >= 100) {
                        float heal = 0;
                        if (regenFlat > 0) heal += (float) regenFlat;
                        if (regenPct > 0) heal += self.getMaxHealth() * (float)(regenPct / 100.0);
                        self.heal(heal);
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setLastRegenTick(pid, now);
                    }
                }
            }

            // ── 火炎鋼: AoE fire damage every 1s (20 ticks) ────────────────
            if (ArmorAffixProcessor.getChestAffix(self, ArmorAffixProcessor.CHEST_FLAME_STEEL) > 0 && now % 20 == 0) {
                double armorVal = self.getArmor();
                float fireDmg = (float)(2.0 + armorVal * 0.10);
                double radius = 1.5;
                var box = self.getBoundingBox().expand(radius);
                for (var entity : sw.getEntitiesByClass(net.minecraft.entity.LivingEntity.class, box,
                        e -> e != self && !(e instanceof PlayerEntity) && e.isAlive())) {
                    entity.setOnFireFor(1);
                    entity.damage(self.getDamageSources().onFire(), fireDmg);
                }
            }

            // ── 護盾: timer management ──────────────────────────────────────
            if (ArmorAffixProcessor.getChestAffix(self, ArmorAffixProcessor.CHEST_SHIELD) > 0) {
                java.util.UUID pid = self.getUuid();
                var rt = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.class;
                int phase = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getShieldPhase(pid);

                if (phase == 0) {
                    // Charging: wait 15s
                    long nextReady = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getShieldNextReady(pid);
                    if (nextReady == 0) {
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setShieldNextReady(pid, now + 300);
                    } else if (now >= nextReady) {
                        // Ready: give 6 absorption, enter phase 1
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setShieldPhase(pid, 1);
                        self.addStatusEffect(new StatusEffectInstance(
                                StatusEffects.ABSORPTION, 400, 2, false, false, true)); // amp2 = 3 hearts = 6hp
                    }
                } else if (phase == 2) {
                    // Triggered: after 5s, remove absorption and reset
                    long until = com.savaru.savaru_affixes.armor.ArmorEffectRuntime.getShieldTriggeredUntil(pid);
                    if (now >= until) {
                        self.removeStatusEffect(StatusEffects.ABSORPTION);
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setShieldPhase(pid, 0);
                        com.savaru.savaru_affixes.armor.ArmorEffectRuntime.setShieldNextReady(pid, now + 300);
                    }
                }
            }

            // ── Cleanup ALL legacy tick-based modifiers ────────────────────
            // These are now item-level (in AffixHelper.addArmorAffixModifiers).
            cleanupLegacyModifier(self, EntityAttributes.GENERIC_ARMOR, ARMOR_PROT_ID);
            cleanupLegacyModifier(self, EntityAttributes.GENERIC_ARMOR_TOUGHNESS, ARMOR_TOUGH_ID);
            cleanupLegacyModifier(self, EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, ARMOR_HEAVY_ID);
            cleanupLegacyModifier(self, EntityAttributes.GENERIC_ATTACK_DAMAGE, ARMOR_WARRIOR_ID);
            if (SavaruAttributes.CRIT_CHANCE_ENTRY != null) {
                cleanupLegacyModifier(self, SavaruAttributes.CRIT_CHANCE_ENTRY, ARMOR_BERSERKER_CHANCE_ID);
                nukeStaleFromEntry(self, SavaruAttributes.CRIT_CHANCE_ENTRY);
            }
            if (SavaruAttributes.CRIT_DAMAGE_ENTRY != null) {
                cleanupLegacyModifier(self, SavaruAttributes.CRIT_DAMAGE_ENTRY, ARMOR_BERSERKER_DMG_ID);
                nukeStaleFromEntry(self, SavaruAttributes.CRIT_DAMAGE_ENTRY);
            }
            cleanupLegacyModifier(self, EntityAttributes.GENERIC_MAX_HEALTH, ARMOR_SAINT_ID);
            // CS crit: NUCLEAR cleanup — remove ALL savaru_affixes modifiers from CS attributes.
            // Old versions used various IDs (affix_cs_cc, armor_cs_cc_pct, etc.) and some are
            // baked as persistent player-level modifiers that specific-ID cleanup can't catch.
            nukeAllSavaruModsFrom(self, "critical_strike", "chance");
            nukeAllSavaruModsFrom(self, "critical_strike", "damage");

            // ── Auto-migrate old armor items to new item-level system ──────
            migrateArmorIfNeeded(self);
        }

        // --- Charge / Starflow per-tick state machines ---
        ItemStack weapon = self.getMainHandStack();
        boolean weaponIdentified = !weapon.isEmpty(); // allow charge/starflow to run even if Unidentified

        // Build a lightweight fingerprint to detect item switching (switch => reset).
        String fp = null;
        if (weaponIdentified) {
            String itemId = Registries.ITEM.getId(weapon.getItem()).toString();
            var comp = weapon.get(DataComponentTypes.CUSTOM_DATA);
            int nbtHash = (comp == null || comp.getNbt() == null) ? 0 : comp.getNbt().hashCode();
            fp = itemId + "|" + weapon.getDamage() + "|" + nbtHash;
        }

        // Determine inscription id (if any)
        String insId = null;
        if (weaponIdentified) {
            var ins = InscriptionHelper.getInscription(weapon);
            if (ins != null) insId = ins.getString("id");
        }

        // ---- Charge (rework): always 75%, every 2s +75% (cap 450%); any hit resets ----
        if ("charge".equals(insId)) {
            String lastFp = InscriptionRuntime.getChargeFingerprint(self.getUuid());
            if (lastFp == null || fp == null || !lastFp.equals(fp)) {
                // equip / switch: start at 75%
                InscriptionRuntime.setChargeState(self.getUuid(), fp, 0, now + 40);
            } else {
                long next = InscriptionRuntime.getChargeNextTick(self.getUuid());
                if (now >= next) {
                    int pct = InscriptionRuntime.getChargePct(self.getUuid());
                    int nextPct = switch (pct) {
                        case 0 -> 100;
                        case 100 -> 200;
                        case 200 -> 400;
                        case 400 -> 800;
                        case 800 -> 1500;
                        default -> 1500;
                    };
                    InscriptionRuntime.setChargeState(self.getUuid(), fp, nextPct, now + 40);
                }
            }

            // persistent indicator (actionbar)
            if (self instanceof ServerPlayerEntity sp) {
                int pct = InscriptionRuntime.getChargePct(self.getUuid());
                String bar = switch (pct) {
                    case 0 -> "<=====>";
                    case 100 -> "<O====>";
                    case 200 -> "<OO===>";
                    case 400 -> "<OOO==>";
                    case 800 -> "<OOOO=>";
                    case 1500 -> "<充能完畢>";
                    default -> "<=====>";
                };
                InscriptionRuntime.sendActionbar(sp, bar + " " + pct + "%");
            }
        } else {
            InscriptionRuntime.resetCharge(self.getUuid());
        }

        // ---- Starflow: switching away resets chain; timed transitions advance stages ----
        if (!"starflow".equals(insId)) {
            InscriptionRuntime.resetStarflow(self.getUuid());
        } else {
            int stage = InscriptionRuntime.getStarStage(self.getUuid());
            long transAt = InscriptionRuntime.getStarTransitionAt(self.getUuid());
            if (stage > 0 && transAt > 0 && now >= transAt && self instanceof ServerPlayerEntity sp) {
                advanceStarflowStage(sp, now);
            }
        }
    }

    private static void advanceStarflowStage(ServerPlayerEntity player, long now) {
        UUID pid = player.getUuid();

        // If hurt recently, cancel chain
        long lastHurt = InscriptionRuntime.getStarLastHurt(pid);
        if (lastHurt + 1 >= now) {
            InscriptionRuntime.resetStarflow(pid);
            return;
        }

        int stage = InscriptionRuntime.getStarStage(pid);

        switch (stage) {
            case 1 -> {
                // After DOT(15s) + 10s => Stage2
                InscriptionRuntime.setStarStage(pid, 2);
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 10 * 20, 0, false, true, true));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 10 * 20, 1, false, true, true));
                InscriptionRuntime.setStarNext350(pid, true);
                InscriptionRuntime.setStarTransitionAt(pid, 0);
                InscriptionRuntime.sendTitle(player, "星擊：二連");
                player.sendMessage(net.minecraft.text.Text.literal("星擊：二連"), false);
            }
            case 4 -> {
                // Stage4 ended -> Stage5
                InscriptionRuntime.setStarStage(pid, 5);
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.HEALTH_BOOST, 15 * 20, 4, false, true, true)); // +20 HP
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, 10 * 20, 2, false, true, true)); // Luck III
                InscriptionRuntime.setStarTransitionAt(pid, now + 15 * 20);
                InscriptionRuntime.sendTitle(player, "星復：五連");
                player.sendMessage(net.minecraft.text.Text.literal("星復：五連"), false);
            }
            case 5 -> {
                // Stage5 ended -> Stage6
                InscriptionRuntime.setStarStage(pid, 6);
                InscriptionRuntime.setStarBurnUntil(pid, now + 10 * 20);
                InscriptionRuntime.setStarTransitionAt(pid, now + 10 * 20);
                InscriptionRuntime.sendTitle(player, "星火：六連");
                player.sendMessage(net.minecraft.text.Text.literal("星火：六連"), false);
            }
            case 6 -> {
                // Stage6 ended -> Stage7
                InscriptionRuntime.setStarStage(pid, 7);
                InscriptionRuntime.setStarNextFinal(pid, true);
                InscriptionRuntime.setStarBurnUntil(pid, 0);
                InscriptionRuntime.setStarTransitionAt(pid, 0);
                InscriptionRuntime.sendTitle(player, "星殞：終連");
                player.sendMessage(net.minecraft.text.Text.literal("星殞：終連"), false);
            }
            default -> InscriptionRuntime.resetStarflow(pid);
        }
    }

    /**
     * Soft-depend: try to apply a modifier to a modded attribute (e.g. critical_strike:chance).
     * Silently does nothing if the attribute is not registered.
     */
    private static void tryApplyModdedAttr(PlayerEntity player, String namespace, String path,
                                            Identifier modId, double flatValue) {
        try {
            var attrId = net.minecraft.util.Identifier.of(namespace, path);
            var entryOpt = net.minecraft.registry.Registries.ATTRIBUTE.getEntry(attrId);
            if (entryOpt.isEmpty()) return;
            var entry = entryOpt.get();
            var inst = player.getAttributeInstance(entry);
            if (inst == null) return;
            if (flatValue > 0.0) {
                var existing = inst.getModifier(modId);
                if (existing == null || Math.abs(existing.value() - flatValue) > 0.0001) {
                    if (existing != null) inst.removeModifier(modId);
                    inst.addPersistentModifier(new EntityAttributeModifier(
                            modId, flatValue, EntityAttributeModifier.Operation.ADD_VALUE));
                }
            } else {
                if (inst.getModifier(modId) != null) inst.removeModifier(modId);
            }
        } catch (Exception ignored) {}
    }

    /**
     * Same as tryApplyModdedAttr but uses ADD_MULTIPLIED_BASE operation.
     * Used for CS crit percentage bonuses (e.g. 0.75 = +75% of base).
     */
    private static void tryApplyModdedAttrMultBase(PlayerEntity player, String namespace, String path,
                                                    Identifier modId, double multBaseValue) {
        try {
            var attrId = net.minecraft.util.Identifier.of(namespace, path);
            var entryOpt = net.minecraft.registry.Registries.ATTRIBUTE.getEntry(attrId);
            if (entryOpt.isEmpty()) return;
            var entry = entryOpt.get();
            var inst = player.getAttributeInstance(entry);
            if (inst == null) return;
            if (multBaseValue > 0.0) {
                var existing = inst.getModifier(modId);
                if (existing == null || Math.abs(existing.value() - multBaseValue) > 0.0001) {
                    if (existing != null) inst.removeModifier(modId);
                    inst.addPersistentModifier(new EntityAttributeModifier(
                            modId, multBaseValue, EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE));
                }
            } else {
                if (inst.getModifier(modId) != null) inst.removeModifier(modId);
            }
        } catch (Exception ignored) {}
    }

    /**
     * Flat uses ADD, pct uses ADD_MULTIPLIED_BASE (applied to the item base value).
     * We combine both into one modifier using ADD for simplicity, converting pct to a
     * flat equivalent based on the attribute's base value.
     */
    private static void applyArmorModifier(
            PlayerEntity player,
            net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> attribute,
            Identifier modId,
            double flat, double pctOf100) {

        var attrInst = player.getAttributeInstance(attribute);
        if (attrInst == null) return;

        boolean hasBonus = (flat > 0.0 || pctOf100 > 0.0);
        EntityAttributeModifier existing = attrInst.getModifier(modId);

        if (hasBonus) {
            // For flat: direct ADD. For pct: ADD_MULTIPLIED_BASE on base value.
            // We use two separate modifiers via a combined Identifier scheme.
            Identifier flatId = Identifier.of(modId.getNamespace(), modId.getPath() + "_flat");
            Identifier pctId  = Identifier.of(modId.getNamespace(), modId.getPath() + "_pct");

            var flatExist = attrInst.getModifier(flatId);
            var pctExist  = attrInst.getModifier(pctId);

            if (flat > 0.0) {
                if (flatExist == null || Math.abs(flatExist.value() - flat) > 0.001) {
                    if (flatExist != null) attrInst.removeModifier(flatId);
                    attrInst.addPersistentModifier(new EntityAttributeModifier(
                            flatId, flat, EntityAttributeModifier.Operation.ADD_VALUE));
                }
            } else if (flatExist != null) {
                attrInst.removeModifier(flatId);
            }

            if (pctOf100 > 0.0) {
                double pctDecimal = pctOf100 / 100.0;
                if (pctExist == null || Math.abs(pctExist.value() - pctDecimal) > 0.0001) {
                    if (pctExist != null) attrInst.removeModifier(pctId);
                    attrInst.addPersistentModifier(new EntityAttributeModifier(
                            pctId, pctDecimal, EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE));
                }
            } else if (pctExist != null) {
                attrInst.removeModifier(pctId);
            }
        } else {
            // No bonus: clean up modifiers
            Identifier flatId = Identifier.of(modId.getNamespace(), modId.getPath() + "_flat");
            Identifier pctId  = Identifier.of(modId.getNamespace(), modId.getPath() + "_pct");
            if (attrInst.getModifier(flatId) != null) attrInst.removeModifier(flatId);
            if (attrInst.getModifier(pctId)  != null) attrInst.removeModifier(pctId);
        }
    }

    /** Remove legacy tick-based modifier from a vanilla attribute. */
    private static void cleanupLegacyModifier(
            PlayerEntity player,
            net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> attribute,
            Identifier modId) {
        try {
            var attrInst = player.getAttributeInstance(attribute);
            if (attrInst == null) return;
            if (attrInst.getModifier(modId) != null) attrInst.removeModifier(modId);
            Identifier flatId = Identifier.of(modId.getNamespace(), modId.getPath() + "_flat");
            Identifier pctId  = Identifier.of(modId.getNamespace(), modId.getPath() + "_pct");
            if (attrInst.getModifier(flatId) != null) attrInst.removeModifier(flatId);
            if (attrInst.getModifier(pctId)  != null) attrInst.removeModifier(pctId);
        } catch (Exception ignored) {}
    }

    /** Remove legacy tick-based modifier from a modded attribute (e.g. critical_strike:chance). */
    private static void cleanupModdedAttr(PlayerEntity player, String namespace, String path, Identifier modId) {
        try {
            var attrId = Identifier.of(namespace, path);
            var entryOpt = net.minecraft.registry.Registries.ATTRIBUTE.getEntry(attrId);
            if (entryOpt.isEmpty()) return;
            var inst = player.getAttributeInstance(entryOpt.get());
            if (inst == null) return;
            if (inst.getModifier(modId) != null) inst.removeModifier(modId);
        } catch (Exception ignored) {}
    }

    /**
     * NUCLEAR cleanup: remove STALE modifiers from our namespace on a modded attribute.
     * Keeps valid current-format modifiers:
     *   - weapon_* (from CritAttributeApplier for held weapon)
     *   - *_head / *_chest / *_legs / *_feet (item-level from armor pieces)
     * Removes everything else from our namespace (old formats without slot suffix).
     */
    private static void nukeAllSavaruModsFrom(PlayerEntity player, String namespace, String path) {
        try {
            var attrId = Identifier.of(namespace, path);
            var entryOpt = net.minecraft.registry.Registries.ATTRIBUTE.getEntry(attrId);
            if (entryOpt.isEmpty()) return;
            var inst = player.getAttributeInstance(entryOpt.get());
            if (inst == null) return;

            java.util.List<Identifier> toRemove = new java.util.ArrayList<>();
            for (var mod : inst.getModifiers()) {
                if (!"savaru_affixes".equals(mod.id().getNamespace())) continue;
                String p = mod.id().getPath();
                // Keep valid current-format modifiers
                if (p.startsWith("weapon_")) continue;                       // weapon crit from CritAttributeApplier
                if (p.endsWith("_head") || p.endsWith("_chest")
                        || p.endsWith("_legs") || p.endsWith("_feet")) continue; // item-level armor
                // Everything else is stale
                toRemove.add(mod.id());
            }
            for (Identifier id : toRemove) {
                inst.removeModifier(id);
            }
        } catch (Exception ignored) {}
    }

    /**
     * NUCLEAR cleanup for RegistryEntry-based attributes (e.g. SavaruAttributes).
     * Same logic as nukeAllSavaruModsFrom but takes a RegistryEntry directly.
     */
    private static void nukeStaleFromEntry(PlayerEntity player,
            net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> attr) {
        try {
            var inst = player.getAttributeInstance(attr);
            if (inst == null) return;
            java.util.List<Identifier> toRemove = new java.util.ArrayList<>();
            for (var mod : inst.getModifiers()) {
                if (!"savaru_affixes".equals(mod.id().getNamespace())) continue;
                String p = mod.id().getPath();
                if (p.startsWith("weapon_")) continue;
                if (p.endsWith("_head") || p.endsWith("_chest")
                        || p.endsWith("_legs") || p.endsWith("_feet")) continue;
                toRemove.add(mod.id());
            }
            for (Identifier id : toRemove) {
                inst.removeModifier(id);
            }
        } catch (Exception ignored) {}
    }

    /** Migrate old armor items to new item-level attribute system (slot-specific IDs). */
    private static void migrateArmorIfNeeded(PlayerEntity player) {
        try {
            for (net.minecraft.entity.EquipmentSlot slot : new net.minecraft.entity.EquipmentSlot[]{
                    net.minecraft.entity.EquipmentSlot.HEAD, net.minecraft.entity.EquipmentSlot.CHEST,
                    net.minecraft.entity.EquipmentSlot.LEGS, net.minecraft.entity.EquipmentSlot.FEET}) {
                ItemStack piece = player.getEquippedStack(slot);
                if (piece.isEmpty()) continue;
                if (!com.savaru.savaru_affixes.AffixHelper.isArmorItem(piece)) continue;
                var rarity = com.savaru.savaru_affixes.AffixHelper.getRarity(piece);
                if (rarity == null) continue;
                if (com.savaru.savaru_affixes.UnidentifiedHandler.isUnidentified(piece)) continue;

                var comp = piece.get(net.minecraft.component.DataComponentTypes.ATTRIBUTE_MODIFIERS);
                boolean hasNewFormat = false;
                if (comp != null) {
                    for (var e : comp.modifiers()) {
                        String p = e.modifier().id().getPath();
                        if (e.modifier().id().getNamespace().equals("savaru_affixes")
                                && (p.endsWith("_head") || p.endsWith("_chest")
                                    || p.endsWith("_legs") || p.endsWith("_feet"))) {
                            hasNewFormat = true;
                            break;
                        }
                    }
                }
                if (!hasNewFormat) {
                    com.savaru.savaru_affixes.AffixHelper.applyRarityNameColor(piece, rarity);
                }
            }
        } catch (Exception ignored) {}
    }
}
