package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.ranged.RangedAffixProcessor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ensure ranged projectiles remember the weapon used to fire them.
 * This fixes cases where the shooter swaps items before the arrow hits.
 */
@Mixin(PersistentProjectileEntity.class)
public abstract class PersistentProjectileEntityOwnerMixin {

    @Shadow private ItemStack weapon;

    @Inject(method = "setOwner", at = @At("HEAD"))
    private void savaru_affixes$captureWeapon(Entity owner, CallbackInfo ci) {
        if (this.weapon != null && !this.weapon.isEmpty()) return;
        if (!(owner instanceof LivingEntity le)) return;

        ItemStack main = le.getMainHandStack();
        ItemStack off = le.getOffHandStack();
        if (RangedAffixProcessor.isRangedWeapon(main)) {
            this.weapon = main.copy();
        } else if (RangedAffixProcessor.isRangedWeapon(off)) {
            this.weapon = off.copy();
        }
    }
}
