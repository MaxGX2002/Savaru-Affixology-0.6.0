package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * draw_speed (bow): increase computed useTicks at release so the shot behaves as if it was charged longer.
 */
@Mixin(BowItem.class)
public abstract class BowItemDrawSpeedMixin {

    /**
     * Redirect the call to BowItem.getPullProgress(int) so we can adjust the computed useTicks.
     *
     * Why redirect instead of @ModifyArg?
     * - In some loader/mixin combinations, @ModifyArg here can be interpreted as requiring a
     *   (I)I handler signature, which then crashes at apply-time.
     * - Redirect is stable and still lets us see the original onStoppedUsing args.
     */
    @Redirect(
            method = "onStoppedUsing(Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/item/BowItem;getPullProgress(I)F")
    )
    private float savaru_affixes$redirectPullProgress(int useTicks, ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        int boosted = useTicks;

        if (AffixHelper.getRarity(stack) != null && !UnidentifiedHandler.isUnidentified(stack)) {
            double sec = AffixHelper.getAffixValue(stack, "draw_speed");
            if (sec > 0.0) {
                int extra = (int) Math.round(sec * 20.0);
                if (extra > 40) extra = 40; // cap at 2 seconds
                boosted = useTicks + extra;
            }
        }

        return BowItem.getPullProgress(boosted);
    }
}
