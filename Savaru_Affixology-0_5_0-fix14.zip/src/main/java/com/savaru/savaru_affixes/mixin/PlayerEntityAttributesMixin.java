package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.SavaruAttributes;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityAttributesMixin {

    @Inject(method = "createPlayerAttributes", at = @At("RETURN"), cancellable = true)
    private static void savaru_affixes$addCustomAttributes(CallbackInfoReturnable<DefaultAttributeContainer.Builder> cir) {
        DefaultAttributeContainer.Builder builder = cir.getReturnValue();

        // Add our custom crit attributes so attribute panels can display them.
        // Use RegistryEntry-based add() for 1.21.1.
        SavaruAttributes.ensureRegistered();
        builder.add(SavaruAttributes.CRIT_CHANCE_ENTRY, 0.0);
        builder.add(SavaruAttributes.CRIT_DAMAGE_ENTRY, 0.0);
        builder.add(SavaruAttributes.LIFESTEAL_ENTRY, 0.0);
        builder.add(SavaruAttributes.TRUE_DAMAGE_ENTRY, 0.0);

        cir.setReturnValue(builder);
    }
}
