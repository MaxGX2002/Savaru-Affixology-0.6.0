package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.UnidentifiedHelper;
import com.savaru.savaru_affixes.WarnMessageHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientAttackMixin {

    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$blockInvalidAttack(CallbackInfoReturnable<Boolean> cir) {
        MinecraftClient client = (MinecraftClient) (Object) this;
        if (client.player == null) return;

        ItemStack stack = client.player.getMainHandStack();

        if (stack.isEmpty()) {
            WarnMessageHelper.send(client.player, Text.literal("請先裝備武器或工具").formatted(Formatting.RED));
            cir.setReturnValue(false);
            return;
        }

        if (UnidentifiedHelper.shouldBlockUse(stack)) {
            WarnMessageHelper.send(client.player, Text.literal("這把武器尚未鑑定，無法使用").formatted(Formatting.RED));
            cir.setReturnValue(false);
        }
    }
}
