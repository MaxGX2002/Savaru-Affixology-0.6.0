package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.inscription.InscriptionArrowRuntime;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PersistentProjectileEntity.class)
public abstract class PersistentProjectileEntityPickupMixin {
    @Inject(method = "onPlayerCollision", at = @At("HEAD"), cancellable = true, require = 0)
    private void savaru$blockInscriptionArrowPickup(PlayerEntity player, CallbackInfo ci) {
        PersistentProjectileEntity proj = (PersistentProjectileEntity) (Object) this;
        if (InscriptionArrowRuntime.shouldBlockPickup(proj, player)) {
            ci.cancel();
        }
    }
}
