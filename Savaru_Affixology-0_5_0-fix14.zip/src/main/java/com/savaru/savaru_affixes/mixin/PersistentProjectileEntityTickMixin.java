package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.inscription.InscriptionArrowRuntime;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import com.savaru.savaru_affixes.inscription.KagushimeiHooks;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.block.LightBlock;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Ensures projectile-side effects are applied during flight (not only after hit).
 * - Luminous arrow: glowing projectile
 */
@Mixin(PersistentProjectileEntity.class)
public abstract class PersistentProjectileEntityTickMixin {

    /**
     * In newer versions PersistentProjectileEntity keeps track of the fired weapon.
     * Using it avoids effects breaking when the player swaps items after shooting.
     */
    @Shadow private ItemStack weapon;

    @Unique private final Deque<BlockPos> savaru_affixes$lightTrail = new ArrayDeque<>();

    @Unique private static final int savaru_affixes$MAX_LIGHT_TRAIL = 12;


    @Inject(method = "tick", at = @At("HEAD"))
    private void savaru_affixes$applyProjectileFlightEffects(CallbackInfo ci) {
        PersistentProjectileEntity proj = (PersistentProjectileEntity) (Object) this;

        // Only care on server (glowing gets synced); client-only doesn't need to decide.
        if (proj.getWorld().isClient()) return;
        if (InscriptionArrowRuntime.shouldExpire(proj)) {
            InscriptionArrowRuntime.forget(proj);
            proj.discard();
            return;
        }

        Entity owner = proj.getOwner();
        if (!(owner instanceof ServerPlayerEntity shooter)) return;

        ItemStack weapon = (this.weapon != null && !this.weapon.isEmpty()) ? this.weapon : shooter.getMainHandStack();
        if (!com.savaru.savaru_affixes.ranged.RangedAffixProcessor.isRangedWeapon(weapon)) return;

        if (AffixHelper.getRarity(weapon) == null) return;
        if (UnidentifiedHandler.isUnidentified(weapon)) return;

        if (AffixHelper.getAffixValue(weapon, "luminous_arrow") > 0.0) {
            proj.setGlowing(true);
            savaru_affixes$placeLightAlongPath((ServerWorld) proj.getWorld(), proj.getBlockPos());
        }

        // ── Kagushimei: claim charge + soul-particle trail ──────────────
        if (InscriptionHelper.hasInscriptionId(weapon, "kagushimei")
                && owner instanceof ServerPlayerEntity sp) {
            long now = ((ServerWorld) proj.getWorld()).getTime();
            KagushimeiHooks.tryClaimCharge(sp, proj, now);
        }
        if (KagushimeiHooks.isChargedArrow(proj)) {
            ((ServerWorld) proj.getWorld()).spawnParticles(
                    net.minecraft.particle.ParticleTypes.SOUL,
                    proj.getX(), proj.getY(), proj.getZ(),
                    2, 0.06, 0.06, 0.06, 0.0);
        }
    }

    /**
     * Cleanup hook for when the projectile is removed.
     *
     * Entity removal method names/signatures can shift across MC versions.
     * Keep these injections optional (require=0) so the mod won't hard-crash
     * if the target method doesn't exist at runtime.
     */
    @Inject(method = "remove(Lnet/minecraft/entity/Entity$RemovalReason;)V", at = @At("HEAD"), require = 0)
    private void savaru_affixes$cleanupLightTrail_onRemove(Entity.RemovalReason reason, CallbackInfo ci) {
        savaru_affixes$cleanupLightTrailCommon();
    }

    @Inject(method = "discard()V", at = @At("HEAD"), require = 0)
    private void savaru_affixes$cleanupLightTrail_onDiscard(CallbackInfo ci) {
        savaru_affixes$cleanupLightTrailCommon();
    }

    @Unique
    private void savaru_affixes$cleanupLightTrailCommon() {
        PersistentProjectileEntity proj = (PersistentProjectileEntity) (Object) this;
        if (!(proj.getWorld() instanceof ServerWorld sw)) return;

        while (!savaru_affixes$lightTrail.isEmpty()) {
            savaru_affixes$removeLightIfPresent(sw, savaru_affixes$lightTrail.removeFirst());
        }
    }

    @Unique
    private void savaru_affixes$placeLightAlongPath(ServerWorld world, BlockPos pos) {
        // Only place on air; never overwrite real blocks.
        BlockState existing = world.getBlockState(pos);
        if (!existing.isAir()) return;

        BlockState light = Blocks.LIGHT.getDefaultState();
        // Some mappings expose the LEVEL property on the LightBlock; set level=15 safely if present.
        if (light.contains(LightBlock.LEVEL_15)) {
            light = light.with(LightBlock.LEVEL_15, 15);
        }

        world.setBlockState(pos, light, Block.NOTIFY_LISTENERS);
        savaru_affixes$lightTrail.addLast(pos.toImmutable());

        // Keep a short trail; remove oldest to avoid littering the world.
        while (savaru_affixes$lightTrail.size() > savaru_affixes$MAX_LIGHT_TRAIL) {
            BlockPos old = savaru_affixes$lightTrail.removeFirst();
            savaru_affixes$removeLightIfPresent(world, old);
        }
    }

    @Unique
    private void savaru_affixes$removeLightIfPresent(ServerWorld world, BlockPos pos) {
        BlockState st = world.getBlockState(pos);
        if (st.isOf(Blocks.LIGHT)) {
            world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
    }
}
