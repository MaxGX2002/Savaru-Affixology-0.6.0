package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.PreviewHelper;
import com.savaru.savaru_affixes.Rarity;
import com.savaru.savaru_affixes.UnidentifiedHelper;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Client-side display name adjustments:
 * - anvil preview stacks always show garbled/obfuscated title
 * - unresolved unidentified equipment -> prefix with 「未鑑定的 」
 * - UNRIVALED -> keep animated rainbow name
 */
@Mixin(ItemStack.class)
public abstract class ItemStackNameMixin {

    @Inject(method = "getName", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$decorateName(CallbackInfoReturnable<Text> cir) {
        ItemStack self = (ItemStack) (Object) this;

        if (PreviewHelper.isPreview(self)) {
            String source = PreviewHelper.getPreviewName(self);
            if (source == null || source.isBlank()) {
                source = self.getItem().getName(self).getString();
            }
            cir.setReturnValue(Text.literal(source).formatted(Formatting.DARK_GRAY, Formatting.OBFUSCATED));
            return;
        }

        Text baseName = self.contains(DataComponentTypes.CUSTOM_NAME)
                ? self.get(DataComponentTypes.CUSTOM_NAME)
                : self.getItem().getName(self);

        if (UnidentifiedHelper.shouldPrefixName(self)) {
            cir.setReturnValue(Text.literal("未鑑定的 ").formatted(Formatting.GRAY).append(baseName));
            return;
        }

        Rarity rarity = AffixHelper.getRarity(self);
        if (rarity != Rarity.UNRIVALED) return;

        String s = baseName.getString();
        cir.setReturnValue(Rarity.rainbowTextDynamic(s, System.currentTimeMillis()));
    }
}
