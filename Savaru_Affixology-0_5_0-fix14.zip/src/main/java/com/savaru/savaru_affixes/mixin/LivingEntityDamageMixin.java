package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.armor.ArmorAffixProcessor;
import com.savaru.savaru_affixes.armor.ArmorEffectRuntime;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityDamageMixin {

    private static final ThreadLocal<Boolean> SAVARU_REDUCING = ThreadLocal.withInitial(() -> false);

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$applyArmorAffixReductions(
            DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {

        if (SAVARU_REDUCING.get()) return;

        LivingEntity self = (LivingEntity) (Object) this;
        if (self.getWorld().isClient()) return;
        if (!(self.getWorld() instanceof ServerWorld sw)) return;
        if (amount <= 0f) return;

        // ── Standard armor reductions (hardened/bulletproof/fire/adapt) ──
        float reduced = ArmorAffixProcessor.applyReductions(self, source, amount);

        // ── Only apply advanced armor affixes to players ──────────────────
        if (self instanceof PlayerEntity player) {
            long now = sw.getTime();

            // Mark combat for regen out-of-combat tracking
            ArmorEffectRuntime.markCombat(player.getUuid(), now);

            // ── 護盾: phase 1 (ready) → absorb hit, transition to phase 2 ──
            if (ArmorAffixProcessor.getChestAffix(player, ArmorAffixProcessor.CHEST_SHIELD) > 0) {
                int phase = ArmorEffectRuntime.getShieldPhase(player.getUuid());
                if (phase == 1) {
                    // Absorb the hit completely
                    ArmorEffectRuntime.setShieldPhase(player.getUuid(), 2);
                    ArmorEffectRuntime.setShieldTriggeredUntil(player.getUuid(), now + 100); // 5 seconds
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.ABSORPTION, 100, 5, false, false, true)); // 12 absorption (amp5 = 6 hearts = 12hp)
                    cir.setReturnValue(false);
                    cir.cancel();
                    return;
                }
            }

            // ── 限制器: threshold check + damage cap ──────────────────────
            double limiterFlat = ArmorAffixProcessor.getTotal(player, ArmorAffixProcessor.LIMITER_FLAT);
            double limiterPct  = ArmorAffixProcessor.getTotal(player, ArmorAffixProcessor.LIMITER_PCT);
            if (limiterFlat > 0 || limiterPct > 0) {
                double threshold = 0;
                if (limiterFlat > 0) threshold = limiterFlat;
                if (limiterPct > 0) threshold = Math.max(threshold, player.getMaxHealth() * (limiterPct / 100.0));

                if (reduced >= threshold) {
                    // Trigger: regen 2 for 5s
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.REGENERATION, 100, 1, false, true, true));
                    // Activate damage cap for 5s
                    ArmorEffectRuntime.activateLimiter(player.getUuid(), now + 100);
                }

                // If limiter active, cap damage to 50%
                if (ArmorEffectRuntime.isLimiterActive(player.getUuid(), now)) {
                    reduced = Math.min(reduced, amount * 0.5f);
                }
            }

            // ── 承量: count hits ────────────────────────────────────────
            if (ArmorAffixProcessor.getChestAffix(player, ArmorAffixProcessor.CHEST_CHARGED_BURST) > 0) {
                int count = ArmorEffectRuntime.incrementBurstCounter(player.getUuid());
                if (count >= 5) {
                    ArmorEffectRuntime.resetBurstCounter(player.getUuid());
                    // Fire 20 fireballs in 360 degrees
                    double totalArmor = player.getArmor();
                    float burstDmg = (float) (totalArmor + 20.0);
                    for (int i = 0; i < 20; i++) {
                        double angle = Math.toRadians(360.0 / 20.0 * i);
                        double vx = Math.cos(angle) * 0.5;
                        double vz = Math.sin(angle) * 0.5;
                        SmallFireballEntity fb = new SmallFireballEntity(sw, player, vx, 0.05, vz);
                        fb.setPosition(player.getX(), player.getY() + 1.0, player.getZ());
                        sw.spawnEntity(fb);
                    }
                    // Spawn particles (handled client-side by fireball visuals)
                }
            }

            // ── 尖刺甲冑: reflect damage to attacker ──────────────────────
            double thornsPct = ArmorAffixProcessor.getChestAffix(player, ArmorAffixProcessor.CHEST_THORNS);
            if (thornsPct > 0 && source.getAttacker() instanceof LivingEntity attacker) {
                float reflectDmg = (float) (reduced * (thornsPct / 100.0));
                if (reflectDmg > 0.5f) {
                    SAVARU_REDUCING.set(true);
                    try {
                        attacker.damage(player.getDamageSources().thorns(player), reflectDmg);
                    } finally {
                        SAVARU_REDUCING.set(false);
                    }
                }
            }
        }

        // ── Apply final reduced damage ──────────────────────────────────
        if (reduced == amount) return; // no change, let vanilla proceed

        if (reduced <= 0f) {
            cir.setReturnValue(false);
            cir.cancel();
            return;
        }

        SAVARU_REDUCING.set(true);
        try {
            boolean result = self.damage(source, reduced);
            cir.setReturnValue(result);
            cir.cancel();
        } finally {
            SAVARU_REDUCING.set(false);
        }
    }
}
