package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.api.SoulbindAccess;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import com.savaru.savaru_affixes.inscription.JingtinFistHooks;
import com.savaru.savaru_affixes.inscription.InscriptionRuntime;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import com.savaru.savaru_affixes.inscription.StarflowHooks;
import com.savaru.savaru_affixes.BurnHooks;
import com.savaru.savaru_affixes.AffixHelper;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;

@Mixin(PlayerEntity.class)
public abstract class InscriptionAttackMixin {

    private static final double INV_SQRT2 = 1.0 / MathHelper.SQUARE_ROOT_OF_TWO;
    private static final Vec3d[] BAFENG_DIRECTIONS = new Vec3d[]{
            new Vec3d(0,0,-1),
            new Vec3d(0,0,1),
            new Vec3d(1,0,0),
            new Vec3d(-1,0,0),
            new Vec3d(INV_SQRT2,0,-INV_SQRT2),
            new Vec3d(-INV_SQRT2,0,-INV_SQRT2),
            new Vec3d(INV_SQRT2,0,INV_SQRT2),
            new Vec3d(-INV_SQRT2,0,INV_SQRT2)
    };

    private static NbtCompound getOrCreateCustomData(ItemStack stack) {
        NbtComponent comp = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (comp != null && comp.getNbt() != null) return comp.getNbt().copy();
        return new NbtCompound();
    }

    private static void setCustomData(ItemStack stack, NbtCompound root) {
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(root));
    }

    private static NbtCompound getOrCreateInsState(NbtCompound root) {
        if (!root.contains("savaru_ins_state")) root.put("savaru_ins_state", new NbtCompound());
        return root.getCompound("savaru_ins_state");
    }

    private static boolean cdReady(NbtCompound state, String key, long now) {
        long next = state.getLong(key);
        return now >= next;
    }

    private static void setCd(NbtCompound state, String key, long next) {
        state.putLong(key, next);
    }

    @Inject(method = "attack(Lnet/minecraft/entity/Entity;)V", at = @At("TAIL"))
    private void savaru$inscriptionPostHit(Entity target, CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (!(target instanceof LivingEntity living)) return;

        // Apply game effects only on server.
        if (self.getWorld().isClient) return;

        ItemStack weapon = self.getMainHandStack();
        if (weapon.isEmpty()) return;

        NbtCompound ins = InscriptionHelper.getInscription(weapon);
        if (ins == null) return;

        String id = ins.getString("id");
        if (id == null || id.isEmpty()) return;

        long now = self.getWorld().getTime();

        NbtCompound root = getOrCreateCustomData(weapon);
        NbtCompound state = getOrCreateInsState(root);

        switch (id) {
            case "blossom" -> {
                if (!cdReady(state, "blossom_cd", now)) break;
                if (self.getWorld().random.nextFloat() < 0.50f) {
                    self.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, 20 * 5, 1));
                    self.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 5, 2));
                    self.addStatusEffect(new StatusEffectInstance(StatusEffects.HEALTH_BOOST, 20 * 5, 1));
                    setCd(state, "blossom_cd", now + 20 * 10);
                }
            }
            case "blackflash" -> {
                if (!cdReady(state, "blackflash_cd", now)) break;
                if (self.getWorld().random.nextFloat() < 0.001f) {
                    // /kill-like: force death, then apply after-effects.
                    living.setHealth(0.0f);
                    living.damage(living.getDamageSources().outOfWorld(), 9999.0f);
                    if (!living.isDead()) living.kill();

                    self.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 20 * 60, 1));
                    self.setHealth(self.getMaxHealth());

                    // +100% damage for 60s (stack duration)
                    if (self instanceof net.minecraft.server.network.ServerPlayerEntity sp) {
                        InscriptionRuntime.extendBlackflashBuff(sp, sp.getServerWorld().getTime(), 60 * 20);
                    }
                    setCd(state, "blackflash_cd", now + 20 * 10);
                }
            }
            case "truefocus" -> {
                int tid = living.getId();
                int lastTid = state.getInt("tf_tid");
                int cnt = state.getInt("tf_cnt");
                if (tid != lastTid) cnt = 0;
                cnt++;
                if (cnt >= 4) {
                    cnt = 0;
                    float base = (float) self.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE);
                    float dmg = base * 5.0f;
                    // "True" magic damage (RPG style)
                    InscriptionRuntime.magicTrueDamage(living, dmg);
                    if (self.getWorld() instanceof ServerWorld sw) {
                        sw.spawnParticles(ParticleTypes.CRIT, living.getX(), living.getBodyY(0.5), living.getZ(), 12, 0.25, 0.25, 0.25, 0.1);
                    }
                }
                state.putInt("tf_tid", tid);
                state.putInt("tf_cnt", cnt);
            }
            case "jingtin_fist" -> {
                // 逕庭拳：目標具備任一負面狀態時，啟動每 0.5 秒一次的固定魔法傷害（忽略護甲/抗性）
                if (living.hasStatusEffect(StatusEffects.POISON)
                        || living.hasStatusEffect(StatusEffects.WITHER)
                        || living.hasStatusEffect(StatusEffects.SLOWNESS)
                        || living.hasStatusEffect(StatusEffects.DARKNESS)
                        || living.hasStatusEffect(StatusEffects.NAUSEA)
                        || living.hasStatusEffect(StatusEffects.WEAKNESS)) {
                    JingtinFistHooks.activate(living);
                }
            }
            case "soulbind" -> {
                // 定魂：20% 機率定身 5 秒（用極高緩速模擬），冷卻 10 秒
                if (cdReady(state, "soulbind_cd", now)) {
                    if (self.getWorld().random.nextFloat() < 0.20f) {
                        living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20 * 5, 255, false, true, true));
                        // 移速直接變 0：比只有緩速更接近「定身」
                        if ((Object) living instanceof SoulbindAccess acc) {
                            acc.savaru$setSoulbindUntil(living.getWorld().getTime() + (20L * 5L));
                        }
                        setCd(state, "soulbind_cd", now + 20 * 10);
                    }
                }
            }
            case "senlingpoison" -> {
                if (self.getWorld().random.nextFloat() < 0.20f) {
                    int dur = 20 * 20;
                    StatusEffectInstance cur = living.getStatusEffect(StatusEffects.POISON);
                    if (cur != null) dur += cur.getDuration();
                    living.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, dur, 2));
                    if (living.getStatusEffect(StatusEffects.POISON) == null) {
                        living.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, dur, 2));
                        if (living.getStatusEffect(StatusEffects.REGENERATION) == null) {
                            living.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, dur, 2));
                            if (living.getStatusEffect(StatusEffects.WITHER) == null) {
                                living.addStatusEffect(new StatusEffectInstance(StatusEffects.INSTANT_DAMAGE, 1, 2));
                            }
                        }
                    }
                }
            }
            case "bafengshen" -> {
    // 八風神：每兩下觸發一次（風爆 + 世界固定八向）
    int cnt = state.getInt("bafeng_cnt") + 1;
    if (cnt < 2) {
        state.putInt("bafeng_cnt", cnt);
        break;
    }
    state.putInt("bafeng_cnt", 0);

    // 風爆：擊退主目標
    Vec3d away = living.getPos().subtract(self.getPos());
    if (away.lengthSquared() > 1.0e-6) {
        away = away.normalize();
        living.addVelocity(away.x * 0.6, 0.15, away.z * 0.6);
        living.velocityModified = true;
    }

    if (self.getWorld() instanceof ServerWorld sw) {
        final double range = 16.0;
        final double radius = 1.25;

        for (Vec3d baseDir : BAFENG_DIRECTIONS) {
            Vec3d dir = baseDir.normalize();
            LivingEntity hit = findFirstLivingInRay(sw, self, dir, range, radius);
            if (hit == null) continue;

            sw.createExplosion(self, hit.getX(), hit.getBodyY(0.5), hit.getZ(), 0.0f, ServerWorld.ExplosionSourceType.NONE);
            hit.damage(sw.getDamageSources().explosion(self, self), 50.0f);
            sw.spawnParticles(ParticleTypes.GUST, hit.getX(), hit.getBodyY(0.5), hit.getZ(), 6, 0.2, 0.2, 0.2, 0.01);
        }
    }
}

            case "charge" -> {
                // 充能（重製）：常駐 75%，每2秒+75%（最多450%）；任意命中後重置
                int pct = InscriptionRuntime.getChargePct(self.getUuid());
                if (pct < 0) pct = 0;

                float base = (float) self.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE);
                float extra = base * (pct / 100.0f);

                boolean ok = living.damage(self.getDamageSources().playerAttack(self), extra);
                if (!ok) {
                    InscriptionRuntime.magicTrueDamage(living, extra);
                }

                // reset after dealing damage
                InscriptionRuntime.setChargeState(self.getUuid(), InscriptionRuntime.getChargeFingerprint(self.getUuid()), 0, now + 40);
            }
            case "sunmoon_corridor" -> {
                // 日月迴廊：每第二下攻擊追加 150%（魔法）傷害；若有魔劍詞綴則改為 150% 無視抗性防禦傷害
                int hits = state.getInt("sm_hits") + 1;

                if (hits >= 2) {
                    hits = 0;

                    float base = (float) self.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE);
                    float dmg = base * 1.50f;

                    boolean hasArcblade = AffixHelper.getAffixValue(weapon, "arcblade") > 0.0;
                    if (hasArcblade) {
                        InscriptionRuntime.magicTrueDamage(living, dmg);
                    } else {
                        // RPGCLASS-like magic hit
                        boolean ok = living.damage(self.getDamageSources().indirectMagic(self, self), dmg);
                        if (!ok) {
                            // ensure visibility if invulnerability frames eat it
                            InscriptionRuntime.magicTrueDamage(living, dmg);
                        }
                    }
                }

                state.putInt("sm_hits", hits);
            }
            case "starflow" -> {
                // 星流七連：不受傷情況下連續擊殺 5 個目標啟動；後續由 tick 狀態機推進
                if (self instanceof ServerPlayerEntity sp) {
                    UUID pid = sp.getUuid();
                    long lastHurt = InscriptionRuntime.getStarLastHurt(pid);
                    if (lastHurt + 1 >= now) {
                        InscriptionRuntime.resetStarflow(pid);
                        break;
                    }

                    int stage = InscriptionRuntime.getStarStage(pid);

                    // Stage-specific on-hit / next-hit actions
                    if (stage == 1 && InscriptionRuntime.consumeStarNextDot(pid)) {
                        // Apply DOT to target and schedule stage2 transition at (dot end +10s)
                        StarflowHooks.startDot((ServerWorld) self.getWorld(), living, sp);
                        InscriptionRuntime.setStarTransitionAt(pid, now + (15 * 20) + (10 * 20));
                        InscriptionRuntime.sendTitle(sp, "星流：一連");
                        sp.sendMessage(net.minecraft.text.Text.literal("星流：一連"), false);
                    } else if (stage == 2 && InscriptionRuntime.consumeStarNext350(pid)) {
                        float base = (float) self.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE);
                        float dmg = base * 3.50f;
                        living.damage(sp.getDamageSources().indirectMagic(sp, sp), dmg);
                        // After 10s -> Stage3 (next-hit arrows)
                        InscriptionRuntime.setStarStage(pid, 3);
                        InscriptionRuntime.setStarNextArrows(pid, true);
                        InscriptionRuntime.setStarTransitionAt(pid, 0);
                        // schedule nothing; stage3 is next hit, but requires 10s wait per spec
                        NbtCompound s = state;
                        long readyAt = now + 10 * 20;
                        s.putLong("star3_readyAt", readyAt);
                    } else if (stage == 3) {
                        long readyAt = state.getLong("star3_readyAt");
                        if (readyAt > 0 && now < readyAt) break;
                        if (InscriptionRuntime.consumeStarNextArrows(pid)) {
                            // Fire 70 arrows in 360 degrees, damage ~2
                            if (self.getWorld() instanceof ServerWorld sw) {
                                for (int i = 0; i < 70; i++) {
                                    double yaw = (i / 70.0) * (Math.PI * 2.0);
                                    Vec3d dir = new Vec3d(Math.cos(yaw), 0.02, Math.sin(yaw)).normalize();
                                    ArrowEntity arrow = net.minecraft.entity.EntityType.ARROW.create(sw);
                                    if (arrow == null) continue;
                                    arrow.setOwner(sp);
                                    arrow.setPos(sp.getX(), sp.getEyeY() - 0.1, sp.getZ());
                                    arrow.setVelocity(dir.x * 1.6, dir.y * 1.6, dir.z * 1.6);
                                    arrow.setDamage(2.0);
                                    arrow.setCritical(true);
                                    sw.spawnEntity(arrow);
                                }
                                sw.playSound(null, sp.getBlockPos(), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0f, 1.0f);
                            }
                            // Immediately enter stage4 (20s resistance + levitate on hit)
                            InscriptionRuntime.setStarStage(pid, 4);
                            sp.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 20, 2, false, true, true));
                            InscriptionRuntime.setStarLevitateUntil(pid, now + 20 * 20);
                            InscriptionRuntime.setStarTransitionAt(pid, now + 20 * 20);
                            InscriptionRuntime.sendTitle(sp, "星矢：三連");
                        sp.sendMessage(net.minecraft.text.Text.literal("星矢：三連"), false);
                            InscriptionRuntime.sendTitle(sp, "星沉：四連");
                        sp.sendMessage(net.minecraft.text.Text.literal("星沉：四連"), false);
                            state.putLong("star3_readyAt", 0L);
                        }
                    } else if (stage == 4) {
                        // levitate on hit while active
                        if (now <= InscriptionRuntime.getStarLevitateUntil(pid)) {
                            living.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 20 * 2, 0, false, true, true));
                        }
                    } else if (stage == 6) {
                        // burn on hit for 10s
                        if (self.getWorld() instanceof ServerWorld sw) {
                            if (now <= InscriptionRuntime.getStarBurnUntil(pid)) {
                                int burnDmg = AffixHelper.getAffixLevel(weapon, "burn");
                                if (burnDmg <= 0) burnDmg = 3;
                                BurnHooks.queueDot2s4Hits(sw, living, self, burnDmg);
                                living.setOnFireFor(2);
                            }
                        }
                    } else if (stage == 7 && InscriptionRuntime.consumeStarNextFinal(pid)) {
                        InscriptionRuntime.magicTrueDamage(living, 200.0);
                        InscriptionRuntime.resetStarflow(pid);
                    }

                    // Kill detection to START chain (stage==0)
                    if (!living.isAlive()) {
                        if (stage == 0) {
                            int k = InscriptionRuntime.addStarKill(pid);
                            if (k >= 5) {
                                InscriptionRuntime.resetStarKills(pid);
                                InscriptionRuntime.setStarStage(pid, 1);
                                InscriptionRuntime.setStarNextDot(pid, true);
                                InscriptionRuntime.setStarTransitionAt(pid, 0);
                                InscriptionRuntime.sendTitle(sp, "星流：一連");
                        sp.sendMessage(net.minecraft.text.Text.literal("星流：一連"), false);
                            }
                        }
                    }
                }
            }
            case "heaven_inverted_spear" -> {
                // 天逆鉾：攻擊目標清除其身上所有效果（正負皆清）
                living.clearStatusEffects();
            }

            default -> { }
        }

        root.put("savaru_ins_state", state);
        setCustomData(weapon, root);
    }

    private static LivingEntity findFirstLivingInRay(ServerWorld world, PlayerEntity player, Vec3d dir, double range, double radius) {
        Vec3d start = player.getEyePos();
        Box box = new Box(start, start).expand(range, 3.0, range);

        LivingEntity best = null;
        double bestT = range + 1.0;

        for (Entity e : world.getOtherEntities(player, box)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (!le.isAlive()) continue;

            Vec3d to = le.getEyePos().subtract(start);
            double t = to.dotProduct(dir);
            if (t <= 0.0 || t > range) continue;

            Vec3d perp = to.subtract(dir.multiply(t));
            if (perp.lengthSquared() > radius * radius) continue;

            if (t < bestT) {
                bestT = t;
                best = le;
            }
        }
        return best;
    }
}