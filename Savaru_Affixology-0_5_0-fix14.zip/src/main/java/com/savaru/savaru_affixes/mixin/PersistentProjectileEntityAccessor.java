package com.savaru.savaru_affixes.mixin;

import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Exposes {@code PersistentProjectileEntity#asItemStack()} which is protected.
 * Used to read arrow ItemStack NBT for the arrow affix system.
 */
@Mixin(PersistentProjectileEntity.class)
public interface PersistentProjectileEntityAccessor {

    @Invoker("asItemStack")
    ItemStack savaru$asItemStack();
}
