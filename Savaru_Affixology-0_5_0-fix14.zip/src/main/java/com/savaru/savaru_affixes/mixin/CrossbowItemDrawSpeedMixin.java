package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * draw_speed for crossbows: reduce pull time by up to 2 seconds.
 */
@Mixin(CrossbowItem.class)
public abstract class CrossbowItemDrawSpeedMixin {

    @Inject(method = "getPullTime", at = @At("RETURN"), cancellable = true)
    private static void savaru_affixes$reducePullTime(ItemStack stack, LivingEntity user, CallbackInfoReturnable<Integer> cir) {
        if (AffixHelper.getRarity(stack) == null) return;
        if (UnidentifiedHandler.isUnidentified(stack)) return;

        double sec = AffixHelper.getAffixValue(stack, "draw_speed");
        if (sec <= 0.0) return;

        int extra = (int) Math.round(sec * 20.0);
        if (extra > 40) extra = 40;

        int base = cir.getReturnValue();
        int reduced = Math.max(1, base - extra);
        cir.setReturnValue(reduced);
    }
}
