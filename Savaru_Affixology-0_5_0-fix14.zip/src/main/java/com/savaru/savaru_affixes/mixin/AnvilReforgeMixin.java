package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.Affix;
import com.savaru.savaru_affixes.AffixHelper;
import com.savaru.savaru_affixes.AffixRegistry;
import com.savaru.savaru_affixes.Rarity;
import com.savaru.savaru_affixes.RarityRoller;
import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.PreviewHelper;
import com.savaru.savaru_affixes.IdentificationHelper;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.SpectralArrowItem;
import net.minecraft.item.TippedArrowItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.Property;
import net.minecraft.text.Text;
import net.minecraft.util.math.random.Random;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;

/**
 * Anvil reforging rules (per your latest spec):
 * - Anvil + (affixed weapon) + Nether Star: reroll ONE random affix, keep the rest.
 *   Costs 100 levels. Also consumes 100 durability on the weapon. Rarity & durability buffs remain.
 * - Anvil + (affixed weapon) + Dragon's Breath: reroll rarity.
 *   Costs 200 levels. Weapon durability loses 30% of max. Keep 1-2 affixes, reroll the rest.
 */
@Mixin(AnvilScreenHandler.class)
public abstract class AnvilReforgeMixin {

    @Shadow @Final private Property levelCost;

    // In vanilla, the anvil consumes the right item by repairItemUsage when taking output.
    @Shadow private int repairItemUsage;

    @Inject(method = "updateResult", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$updateResult(CallbackInfo ci) {
        AnvilScreenHandler self = (AnvilScreenHandler) (Object) this;

        ItemStack left = self.getSlot(0).getStack();
        ItemStack right = self.getSlot(1).getStack();

        if (left.isEmpty() || right.isEmpty()) return;

        // allow PAPER (鑑定券), BOOK (affix book), WEAPON, ARMOR, and BLAZE_ROD (inscription proofs)
        if (!left.isOf(Items.PAPER) && !left.isOf(Items.BOOK) && !left.isOf(Items.BLAZE_ROD) && !AffixHelper.isWeapon(left) && !AffixHelper.isArrowItem(left) && !AffixHelper.isArmorItem(left)) return;

        ItemStack out = ItemStack.EMPTY;
        int cost = 0;

        // ---- Identification Ticket (鑑定券) ----
        if (left.isOf(Items.PAPER) && right.isOf(Items.EMERALD)) {
            int craftCount = Math.min(left.getCount(), right.getCount());
            out = IdentificationHelper.makeTicket(craftCount);
            cost = craftCount;
        }
        // ---- Identify weapon without rerolling via ticket ----
        else if (IdentificationHelper.canIdentifyWeapon(left) && IdentificationHelper.isTicket(right)) {
            out = IdentificationHelper.identify(left);
            UnidentifiedHandler.markUnidentified(out);
            setPreviewName(out, buildPreviewName(out, AffixHelper.getRarity(out)));
            cost = 15;
        }

        // ---- Inscription Proofs (銘刻之証) ----
// Blaze Rod + Dragon's Breath -> Outland proof (cost 1000 levels)
if (left.isOf(Items.BLAZE_ROD) && right.isOf(Items.DRAGON_BREATH)) {
    out = makeInscriptionProof(InscriptionHelper.TYPE_OUTLAND, left);
    cost = 1000;
}
// Blaze Rod + Ghast Tear -> Secret proof (cost 500 levels)
else if (left.isOf(Items.BLAZE_ROD) && right.isOf(Items.GHAST_TEAR)) {
    out = makeInscriptionProof(InscriptionHelper.TYPE_SECRET, left);
    cost = 500;
}
// Weapon + proof -> apply inscription (cost depends on type)
else if (!left.isOf(Items.BOOK) && isInscriptionProof(right)) {
    String type = getProofType(right);
    Rarity r = AffixHelper.getRarity(left);
    if (r == null) return;
    if (!InscriptionHelper.isAllowedWeapon(left)) return;
    out = left.copy();
    String insId = getProofId(right);

    // If the proof was rolled from the wrong weapon family (old generic proof behavior),
    // reroll it into a compatible inscription from the same type pool for the target weapon.
    if (!InscriptionHelper.isIdCompatibleWithWeapon(insId, left)) {
        java.util.List<String> compatiblePool = InscriptionHelper.getPoolFor(type, left);
        if (compatiblePool.isEmpty()) return;
        insId = compatiblePool.get(new java.util.Random().nextInt(compatiblePool.size()));
    }

    if (!InscriptionHelper.canApplyToWeapon(type, r, left, insId)) return;

    InscriptionHelper.setInscription(out, type, insId);
    UnidentifiedHandler.markUnidentified(out);
    setPreviewName(out, buildInscriptionPreviewName(out, insId));
    cost = InscriptionHelper.TYPE_OUTLAND.equals(type) ? 1000 : 500;
}

// ---- Affix Transfer (詞綴轉移) ----

        // Step A: Book + Ghast Tear -> "詞綴之書" with 1-2 random affixes. Cost 30 levels.
        if (left.isOf(Items.BOOK) && right.isOf(Items.GHAST_TEAR)) {
            out = makeAffixBook();
            cost = 30;
        }
        // Step B: Legendary+ weapon/armor + "詞綴之書" -> write affixes into item. Cost 30 levels.
        else if (!left.isOf(Items.BOOK) && isAffixBook(right)) {
            Rarity r = AffixHelper.getRarity(left);
            if (r == null) return;
            if (r.ordinal() < Rarity.LEGENDARY.ordinal()) return;

            out = applyAffixBook(left, right);
            if (!out.isEmpty()) UnidentifiedHandler.markUnidentified(out);
            cost = 30;
        }

        if (out.isEmpty()) {
        // Only actual weapons/arrows/armor can use reroll materials. Books must use the dedicated affix-book recipe.
        if (!AffixHelper.isWeapon(left) && !AffixHelper.isArrowItem(left) && !AffixHelper.isArmorItem(left)) {
            return;
        }
        if (right.isOf(Items.NETHER_STAR)) {
            // needs existing Savaru data
            if (AffixHelper.getRarity(left) == null) return;
            if (AffixHelper.getAffixes(left).isEmpty()) return;
            out = makeReforgeOneAffix(left);
            cost = 100;
        } else if (right.isOf(Items.END_CRYSTAL)) {
            // reroll quality for any weapon
            out = makeRerollRarity(left, false);
            cost = 200;
        } else if (right.isOf(Items.DRAGON_BREATH)) {
            // reroll quality (epic+ guaranteed)
            out = makeRerollRarity(left, true);
            cost = 200;
        } else {
            return;
        }
        }

        if (out.isEmpty()) {
            self.getSlot(2).setStack(ItemStack.EMPTY);
            this.levelCost.set(0);
            this.repairItemUsage = 0;
            ci.cancel();
            return;
        }

        self.getSlot(2).setStack(out);
        this.levelCost.set(cost);
        this.repairItemUsage = 1;
        ci.cancel();
    }


    @Inject(method = "onTakeOutput", at = @At("HEAD"))
    private void savaru_affixes$finalizeInscriptionTake(PlayerEntity player, ItemStack stack, CallbackInfo ci) {
        if (stack == null || stack.isEmpty()) return;

        AnvilScreenHandler self = (AnvilScreenHandler) (Object) this;
        ItemStack left = self.getSlot(0).getStack();
        ItemStack right = self.getSlot(1).getStack();

        if (left.isEmpty() || right.isEmpty()) return;
        if (!AffixHelper.isWeapon(left)) return;
        if (!isInscriptionProof(right)) return;
        if (InscriptionHelper.getInscription(stack) == null) return;

        // Preview in slot 2 should stay obfuscated, but once taken the inscription must be visible immediately.
        UnidentifiedHandler.clearUnidentified(stack);
        PreviewHelper.clearPreviewName(stack);
    }

    @Inject(method = "onTakeOutput", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$consumeTicketRecipe(PlayerEntity player, ItemStack stack, CallbackInfo ci) {
        if (!IdentificationHelper.isTicket(stack)) return;

        AnvilScreenHandler self = (AnvilScreenHandler) (Object) this;
        ItemStack left = self.getSlot(0).getStack();
        ItemStack right = self.getSlot(1).getStack();

        if (!left.isOf(Items.PAPER) || !right.isOf(Items.EMERALD)) return;

        int craftCount = Math.min(left.getCount(), right.getCount());
        if (craftCount <= 0) return;

        ItemStack out = stack.copy();
        out.setCount(craftCount);

        self.getSlot(2).setStack(ItemStack.EMPTY);
        left.decrement(craftCount);
        right.decrement(craftCount);
        if (left.isEmpty()) self.getSlot(0).setStack(ItemStack.EMPTY);
        if (right.isEmpty()) self.getSlot(1).setStack(ItemStack.EMPTY);

        player.addExperienceLevels(-this.levelCost.get());

        if (!player.getInventory().insertStack(out)) {
            player.dropItem(out, false);
        }

        this.levelCost.set(0);
        this.repairItemUsage = 0;
        self.updateResult();
        ci.cancel();
    }

    // ---- helpers (ported from previous smithing implementation) ----

    private static ItemStack makeReforgeOneAffix(ItemStack base) {
        if (base.isDamageable() && base.getMaxDamage() > 0) {
            int newDamage = base.getDamage() + 100;
            if (newDamage >= base.getMaxDamage()) return ItemStack.EMPTY;
        }

        ItemStack out = base.copy();
        if (out.isDamageable() && out.getMaxDamage() > 0) {
            out.setDamage(out.getDamage() + 100);
        }

        Random rnd = Random.create();
        reforgeSingleAffixInPlace(out, rnd);

        Rarity r = AffixHelper.getRarity(out);
        if (r != null) AffixHelper.applyRarityNameColor(out, r);

        // Hide result in preview until taken
        UnidentifiedHandler.markUnidentified(out);
        setPreviewName(out, buildPreviewName(out, r));
        return out;
    }

    private static ItemStack makeRerollRarity(ItemStack base, boolean epicPlusOnly) {
        if (base.isDamageable() && base.getMaxDamage() > 0) {
            int cost = Math.max(1, (int) Math.round(base.getMaxDamage() * 0.30));
            int newDamage = base.getDamage() + cost;
            if (newDamage >= base.getMaxDamage()) return ItemStack.EMPTY;
        }

        ItemStack out = base.copy();
        if (out.isDamageable() && out.getMaxDamage() > 0) {
            int cost = Math.max(1, (int) Math.round(out.getMaxDamage() * 0.30));
            out.setDamage(out.getDamage() + cost);
        }

        Random rnd = Random.create();
        Rarity newR;
        if (epicPlusOnly) {
            // Epic 74%, Legendary 25%, Beyond 0.99%, Unrivaled 0.01%
            newR = RarityRoller.rollByWeights(rnd, new double[]{0.0, 0.0, 0.0, 74.0, 25.0, 0.0, 0.99, 0.01});
        } else {
            // Common 50%, Uncommon 40%, Rare 8%, Epic 1.9%, Legendary 0.09%, Beyond 0.009%, Unrivaled 0.001%
            newR = RarityRoller.rollByWeights(rnd, new double[]{50.0, 40.0, 8.0, 1.9, 0.09, 0.0, 0.009, 0.001});
        }

        // If no affixes exist yet, generate them. Otherwise keep 1-2 and reroll the rest.
        if (AffixHelper.getAffixes(out).isEmpty()) {
            AffixHelper.setRarity(out, newR);
            AffixHelper.rollAffixes(out, newR);
        } else {
            rerollAffixesKeepSome(out, newR, rnd);
        }
        AffixHelper.applyRarityNameColor(out, newR);
        forceSetRarityName(out, newR);

        // Hide result in preview until taken
        UnidentifiedHandler.markUnidentified(out);
        setPreviewName(out, buildPreviewName(out, newR));
        return out;
    }

    private static void forceSetRarityName(ItemStack stack, Rarity rarity) {
        if (stack == null || rarity == null) return;
        String prefix = switch (rarity) {
            case COMMON -> "普通";
            case UNCOMMON -> "罕見";
            case RARE -> "稀有";
            case EPIC -> "史詩";
            case LEGENDARY -> "傳說";
            case MYTHIC -> "神話";
            case BEYOND -> "超乎想像";
            case UNRIVALED -> "無與倫比";
        };

        String name = stack.getName().getString();
        for (String p : new String[]{"普通", "罕見", "稀有", "史詩", "傳說", "神話", "超乎想像", "無與倫比"}) {
            String head = p + "的 ";
            if (name.startsWith(head)) {
                name = name.substring(head.length());
                break;
            }
        }

        String full = prefix + "的 " + name;
        stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal(full).setStyle(rarity.style()));
    }

    private static void rerollAffixesKeepSome(ItemStack stack, Rarity newR, Random rnd) {
        NbtList existing = AffixHelper.getAffixes(stack);
        List<NbtCompound> old = new ArrayList<>();
        for (int i = 0; i < existing.size(); i++) old.add(existing.getCompound(i).copy());

        int keepCount = Math.min(old.size(), 1 + rnd.nextInt(2));
        Collections.shuffle(old, new java.util.Random(rnd.nextLong()));

        List<NbtCompound> kept = old.subList(0, keepCount);

        int target = getAffixCountForRarity(newR, rnd);
        if (target < kept.size()) {
            kept = kept.subList(0, target);
        }

        Set<String> used = new HashSet<>();
        NbtList outList = new NbtList();
        for (NbtCompound c : kept) {
            used.add(c.getString("id"));
            outList.add(c);
        }

        List<Affix> pool = filteredPoolForStack(stack, used);

        int guard = 0;
        while (outList.size() < target && !pool.isEmpty() && guard++ < 512) {
            Affix pick = weightedPick(pool, rnd);
            pool.remove(pick);
            if (used.contains(pick.id())) continue;
            if (!passesMutualExclusion(pick.id(), used)) continue;

            double value = invokeRollValueByRarity(pick, newR, rnd);
            NbtCompound entry = new NbtCompound();
            entry.putString("id", pick.id());
            entry.putDouble("value", value);

            if ("wither".equals(pick.id()) || "weakness".equals(pick.id()) || "frailty".equals(pick.id())) {
                entry.putInt("level", 1 + rnd.nextInt(2));
            }
            if ("res_pen_flat".equals(pick.id()) || "res_pen_pct".equals(pick.id())) {
                entry.putInt("level", 1 + rnd.nextInt(3));
            }
            if ("durability_bonus".equals(pick.id())) {
                int extra = Math.max(1, (int) Math.round(stack.getMaxDamage() * (value / 100.0)));
                entry.putInt("buf", extra);
            }

            used.add(pick.id());
            outList.add(entry);
        }

        // Use AffixHelper to initialize/normalize root then overwrite
        AffixHelper.rollAffixes(stack, newR);
        NbtCompound root2 = getRootDirect(stack);
        if (root2 != null) {
            root2.putString("rarity", newR.name());
            root2.put("affixes", outList);
            setRootDirect(stack, root2);
        }
    }

    private static void reforgeSingleAffixInPlace(ItemStack stack, Random rnd) {
        Rarity rarity = AffixHelper.getRarity(stack);
        if (rarity == null) return;
        NbtList list = AffixHelper.getAffixes(stack);
        if (list.isEmpty()) return;

        int idx = rnd.nextInt(list.size());
        Set<String> used = new HashSet<>();
        for (int i = 0; i < list.size(); i++) {
            if (i == idx) continue;
            used.add(list.getCompound(i).getString("id"));
        }

        List<Affix> pool = filteredPoolForStack(stack, used);

        Affix pick = null;
        int guard = 0;
        while (pick == null && guard++ < 512 && !pool.isEmpty()) {
            Affix cand = weightedPick(pool, rnd);
            pool.remove(cand);
            if (!passesMutualExclusion(cand.id(), used)) continue;
            pick = cand;
        }
        if (pick == null) return;

        double value = invokeRollValueByRarity(pick, rarity, rnd);
        NbtCompound entry = new NbtCompound();
        entry.putString("id", pick.id());
        entry.putDouble("value", value);

        if ("wither".equals(pick.id()) || "weakness".equals(pick.id()) || "frailty".equals(pick.id())) {
            entry.putInt("level", 1 + rnd.nextInt(2));
        }
        if ("res_pen_flat".equals(pick.id()) || "res_pen_pct".equals(pick.id())) {
            entry.putInt("level", 1 + rnd.nextInt(3));
        }
        if ("durability_bonus".equals(pick.id())) {
            int extra = Math.max(1, (int) Math.round(stack.getMaxDamage() * (value / 100.0)));
            entry.putInt("buf", extra);
        }

        list.set(idx, entry);

        NbtCompound root = getRootDirect(stack);
        if (root == null) root = new NbtCompound();
        root.putString("rarity", rarity.name());
        root.put("affixes", list);
        setRootDirect(stack, root);
    }

    private static boolean passesMutualExclusion(String pickId, Set<String> used) {
        Set<String> armorPen = Set.of("armor_pen_flat", "armor_pen_pct");
        Set<String> resPen = Set.of("res_pen_flat", "res_pen_pct");
        Set<String> health = Set.of("max_hp_pct", "cur_hp_pct", "execute_flat", "execute_pct");
        Set<String> dot = Set.of("wither", "weakness", "frailty", "lifesteal");
        Set<String> healing = Set.of("lifesteal", "overheal");
        Set<String> durability = Set.of("durability_bonus", "durability_nocost");

        if ("true_damage".equals(pickId) && used.stream().anyMatch(armorPen::contains)) return false;
        if (armorPen.contains(pickId) && used.contains("true_damage")) return false;

        if (resPen.contains(pickId)) {
            if (used.contains("true_damage") || used.stream().anyMatch(armorPen::contains) || used.stream().anyMatch(resPen::contains)) return false;
        }
        if (armorPen.contains(pickId) && used.stream().anyMatch(resPen::contains)) return false;
        if ("true_damage".equals(pickId) && used.stream().anyMatch(resPen::contains)) return false;

        if (health.contains(pickId)) {
            for (String g : health) {
                if (!g.equals(pickId) && used.contains(g)) return false;
            }
        }
        if (("max_hp_pct".equals(pickId) || "cur_hp_pct".equals(pickId)) && used.contains("bonus_damage")) return false;
        if ("bonus_damage".equals(pickId) && (used.contains("max_hp_pct") || used.contains("cur_hp_pct"))) return false;

        if (dot.contains(pickId)) {
            for (String g : dot) {
                if (!g.equals(pickId) && used.contains(g)) return false;
            }
        }
        if (healing.contains(pickId)) {
            for (String g : healing) {
                if (!g.equals(pickId) && used.contains(g)) return false;
            }
        }
        if (durability.contains(pickId)) {
            for (String g : durability) {
                if (!g.equals(pickId) && used.contains(g)) return false;
            }
        }
        return true;
    }

    private static int getAffixCountForRarity(Rarity rarity, Random rnd) {
        int min, max;
        switch (rarity) {
            case COMMON -> { min = 0; max = 1; }
            case UNCOMMON -> { min = 1; max = 2; }
            case RARE -> { min = 1; max = 2; }
            case EPIC -> { min = 2; max = 3; }
            case LEGENDARY -> { min = 3; max = 4; }
            case MYTHIC -> { min = 4; max = 5; }
            case BEYOND -> { min = 6; max = 7; }
            case UNRIVALED -> { min = 6; max = 7; }
            default -> { min = 1; max = 1; }
        }
        return min + rnd.nextInt(max - min + 1);
    }

    private static Affix weightedPick(List<Affix> pool, Random rnd) {
        int total = 0;
        for (Affix a : pool) total += Math.max(1, a.weight());
        int roll = rnd.nextInt(Math.max(1, total));
        int acc = 0;
        for (Affix a : pool) {
            acc += Math.max(1, a.weight());
            if (roll < acc) return a;
        }
        return pool.get(pool.size() - 1);
    }

    private static double invokeRollValueByRarity(Affix affix, Rarity rarity, Random rnd) {
        double base = affix.min() + (affix.max() - affix.min()) * rnd.nextDouble();
        if ("max_hp_pct".equals(affix.id()) || "poison_aoe".equals(affix.id())) return base;

        double mult;
        switch (rarity) {
            case COMMON -> mult = 0.35;
            case UNCOMMON -> mult = 0.55;
            case RARE -> mult = 0.75;
            case EPIC -> mult = 0.90;
            default -> mult = 1.00;
        }
        return base * mult;
    }

    private static NbtCompound getRootDirect(ItemStack stack) {
        try {
            var comp = stack.getOrDefault(DataComponentTypes.CUSTOM_DATA, net.minecraft.component.type.NbtComponent.DEFAULT);
            NbtCompound all = comp.copyNbt();
            return all.contains("savaru_affixes", 10) ? all.getCompound("savaru_affixes") : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static void setRootDirect(ItemStack stack, NbtCompound root) {
        var comp = stack.getOrDefault(DataComponentTypes.CUSTOM_DATA, net.minecraft.component.type.NbtComponent.DEFAULT);
        NbtCompound all = comp.copyNbt();
        all.put("savaru_affixes", root);
        stack.set(DataComponentTypes.CUSTOM_DATA, net.minecraft.component.type.NbtComponent.of(all));
    }
    // ---- Affix Book helpers ----

    private static final String BOOK_TYPE_KEY = "book_type";

    private static String stackAffixTypeKey(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "weapon";
        if (AffixHelper.isArrowItem(stack)) return "arrow";
        if (AffixHelper.isArmorItem(stack)) return "armor";
        if (stack.getItem() instanceof BowItem || stack.getItem() instanceof CrossbowItem) return "ranged";
        return "weapon";
    }

    private static List<Affix> filteredPoolForStack(ItemStack stack, Set<String> used) {
        String type = stackAffixTypeKey(stack);
        List<Affix> pool = new ArrayList<>(AffixRegistry.getAll());
        pool.removeIf(a -> !affixBookTypeKey(a.id()).equals(type));
        if (used != null && !used.isEmpty()) {
            pool.removeIf(a -> used.contains(a.id()));
        }
        return pool;
    }


    private static String affixBookTypeKey(String affixId) {
        // Armor affixes
        if (affixId.startsWith("armor_")) return "armor";
        return switch (affixId) {
            case "magic_arrow", "luminous_arrow", "piercing_path", "draw_speed", "lifeshot", "hunter_mark", "finisher_shot", "ricochet", "pin_arrow", "reserve" -> "ranged";
            case "arrow_damage_boost", "arrow_effect_level_boost", "arrow_effect_duration_boost" -> "arrow";
            default -> "weapon";
        };
    }

    private static Text affixBookName(String type) {
        return switch (type) {
            case "ranged" -> Text.translatable("item.savaru_affixes.affix_book_ranged");
            case "arrow" -> Text.translatable("item.savaru_affixes.affix_book_arrow");
            case "armor" -> Text.translatable("item.savaru_affixes.affix_book_armor");
            default -> Text.translatable("item.savaru_affixes.affix_book_weapon");
        };
    }

    private static boolean isAffixBook(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (!stack.isOf(Items.BOOK)) return false;

        try {
            if (stack.contains(DataComponentTypes.CUSTOM_NAME)) {
                Text t = stack.get(DataComponentTypes.CUSTOM_NAME);
                if (t != null && (t.getString().startsWith("詞綴之書") || t.getString().equals(Text.translatable("item.savaru_affixes.affix_book_weapon").getString()) || t.getString().equals(Text.translatable("item.savaru_affixes.affix_book_ranged").getString()) || t.getString().equals(Text.translatable("item.savaru_affixes.affix_book_arrow").getString()) || t.getString().equals(Text.translatable("item.savaru_affixes.affix_book_armor").getString()))) return true;
            }
        } catch (Exception ignored) {}

        try {
            NbtCompound root = AffixHelper.getRoot(stack);
            return root != null && root.contains(AffixHelper.KEY_AFFIXES);
        } catch (Exception ignored) {}

        return false;
    }

    private static ItemStack makeAffixBook() {
        Random rnd = Random.create();
        AffixRegistry.init();

        ItemStack book = new ItemStack(Items.BOOK);

        String bookType = switch (rnd.nextInt(4)) {
            case 1 -> "ranged";
            case 2 -> "arrow";
            case 3 -> "armor";
            default -> "weapon";
        };

        List<Affix> pool = new ArrayList<>(AffixRegistry.getAll());
        pool.removeIf(a -> !affixBookTypeKey(a.id()).equals(bookType));
        Collections.shuffle(pool, new java.util.Random(rnd.nextLong()));

        int count = "arrow".equals(bookType) ? 1 : (1 + rnd.nextInt(2));
        Set<String> used = new HashSet<>();

        NbtList affixes = new NbtList();
        for (Affix a : pool) {
            if (affixes.size() >= count) break;
            if (used.contains(a.id())) continue;

            // basic mutual exclusions for book pick
            if (("berserk".equals(a.id()) && used.contains("greedlife")) || ("greedlife".equals(a.id()) && used.contains("berserk"))) continue;
            if (("arcblade".equals(a.id()) && used.contains("berserk")) || ("berserk".equals(a.id()) && used.contains("arcblade"))) continue;
            if (("burn".equals(a.id()) && (used.contains("poison_aoe") || used.contains("wither")))) continue;
            if (("poison_aoe".equals(a.id()) && (used.contains("burn") || used.contains("wither")))) continue;
            if (("wither".equals(a.id()) && (used.contains("burn") || used.contains("poison_aoe")))) continue;
            if (("devour".equals(a.id()) && used.contains("lifesteal")) || ("lifesteal".equals(a.id()) && used.contains("devour"))) continue;

            used.add(a.id());

            double value = a.min();
            double max = a.max();
            if (max > value) value = value + (rnd.nextDouble() * (max - value));

            NbtCompound entry = new NbtCompound();
            entry.putString(AffixHelper.KEY_ID, a.id());
            entry.putDouble(AffixHelper.KEY_VALUE, value);

            if ("wither".equals(a.id()) || "weakness".equals(a.id()) || "frailty".equals(a.id())) {
                entry.putInt(AffixHelper.KEY_LEVEL, 1 + rnd.nextInt(3));
            } else if ("burn".equals(a.id()) || "devour".equals(a.id())) {
                entry.putInt(AffixHelper.KEY_LEVEL, 1 + rnd.nextInt(5));
            } else {
                entry.putInt(AffixHelper.KEY_LEVEL, 0);
            }

            affixes.add(entry);
        }

        NbtCompound root = new NbtCompound();
        if (affixes.isEmpty()) {
            List<Affix> fallbackPool = new ArrayList<>(AffixRegistry.getAll());
            fallbackPool.removeIf(a -> !affixBookTypeKey(a.id()).equals(bookType));
            if (fallbackPool.isEmpty()) return ItemStack.EMPTY;

            Affix pick = fallbackPool.get(rnd.nextInt(fallbackPool.size()));
            NbtCompound aff = new NbtCompound();
            aff.putString(AffixHelper.KEY_ID, pick.id());
            aff.putDouble(AffixHelper.KEY_VALUE, pick.min());
            aff.putInt(AffixHelper.KEY_LEVEL, 0);
            affixes.add(aff);
        }

        root.put(AffixHelper.KEY_AFFIXES, affixes);
        root.putString(BOOK_TYPE_KEY, bookType);

        AffixHelper.setRoot(book, root);
        book.set(DataComponentTypes.CUSTOM_NAME, affixBookName(bookType));
        UnidentifiedHandler.markUnidentified(book);
        return book;
    }

    private static boolean isBookTypeCompatible(String bookType, ItemStack stack) {
        return switch (bookType) {
            case "ranged" -> "ranged".equals(stackAffixTypeKey(stack));
            case "arrow" -> "arrow".equals(stackAffixTypeKey(stack));
            case "armor" -> "armor".equals(stackAffixTypeKey(stack));
            default -> "weapon".equals(stackAffixTypeKey(stack));
        };
    }

    private static boolean affixMatchesBookType(String bookType, String affixId) {
        return affixBookTypeKey(affixId).equals(bookType);
    }

private static ItemStack applyAffixBook(ItemStack weapon, ItemStack book) {
    if (weapon == null || weapon.isEmpty()) return ItemStack.EMPTY;

    NbtCompound rootBook = AffixHelper.getRoot(book);
    if (rootBook == null || !rootBook.contains(AffixHelper.KEY_AFFIXES)) return ItemStack.EMPTY;
    NbtList bookAffixes = rootBook.getList(AffixHelper.KEY_AFFIXES, 10);
    if (bookAffixes.isEmpty()) return ItemStack.EMPTY;

    String bookType = rootBook.contains(BOOK_TYPE_KEY) ? rootBook.getString(BOOK_TYPE_KEY) : "weapon";
    if (!isBookTypeCompatible(bookType, weapon)) return ItemStack.EMPTY;

    ItemStack out = weapon.copy();
    Rarity r = AffixHelper.getRarity(out);
    if (r == null) return ItemStack.EMPTY;

    // Prepare weapon affix list
    NbtList weaponAffixes = AffixHelper.getAffixes(out);

    final boolean overwriteMode = (r == Rarity.LEGENDARY || r == Rarity.MYTHIC);
    // LEGENDARY / MYTHIC: overwrite only N affixes (N = book affix count), keep the rest
    // BEYOND (超乎想像 / 無與倫比): append/merge by id
    if (overwriteMode) {
        // Ensure list has at least N slots
        for (int i = 0; i < bookAffixes.size(); i++) {
            NbtCompound e = bookAffixes.getCompound(i);
            String id = e.getString(AffixHelper.KEY_ID);
            if (!affixMatchesBookType(bookType, id)) continue;
            double v = e.getDouble(AffixHelper.KEY_VALUE);
            int lvl = e.contains(AffixHelper.KEY_LEVEL) ? e.getInt(AffixHelper.KEY_LEVEL) : 0;

            // enforce mutual exclusions at write-time (skip if conflicts)
            if ("berserk".equals(id) && AffixHelper.getAffixValue(out, "greedlife") > 0.0) continue;
            if ("greedlife".equals(id) && AffixHelper.getAffixValue(out, "berserk") > 0.0) continue;
            if ("arcblade".equals(id) && AffixHelper.getAffixValue(out, "berserk") > 0.0) continue;
            if ("berserk".equals(id) && AffixHelper.getAffixValue(out, "arcblade") > 0.0) continue;

            if ("burn".equals(id) && (AffixHelper.getAffixValue(out, "poison_aoe") > 0.0 || AffixHelper.getAffixValue(out, "wither") > 0.0)) continue;
            if ("wither".equals(id) && (AffixHelper.getAffixValue(out, "burn") > 0.0 || AffixHelper.getAffixValue(out, "poison_aoe") > 0.0)) continue;
            if ("poison_aoe".equals(id) && (AffixHelper.getAffixValue(out, "burn") > 0.0 || AffixHelper.getAffixValue(out, "wither") > 0.0)) continue;

            if ("devour".equals(id) && AffixHelper.getAffixValue(out, "lifesteal") > 0.0) continue;
            if ("lifesteal".equals(id) && AffixHelper.getAffixValue(out, "devour") > 0.0) continue;

            NbtCompound entry = new NbtCompound();
            entry.putString(AffixHelper.KEY_ID, id);
            entry.putDouble(AffixHelper.KEY_VALUE, v);
            entry.putInt(AffixHelper.KEY_LEVEL, lvl);

            if (i < weaponAffixes.size()) {
                weaponAffixes.set(i, entry);
            } else {
                weaponAffixes.add(entry);
            }
        }

        NbtCompound rootW = AffixHelper.getRoot(out);
        if (rootW == null) rootW = new NbtCompound();
        rootW.put(AffixHelper.KEY_AFFIXES, weaponAffixes);
        AffixHelper.setRoot(out, rootW);

    } else {
        // BEYOND: merge by id (append/replace)
        for (int i = 0; i < bookAffixes.size(); i++) {
            NbtCompound e = bookAffixes.getCompound(i);
            String id = e.getString(AffixHelper.KEY_ID);
            if (!affixMatchesBookType(bookType, id)) continue;
            double v = e.getDouble(AffixHelper.KEY_VALUE);
            int lvl = e.contains(AffixHelper.KEY_LEVEL) ? e.getInt(AffixHelper.KEY_LEVEL) : 0;

            // enforce mutual exclusions at write-time
            if ("berserk".equals(id) && AffixHelper.getAffixValue(out, "greedlife") > 0.0) continue;
            if ("greedlife".equals(id) && AffixHelper.getAffixValue(out, "berserk") > 0.0) continue;
            if ("arcblade".equals(id) && AffixHelper.getAffixValue(out, "berserk") > 0.0) continue;
            if ("berserk".equals(id) && AffixHelper.getAffixValue(out, "arcblade") > 0.0) continue;

            if ("burn".equals(id) && (AffixHelper.getAffixValue(out, "poison_aoe") > 0.0 || AffixHelper.getAffixValue(out, "wither") > 0.0)) continue;
            if ("wither".equals(id) && (AffixHelper.getAffixValue(out, "burn") > 0.0 || AffixHelper.getAffixValue(out, "poison_aoe") > 0.0)) continue;
            if ("poison_aoe".equals(id) && (AffixHelper.getAffixValue(out, "burn") > 0.0 || AffixHelper.getAffixValue(out, "wither") > 0.0)) continue;

            if ("devour".equals(id) && AffixHelper.getAffixValue(out, "lifesteal") > 0.0) continue;
            if ("lifesteal".equals(id) && AffixHelper.getAffixValue(out, "devour") > 0.0) continue;

            AffixHelper.putOrReplaceAffix(out, id, v, lvl);
        }
    }

    AffixHelper.applyRarityNameColor(out, r);
    UnidentifiedHandler.markUnidentified(out);
    setPreviewName(out, buildPreviewName(out, r));
    return out;
}




// ---- Inscription helper methods (銘刻之証) ----
private static ItemStack makeInscriptionProof(String type, ItemStack previewWeapon) {
    ItemStack out = new ItemStack(Items.BLAZE_ROD);
    java.util.Random rnd = new java.util.Random();
    java.util.List<String> pool = InscriptionHelper.TYPE_SECRET.equals(type)
            ? InscriptionHelper.SECRET_POOL
            : InscriptionHelper.OUTLAND_POOL;
    if (pool.isEmpty()) return ItemStack.EMPTY;
    String id = pool.get(rnd.nextInt(pool.size()));
    String target = InscriptionHelper.getTargetForId(id);
    if (id == null || id.isEmpty() || target == null) return ItemStack.EMPTY;

    if (InscriptionHelper.TYPE_OUTLAND.equals(type)) {
        if (InscriptionHelper.TARGET_RANGED.equals(target)) {
            out.set(DataComponentTypes.CUSTOM_NAME, Text.translatable("item.savaru_affixes.inscription_proof_outland_ranged").formatted(net.minecraft.util.Formatting.LIGHT_PURPLE));
        } else {
            out.set(DataComponentTypes.CUSTOM_NAME, Text.translatable("item.savaru_affixes.inscription_proof_outland_melee").formatted(net.minecraft.util.Formatting.LIGHT_PURPLE));
        }
    } else {
        if (InscriptionHelper.TARGET_RANGED.equals(target)) {
            out.set(DataComponentTypes.CUSTOM_NAME, Text.translatable("item.savaru_affixes.inscription_proof_secret_ranged").formatted(net.minecraft.util.Formatting.AQUA));
        } else {
            out.set(DataComponentTypes.CUSTOM_NAME, Text.translatable("item.savaru_affixes.inscription_proof_secret_melee").formatted(net.minecraft.util.Formatting.AQUA));
        }
    }

    // store inscription on the rod itself
    InscriptionHelper.setInscription(out, type, id);

    // 預覽階段就要是亂碼（與武器未鑑定規則一致）
    UnidentifiedHandler.markUnidentified(out);
    return out;
}

private static boolean isInscriptionProof(ItemStack stack) {
    if (stack == null || stack.isEmpty()) return false;
    if (!stack.isOf(Items.BLAZE_ROD)) return false;
    var ins = InscriptionHelper.getInscription(stack);
    return ins != null && ins.contains("type") && ins.contains("id");
}

private static String getProofType(ItemStack stack) {
    var ins = InscriptionHelper.getInscription(stack);
    return ins == null ? "" : ins.getString("type");
}

private static String getProofId(ItemStack stack) {
    var ins = InscriptionHelper.getInscription(stack);
    return ins == null ? "" : ins.getString("id");
}

private static void setPreviewName(ItemStack stack, String name) {
    PreviewHelper.setPreviewName(stack, name);
}

private static String cleanBaseName(ItemStack stack) {
    if (stack == null || stack.isEmpty()) return "";
    Text custom = stack.get(DataComponentTypes.CUSTOM_NAME);
    if (custom != null) return custom.getString();
    return stack.getItem().getName(stack).getString();
}

private static String rarityPrefix(Rarity rarity) {
    if (rarity == null) return "";
    return switch (rarity) {
        case COMMON -> "普通";
        case UNCOMMON -> "罕見";
        case RARE -> "稀有";
        case EPIC -> "史詩";
        case LEGENDARY -> "傳說";
        case MYTHIC -> "神話";
        case BEYOND -> "超乎想像";
        case UNRIVALED -> "無與倫比";
    };
}

private static String buildPreviewName(ItemStack stack, Rarity rarity) {
    String prefix = rarityPrefix(rarity);
    String base = cleanBaseName(stack);
    if (prefix.isBlank()) return base;
    return prefix + " " + base;
}

private static String buildInscriptionPreviewName(ItemStack stack, String inscriptionId) {
    String insName;
    try {
        insName = Text.translatable("inscription.savaru_affixes." + inscriptionId).getString();
    } catch (Exception e) {
        insName = inscriptionId;
    }
    if (insName == null || insName.isBlank() || insName.startsWith("inscription.savaru_affixes.")) {
        insName = inscriptionId;
    }
    return "銘刻：" + insName + " " + cleanBaseName(stack);
}


}
