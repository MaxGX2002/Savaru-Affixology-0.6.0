package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.LootWeaponTransformer;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.function.Consumer;

@Mixin(LootTable.class)
public abstract class LootTableWeaponTransformMixin {

    @SuppressWarnings("unchecked")
    @ModifyVariable(
            method = "generateUnprocessedLoot(Lnet/minecraft/loot/context/LootContext;Ljava/util/function/Consumer;)V",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private Consumer<ItemStack> savaru$wrapLootConsumer(Consumer<ItemStack> lootConsumer) {
        return stack -> lootConsumer.accept(LootWeaponTransformer.convertIfEligible(stack));
    }
}
