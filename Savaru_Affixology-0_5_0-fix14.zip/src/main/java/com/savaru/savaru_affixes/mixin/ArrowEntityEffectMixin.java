package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.arrow.ArrowAffixProcessor;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.projectile.ArrowEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * Scales vanilla tipped-arrow potion effects based on arrow-item affixes.
 */
@Mixin(ArrowEntity.class)
public abstract class ArrowEntityEffectMixin {

    /**
     * Yarn has changed the "entity hit" hook name across versions.
     * We apply the same ModifyArg against several likely names and mark them optional
     * (require = 0) so the game won't crash if a method name doesn't exist.
     */
    @ModifyArg(
            method = "onEntityHit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z"
            ),
            index = 0,
            require = 0
    )
    private StatusEffectInstance savaru$scaleArrowEffects_onEntityHit(StatusEffectInstance original) {
        return savaru$scaleArrowEffectsImpl(original);
    }

    @ModifyArg(
            method = "onHit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z"
            ),
            index = 0,
            require = 0
    )
    private StatusEffectInstance savaru$scaleArrowEffects_onHit(StatusEffectInstance original) {
        return savaru$scaleArrowEffectsImpl(original);
    }

    @ModifyArg(
            method = "onHit(Lnet/minecraft/util/hit/EntityHitResult;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z"
            ),
            index = 0,
            require = 0
    )
    private StatusEffectInstance savaru$scaleArrowEffects_onHitDesc(StatusEffectInstance original) {
        return savaru$scaleArrowEffectsImpl(original);
    }

    private StatusEffectInstance savaru$scaleArrowEffectsImpl(StatusEffectInstance original) {
        if (original == null) return null;

        net.minecraft.item.ItemStack arrowStack;
        try {
            arrowStack = ((PersistentProjectileEntityAccessor) (Object) this).savaru$asItemStack();
        } catch (Throwable t) {
            return original;
        }

        double levelMult = ArrowAffixProcessor.getEffectLevelMultiplier(arrowStack);
        double durMult = ArrowAffixProcessor.getEffectDurationMultiplier(arrowStack);
        if (levelMult == 1.0 && durMult == 1.0) return original;

        int oldAmp = original.getAmplifier();
        int newAmp = oldAmp;
        if (levelMult != 1.0) {
            // Use ceil so even small % boosts can increase level (e.g., 10% turns level 1 into 2).
            newAmp = Math.max(oldAmp, (int) Math.ceil((oldAmp + 1) * levelMult) - 1);
        }

        int oldDur = original.getDuration();
        int newDur = oldDur;
        if (durMult != 1.0) {
            newDur = (int) Math.ceil(oldDur * durMult);
        }

        return new StatusEffectInstance(
                original.getEffectType(),
                newDur,
                newAmp,
                original.isAmbient(),
                original.shouldShowParticles(),
                original.shouldShowIcon()
        );
    }
}
