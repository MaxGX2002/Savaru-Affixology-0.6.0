package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.UnidentifiedHelper;
import com.savaru.savaru_affixes.WarnMessageHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BowItem.class)
public abstract class BowItemUseMixin {

    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void savaru_affixes$blockUnidentifiedBow(World world, PlayerEntity user, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        ItemStack stack = user.getStackInHand(hand);
        if (!UnidentifiedHelper.shouldBlockUse(stack)) return;
        WarnMessageHelper.send(user, Text.literal("這把武器尚未鑑定，無法使用").formatted(Formatting.RED));
        cir.setReturnValue(ActionResult.FAIL);
    }
}
