package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.SavaruAffixesMod;
import com.savaru.savaru_affixes.api.SoulbindAccess;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntitySoulbindMixin implements SoulbindAccess {

    @Unique private static final Identifier SAVARU_SOULBIND_ZERO_ID = Identifier.of(SavaruAffixesMod.MOD_ID, "soulbind_zero");
    @Unique private long savaru$soulbindUntilTick = 0L;

    @Override
    public void savaru$setSoulbindUntil(long untilTick) {
        this.savaru$soulbindUntilTick = Math.max(this.savaru$soulbindUntilTick, untilTick);
    }

    @Override
    public long savaru$getSoulbindUntil() {
        return this.savaru$soulbindUntilTick;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void savaru$applySoulbindEveryTick(CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.getWorld().isClient) return;

        long now = self.getWorld().getTime();
        boolean active = this.savaru$soulbindUntilTick > now;

        EntityAttributeInstance inst = self.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (inst == null) return;

        if (active) {
            // 移速 = 0：1.21+ 用 ADD_MULTIPLIED_TOTAL -1 把基礎移速乘成 0
            if (inst.getModifier(SAVARU_SOULBIND_ZERO_ID) == null) {
                inst.addTemporaryModifier(new EntityAttributeModifier(
                        SAVARU_SOULBIND_ZERO_ID,
                        -1.0,
                        EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                ));
            }

            // 保險：把速度向量清 0，避免慣性滑動
            self.setVelocity(Vec3d.ZERO);
        } else {
            if (inst.getModifier(SAVARU_SOULBIND_ZERO_ID) != null) {
                inst.removeModifier(SAVARU_SOULBIND_ZERO_ID);
            }
        }
    }
}
