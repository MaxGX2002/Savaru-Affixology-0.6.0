package com.savaru.savaru_affixes.mixin;

import com.savaru.savaru_affixes.armor.ArmorAffixProcessor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(LivingEntity.class)
public abstract class LivingEntityEffectMixin {

    /**
     * Intercept addStatusEffect to apply 適性(時間/等級) reductions.
     * If duration or level would reach 0, cancel the effect entirely.
     */
    @Inject(
            method = "addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z",
            at = @At("HEAD"),
            cancellable = true,
            require = 0
    )
    private void savaru_affixes$adaptEffectReduction(
            StatusEffectInstance effect, Entity source,
            CallbackInfoReturnable<Boolean> cir) {

        if (effect == null) return;
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.getWorld().isClient()) return;

        String effectId = getEffectId(effect.getEffectType());
        if (effectId == null) return;

        List<ArmorAffixProcessor.AdaptEntry> adapts = ArmorAffixProcessor.getAllAdapts(self);
        if (adapts.isEmpty()) return;

        int duration  = effect.getDuration();
        int amplifier = effect.getAmplifier();
        boolean modified = false;

        for (ArmorAffixProcessor.AdaptEntry adapt : adapts) {
            if (adapt.effectId == null || adapt.effectId.isEmpty()) continue;
            if (!effectMatches(adapt.effectId, effectId)) continue;

            switch (adapt.affixId) {
                case ArmorAffixProcessor.ADAPT_DUR -> {
                    // duration reduction 50% or 100%
                    if (adapt.value >= 100.0) {
                        cir.setReturnValue(false);
                        cir.cancel();
                        return;
                    }
                    duration = (int)(duration * (1.0 - adapt.value / 100.0));
                    modified = true;
                }
                case ArmorAffixProcessor.ADAPT_LVL -> {
                    // level reduction 1 or 2
                    int reduce = (int) Math.round(adapt.value);
                    amplifier = amplifier - reduce;
                    modified = true;
                    if (amplifier < 0) {
                        cir.setReturnValue(false);
                        cir.cancel();
                        return;
                    }
                }
            }
        }

        if (!modified) return;
        if (duration <= 0) {
            cir.setReturnValue(false);
            cir.cancel();
            return;
        }

        // Re-apply with modified values
        StatusEffectInstance modified_effect = new StatusEffectInstance(
                effect.getEffectType(), duration, amplifier,
                effect.isAmbient(), effect.shouldShowParticles(), effect.shouldShowIcon()
        );
        self.addStatusEffect(modified_effect, source);
        cir.setReturnValue(true);
        cir.cancel();
    }

    private static String getEffectId(RegistryEntry<StatusEffect> effectType) {
        var key = effectType.getKey();
        return key.map(k -> k.getValue().toString()).orElse(null);
    }

    private static boolean effectMatches(String stored, String current) {
        if (stored.equals(current)) return true;
        // Allow both "minecraft:poison" and "poison" forms
        if (stored.contains(":")) {
            return stored.equals(current) || stored.endsWith(":" + current);
        }
        return current.endsWith(":" + stored);
    }
}
