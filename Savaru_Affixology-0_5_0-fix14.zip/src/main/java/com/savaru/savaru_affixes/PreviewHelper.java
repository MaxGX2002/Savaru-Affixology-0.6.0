package com.savaru.savaru_affixes;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

public final class PreviewHelper {
    public static final String KEY_PREVIEW_NAME = "savaru_preview_name";

    private PreviewHelper() {}

    public static boolean isPreview(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        NbtCompound root = AffixHelper.getRoot(stack);
        return root != null && (root.contains(KEY_PREVIEW_NAME) || root.getBoolean(AffixHelper.KEY_PENDING_ROLL));
    }

    public static String getPreviewName(ItemStack stack) {
        NbtCompound root = AffixHelper.getRoot(stack);
        if (root == null || !root.contains(KEY_PREVIEW_NAME)) return "";
        return root.getString(KEY_PREVIEW_NAME);
    }

    public static void setPreviewName(ItemStack stack, String name) {
        if (stack == null || stack.isEmpty() || name == null || name.isBlank()) return;
        NbtCompound root = AffixHelper.getRoot(stack);
        root.putString(KEY_PREVIEW_NAME, name);
        AffixHelper.setRoot(stack, root);
    }

    public static void clearPreviewName(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return;
        NbtCompound root = AffixHelper.getRoot(stack);
        if (root == null) return;
        root.remove(KEY_PREVIEW_NAME);
        AffixHelper.setRoot(stack, root);
    }
}
