package com.savaru.savaru_affixes;

import net.minecraft.util.math.random.Random;

import com.savaru.savaru_affixes.config.ConfigManager;
import com.savaru.savaru_affixes.config.SavaruConfig;

/**
 * Centralized rarity rolling helpers.
 *
 * This class intentionally does NOT store ad-hoc NBT flags.
 * Rarity is stored/queried via {@link AffixHelper}.
 */
public final class RarityRoller {

    private RarityRoller() {}

    /**
     * Rolls rarity for "first time" generation (e.g. /give, chest roll) using Roll chances.
     */
    public static Rarity rollFirstTime(Random random) {
        SavaruConfig cfg = ConfigManager.get();

        double c = Math.max(0.0, cfg.rollCommon);
        double u = Math.max(0.0, cfg.rollUncommon);
        double r = Math.max(0.0, cfg.rollRare);
        double e = Math.max(0.0, cfg.rollEpic);
        double l = Math.max(0.0, cfg.rollLegendary);
        double m = Math.max(0.0, cfg.rollMythic);
        double b = Math.max(0.0, cfg.rollBeyond);
        double x = Math.max(0.0, cfg.rollUnrivaled);

        double total = c + u + r + e + l + m + b + x;
        if (total <= 0.0) return Rarity.COMMON;

        double p = random.nextDouble() * total;
        if ((p -= c) < 0) return Rarity.COMMON;
        if ((p -= u) < 0) return Rarity.UNCOMMON;
        if ((p -= r) < 0) return Rarity.RARE;
        if ((p -= e) < 0) return Rarity.EPIC;
        if ((p -= l) < 0) return Rarity.LEGENDARY;
        if ((p -= m) < 0) return Rarity.MYTHIC;
        if ((p -= b) < 0) return Rarity.BEYOND;
        return Rarity.UNRIVALED;
    }

    /**
     * Returns whether a mob should drop any affixed weapon at all.
     * Uses Drop chances (absolute probabilities).
     */
    public static boolean shouldDropAnyWeapon(Random random) {
        SavaruConfig cfg = ConfigManager.get();
        double sum =
                Math.max(0.0, cfg.dropCommon) +
                Math.max(0.0, cfg.dropUncommon) +
                Math.max(0.0, cfg.dropRare) +
                Math.max(0.0, cfg.dropEpic) +
                Math.max(0.0, cfg.dropLegendary) +
                Math.max(0.0, cfg.dropMythic) +
                Math.max(0.0, cfg.dropBeyond) +
                Math.max(0.0, cfg.dropUnrivaled);

        if (sum <= 0.0) return false;
        // Clamp to 1.0 to avoid >100% total.
        if (sum > 1.0) sum = 1.0;
        return random.nextDouble() < sum;
    }

    /**
     * Rolls rarity for mob drops using Drop chances (absolute probabilities).
     * Returns null if nothing should drop.
     */
    public static Rarity rollMobDrop(Random random) {
        SavaruConfig cfg = ConfigManager.get();

        double c = Math.max(0.0, cfg.dropCommon);
        double u = Math.max(0.0, cfg.dropUncommon);
        double r = Math.max(0.0, cfg.dropRare);
        double e = Math.max(0.0, cfg.dropEpic);
        double l = Math.max(0.0, cfg.dropLegendary);
        double m = Math.max(0.0, cfg.dropMythic);
        double b = Math.max(0.0, cfg.dropBeyond);
        double x = Math.max(0.0, cfg.dropUnrivaled);

        double total = c + u + r + e + l + m + b + x;
        if (total <= 0.0) return null;
        if (total > 1.0) total = 1.0;

        double p = random.nextDouble() * total;

        // Order: highest -> lowest feels more intuitive for "absolute chance" style configs.
        // But for cumulative we need consistent ordering; here we build cumulative from high to low.
        double cum = 0.0;

        cum += x; if (p < cum) return Rarity.UNRIVALED;
        cum += b; if (p < cum) return Rarity.BEYOND;
        cum += m; if (p < cum) return Rarity.MYTHIC;
        cum += l; if (p < cum) return Rarity.LEGENDARY;
        cum += e; if (p < cum) return Rarity.EPIC;
        cum += r; if (p < cum) return Rarity.RARE;
        cum += u; if (p < cum) return Rarity.UNCOMMON;
        return Rarity.COMMON;
    }

    /**
     * Roll a rarity from explicit weights (percentages or any positive weights).
     * Order: COMMON, UNCOMMON, RARE, EPIC, LEGENDARY, MYTHIC, BEYOND, UNRIVALED.
     */
    public static Rarity rollByWeights(Random random, double[] weights) {
        if (weights == null || weights.length != 8) {
            return rollFirstTime(random);
        }
        double total = 0.0;
        for (double w : weights) total += Math.max(0.0, w);
        if (total <= 0.0) return rollFirstTime(random);

        double p = random.nextDouble() * total;
        double c = Math.max(0.0, weights[0]);
        double u = Math.max(0.0, weights[1]);
        double r = Math.max(0.0, weights[2]);
        double e = Math.max(0.0, weights[3]);
        double l = Math.max(0.0, weights[4]);
        double m = Math.max(0.0, weights[5]);
        double b = Math.max(0.0, weights[6]);
        double x = Math.max(0.0, weights[7]);

        if ((p -= c) < 0) return Rarity.COMMON;
        if ((p -= u) < 0) return Rarity.UNCOMMON;
        if ((p -= r) < 0) return Rarity.RARE;
        if ((p -= e) < 0) return Rarity.EPIC;
        if ((p -= l) < 0) return Rarity.LEGENDARY;
        if ((p -= m) < 0) return Rarity.MYTHIC;
        if ((p -= b) < 0) return Rarity.BEYOND;
        if ((p -= x) < 0) return Rarity.UNRIVALED;
        return Rarity.UNRIVALED;
    }
}
