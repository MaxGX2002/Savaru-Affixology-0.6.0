package com.savaru.savaru_affixes.client;

import com.savaru.savaru_affixes.config.ConfigManager;
import com.savaru.savaru_affixes.config.SavaruConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * ModMenu config screen (Fabric 1.21.1 compatible).
 *
 * IMPORTANT:
 * Some 1.21.1 Yarn variants do not reliably forward input events to
 * AlwaysSelectedEntryListWidget entries, causing TextFields to be "view only".
 * This screen uses a simple manual scroll layout to guarantee fields are editable.
 */
public class SavaruConfigScreen extends Screen {
    private final Screen parent;

    // Rows (label + desc + optional widget)
    private final List<Row> rows = new ArrayList<>();

    // Widgets
    private ButtonWidget includeVanillaWeapons;
    private TextFieldWidget weaponTags;
    private TextFieldWidget chestWeaponChance;
    private TextFieldWidget scanPerTick;

    private TextFieldWidget dropCommon, dropUncommon, dropRare, dropEpic, dropLegendary, dropMythic, dropBeyond, dropUnrivaled;
    private TextFieldWidget rollCommon, rollUncommon, rollRare, rollEpic, rollLegendary, rollMythic, rollBeyond, rollUnrivaled;

    private ButtonWidget saveBtn;
    private ButtonWidget cancelBtn;

    private double scrollY = 0.0;
    private Text errorMsg = null;
    private int contentHeight = 0;

    private static final int TOP = 28;
    private static final int BOTTOM_PAD = 48;
    private static final int ROW_H = 36;

    private static final DecimalFormat PCT_FMT = new DecimalFormat("0.########");

    public SavaruConfigScreen(Screen parent) {
        super(Text.translatable("screen.savaru_affixes.config.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.clearChildren();
        this.rows.clear();

        SavaruConfig c = ConfigManager.get();

        // Build widgets first (added as drawable children so Screen handles focus/typing)
        includeVanillaWeapons = ButtonWidget.builder(
                Text.translatable("screen.savaru_affixes.config.toggle",
                        Text.translatable("screen.savaru_affixes.config.include_vanilla"),
                        c.includeVanillaWeapons ? Text.translatable("screen.savaru_affixes.config.on") : Text.translatable("screen.savaru_affixes.config.off")),
                b -> {
                    boolean now = !c.includeVanillaWeapons;
                    c.includeVanillaWeapons = now;
                    b.setMessage(Text.translatable("screen.savaru_affixes.config.toggle",
                            Text.translatable("screen.savaru_affixes.config.include_vanilla"),
                            now ? Text.translatable("screen.savaru_affixes.config.on") : Text.translatable("screen.savaru_affixes.config.off")));
                }
        ).dimensions(0, 0, 180, 20).build();
        this.addDrawableChild(includeVanillaWeapons);

        weaponTags = new TextFieldWidget(this.textRenderer, 0, 0, 260, 20, Text.translatable("screen.savaru_affixes.config.weapon_tags"));
        weaponTags.setText(String.join(",", c.weaponTags));
        weaponTags.setMaxLength(4096);
        weaponTags.setEditable(true);
        this.addDrawableChild(weaponTags);

        chestWeaponChance = new TextFieldWidget(this.textRenderer, 0, 0, 110, 20, Text.translatable("screen.savaru_affixes.config.chest_weapon_chance"));
        chestWeaponChance.setText(pct(c.chestWeaponChance));
        chestWeaponChance.setMaxLength(64);
        chestWeaponChance.setEditable(true);
        this.addDrawableChild(chestWeaponChance);

        scanPerTick = new TextFieldWidget(this.textRenderer, 0, 0, 110, 20, Text.translatable("screen.savaru_affixes.config.scan_per_tick"));
        scanPerTick.setText(String.valueOf(c.scanPerTick));
        scanPerTick.setMaxLength(32);
        scanPerTick.setEditable(true);
        this.addDrawableChild(scanPerTick);

        // Drop fields
        dropCommon = numberField(pct(c.dropCommon));
        dropUncommon = numberField(pct(c.dropUncommon));
        dropRare = numberField(pct(c.dropRare));
        dropEpic = numberField(pct(c.dropEpic));
        dropLegendary = numberField(pct(c.dropLegendary));
        dropMythic = numberField(pct(c.dropMythic));
        dropBeyond = numberField(pct(c.dropBeyond));
        dropUnrivaled = numberField(pct(c.dropUnrivaled));

        // Roll fields
        rollCommon = numberField(pct(c.rollCommon));
        rollUncommon = numberField(pct(c.rollUncommon));
        rollRare = numberField(pct(c.rollRare));
        rollEpic = numberField(pct(c.rollEpic));
        rollLegendary = numberField(pct(c.rollLegendary));
        rollMythic = numberField(pct(c.rollMythic));
        rollBeyond = numberField(pct(c.rollBeyond));
        rollUnrivaled = numberField(pct(c.rollUnrivaled));

        // Build rows (labels + desc + widget)
        addSection("screen.savaru_affixes.config.section.mob_drop", "screen.savaru_affixes.config.section.mob_drop.desc");
        addNumberRow("screen.savaru_affixes.config.drop.common", "screen.savaru_affixes.config.drop.base", dropCommon);
        addNumberRow("screen.savaru_affixes.config.drop.uncommon", "screen.savaru_affixes.config.drop.base", dropUncommon);
        addNumberRow("screen.savaru_affixes.config.drop.rare", "screen.savaru_affixes.config.drop.base", dropRare);
        addNumberRow("screen.savaru_affixes.config.drop.epic", "screen.savaru_affixes.config.drop.base", dropEpic);
        addNumberRow("screen.savaru_affixes.config.drop.legendary", "screen.savaru_affixes.config.drop.base", dropLegendary);
        addNumberRow("screen.savaru_affixes.config.drop.mythic", "screen.savaru_affixes.config.drop.ultra", dropMythic);
        addNumberRow("screen.savaru_affixes.config.drop.beyond", "screen.savaru_affixes.config.drop.ultra", dropBeyond);
        addNumberRow("screen.savaru_affixes.config.drop.unrivaled", "screen.savaru_affixes.config.drop.ultra", dropUnrivaled);

        addSection("screen.savaru_affixes.config.section.roll", "screen.savaru_affixes.config.section.roll.desc");
        addNumberRow("screen.savaru_affixes.config.roll.common", "screen.savaru_affixes.config.roll.weight", rollCommon);
        addNumberRow("screen.savaru_affixes.config.roll.uncommon", "screen.savaru_affixes.config.roll.weight", rollUncommon);
        addNumberRow("screen.savaru_affixes.config.roll.rare", "screen.savaru_affixes.config.roll.weight", rollRare);
        addNumberRow("screen.savaru_affixes.config.roll.epic", "screen.savaru_affixes.config.roll.weight", rollEpic);
        addNumberRow("screen.savaru_affixes.config.roll.legendary", "screen.savaru_affixes.config.roll.weight", rollLegendary);
        addNumberRow("screen.savaru_affixes.config.roll.mythic", "screen.savaru_affixes.config.roll.ultra", rollMythic);
        addNumberRow("screen.savaru_affixes.config.roll.beyond", "screen.savaru_affixes.config.roll.ultra", rollBeyond);
        addNumberRow("screen.savaru_affixes.config.roll.unrivaled", "screen.savaru_affixes.config.roll.ultra", rollUnrivaled);

        addSection("screen.savaru_affixes.config.section.weapons", "screen.savaru_affixes.config.section.weapons.desc");
        addButtonRow("screen.savaru_affixes.config.include_vanilla", "screen.savaru_affixes.config.include_vanilla.desc", includeVanillaWeapons);
        addTextRow("screen.savaru_affixes.config.weapon_tags", "screen.savaru_affixes.config.weapon_tags.desc", weaponTags);
        addNumberRow("screen.savaru_affixes.config.chest_weapon_chance", "screen.savaru_affixes.config.chest_weapon_chance.desc", chestWeaponChance);
        addNumberRow("screen.savaru_affixes.config.scan_per_tick", "screen.savaru_affixes.config.scan_per_tick.desc", scanPerTick);

        // Bottom buttons (fixed)
        int btnW = 120;
        int y = this.height - 28;
        saveBtn = ButtonWidget.builder(Text.translatable("screen.savaru_affixes.config.save"), b -> onSave()).dimensions(this.width / 2 - btnW - 6, y, btnW, 20).build();
        cancelBtn = ButtonWidget.builder(Text.translatable("screen.savaru_affixes.config.cancel"), b -> close()).dimensions(this.width / 2 + 6, y, btnW, 20).build();
        this.addDrawableChild(saveBtn);
        this.addDrawableChild(cancelBtn);

        recalcContentHeight();
        clampScroll();
        layoutRows();
    }

    private TextFieldWidget numberField(String value) {
        TextFieldWidget tf = new TextFieldWidget(this.textRenderer, 0, 0, 110, 20, Text.empty());
        tf.setText(value);
        tf.setMaxLength(64);
        tf.setEditable(true);
        this.addDrawableChild(tf);
        return tf;
    }

    private void addSection(String titleKey, String descKey) {
        rows.add(Row.section(Text.translatable(titleKey), Text.translatable(descKey)));
    }

    private void addNumberRow(String labelKey, String descKey, TextFieldWidget field) {
        rows.add(Row.withWidget(Text.translatable(labelKey), Text.translatable(descKey), field));
    }

    private void addTextRow(String labelKey, String descKey, TextFieldWidget field) {
        rows.add(Row.withWidget(Text.translatable(labelKey), Text.translatable(descKey), field));
    }

    private void addButtonRow(String labelKey, String descKey, ButtonWidget button) {
        rows.add(Row.withWidget(Text.translatable(labelKey), Text.translatable(descKey), button));
    }

    private void recalcContentHeight() {
        contentHeight = rows.size() * ROW_H;
    }

    private int viewTop() {
        return TOP;
    }

    private int viewBottom() {
        return this.height - BOTTOM_PAD;
    }

    private int viewHeight() {
        return Math.max(32, viewBottom() - viewTop());
    }

    private void clampScroll() {
        int max = Math.max(0, contentHeight - viewHeight());
        if (scrollY < 0) scrollY = 0;
        if (scrollY > max) scrollY = max;
    }

    private void layoutRows() {
        int rowLeft = Math.max(20, (this.width - 520) / 2);
        int rowWidth = Math.min(520, this.width - 40);

        int y = viewTop() - (int) scrollY;

        for (Row r : rows) {
            r.x = rowLeft;
            r.y = y;
            r.w = rowWidth;

            if (r.widget instanceof TextFieldWidget tf) {
                tf.setX(rowLeft + rowWidth - tf.getWidth() - 10);
                tf.setY(y + 10);
            } else if (r.widget instanceof ButtonWidget btn) {
                btn.setX(rowLeft + rowWidth - btn.getWidth() - 10);
                btn.setY(y + 10);
            }

            y += ROW_H;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        layoutRows();

        // Let Screen draw children first (TextFields/Buttons). This avoids some resource-pack z-order oddities.
        super.render(context, mouseX, mouseY, delta);

        // Title on top
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFF);

        // Render labels/descriptions on top of widgets.
        // Use loose visibility bounds so text doesn't disappear when UI scale / resource packs affect viewTop/viewBottom.
        for (Row r : rows) {
            if (r == null) continue;
            if (r.y + ROW_H < -ROW_H || r.y > this.height + ROW_H) continue;

            int labelColor = r.isSection ? 0xFFFFFF : 0xFFFFFF;
            int descColor  = r.isSection ? 0xAAAAAA : 0x888888;

            context.drawTextWithShadow(this.textRenderer, r.label, r.x + 6, r.y + (r.isSection ? 6 : 4), labelColor);
            context.drawTextWithShadow(this.textRenderer, r.desc,  r.x + 6, r.y + 18, descColor);
        }

        drawScrollbar(context);

        if (this.errorMsg != null) {
            context.drawCenteredTextWithShadow(this.textRenderer, this.errorMsg, this.width / 2, this.height - 52, 0xFF5555);
        }
    }


    private void drawScrollbar(DrawContext context) {
        int top = viewTop();
        int bottom = viewBottom();
        int left = this.width - 16;
        int right = this.width - 12;

        int vh = viewHeight();
        int ch = Math.max(vh, contentHeight);
        if (ch <= vh) return;

        int barH = Math.max(20, (int) ((double) vh * (double) vh / (double) ch));
        int maxScroll = Math.max(1, contentHeight - vh);
        int barY = top + (int) ((scrollY / (double) maxScroll) * (vh - barH));

        context.fill(left, top, right, bottom, 0x33000000);
        context.fill(left, barY, right, barY + barH, 0xAAFFFFFF);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        // Scroll when inside config area
        if (mouseY >= viewTop() && mouseY <= viewBottom()) {
            scrollY -= verticalAmount * 18.0;
            clampScroll();
            layoutRows();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        layoutRows();
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        layoutRows();
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    private void onSave() {
        SavaruConfig c = ConfigManager.get();
        this.errorMsg = null;

        // Parse tags
        c.weaponTags = Arrays.stream(weaponTags.getText().split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .distinct()
                .collect(java.util.stream.Collectors.toList());

        // Validate numeric fields first (show a readable error instead of silently falling back).
        List<String> bad = new ArrayList<>();

        // Drop
        Double v;
        v = tryParsePct(dropCommon.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.drop.common").getString()); else c.dropCommon = v;
        v = tryParsePct(dropUncommon.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.drop.uncommon").getString()); else c.dropUncommon = v;
        v = tryParsePct(dropRare.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.drop.rare").getString()); else c.dropRare = v;
        v = tryParsePct(dropEpic.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.drop.epic").getString()); else c.dropEpic = v;
        v = tryParsePct(dropLegendary.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.drop.legendary").getString()); else c.dropLegendary = v;
        v = tryParsePct(dropMythic.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.drop.mythic").getString()); else c.dropMythic = v;
        v = tryParsePct(dropBeyond.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.drop.beyond").getString()); else c.dropBeyond = v;
        v = tryParsePct(dropUnrivaled.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.drop.unrivaled").getString()); else c.dropUnrivaled = v;

        // Roll
        v = tryParsePct(rollCommon.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.roll.common").getString()); else c.rollCommon = v;
        v = tryParsePct(rollUncommon.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.roll.uncommon").getString()); else c.rollUncommon = v;
        v = tryParsePct(rollRare.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.roll.rare").getString()); else c.rollRare = v;
        v = tryParsePct(rollEpic.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.roll.epic").getString()); else c.rollEpic = v;
        v = tryParsePct(rollLegendary.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.roll.legendary").getString()); else c.rollLegendary = v;
        v = tryParsePct(rollMythic.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.roll.mythic").getString()); else c.rollMythic = v;
        v = tryParsePct(rollBeyond.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.roll.beyond").getString()); else c.rollBeyond = v;
        v = tryParsePct(rollUnrivaled.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.roll.unrivaled").getString()); else c.rollUnrivaled = v;

        // Others
        v = tryParsePct(chestWeaponChance.getText()); if (v == null) bad.add(Text.translatable("screen.savaru_affixes.config.chest_weapon_chance").getString()); else c.chestWeaponChance = v;
        Integer iv = tryParseInt(scanPerTick.getText()); if (iv == null) bad.add(Text.translatable("screen.savaru_affixes.config.scan_per_tick").getString()); else c.scanPerTick = iv;

        if (!bad.isEmpty()) {
            this.errorMsg = Text.translatable("screen.savaru_affixes.config.error_numbers", String.join("、", bad));
            return;
        }

        ConfigManager.save();
        close();
    }

    private static Double tryParsePct(String s) {
        try {
            double v = Double.parseDouble(s.trim());
            return v / 100.0;
        } catch (Exception e) {
            return null;
        }
    }

    private Integer tryParseInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return null;
        }
    }

double parsePct(String s, double fallback) {
        try {
            double v = Double.parseDouble(s.trim());
            // UI uses percent: 2 = 2% => 0.02
            return v / 100.0;
        } catch (Exception e) {
            return fallback;
        }
    }

    private static int parseInt(String s, int fallback) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    private static String pct(double v) {
        return PCT_FMT.format(v * 100.0);
    }

    private static final class Row {
        final Text label;
        final Text desc;
        final boolean isSection;
        final Object widget; // TextFieldWidget or ButtonWidget, or null

        int x, y, w;

        private Row(Text label, Text desc, boolean isSection, Object widget) {
            this.label = label;
            this.desc = desc;
            this.isSection = isSection;
            this.widget = widget;
        }

        static Row section(Text label, Text desc) {
            return new Row(label, desc, true, null);
        }

        static Row withWidget(Text label, Text desc, Object widget) {
            return new Row(label, desc, false, widget);
        }
    }
}
