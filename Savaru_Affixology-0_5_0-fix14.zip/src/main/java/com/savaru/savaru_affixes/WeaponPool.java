package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.random.Random;
import java.util.Map;

public final class WeaponPool {
    private WeaponPool(){}

    public static List<Item> buildEligibleItems() {
        List<Item> out = new ArrayList<>();

        // Tags from config
        for (String tagId : ConfigManager.get().weaponTags) {
            try {
                TagKey<Item> tag = TagKey.of(net.minecraft.registry.RegistryKeys.ITEM, Identifier.of(tagId));
                for (Item item : Registries.ITEM) {
                    if (Registries.ITEM.getEntry(item).isIn(tag)) out.add(item);
                }
            } catch (Exception ignored) {}
        }

        if (ConfigManager.get().includeVanillaWeapons) {
            addIfMissing(out, Items.WOODEN_SWORD);
            addIfMissing(out, Items.STONE_SWORD);
            addIfMissing(out, Items.IRON_SWORD);
            addIfMissing(out, Items.GOLDEN_SWORD);
            addIfMissing(out, Items.DIAMOND_SWORD);
            addIfMissing(out, Items.NETHERITE_SWORD);
            addIfMissing(out, Items.WOODEN_AXE);
            addIfMissing(out, Items.STONE_AXE);
            addIfMissing(out, Items.IRON_AXE);
            addIfMissing(out, Items.GOLDEN_AXE);
            addIfMissing(out, Items.DIAMOND_AXE);
            addIfMissing(out, Items.NETHERITE_AXE);
            addIfMissing(out, Items.BOW);
            addIfMissing(out, Items.CROSSBOW);
            addIfMissing(out, Items.TRIDENT);
        }

        // Custom additions (by item id)
        for (String idStr : ConfigManager.get().customWeaponRates.keySet()) {
            try {
                Identifier id = Identifier.of(idStr);
                Item item = Registries.ITEM.get(id);
                if (item != null && item != net.minecraft.item.Items.AIR) {
                    addIfMissing(out, item);
                }
            } catch (Exception ignored) {}
        }

        return out;
    }

    private static void addIfMissing(List<Item> list, Item item) {
        if (!list.contains(item)) list.add(item);
    }

    public static ItemStack randomWeapon(Random random) {
        List<Item> items = buildEligibleItems();
        if (items.isEmpty()) return ItemStack.EMPTY;

        // Weighted pick: custom items can be tuned via customWeaponRates.
        Map<String, Double> rates = ConfigManager.get().customWeaponRates;
        double total = 0.0;
        double[] w = new double[items.size()];
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            Identifier id = Registries.ITEM.getId(it);
            double weight = 1.0;
            if (id != null) {
                Double v = rates.get(id.toString());
                if (v != null) weight = Math.max(0.0, v);
            }
            w[i] = weight;
            total += weight;
        }
        if (total <= 0.0) return ItemStack.EMPTY;

        double r = random.nextDouble() * total;
        for (int i = 0; i < items.size(); i++) {
            r -= w[i];
            if (r <= 0) return new ItemStack(items.get(i));
        }
        return new ItemStack(items.get(items.size() - 1));
    }
}
