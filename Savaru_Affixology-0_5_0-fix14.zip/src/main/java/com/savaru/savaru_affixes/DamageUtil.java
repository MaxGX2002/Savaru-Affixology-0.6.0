package com.savaru.savaru_affixes;

import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

/**
 * Helpers for creating damage sources.
 *
 * We use a custom DamageType (data-driven JSON) to emulate "RPG magic":
 * bypass armor + bypass resistance.
 */
public final class DamageUtil {
    private DamageUtil() {}

    public static final RegistryKey<DamageType> SAVARU_MAGIC = RegistryKey.of(
            RegistryKeys.DAMAGE_TYPE,
            Identifier.of("savaru_affixes", "savaru_magic")
    );

    /** Create our magic damage source if the registry key exists, otherwise fall back to vanilla magic. */
    public static DamageSource savaruMagic(World world) {
        try {
            return world.getDamageSources().create(SAVARU_MAGIC);
        } catch (Throwable ignored) {
            return world.getDamageSources().magic();
        }
    }
}
