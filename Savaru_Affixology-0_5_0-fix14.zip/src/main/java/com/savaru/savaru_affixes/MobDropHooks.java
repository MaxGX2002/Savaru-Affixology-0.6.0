
package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import com.savaru.savaru_affixes.config.MobDropRule;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.List;

public final class MobDropHooks {
    private MobDropHooks() {}

    public static void init() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity.getWorld() instanceof ServerWorld world)) return;
            if (!(entity instanceof LivingEntity living)) return;
            if (living.isPlayer()) return;

            ItemStack extra = rollConfiguredDrop(living);
            if (extra.isEmpty()) return;

            ItemEntity item = new ItemEntity(world, living.getX(), living.getY(), living.getZ(), extra);
            world.spawnEntity(item);
        });
    }

    public static ItemStack rollConfiguredDrop(LivingEntity living) {
        Random random = living.getRandom();
        String entityId = Registries.ENTITY_TYPE.getId(living.getType()).toString();

        List<MobDropRule> rules = new ArrayList<>();
        for (MobDropRule rule : ConfigManager.get().mobDropRules) {
            if (rule == null) continue;
            if (entityId.equals(rule.entityId) && rule.itemId != null && !rule.itemId.isBlank() && rule.weight > 0.0D) {
                rules.add(rule);
            }
        }
        if (rules.isEmpty()) return ItemStack.EMPTY;

        MobDropRule selected = weightedPick(rules, random);
        if (selected == null) return ItemStack.EMPTY;
        if (selected.chance <= 0.0D || random.nextDouble() > Math.min(1.0D, selected.chance)) {
            return ItemStack.EMPTY;
        }

        Identifier itemId;
        try {
            itemId = Identifier.of(selected.itemId);
        } catch (Exception ignored) {
            return ItemStack.EMPTY;
        }

        Item item = Registries.ITEM.get(itemId);
        if (item == null) return ItemStack.EMPTY;

        ItemStack stack = new ItemStack(item);
        if (stack.isEmpty()) return ItemStack.EMPTY;

        if (selected.useSavaruRoll && AffixHelper.isEligibleWeapon(stack)) {
            Rarity min = parseRarity(selected.minRarity, Rarity.COMMON);
            Rarity max = parseRarity(selected.maxRarity, Rarity.UNRIVALED);
            Rarity rarity = rollBoundedRarity(random, min, max);
            if (rarity == null) rarity = RarityRoller.rollFirstTime(random);
            AffixHelper.rollAffixes(stack, rarity);
            AffixHelper.applyRarityNameColor(stack, rarity);
            UnidentifiedHandler.markUnidentified(stack);
        } else if (selected.customName != null && !selected.customName.isBlank()) {
            stack.set(DataComponentTypes.CUSTOM_NAME, Text.literal(selected.customName));
        }

        return stack;
    }

    private static MobDropRule weightedPick(List<MobDropRule> rules, Random random) {
        double total = 0.0D;
        for (MobDropRule rule : rules) total += Math.max(0.0D, rule.weight);
        if (total <= 0.0D) return null;

        double p = random.nextDouble() * total;
        for (MobDropRule rule : rules) {
            p -= Math.max(0.0D, rule.weight);
            if (p <= 0.0D) return rule;
        }
        return rules.get(rules.size() - 1);
    }

    private static Rarity parseRarity(String s, Rarity fallback) {
        if (s == null || s.isBlank()) return fallback;
        try {
            return Rarity.valueOf(s.toUpperCase());
        } catch (Exception ignored) {
            return fallback;
        }
    }

    public static Rarity rollBoundedRarity(Random random, Rarity min, Rarity max) {
        if (min == null) min = Rarity.COMMON;
        if (max == null) max = Rarity.UNRIVALED;
        if (min.ordinal() > max.ordinal()) {
            Rarity t = min;
            min = max;
            max = t;
        }

        double[] weights = new double[] {
                Math.max(0.0, ConfigManager.get().rollCommon),
                Math.max(0.0, ConfigManager.get().rollUncommon),
                Math.max(0.0, ConfigManager.get().rollRare),
                Math.max(0.0, ConfigManager.get().rollEpic),
                Math.max(0.0, ConfigManager.get().rollLegendary),
                Math.max(0.0, ConfigManager.get().rollMythic),
                Math.max(0.0, ConfigManager.get().rollBeyond),
                Math.max(0.0, ConfigManager.get().rollUnrivaled)
        };

        for (int i = 0; i < weights.length; i++) {
            if (i < min.ordinal() || i > max.ordinal()) {
                weights[i] = 0.0D;
            }
        }
        return RarityRoller.rollByWeights(random, weights);
    }
}
