package com.savaru.savaru_affixes;

import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import com.savaru.savaru_affixes.UnidentifiedHandler;

/**
 * Keeps player attributes in sync with held weapon affixes, so attribute panels can display crit stats.
 */
public final class CritAttributeApplier {

    private static final Identifier MOD_CHANCE = Identifier.of(SavaruAffixesMod.MOD_ID, "weapon_crit_chance");
    private static final Identifier MOD_DAMAGE = Identifier.of(SavaruAffixesMod.MOD_ID, "weapon_crit_damage");
    private static final Identifier MOD_LIFESTEAL = Identifier.of(SavaruAffixesMod.MOD_ID, "weapon_lifesteal");
    private static final Identifier MOD_TRUE_DAMAGE = Identifier.of(SavaruAffixesMod.MOD_ID, "weapon_true_damage");
    private static final Identifier MOD_ATTACK_SPEED = Identifier.of(SavaruAffixesMod.MOD_ID, "weapon_attack_speed");

    private CritAttributeApplier() {}


public static void tick(PlayerEntity player) {
    if (player.getWorld().isClient()) return;

    RegistryEntry<EntityAttribute> chanceAttr = SavaruAttributes.CRIT_CHANCE_ENTRY;
    RegistryEntry<EntityAttribute> damageAttr = SavaruAttributes.CRIT_DAMAGE_ENTRY;
    RegistryEntry<EntityAttribute> lifestealAttr = SavaruAttributes.LIFESTEAL_ENTRY;
    RegistryEntry<EntityAttribute> trueDamageAttr = SavaruAttributes.TRUE_DAMAGE_ENTRY;
    if (chanceAttr == null || damageAttr == null || lifestealAttr == null || trueDamageAttr == null) return;

    // always clean slate
    remove(player, chanceAttr, MOD_CHANCE);
    remove(player, damageAttr, MOD_DAMAGE);
    remove(player, lifestealAttr, MOD_LIFESTEAL);
    remove(player, trueDamageAttr, MOD_TRUE_DAMAGE);
    removeVanilla(player, EntityAttributes.GENERIC_ATTACK_SPEED, MOD_ATTACK_SPEED);

    var stack = player.getMainHandStack();
    if (stack.isEmpty()) return;
    if (AffixHelper.getRarity(stack) == null) return;

    // do not reveal stats on unidentified items
    if (UnidentifiedHandler.isUnidentified(stack)) return;

    // Stored as percent points in NBT; convert to 0-1 range for attribute
    double cc = AffixHelper.getAffixValue(stack, "crit_chance") / 100.0;
    double cd = AffixHelper.getAffixValue(stack, "crit_damage") / 100.0;
    double ls = AffixHelper.getAffixValue(stack, "lifesteal") / 100.0;
    double td = AffixHelper.getAffixValue(stack, "true_damage") / 100.0;
    double asp = AffixHelper.getAffixValue(stack, "attack_speed") / 100.0;

    if (cc != 0.0) add(player, chanceAttr, MOD_CHANCE, cc);
    if (cd != 0.0) add(player, damageAttr, MOD_DAMAGE, cd);
    if (ls != 0.0) add(player, lifestealAttr, MOD_LIFESTEAL, ls);
    if (td != 0.0) add(player, trueDamageAttr, MOD_TRUE_DAMAGE, td);

    // vanilla attack speed is multiplicative total
    if (asp != 0.0) addVanilla(player, EntityAttributes.GENERIC_ATTACK_SPEED, MOD_ATTACK_SPEED, asp);
}
    private static void add(PlayerEntity player, RegistryEntry<EntityAttribute> attr, Identifier id, double value) {
        EntityAttributeInstance inst = player.getAttributeInstance(attr);
        if (inst == null) return;
        // persistent -> visible to client UI; we remove/re-add each tick
        inst.addPersistentModifier(new EntityAttributeModifier(id, value, EntityAttributeModifier.Operation.ADD_VALUE));
    }

    private static void remove(PlayerEntity player, RegistryEntry<EntityAttribute> attr, Identifier id) {
        EntityAttributeInstance inst = player.getAttributeInstance(attr);
        if (inst == null) return;
        if (inst.getModifier(id) != null) inst.removeModifier(id);
    }


private static void addVanilla(PlayerEntity player, RegistryEntry<EntityAttribute> attr, Identifier id, double value) {
    EntityAttributeInstance inst = player.getAttributeInstance(attr);
    if (inst == null) return;
    inst.addPersistentModifier(new EntityAttributeModifier(id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
}

private static void removeVanilla(PlayerEntity player, RegistryEntry<EntityAttribute> attr, Identifier id) {
    EntityAttributeInstance inst = player.getAttributeInstance(attr);
    if (inst == null) return;
    if (inst.getModifier(id) != null) inst.removeModifier(id);
}

}