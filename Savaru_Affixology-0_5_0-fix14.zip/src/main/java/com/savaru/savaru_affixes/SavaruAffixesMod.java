package com.savaru.savaru_affixes;

import com.savaru.savaru_affixes.config.ConfigManager;
import com.savaru.savaru_affixes.inscription.BladeSongHooks;
import com.savaru.savaru_affixes.inscription.JingtinFistHooks;
import com.savaru.savaru_affixes.inscription.StarflowHooks;
import com.savaru.savaru_affixes.inscription.SpringRainHooks;
import com.savaru.savaru_affixes.inscription.HundredBlossomsHooks;
import com.savaru.savaru_affixes.inscription.DistantThunderHooks;
import com.savaru.savaru_affixes.inscription.KagushimeiHooks;
import com.savaru.savaru_affixes.inscription.ChidoriHooks;
import com.savaru.savaru_affixes.inscription.MimicArrowHooks;
import com.savaru.savaru_affixes.inscription.DetonationHooks;
import com.savaru.savaru_affixes.inscription.ThunderfireCannonHooks;
import com.savaru.savaru_affixes.ranged.PinArrowHooks;
import com.savaru.savaru_affixes.ranged.RicochetHooks;
// Project keeps most hook/registry classes in the base package.
// Avoid importing non-existent subpackages (e.g. ".effects" / ".registry").
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Main initializer.
 *
 * Keep this class minimal: register content & init hooks only.
 * Runtime combat logic lives in dedicated hook classes / mixins.
 */
public class SavaruAffixesMod implements ModInitializer {
    public static final String MOD_ID = "savaru_affixes";

    /** Convenience: create identifiers under this mod id. */
    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }
    public static final Identifier ITEM_GROUP_KEY = Identifier.of(MOD_ID, "item_group");

    public static final ItemGroup ITEM_GROUP = FabricItemGroup.builder()
            .displayName(Text.translatable("itemGroup." + MOD_ID))
            .icon(() -> new ItemStack(Items.NETHERITE_SWORD))
            .entries((ctx, entries) -> {
                // Intentionally empty.
            })
            .build();

    @Override
    public void onInitialize() {
        // Config & utilities
        UnidentifiedHandler.init();
        ConfigManager.load();

        // Registries
        AffixRegistry.init();
        SavaruAttributes.register();

        // Loot / drop
        WeaponDropHooks.init();
        MobDropHooks.init();
        ChestLootHooks.init();
        LootContainerTransformHooks.init();

        // Effects
        ArmorStealHooks.init();
        OverhealHooks.init();
        BurnHooks.init();
        PinArrowHooks.init();
        RicochetHooks.init();

        // UI / commands
        TooltipHooks.init();
        CommandHooks.register();

        // Inscription
        BladeSongHooks.init();
        JingtinFistHooks.init();
        StarflowHooks.init();
        SpringRainHooks.init();
        HundredBlossomsHooks.init();
        DetonationHooks.init();
        ThunderfireCannonHooks.init();
        KagushimeiHooks.init();
        ChidoriHooks.init();

        // Creative tab
        Registry.register(Registries.ITEM_GROUP, ITEM_GROUP_KEY, ITEM_GROUP);
    }
}