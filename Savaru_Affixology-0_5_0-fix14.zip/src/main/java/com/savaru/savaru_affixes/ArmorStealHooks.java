package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Tracks the "armor steal" debuff on targets and removes it when expired.
 *
 * Implementation notes:
 * - We use a per-world map keyed by entityId for fast lookups.
 * - The debuff is applied as an EntityAttributeModifier on GENERIC_ARMOR.
 */
public final class ArmorStealHooks {
    private ArmorStealHooks() {}

    private record State(Identifier modifierId, double pct01, long expiresAt) {}

    private static final Map<RegistryKey<net.minecraft.world.World>, Map<Integer, State>> STATES = new HashMap<>();

    public static void init() {
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (!(world instanceof ServerWorld sw)) return;
            tickWorld(sw);
        });
    }

    private static void tickWorld(ServerWorld world) {
        Map<Integer, State> map = STATES.get(world.getRegistryKey());
        if (map == null || map.isEmpty()) return;

        long now = world.getTime();
        Iterator<Map.Entry<Integer, State>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, State> e = it.next();
            State s = e.getValue();
            if (now < s.expiresAt) continue;

            var ent = world.getEntityById(e.getKey());
            if (ent instanceof LivingEntity living) {
                var inst = living.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
                if (inst != null && inst.getModifier(s.modifierId) != null) {
                    inst.removeModifier(s.modifierId);
                }
            }
            it.remove();
        }
    }

    /**
     * Apply or refresh armor steal on a target.
     *
     * @param target living entity being hit
     * @param perHitPctPoints percent points to add per hit (e.g. 3.0 for 3%)
     * @param capPctPoints cap percent points (e.g. 10.0 for 10%)
     * @param durationTicks refresh duration (e.g. 60 ticks for 3s)
     * @param attackerKey stable key to avoid players overwriting each other
     */
    public static void apply(ServerWorld world, LivingEntity target, double perHitPctPoints, double capPctPoints, int durationTicks, String attackerKey) {
        if (perHitPctPoints <= 0.0 || capPctPoints <= 0.0) return;

        double add01 = perHitPctPoints / 100.0;
        double cap01 = capPctPoints / 100.0;

        Identifier modId = Identifier.of(SavaruAffixesMod.MOD_ID, "armor_steal_" + attackerKey);

        Map<Integer, State> map = STATES.computeIfAbsent(world.getRegistryKey(), k -> new HashMap<>());
        State prev = map.get(target.getId());
        double next01 = add01;
        if (prev != null && prev.modifierId.equals(modId)) {
            next01 = Math.min(cap01, prev.pct01 + add01);
        } else if (prev != null) {
            // another player/instance already applied; don't override it, just respect it
            next01 = prev.pct01;
        }

        var inst = target.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
        if (inst == null) return;

        if (inst.getModifier(modId) != null) inst.removeModifier(modId);

        // Multiply total by (1 - pct). Negative reduces armor.
        inst.addPersistentModifier(new EntityAttributeModifier(modId, -next01, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));

        long expiresAt = world.getTime() + durationTicks;
        map.put(target.getId(), new State(modId, next01, expiresAt));
    }
}
