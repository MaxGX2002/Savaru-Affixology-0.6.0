package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;

public final class WeaponDropHooks {
    private WeaponDropHooks(){}

    public static void init() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity.getWorld() instanceof ServerWorld world)) return;
            if (!(entity instanceof LivingEntity living)) return;
            // Only mobs (exclude players)
            if (living.isPlayer()) return;

            var random = living.getRandom();
            if (!RarityRoller.shouldDropAnyWeapon(random)) return;

            ItemStack stack = WeaponPool.randomWeapon(random);
            if (stack.isEmpty()) return;

            // Mark as unidentified. The actual quality/affixes will be rolled when the player picks it up.
            UnidentifiedHandler.markUnidentified(stack);

            ItemEntity item = new ItemEntity(world, living.getX(), living.getY(), living.getZ(), stack);
            world.spawnEntity(item);
        });
    }
}
