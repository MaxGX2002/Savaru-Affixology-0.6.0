package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.HopperScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.Slot;

public final class LootContainerTransformHooks {
    private LootContainerTransformHooks() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (PlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (player.currentScreenHandler == null) continue;
                if (!(player.currentScreenHandler instanceof GenericContainerScreenHandler
                        || player.currentScreenHandler instanceof ShulkerBoxScreenHandler
                        || player.currentScreenHandler instanceof HopperScreenHandler)) {
                    continue;
                }
                Inventory playerInv = player.getInventory();
                for (Slot slot : player.currentScreenHandler.slots) {
                    if (slot == null || slot.inventory == playerInv) continue;
                    ItemStack stack = slot.getStack();
                    if (stack == null || stack.isEmpty()) continue;
                    if (!AffixHelper.isEligibleWeapon(stack)) continue;
                    if (UnidentifiedHandler.isUnidentified(stack)) continue;
                    if (AffixHelper.getRarity(stack) != null) continue;
                    if (!AffixHelper.getAffixes(stack).isEmpty()) continue;

                    ItemStack converted = new ItemStack(stack.getItem(), stack.getCount());
                    UnidentifiedHandler.markUnidentified(converted);
                    slot.setStack(converted);
                    slot.markDirty();
                }
            }
        });
    }
}
