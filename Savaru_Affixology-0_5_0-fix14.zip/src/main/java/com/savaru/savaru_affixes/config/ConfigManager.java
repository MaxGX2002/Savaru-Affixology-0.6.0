package com.savaru.savaru_affixes.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("savaru_affixes.json");

    private static SavaruConfig CONFIG = new SavaruConfig();

    public static SavaruConfig get() { return CONFIG; }

    public static void load() {
        if (!Files.exists(PATH)) {
            save();
            return;
        }
        try {
            String s = Files.readString(PATH);
            CONFIG = GSON.fromJson(s, SavaruConfig.class);
            if (CONFIG == null) CONFIG = new SavaruConfig();
            if (CONFIG.weaponTags == null) CONFIG.weaponTags = new java.util.ArrayList<>();
            if (CONFIG.customWeaponRates == null) CONFIG.customWeaponRates = new java.util.HashMap<>();
            if (CONFIG.inscriptionWhitelist == null) CONFIG.inscriptionWhitelist = new java.util.ArrayList<>();
            if (CONFIG.mobDropRules == null) CONFIG.mobDropRules = new java.util.ArrayList<>();
        } catch (Exception e) {
            CONFIG = new SavaruConfig();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(CONFIG));
        } catch (IOException ignored) {}
    }
}
