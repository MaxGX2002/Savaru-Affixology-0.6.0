package com.savaru.savaru_affixes.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SavaruConfig {
    // Mob drop chances (absolute probabilities, not forced to sum to 1)
    // Defaults include your requested ultra-rare tiers:
    // Mythic 0.0005%  (0.000005)
    // Beyond 0.0001%  (0.000001)
    // Unrivaled 0.00005% (0.0000005)
    public double dropCommon = 0.0200;
    public double dropUncommon = 0.0060;
    public double dropRare = 0.0010;
    public double dropEpic = 0.0006;
    public double dropLegendary = 0.0001;
    public double dropMythic = 0.000005;
    public double dropBeyond = 0.000001;
    public double dropUnrivaled = 0.0000005;

    // First-roll weights (normalized by sum). Defaults include your requested top-tier roll odds:
    // Mythic 0.005% (0.00005)
    // Beyond 0.001% (0.00001)
    // Unrivaled 0.0001% (0.000001)
    public double rollCommon = 0.70;
    public double rollUncommon = 0.25;
    public double rollRare = 0.040;
    public double rollEpic = 0.009;
    public double rollLegendary = 0.000939;
    public double rollMythic = 0.00005;
    public double rollBeyond = 0.00001;
    public double rollUnrivaled = 0.000001;

    // Eligible weapon tags (any item inside these tags will be eligible)
    public List<String> weaponTags = new ArrayList<>(List.of("savaru_affixes:affixweapons"));

    // Whether to also treat vanilla swords/axes/tridents/bows as eligible even if not in tag
    public boolean includeVanillaWeapons = true;

    /**
     * Extra weapon pool additions (runtime-managed via command).
     *
     * Key: item id, e.g. "minecraft:iron_sword" or "my_mod:katana".
     * Value: weight multiplier when selecting a random weapon from the pool.
     * - 1.0 = 100% (normal)
     * - 0.5 = 50% (half as common)
     * - 0.0 = disabled
     */
    public Map<String, Double> customWeaponRates = new HashMap<>();

    // Inscription weapon whitelist (runtime-managed via /savaru whitelist). Items in this list can receive 銘刻.
    public List<String> inscriptionWhitelist = new ArrayList<>();


    // Custom per-mob extra drop rules (runtime-managed via /savaru mobdrop).
    public List<MobDropRule> mobDropRules = new ArrayList<>();

    // Chance for chests to include an extra unrolled weapon
    public double chestWeaponChance = 0.08;

    // Performance: how many stacks to scan per tick per player
    public int scanPerTick = 24;
}
