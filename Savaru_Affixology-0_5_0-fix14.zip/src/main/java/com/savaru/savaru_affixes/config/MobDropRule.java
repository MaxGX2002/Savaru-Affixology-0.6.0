
package com.savaru.savaru_affixes.config;

public class MobDropRule {
    public String entityId = "";
    public String itemId = "";
    public double weight = 1.0D;
    public double chance = 1.0D;
    public boolean useSavaruRoll = true;
    public String minRarity = "COMMON";
    public String maxRarity = "UNRIVALED";
    public String customName = "";

    public MobDropRule() {}

    public MobDropRule(String entityId, String itemId, double weight, double chance,
                       boolean useSavaruRoll, String minRarity, String maxRarity, String customName) {
        this.entityId = entityId;
        this.itemId = itemId;
        this.weight = weight;
        this.chance = chance;
        this.useSavaruRoll = useSavaruRoll;
        this.minRarity = minRarity;
        this.maxRarity = maxRarity;
        this.customName = customName == null ? "" : customName;
    }
}
