package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;

/**
 * Unidentified items keep their hidden state until they are explicitly resolved by the mod flow.
 *
 * Current behavior:
 * - Mob/loot drops stay unidentified; they are NOT auto-rolled/auto-identified when entering inventory.
 * - Anvil preview outputs still use the same flag to hide details; once the taken output already contains
 *   rolled data (rarity / affixes), the preview flag is cleared on the next server tick.
 * - Affix books also use the same preview-hiding flag and are cleared once taken.
 */
public final class UnidentifiedHandler {

    private static final String KEY_UNIDENTIFIED = "unidentified";

    private UnidentifiedHandler() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (PlayerEntity player : server.getPlayerManager().getPlayerList()) {
                for (ItemStack stack : player.getInventory().main) {
                    if (stack.isEmpty()) continue;
                    if (!isUnidentified(stack)) continue;
                    if (UnidentifiedHelper.isResolvedPreviewOutput(stack)) {
                        clearUnidentified(stack);
                    }
                }

                ItemStack offhand = player.getOffHandStack();
                if (!offhand.isEmpty() && isUnidentified(offhand) && UnidentifiedHelper.isResolvedPreviewOutput(offhand)) {
                    clearUnidentified(offhand);
                }

                for (ItemStack stack : player.getInventory().armor) {
                    if (stack.isEmpty()) continue;
                    if (!isUnidentified(stack)) continue;
                    if (UnidentifiedHelper.isResolvedPreviewOutput(stack)) {
                        clearUnidentified(stack);
                    }
                }

                if (player.currentScreenHandler != null) {
                    ItemStack cursor = player.currentScreenHandler.getCursorStack();
                    if (!cursor.isEmpty() && isUnidentified(cursor) && UnidentifiedHelper.isResolvedPreviewOutput(cursor)) {
                        clearUnidentified(cursor);
                    }
                }
            }
        });
    }

    public static boolean isUnidentified(ItemStack stack) {
        NbtCompound root = AffixHelper.getRoot(stack);
        return root != null && root.getBoolean(KEY_UNIDENTIFIED);
    }

    public static void markUnidentified(ItemStack stack) {
        NbtCompound root = AffixHelper.getRoot(stack);
        if (root == null) root = new NbtCompound();
        root.putBoolean(KEY_UNIDENTIFIED, true);
        AffixHelper.setRoot(stack, root);
    }

    public static void clearUnidentified(ItemStack stack) {
        NbtCompound root = AffixHelper.getRoot(stack);
        if (root == null) return;
        root.remove(KEY_UNIDENTIFIED);
        root.remove(PreviewHelper.KEY_PREVIEW_NAME);
        root.remove(AffixHelper.KEY_PENDING_ROLL);
        AffixHelper.setRoot(stack, root);
    }

    /**
     * Returns a scrambled placeholder string for unidentified display.
     */
    public static String scramble(String s) {
        if (s == null) return "";
        final String glyphs = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
        java.util.Random r = new java.util.Random();
        StringBuilder sb = new StringBuilder();
        int n = s.length();
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c)) { sb.append(c); continue; }
            sb.append(glyphs.charAt(r.nextInt(glyphs.length())));
        }
        return sb.toString();
    }
}
