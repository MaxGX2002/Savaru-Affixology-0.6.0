package com.savaru.savaru_affixes;

import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.TextContent;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.text.Text;
import net.minecraft.text.MutableText;
import net.minecraft.util.Formatting;
import net.minecraft.item.*;
import com.savaru.savaru_affixes.inscription.InscriptionHelper;


public final class TooltipHooks {


    private TooltipHooks() {}

    private static final String BOOK_TYPE_KEY = "book_type";

    private static String getBookType(ItemStack stack) {
        try {
            NbtCompound root = AffixHelper.getRoot(stack);
            if (root != null && root.contains(BOOK_TYPE_KEY)) return root.getString(BOOK_TYPE_KEY);
        } catch (Exception ignored) {}
        return "weapon";
    }

    private static Text getBookTitleText(ItemStack stack) {
        return switch (getBookType(stack)) {
            case "ranged" -> Text.translatable("item.savaru_affixes.affix_book_ranged");
            case "arrow" -> Text.translatable("item.savaru_affixes.affix_book_arrow");
            case "armor" -> Text.translatable("item.savaru_affixes.affix_book_armor");
            default -> Text.translatable("item.savaru_affixes.affix_book_weapon");
        };
    }

    private static Text getTypeLabel(ItemStack stack) {
        if (isAffixBook(stack)) {
            return switch (getBookType(stack)) {
                case "ranged" -> Text.translatable("savaru.affix.type.ranged");
                case "arrow" -> Text.translatable("savaru.affix.type.arrow");
                case "armor" -> Text.translatable("savaru.affix.type.armor");
                default -> Text.translatable("savaru.affix.type.weapon");
            };
        }
        if (stack.getItem() instanceof ArrowItem || stack.getItem() instanceof SpectralArrowItem || stack.getItem() instanceof TippedArrowItem) {
            return Text.translatable("savaru.affix.type.arrow");
        }
        if (stack.getItem() instanceof BowItem || stack.getItem() instanceof CrossbowItem) {
            return Text.translatable("savaru.affix.type.ranged");
        }
        if (stack.getItem() instanceof net.minecraft.item.ArmorItem) {
            return Text.translatable("savaru.affix.type.armor");
        }
        if (isWeaponLike(stack.getItem())) {
            return Text.translatable("savaru.affix.type.weapon");
        }
        return Text.empty();
    }


    /**
     * Vanilla tooltip attack damage line is item-based (attribute modifiers),
     * but our rarity bonus is applied to the player attribute (server-side).
     * Patch the tooltip line so the green number also includes the rarity bonus.
     */
    private static void applyRarityBonusToVanillaAttackLine(java.util.List<Text> lines, double rarityAtk) {
        if (rarityAtk == 0.0) return;

        for (int i = 0; i < lines.size(); i++) {
            Text t = lines.get(i);
            TextContent content = t.getContent();
            if (!(content instanceof TranslatableTextContent tr)) continue;

            String key = tr.getKey();
            if (key == null || !key.startsWith("attribute.modifier.")) continue;

            Object[] args = tr.getArgs();
            if (args == null || args.length < 2) continue;

            // arg[1] should be the attribute name
            if (!(args[1] instanceof Text attrText)) continue;
            TextContent attrContent = attrText.getContent();
            if (!(attrContent instanceof TranslatableTextContent attrTr)) continue;
            if (!"attribute.name.generic.attack_damage".equals(attrTr.getKey())) continue;

            // arg[0] is the amount (usually a Double)
            double base;
            try {
                if (args[0] instanceof Number n) base = n.doubleValue();
                else base = Double.parseDouble(String.valueOf(args[0]));
            } catch (Exception ignored) {
                continue;
            }

            double patched = base + rarityAtk;
            Text replacement = Text.translatable(key, patched, attrText).setStyle(t.getStyle());
            lines.set(i, replacement);
            return;
        }
    }

    /**
     * Patch the "遠程傷害" line from the 戰鬥 mod to include our quality bonus.
     * Matches any attribute.modifier.* line whose attribute name Text contains "遠程".
     * Fallback: also matches any numeric line whose whole string contains "遠程".
     */
    private static void applyRarityBonusToRangedLine(java.util.List<Text> lines, double rarityAtk) {
        if (rarityAtk == 0.0) return;

        for (int i = 0; i < lines.size(); i++) {
            Text t = lines.get(i);
            TextContent content = t.getContent();
            if (!(content instanceof TranslatableTextContent tr)) continue;

            String key = tr.getKey();
            if (key == null || !key.startsWith("attribute.modifier.")) continue;

            Object[] args = tr.getArgs();
            if (args == null || args.length < 2) continue;

            if (!(args[1] instanceof Text attrText)) continue;

            // Match if attribute name contains "遠程" (zh_tw) or key contains "ranged"
            String attrStr = attrText.getString();
            String attrKey = "";
            TextContent ac = attrText.getContent();
            if (ac instanceof TranslatableTextContent atc) attrKey = atc.getKey();

            boolean isRangedLine = attrStr.contains("遠程")
                    || attrKey.contains("ranged")
                    || attrKey.contains("projectile");
            if (!isRangedLine) continue;

            double base;
            try {
                if (args[0] instanceof Number n) base = n.doubleValue();
                else base = Double.parseDouble(String.valueOf(args[0]));
            } catch (Exception ignored) {
                continue;
            }

            double patched = base + rarityAtk;
            Text replacement = Text.translatable(key, patched, attrText).setStyle(t.getStyle());
            lines.set(i, replacement);
            return;
        }
    }

    
    private static Formatting colorForAffix(String path) {
        // Damage-type (yellow)
        switch (path) {
            case "crit_chance", "crit_damage", "bonus_damage", "true_damage",
                 "armor_pen_flat", "armor_pen_pct", "res_pen_flat", "res_pen_pct",
                 "max_hp_pct", "cur_hp_pct", "execute_flat", "execute_pct",
                 "attack_speed", "burn", "arcblade", "berserk", "greedlife", "wenwu",
                 "armor_warrior",
                 "armor_berserker_crit_chance", "armor_berserker_crit_dmg",
                 "armor_cs_crit_chance_pct", "armor_cs_crit_chance_flat", "armor_cs_crit_dmg":
                return Formatting.YELLOW;
        }
        // Support-type (blue)
        switch (path) {
            case "lifesteal", "devour", "durability_bonus", "durability_nocost", "overheal", "armor_steal",
                 "armor_regen_flat", "armor_regen_pct", "armor_limiter_flat", "armor_limiter_pct":
                return Formatting.AQUA;
        }
        // ★ Chest-exclusive affixes (light purple — stands out)
        switch (path) {
            case "armor_chest_thorns", "armor_chest_flame_steel",
                 "armor_chest_charged_burst", "armor_chest_shield":
                return Formatting.LIGHT_PURPLE;
        }
        // Effect-type (green) — default for all armor defensive affixes
        return Formatting.GREEN;
    }

    private static MutableText buildValueText(String valueStr, Formatting mainColor) {
        int idx = valueStr.indexOf('(');
        if (idx < 0) {
            return Text.literal(valueStr).formatted(mainColor);
        }
        String mainPart = valueStr.substring(0, idx).trim();
        String notePart = valueStr.substring(idx).trim();
        MutableText out = Text.literal(mainPart).formatted(mainColor);
        if (!notePart.isEmpty()) {
            out.append(Text.literal(" "))
               .append(Text.literal(notePart).copy().styled(style -> style.withColor(Formatting.DARK_GRAY)));
        }
        return out;
    }

    private static MutableText affixLine(String nameKey, String valueStr, Formatting mainColor) {
        return Text.translatable(
                "tooltip.savaru_affixes.affix_line",
                Text.translatable(nameKey).formatted(mainColor),
                buildValueText(valueStr, mainColor)
        );
    }


    
    private static boolean isAffixBook(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (!stack.isOf(net.minecraft.item.Items.BOOK)) return false;
        try {
            if (stack.contains(net.minecraft.component.DataComponentTypes.CUSTOM_NAME)) {
                Text t = stack.get(net.minecraft.component.DataComponentTypes.CUSTOM_NAME);
                if (t != null && (t.getString().startsWith("詞綴之書") || t.getString().equals(Text.translatable("item.savaru_affixes.affix_book_weapon").getString()) || t.getString().equals(Text.translatable("item.savaru_affixes.affix_book_ranged").getString()) || t.getString().equals(Text.translatable("item.savaru_affixes.affix_book_arrow").getString()) || t.getString().equals(Text.translatable("item.savaru_affixes.affix_book_armor").getString()))) return true;
            }
        } catch (Exception ignored) {}

        try {
            var root = AffixHelper.getRoot(stack);
            return root != null && root.contains(AffixHelper.KEY_AFFIXES);
        } catch (Exception ignored) {}

        return false;
    }

private static boolean isWeaponLike(Item item) {
        return item instanceof SwordItem
                || item instanceof AxeItem
                || item instanceof BowItem
                || item instanceof CrossbowItem
                || item instanceof TridentItem
                || item instanceof MiningToolItem;
    }

    private static boolean isInscriptionProof(ItemStack stack) {
        return stack != null && !stack.isEmpty()
                && stack.isOf(Items.BLAZE_ROD)
                && InscriptionHelper.getInscription(stack) != null;
    }

    private static Text unknownInscriptionLine() {
        return Text.literal("[未知的銘刻，刻印在武器上揭露其效果]")
                .formatted(Formatting.GRAY, Formatting.ITALIC);
    }


public static void init() {
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            // Unidentified equipment keeps its real title (e.g. 「未鑑定的 獄髓劍」),
            // but still hides rarity / affixes. Affix-book preview outputs remain fully scrambled.
            if (UnidentifiedHandler.isUnidentified(stack)) {
                if (isAffixBook(stack)) {
                    if (!lines.isEmpty()) {
                        lines.set(0, Text.literal(lines.get(0).getString())
                                .formatted(net.minecraft.util.Formatting.DARK_GRAY, net.minecraft.util.Formatting.OBFUSCATED));
                    }
                    lines.add(Text.empty());
                    lines.add(Text.literal("????????").formatted(Formatting.DARK_GRAY, Formatting.OBFUSCATED));
                    lines.add(Text.literal("????????").formatted(Formatting.DARK_GRAY, Formatting.OBFUSCATED));
                    lines.add(Text.literal("????????").formatted(Formatting.DARK_GRAY, Formatting.OBFUSCATED));
                    lines.add(Text.literal("????????").formatted(Formatting.DARK_GRAY, Formatting.OBFUSCATED));
                    return;
                }

                Text title = lines.isEmpty() ? stack.getName() : lines.get(0);
                lines.clear();
                lines.add(title);

                Text typeLabel = getTypeLabel(stack);
                if (!typeLabel.getString().isEmpty()) {
                    lines.add(typeLabel.copy().styled(style -> style.withColor(Formatting.DARK_GRAY)));
                }

                lines.add(Text.empty());
                lines.add(Text.literal("【未鑑定】").formatted(Formatting.DARK_GRAY, Formatting.BOLD, Formatting.ITALIC));
                lines.add(Text.literal("[鑑定該武器，使武器獲得完整效果]").formatted(Formatting.DARK_GRAY));

                if (InscriptionHelper.getInscription(stack) != null || isInscriptionProof(stack)) {
                    lines.add(unknownInscriptionLine());
                    return;
                }

                lines.add(Text.literal("?? 未知詞綴").formatted(Formatting.GRAY, Formatting.ITALIC));
                lines.add(Text.literal("?? 未知詞綴").formatted(Formatting.GRAY, Formatting.ITALIC));
                return;
            }

            if (isAffixBook(stack)) {
                if (!lines.isEmpty()) lines.set(0, getBookTitleText(stack));
                Text typeLabel = getTypeLabel(stack);
                if (!typeLabel.getString().isEmpty()) lines.add(1, typeLabel.copy().copy().styled(style -> style.withColor(Formatting.DARK_GRAY)));
            }

            NbtList affixes = AffixHelper.getAffixes(stack);

            // Show quality line above the affix list.
            Rarity rarity = AffixHelper.getRarity(stack);

            // Items without rarity: weapons show 未鑑定, but affix books still need to show their own affix list after identification.
            boolean isBook = isAffixBook(stack);
            if (rarity == null && !isBook) {
                if (isWeaponLike(stack.getItem())) {
                    lines.add(Text.literal("【未鑑定】").formatted(Formatting.DARK_GRAY, Formatting.BOLD, Formatting.ITALIC));
                }
                return;
            }

            // Patch vanilla attack damage tooltip so the green number matches our rarity bonus.
            // Do NOT patch for bows/crossbows here; they get patched via applyRarityBonusToRangedLine below.
            // Do NOT patch for armor; armor uses GENERIC_ARMOR which vanilla shows correctly.
            if (rarity != null) {
                boolean isRanged = (stack.getItem() instanceof BowItem) || (stack.getItem() instanceof CrossbowItem);
                boolean isArmor  = (stack.getItem() instanceof ArmorItem);
                if (!isRanged && !isArmor) {
                    double atk = rarity.attackBonus();
                    if (atk != 0.0) applyRarityBonusToVanillaAttackLine(lines, atk);
                }
                if (isRanged) {
                    double atk = rarity.attackBonus();
                    if (atk != 0.0) applyRarityBonusToRangedLine(lines, atk);
                }
            }

            lines.add(Text.empty());
            if (rarity != null) {
                String rKey = "rarity.savaru_affixes." + rarity.name().toLowerCase();
                lines.add(rarity == Rarity.UNRIVALED ? Rarity.rainbowTextDynamic(Text.translatable(rKey).getString(), System.currentTimeMillis()) : Text.translatable(rKey).setStyle(rarity.style()));

                // Rarity bonus line
                boolean isRanged = (stack.getItem() instanceof BowItem) || (stack.getItem() instanceof CrossbowItem);
                boolean isArmor  = (stack.getItem() instanceof ArmorItem);
                if (isArmor) {
                    double arm = rarity.armorBonus();
                    if (arm > 0.0) {
                        lines.add(Text.translatable("tooltip.savaru_affixes.rarity_armor",
                                String.format("+%.0f", arm)));
                    }
                } else {
                    double atk = rarity.attackBonus();
                    if (atk > 0.0) {
                        lines.add(Text.translatable(
                                isRanged ? "tooltip.savaru_affixes.rarity_ranged_damage" : "tooltip.savaru_affixes.rarity_attack",
                                String.format("+%.1f", atk)));
                    }
                }
            }


            Text typeLabel = getTypeLabel(stack);
            if (!typeLabel.getString().isEmpty()) {
                lines.add(typeLabel.copy().copy().styled(style -> style.withColor(Formatting.DARK_GRAY)));
            }

            // Do not show the "詞綴" header; keep the list itself.







            for (NbtElement el : affixes) {
                if (!(el instanceof NbtCompound tag)) continue;

                String idStr = tag.getString("id"); // e.g. "savaru_affixes:crit_damage"
                double value = tag.getDouble("value"); // stored in "percent points" for % affixes

                String path = idStr;
                String ns = "savaru_affixes";
                int colon = idStr.indexOf(':');
                if (colon >= 0) {
                    ns = idStr.substring(0, colon);
                    path = idStr.substring(colon + 1);
                }

                Formatting fmt = colorForAffix(path);

                Affix meta = null;
                for (Affix a : AffixRegistry.getAll()) {
                    if (a.id().equals(path)) { meta = a; break; }
                }

                // Special formatting for multi-param affixes
                if ("wither".equals(path) || "weakness".equals(path) || "frailty".equals(path)) {
                    int level = tag.getInt("level");
                    String chance = String.format("%.0f%%", value);
                    String key = "affix." + ns + "." + path;
                    lines.add(affixLine(key, "Lv." + level + " (" + chance + ")", fmt));
                    continue;
                }

                if ("overheal".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    // value is percent points (5)
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal(String.format("%.0f%% (額外生命+2，可疊到+10，2秒)", value))
                    ));
                    continue;
                }

                if ("durability_bonus".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal(String.format("+%.0f%% 耐久度", value))
                    ));
                    continue;
                }

                if ("durability_nocost".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal(String.format("%.0f%% 不消耗耐久", value))
                    ));
                    continue;
                }


                if ("attack_speed".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal(String.format("+%.0f%% 攻擊速度", value))
                    ));
                    continue;
                }

                if ("burn".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    int level = tag.getInt("level"); // 1-5 extra magic dmg
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal(String.format("%.0f%%", value))
                                    .append(Text.literal(String.format("（額外%d點魔法傷害，2秒）", level)).copy().styled(style -> style.withColor(Formatting.DARK_GRAY)))
                    ));
                    continue;
                }

                if ("devour".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    int level = tag.getInt("level"); // 1-5 hunger
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal(String.format("%.0f%%", value))
                                    .append(Text.literal(String.format("（回復%d飽食度）", level)).copy().styled(style -> style.withColor(Formatting.DARK_GRAY)))
                    ));
                    continue;
                }

                if ("arcblade".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal("攻擊轉為等值魔法傷害")
                    ));
                    continue;
                }

                // ---- Ranged affix short descriptions (keep it simple) ----
                if ("magic_arrow".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.translatable("affixdesc.savaru_affixes.magic_arrow").copy().styled(style -> style.withColor(Formatting.DARK_GRAY))));
                    continue;
                }
                if ("luminous_arrow".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.translatable("affixdesc.savaru_affixes.luminous_arrow").copy().styled(style -> style.withColor(Formatting.DARK_GRAY))));
                    continue;
                }
                if ("hunter_mark".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.translatable("affixdesc.savaru_affixes.hunter_mark").copy().styled(style -> style.withColor(Formatting.DARK_GRAY))));
                    continue;
                }
                if ("piercing_path".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal(String.format("%.0f%% ", value)).append(Text.translatable("affixdesc.savaru_affixes.piercing_path").copy().styled(style -> style.withColor(Formatting.DARK_GRAY)))
                    ));
                    continue;
                }
                if ("draw_speed".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal(String.format("+%.2fs ", value)).append(Text.translatable("affixdesc.savaru_affixes.draw_speed").copy().styled(style -> style.withColor(Formatting.DARK_GRAY)))
                    ));
                    continue;
                }
                if ("lifeshot".equals(path) || "finisher_shot".equals(path) || "crit_chance".equals(path) || "crit_damage".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    String pct = String.format("%.0f%% ", value);
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal(pct).append(Text.translatable("affixdesc.savaru_affixes." + path).copy().styled(style -> style.withColor(Formatting.DARK_GRAY)))
                    ));
                    continue;
                }

                if ("berserk".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable(
                            "tooltip.savaru_affixes.affix_line",
                            Text.translatable(key),
                            Text.literal("生命≤50%時造成250%傷害")
                    ));
                    continue;
                }

                if ("armor_pen_flat".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.literal("+" + String.format("%.0f", value))).formatted(fmt));
                    continue;
                }

                if ("armor_pen_pct".equals(path) || "armor_steal".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.literal(String.format("%.0f%%", value))).formatted(fmt));
                    continue;
                }

                if ("res_pen_flat".equals(path) || "res_pen_pct".equals(path)) {
                    int level = tag.getInt("level");
                    String key = "affix." + ns + "." + path;
                    String val = ("res_pen_flat".equals(path)) ? ("+" + String.format("%.0f", value)) : (String.format("%.0f%%", value));
                    lines.add(affixLine(key, "Lv." + level + " (" + val + ")", fmt));
                    continue;
                }

                if ("max_hp_pct".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.literal(String.format("%.0f%%", value))).formatted(fmt));
                    continue;
                }

                if ("cur_hp_pct".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.literal(String.format("%.0f%%", value))).formatted(fmt));
                    continue;
                }

                if ("execute_flat".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.literal(String.format("≤%.0f", value))).formatted(fmt));
                    continue;
                }

                if ("execute_pct".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.literal(String.format("≤%.0f%%", value))).formatted(fmt));
                    continue;
                }

                if ("poison_aoe".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    lines.add(affixLine(key, String.format("%.0f%% (半徑5格，中毒I 3秒，冷卻10秒)", value), fmt));
                    continue;
                }

                // ── CS爆擊 affixes: display value ÷ 100 ────────────────────
                if ("armor_cs_crit_chance_pct".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    String pct = String.format("+%.1f%%", value / 100.0);
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line",
                            Text.translatable(key).formatted(fmt),
                            Text.literal(pct + " ").formatted(fmt)
                                    .append(Text.translatable("affixdesc.savaru_affixes.armor_cs_crit_chance_pct")
                                            .copy().styled(s -> s.withColor(Formatting.DARK_GRAY)))
                    ));
                    continue;
                }
                if ("armor_cs_crit_chance_flat".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    String val = String.format("+%.0f", value);
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line",
                            Text.translatable(key).formatted(fmt),
                            Text.literal(val + " ").formatted(fmt)
                                    .append(Text.translatable("affixdesc.savaru_affixes.armor_cs_crit_chance_flat")
                                            .copy().styled(s -> s.withColor(Formatting.DARK_GRAY)))
                    ));
                    continue;
                }
                if ("armor_cs_crit_dmg".equals(path)) {
                    String key = "affix." + ns + "." + path;
                    String pct = String.format("+%.1f%%", value / 100.0);
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line",
                            Text.translatable(key).formatted(fmt),
                            Text.literal(pct + " ").formatted(fmt)
                                    .append(Text.translatable("affixdesc.savaru_affixes.armor_cs_crit_dmg")
                                            .copy().styled(s -> s.withColor(Formatting.DARK_GRAY)))
                    ));
                    continue;
                }

                // ── Armor affixes with descriptions ─────────────────────────
                if (path.startsWith("armor_")) {
                    String key = "affix." + ns + "." + path;
                    String descKey = "affixdesc.savaru_affixes." + path;
                    boolean pctAffix = meta != null && meta.percent();

                    // ★ Chest-exclusive affixes: special header + light purple
                    if (path.startsWith("armor_chest_")) {
                        lines.add(Text.literal("  ────────────").styled(s -> s.withColor(Formatting.DARK_PURPLE)));
                        lines.add(Text.literal("  ★ ").formatted(Formatting.LIGHT_PURPLE)
                                .append(Text.translatable("tooltip.savaru_affixes.chest_exclusive").formatted(Formatting.LIGHT_PURPLE)));
                        String valStr;
                        if ("armor_chest_thorns".equals(path)) {
                            valStr = String.format("%.0f%%", value);
                        } else {
                            valStr = ""; // binary affixes
                        }
                        lines.add(Text.translatable("tooltip.savaru_affixes.affix_line",
                                Text.translatable(key).formatted(Formatting.LIGHT_PURPLE),
                                Text.literal(valStr.isEmpty() ? "" : valStr + " ").formatted(Formatting.LIGHT_PURPLE)
                                        .append(Text.translatable(descKey).copy().styled(s -> s.withColor(Formatting.DARK_PURPLE)))
                        ));
                        lines.add(Text.literal("  ────────────").styled(s -> s.withColor(Formatting.DARK_PURPLE)));
                        continue;
                    }

                    // Special: adapt affixes show the target effect name
                    if ("armor_adapt_dmg".equals(path) || "armor_adapt_dur".equals(path) || "armor_adapt_lvl".equals(path)) {
                        String effectId = tag.getString(com.savaru.savaru_affixes.armor.ArmorAffixProcessor.KEY_ADAPT_EFFECT);
                        String effectName = effectId;
                        try {
                            if (effectId.contains(":")) effectName = effectId.substring(effectId.indexOf(':') + 1);
                            effectName = net.minecraft.text.Text.translatable("effect.minecraft." + effectName).getString();
                        } catch (Exception ignored) {}
                        String valStr = pctAffix ? String.format("+%.0f%%", value) : String.format("+%.0f", value);
                        lines.add(Text.translatable("tooltip.savaru_affixes.affix_line",
                                Text.translatable(key).formatted(fmt),
                                Text.literal(valStr + " ").formatted(fmt)
                                        .append(Text.literal("(" + effectName + ")").copy().styled(s -> s.withColor(Formatting.DARK_GRAY)))
                        ));
                        continue;
                    }

                    String valStr = pctAffix ? String.format("+%.2f%%", value) : String.format("+%.2f", value);
                    lines.add(Text.translatable("tooltip.savaru_affixes.affix_line",
                            Text.translatable(key).formatted(fmt),
                            Text.literal(valStr + " ").formatted(fmt)
                                    .append(Text.translatable(descKey)
                                            .copy().styled(s -> s.withColor(Formatting.DARK_GRAY)))
                    ));
                    continue;
                }

                boolean percent = meta != null && meta.percent();
                String display = percent
                        ? String.format("+%.2f%%", value)
                        : String.format("+%.2f", value);

                String key = "affix." + ns + "." + path;
                lines.add(Text.translatable("tooltip.savaru_affixes.affix_line", Text.translatable(key), Text.literal(display)).formatted(fmt));
            }

            // ---- Inscription (銘刻) block ----
            // Spec: show above ALL attribute lines; normal affixes remain below.
            NbtCompound ins = InscriptionHelper.getInscription(stack);
            if (ins != null) {
                String typeStr = ins.getString("type");
                String idStr2 = ins.getString("id");

                Formatting nameColor = InscriptionHelper.TYPE_OUTLAND.equals(typeStr) ? Formatting.LIGHT_PURPLE
                        : (InscriptionHelper.TYPE_SECRET.equals(typeStr) ? Formatting.AQUA : Formatting.WHITE);

                java.util.List<Text> block = new java.util.ArrayList<>();
                block.add(Text.empty());
                block.add(Text.literal("==========").copy().styled(style -> style.withColor(Formatting.DARK_GRAY)));
                // Content is inside the box (per spec)
                block.add(Text.literal("銘刻").formatted(nameColor, Formatting.BOLD));
                String targetStr = ins.contains("target") ? ins.getString("target") : InscriptionHelper.getTargetForId(idStr2);
                if (targetStr != null && !targetStr.isEmpty()) {
                    block.add(Text.translatable("tooltip.savaru_affixes.inscription.target." + targetStr).formatted(Formatting.DARK_GRAY));
                }
                block.add(InscriptionHelper.displayName(typeStr, idStr2).copy().formatted(nameColor));
                for (Text desc : InscriptionHelper.descriptionLines(typeStr, idStr2)) {
                    block.add(desc.copy().formatted(nameColor));
                }
                block.add(Text.literal("==========").copy().styled(style -> style.withColor(Formatting.DARK_GRAY)));

                int insertAt = Math.min(1, lines.size());
                lines.addAll(insertAt, block);
            }
        });
    }
}