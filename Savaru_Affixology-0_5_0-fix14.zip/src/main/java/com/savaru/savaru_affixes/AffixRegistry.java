package com.savaru.savaru_affixes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class AffixRegistry {
    private static final List<Affix> AFFIXES = new ArrayList<>();
    private static final Set<String> IDS = new HashSet<>();
    private static boolean initialized = false;

    private AffixRegistry() {}

    public static void init() {
        if (initialized) return;
        initialized = true;

        // Weapon affixes (final balancing is done in AffixHelper per rarity).
        register(new Affix("crit_chance", 20.0, 30.0, 90, true, true)); // Mythic: 20-30%
        register(new Affix("crit_damage", 80.0, 150.0, 80, true, true)); // Mythic: 80-150%

        // Mythic-only weapon affixes (filtered in AffixHelper by rarity).
        register(new Affix("bonus_damage", 5.0, 10.0, 60, false, true)); // Mythic-only: +5-10 flat
        register(new Affix("lifesteal", 5.0, 10.0, 55, true, true)); // Mythic-only: 5-10%
        register(new Affix("true_damage", 0.0, 5.0, 45, true, true)); // Mythic-only: 0-5%

        // New weapon effects (your spec)
        // Armor penetration (flat or %) - mutually exclusive with true_damage.
        register(new Affix("armor_pen_flat", 5.0, 10.0, 50, false, true));
        register(new Affix("armor_pen_pct", 15.0, 50.0, 45, true, true));

        // Chance-based potion effects (stored as percent points; level stored as extra int in NBT).
        // Mutually exclusive with lifesteal and with each other.
        register(new Affix("wither", 5.0, 10.0, 35, true, true));
        register(new Affix("weakness", 5.0, 10.0, 35, true, true));
        register(new Affix("frailty", 5.0, 10.0, 35, true, true)); // Slowness

        // Healing (mutually exclusive with lifesteal)
        register(new Affix("overheal", 5.0, 5.0, 30, true, true)); // 5% chance, +2 absorption (stack to 10) for 2s

        // Durability (mutually exclusive)
        register(new Affix("durability_bonus", 5.0, 15.0, 28, true, true)); // +5%~15% effective durability
        register(new Affix("durability_nocost", 5.0, 5.0, 28, true, true)); // 5% chance no durability loss on hit

        // Armor steal per-hit (stored as percent points; stacks to 10% cap on target).
        register(new Affix("armor_steal", 1.0, 5.0, 30, true, true));

        // ---- 0.3.1+ weapon affixes (health scaling / execute / poison aoe / resistance penetration) ----

        // Resistance penetration (flat or %). (Mutual exclusion enforced in AffixHelper)
        register(new Affix("res_pen_flat", 1.0, 5.0, 32, false, true));
        register(new Affix("res_pen_pct", 10.0, 30.0, 30, true, true));

        // Health-scaling damage / execute
        register(new Affix("max_hp_pct", 1.0, 1.0, 18, true, true)); // fixed 1%
        register(new Affix("cur_hp_pct", 1.0, 10.0, 18, true, true));
        register(new Affix("execute_flat", 2.0, 4.0, 14, false, true));
        register(new Affix("execute_pct", 5.0, 8.0, 14, true, true));

        
        // ---- v0.4 new weapon affixes (attack speed / burn / devour / arcblade / berserk) ----

        // Attack speed bonus (percent points)
        register(new Affix("attack_speed", 10.0, 25.0, 28, true, true));

        // Burn: chance% stored in value, extra magic damage stored in level (1-5). Mutually exclusive handled in AffixHelper.
        register(new Affix("burn", 10.0, 20.0, 18, true, true));

        // Devour: chance% stored in value, hunger restore stored in level (1-5). Mutually exclusive handled in AffixHelper.
        register(new Affix("devour", 10.0, 25.0, 16, true, true));

        // Arcblade: converts melee hit to magic damage (value unused)
        register(new Affix("arcblade", 1.0, 1.0, 10, false, true));

        // Berserk: below 50% HP deal 250% damage (value unused)
        register(new Affix("berserk", 1.0, 1.0, 10, false, true));

        // Greedlife (貪生): HP >= 80% => +150% damage, else -50% damage (value unused)
        register(new Affix("greedlife", 1.0, 1.0, 10, false, true));

        // Wenwu (文武): damage scales with enchant count; flat +0.2 attack damage per enchant level (value unused)
        register(new Affix("wenwu", 1.0, 1.0, 10, false, true));



// AoE poison proc with cooldown (chance stored as percent)
        
        // ---- v0.4.0 ranged affixes (bows/crossbows) ----
        register(new Affix("magic_arrow", 1.0, 1.0, 18, false, true));        // arrow damage becomes savaru_magic
        register(new Affix("piercing_path", 15.0, 30.0, 14, true, true));    // decay per pierced target: 15-30%
        register(new Affix("draw_speed", 0.5, 2.0, 16, true, true));         // up to 2s faster draw/load
        register(new Affix("lifeshot", 1.0, 5.0, 16, true, true));           // heal on hit
        register(new Affix("hunter_mark", 1.0, 1.0, 12, false, true));       // mark: +150% damage
        register(new Affix("luminous_arrow", 1.0, 1.0, 10, false, true));    // glowing projectile
        register(new Affix("finisher_shot", 200.0, 400.0, 12, true, true));  // +200-400% vs <50% HP

        // ---- v0.4.0 ranged (general) affixes ----
        register(new Affix("ricochet", 1.0, 1.0, 14, false, true));          // up to 5 bounces, 70% dmg per bounce
        register(new Affix("pin_arrow", 5.0, 15.0, 14, true, true));         // 5-15% proc, 1-5 true dmg per tick (scaled)
        register(new Affix("reserve", 10.0, 30.0, 14, true, true));          // 10-30% chance to not consume arrow

        // ---- v0.4.0 arrow-only affixes (arrow items) ----
        register(new Affix("arrow_damage_boost", 10.0, 30.0, 22, true, false));          // +10-30% arrow hit damage
        register(new Affix("arrow_effect_level_boost", 10.0, 30.0, 18, true, false));    // +10-30% potion effect level scaling
        register(new Affix("arrow_effect_duration_boost", 10.0, 20.0, 18, true, false)); // +10-20% potion effect duration

        register(new Affix("poison_aoe", 5.0, 5.0, 16, true, true));

        // ---- Armor affixes (v0.5) ----
        // 通用 — 保護力提升
        register(new Affix("armor_protection_flat", 1.0,  5.0,  50, false, false));
        register(new Affix("armor_protection_pct",  5.0, 25.0,  45, true,  false));
        // 通用 — 抗性提升（與保護力同時存在OK，但和適性互斥）
        register(new Affix("armor_toughness_flat",  5.0, 10.0,  45, false, false));
        register(new Affix("armor_toughness_pct",   5.0, 25.0,  40, true,  false));
        // 通用 — 鋼化：近戰傷害減少 5-30%
        register(new Affix("armor_hardened",       5.0, 30.0,  40, true,  false));
        // 通用 — 防彈：遠程傷害減少 10-20%
        register(new Affix("armor_bulletproof",   10.0, 20.0,  38, true,  false));
        // 通用 — 防火：火焰傷害減少 50/75/100%（roll 後 snap）
        register(new Affix("armor_fire_resist",   50.0,100.0,  35, true,  false));
        // 通用 — 適性三選一（互斥）
        register(new Affix("armor_adapt_dmg",     50.0,100.0,  28, true,  false));
        register(new Affix("armor_adapt_dur",     50.0,100.0,  28, true,  false));
        register(new Affix("armor_adapt_lvl",      1.0,  2.0,  28, false, false));

        // 通用 — 重裝：抗擊退 5-20%（加值 0.05-0.20）
        register(new Affix("armor_heavy",          5.0, 20.0,  42, true,  false));
        // 通用 — 戰士：攻擊傷害 +5-15%
        register(new Affix("armor_warrior",        5.0, 15.0,  38, true,  false));
        // 通用 — 狂徒：弱點命中率 或 弱點傷害 二選一（互斥）— 與武器弱點相同屬性
        register(new Affix("armor_berserker_crit_chance",  2.0,  5.0, 32, true,  false));
        register(new Affix("armor_berserker_crit_dmg",    10.0, 70.0, 32, true,  false));
        // 通用 — CS爆擊率：百分比(750-3000%) 或 固定數值(10-25)，二選一（互斥）
        register(new Affix("armor_cs_crit_chance_pct", 750.0, 3000.0, 28, true,  false));
        register(new Affix("armor_cs_crit_chance_flat", 10.0,   25.0, 28, false, false));
        // 通用 — CS爆擊傷害：百分比(500-5000%)
        register(new Affix("armor_cs_crit_dmg",        500.0, 5000.0, 28, true,  false));
        // 通用 — 聖徒：最大生命值 數值或百分比 二選一（互斥）
        register(new Affix("armor_saint_flat",     1.0,  5.0,  40, false, false));
        register(new Affix("armor_saint_pct",      5.0, 20.0,  36, true,  false));
        // 通用 — 恩賜：額外生命值（吸收值）2-10，每60秒刷新
        register(new Affix("armor_grace",          2.0, 10.0,  35, false, false));

        // ── v0.5 新增通用盔甲詞綴 ────────────────────────────────────────
        // 自然回血（數值 / 百分比，二選一）
        register(new Affix("armor_regen_flat",     1.0,  5.0,  38, false, false));  // 每5秒回復1-5 HP
        register(new Affix("armor_regen_pct",      5.0, 10.0,  36, true,  false));  // 每5秒回復5-10% max HP
        // 限制器（數值 / 百分比，二選一）
        register(new Affix("armor_limiter_flat",  10.0,100.0,  30, false, false));  // 單次傷害>閾值觸發
        register(new Affix("armor_limiter_pct",    5.0, 50.0,  28, true,  false));  // 單次傷害>%max HP觸發

        // ── v0.5 胸甲專用詞綴（互斥，僅胸甲） ─────────────────────────────
        register(new Affix("armor_chest_thorns",       20.0, 50.0, 24, true,  false));  // 反彈20-50%傷害
        register(new Affix("armor_chest_flame_steel",   1.0,  1.0, 20, false, false));  // 火焰光環（公式型）
        register(new Affix("armor_chest_charged_burst", 1.0,  1.0, 18, false, false));  // 承量爆發（公式型）
        register(new Affix("armor_chest_shield",        1.0,  1.0, 16, false, false));  // 護盾（固定數值）
    }

    private static void register(Affix a) {
        if (!IDS.add(a.id())) return; // prevent duplicates
        AFFIXES.add(a);
    }

    public static List<Affix> getAll() {
        init();
        return Collections.unmodifiableList(AFFIXES);
    }
}