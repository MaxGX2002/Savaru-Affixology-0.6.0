package com.savaru.savaru_affixes;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.math.random.Random;

public final class IdentificationHelper {
    public static final String KEY_ID_TICKET = "savaru_identification_ticket";

    private IdentificationHelper() {}

    public static ItemStack makeTicket(int count) {
        ItemStack out = new ItemStack(Items.PAPER, Math.max(1, count));
        out.set(DataComponentTypes.CUSTOM_NAME, Text.literal("鑑定券"));
        NbtCompound root = AffixHelper.getRoot(out);
        root.putBoolean(KEY_ID_TICKET, true);
        AffixHelper.setRoot(out, root);
        return out;
    }

    public static ItemStack makeTicket() {
        return makeTicket(1);
    }

    public static boolean isTicket(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(Items.PAPER)) return false;
        NbtCompound root = AffixHelper.getRoot(stack);
        return root != null && root.getBoolean(KEY_ID_TICKET);
    }

    public static boolean canIdentifyWeapon(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (!AffixHelper.isWeapon(stack) && !AffixHelper.isArrowItem(stack) && !AffixHelper.isArmorItem(stack)) return false;
        return UnidentifiedHandler.isUnidentified(stack);
    }

    public static ItemStack identify(ItemStack base) {
        if (base == null || base.isEmpty()) return ItemStack.EMPTY;
        ItemStack out = base.copy();

        if (AffixHelper.getRarity(out) == null) {
            Random rnd = Random.create();
            Rarity rarity = RarityRoller.rollFirstTime(rnd);
            if (AffixHelper.isArrowItem(out)) {
                // Arrow rarity cap is enforced by setRarity, but keep allowed tiers readable.
                if (rarity.ordinal() > Rarity.RARE.ordinal()) rarity = Rarity.RARE;
            }
            AffixHelper.setRarity(out, rarity);
            AffixHelper.rollAffixes(out, rarity);
            AffixHelper.applyRarityNameColor(out, rarity);
        } else if (!AffixHelper.getAffixes(out).isEmpty()) {
            // Existing rolled preview/final item: ensure visible rarity name styling exists.
            AffixHelper.applyRarityNameColor(out, AffixHelper.getRarity(out));
        }

        UnidentifiedHandler.clearUnidentified(out);
        PreviewHelper.clearPreviewName(out);
        return out;
    }
}
