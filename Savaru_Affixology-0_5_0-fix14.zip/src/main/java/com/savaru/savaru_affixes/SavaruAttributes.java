package com.savaru.savaru_affixes;

import net.minecraft.entity.attribute.ClampedEntityAttribute;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

/**
 * Custom attributes used by Savaru Affixes.
 *
 * crit_chance: stored as 0..1 (e.g., 0.15 = 15%)
 * crit_damage: stored as 0..1 bonus multiplier (e.g., 0.45 = +45% => 1.45x damage)
 * lifesteal: stored as 0..1 (e.g., 0.08 = 8% of damage dealt healed)
 * true_damage: stored as 0..1 (e.g., 0.03 = 3% of dealt damage applied as armor/resistance-bypassing)
 *
 * UIs such as Kev's Attributes Panel can display these once they exist on the player's default attributes.
 */
public final class SavaruAttributes {

    private SavaruAttributes() {}

    public static final Identifier CRIT_CHANCE_ID = SavaruAffixesMod.id("crit_chance");
    public static final Identifier CRIT_DAMAGE_ID = SavaruAffixesMod.id("crit_damage");
    public static final Identifier LIFESTEAL_ID = SavaruAffixesMod.id("lifesteal");
    public static final Identifier TRUE_DAMAGE_ID = SavaruAffixesMod.id("true_damage");

    public static final EntityAttribute CRIT_CHANCE = new ClampedEntityAttribute(
            "attribute.name.savaru_affixes.crit_chance",
            0.0,
            0.0,
            1.0
    );

    public static final EntityAttribute CRIT_DAMAGE = new ClampedEntityAttribute(
            "attribute.name.savaru_affixes.crit_damage",
            0.0,
            0.0,
            1.0E9
    );

    public static final EntityAttribute LIFESTEAL = new ClampedEntityAttribute(
            "attribute.name.savaru_affixes.lifesteal",
            0.0,
            0.0,
            1.0
    );

    public static final EntityAttribute TRUE_DAMAGE = new ClampedEntityAttribute(
            "attribute.name.savaru_affixes.true_damage",
            0.0,
            0.0,
            1.0
    );

    // Cached entries for DefaultAttributeContainer.Builder.add(RegistryEntry, base) in 1.21.1
    public static RegistryEntry<EntityAttribute> CRIT_CHANCE_ENTRY;
    public static RegistryEntry<EntityAttribute> CRIT_DAMAGE_ENTRY;
    public static RegistryEntry<EntityAttribute> LIFESTEAL_ENTRY;
    public static RegistryEntry<EntityAttribute> TRUE_DAMAGE_ENTRY;

    /**
     * Ensure our attributes are registered and RegistryEntry handles are cached.
     * Safe to call multiple times after bootstrap.
     */
    public static void ensureRegistered() {
        if (CRIT_CHANCE_ENTRY != null && CRIT_DAMAGE_ENTRY != null && LIFESTEAL_ENTRY != null && TRUE_DAMAGE_ENTRY != null) {
            return;
        }

        if (!Registries.ATTRIBUTE.containsId(CRIT_CHANCE_ID)) {
            Registry.register(Registries.ATTRIBUTE, CRIT_CHANCE_ID, CRIT_CHANCE);
        }
        if (!Registries.ATTRIBUTE.containsId(CRIT_DAMAGE_ID)) {
            Registry.register(Registries.ATTRIBUTE, CRIT_DAMAGE_ID, CRIT_DAMAGE);
        }
        if (!Registries.ATTRIBUTE.containsId(LIFESTEAL_ID)) {
            Registry.register(Registries.ATTRIBUTE, LIFESTEAL_ID, LIFESTEAL);
        }
        if (!Registries.ATTRIBUTE.containsId(TRUE_DAMAGE_ID)) {
            Registry.register(Registries.ATTRIBUTE, TRUE_DAMAGE_ID, TRUE_DAMAGE);
        }

        CRIT_CHANCE_ENTRY = Registries.ATTRIBUTE.getEntry(CRIT_CHANCE_ID)
                .orElseThrow(() -> new IllegalStateException("Missing attribute entry: " + CRIT_CHANCE_ID));
        CRIT_DAMAGE_ENTRY = Registries.ATTRIBUTE.getEntry(CRIT_DAMAGE_ID)
                .orElseThrow(() -> new IllegalStateException("Missing attribute entry: " + CRIT_DAMAGE_ID));

        LIFESTEAL_ENTRY = Registries.ATTRIBUTE.getEntry(LIFESTEAL_ID)
                .orElseThrow(() -> new IllegalStateException("Missing attribute entry: " + LIFESTEAL_ID));
        TRUE_DAMAGE_ENTRY = Registries.ATTRIBUTE.getEntry(TRUE_DAMAGE_ID)
                .orElseThrow(() -> new IllegalStateException("Missing attribute entry: " + TRUE_DAMAGE_ID));
    }

    /** Called from ModInitializer; delegates to {@link #ensureRegistered()}. */
    public static void register() {
        ensureRegistered();
    }
}
