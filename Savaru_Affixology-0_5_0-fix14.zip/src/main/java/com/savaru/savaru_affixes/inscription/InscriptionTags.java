package com.savaru.savaru_affixes.inscription;

import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public final class InscriptionTags {
    private InscriptionTags() {}
    public static final TagKey<Item> INSCRIPTION_ALLOWED =
            TagKey.of(RegistryKeys.ITEM, Identifier.of("savaru_affixes", "inscription_allowed"));
}
