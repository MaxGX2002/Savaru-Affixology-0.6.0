package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class DetonationHooks {
    private DetonationHooks() {}
    private static final double PROC_CHANCE = 0.15;
    private static final Map<UUID, Pending> PENDING = new ConcurrentHashMap<>();

    private static final class Pending {
        final net.minecraft.registry.RegistryKey<net.minecraft.world.World> worldKey;
        final UUID ownerId;
        final double damage;
        final long explodeAt;
        Pending(ServerWorld world, UUID ownerId, double damage, long explodeAt) {
            this.worldKey = world.getRegistryKey();
            this.ownerId = ownerId;
            this.damage = damage;
            this.explodeAt = explodeAt;
        }
    }

    public static void init() { ServerTickEvents.END_SERVER_TICK.register(DetonationHooks::tick); }

    public static void onBowHit(ServerWorld world, PersistentProjectileEntity proj, LivingEntity target, ItemStack weapon, LivingEntity owner) {
        if (world == null || proj == null || target == null || !(owner instanceof ServerPlayerEntity sp)) return;
        if (world.random.nextDouble() >= PROC_CHANCE) return;
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.LEVITATION, 3 * 20, 0, false, true, true));
        PENDING.put(target.getUuid(), new Pending(world, sp.getUuid(), Math.max(1.0, proj.getDamage()) * 5.0, world.getTime() + 3L * 20L));
    }

    private static void tick(MinecraftServer server) {
        long now = server.getOverworld().getTime();
        Iterator<Map.Entry<UUID, Pending>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Pending> e = it.next();
            Pending p = e.getValue();
            if (now < p.explodeAt) continue;
            ServerWorld world = server.getWorld(p.worldKey);
            if (world == null) { it.remove(); continue; }
            var entity = world.getEntity(e.getKey());
            if (!(entity instanceof LivingEntity target) || !target.isAlive()) { it.remove(); continue; }
            var owner = server.getPlayerManager().getPlayer(p.ownerId);
            target.damage(world.getDamageSources().explosion(owner, owner), (float)p.damage);
            if (target.isAlive()) {
                InscriptionRuntime.magicTrueDamage(target, p.damage);
            }
            world.spawnParticles(ParticleTypes.EXPLOSION, target.getX(), target.getBodyY(0.5), target.getZ(), 1, 0, 0, 0, 0.0);
            it.remove();
        }
    }
}
