package com.savaru.savaru_affixes.inscription;

import com.savaru.savaru_affixes.Rarity;
import com.savaru.savaru_affixes.config.ConfigManager;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.Random;

public final class InscriptionHelper {
    private InscriptionHelper() {}

    public static final String ROOT = "savaru_inscription";
    public static final String TYPE_OUTLAND = "outland";
    public static final String TYPE_SECRET = "secret";
    public static final String TARGET_MELEE = "melee";
    public static final String TARGET_RANGED = "ranged";

    // Pools split by weapon family
    public static final List<String> OUTLAND_POOL_MELEE = List.of(
            "blossom",
            "blackflash",
            "senlingpoison",
            "blade_song",
            "jingtin_fist",
            "heaven_inverted_spear"
    );
    public static final List<String> SECRET_POOL_MELEE = List.of(
            "truefocus",
            "soulbind",
            "bafengshen",
            "charge",
            "sunmoon_corridor",
            "starflow"
    );
    public static final List<String> OUTLAND_POOL_RANGED = List.of(
            "thunderfire_cannon",
            "kagushimei",
            "chidori"
    );
    public static final List<String> SECRET_POOL_RANGED = List.of(
            "spring_rain",
            "hundred_blossoms",
            "detonation",
            "mimic_arrow",
            "distant_thunder"
    );

    public static final List<String> OUTLAND_POOL = concat(OUTLAND_POOL_MELEE, OUTLAND_POOL_RANGED);
    public static final List<String> SECRET_POOL  = concat(SECRET_POOL_MELEE, SECRET_POOL_RANGED);

    private static List<String> concat(List<String> a, List<String> b) {
        java.util.ArrayList<String> out = new java.util.ArrayList<>(a);
        out.addAll(b);
        return java.util.List.copyOf(out);
    }

    public static boolean isRangedWeapon(ItemStack weapon) {
        if (weapon == null || weapon.isEmpty()) return false;
        return weapon.getItem() instanceof BowItem || weapon.getItem() instanceof CrossbowItem;
    }

    public static String getTargetForWeapon(ItemStack weapon) {
        return isRangedWeapon(weapon) ? TARGET_RANGED : TARGET_MELEE;
    }

    public static String getTargetForId(String id) {
        if (id == null) return null;
        if (OUTLAND_POOL_MELEE.contains(id) || SECRET_POOL_MELEE.contains(id)) return TARGET_MELEE;
        if (OUTLAND_POOL_RANGED.contains(id) || SECRET_POOL_RANGED.contains(id)) return TARGET_RANGED;
        return null;
    }

    public static boolean isIdCompatibleWithWeapon(String id, ItemStack weapon) {
        String target = getTargetForId(id);
        return target != null && target.equals(getTargetForWeapon(weapon));
    }

    public static List<String> getPoolFor(String type, ItemStack weapon) {
        String target = getTargetForWeapon(weapon);
        if (TARGET_RANGED.equals(target)) {
            return TYPE_SECRET.equals(type) ? SECRET_POOL_RANGED : OUTLAND_POOL_RANGED;
        }
        return TYPE_SECRET.equals(type) ? SECRET_POOL_MELEE : OUTLAND_POOL_MELEE;
    }

    public static boolean isAllowedWeapon(ItemStack weapon) {
        if (weapon == null || weapon.isEmpty()) return false;

        // Always allow normal recognized weapon families, including bows / crossbows.
        // Tags / whitelist remain available for custom items that are not vanilla weapon classes.
        if (com.savaru.savaru_affixes.AffixHelper.isWeapon(weapon)) return true;

        if (weapon.isIn(InscriptionTags.INSCRIPTION_ALLOWED)) return true;
        String id = Registries.ITEM.getId(weapon.getItem()).toString();
        var wl = ConfigManager.get().inscriptionWhitelist;
        return wl.isEmpty() || wl.contains(id);
    }

    public static NbtCompound getInscription(ItemStack stack) {
        NbtComponent comp = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (comp == null) return null;
        NbtCompound root = comp.getNbt();
        if (root == null || !root.contains(ROOT)) return null;
        NbtCompound ins = root.getCompound(ROOT);
        return ins.isEmpty() ? null : ins;
    }

    public static void setInscription(ItemStack stack, String type, String id) {
        NbtCompound root;
        NbtComponent comp = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (comp != null && comp.getNbt() != null) root = comp.getNbt().copy();
        else root = new NbtCompound();

        NbtCompound ins = new NbtCompound();
        ins.putString("type", type);
        ins.putString("id", id);
        String target = getTargetForId(id);
        if (target != null) ins.putString("target", target);

        root.put(ROOT, ins);
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(root));
    }

    public static boolean canApplyToWeapon(String type, Rarity rarity) {
        if (rarity == null) return false;
        if (TYPE_OUTLAND.equals(type)) return rarity.ordinal() >= Rarity.MYTHIC.ordinal();
        if (TYPE_SECRET.equals(type)) return rarity.ordinal() >= Rarity.LEGENDARY.ordinal();
        return false;
    }

    public static String rollRandom(String type, ItemStack weapon, Random rnd) {
        List<String> pool = getPoolFor(type, weapon);
        if (pool.isEmpty()) return "";
        return pool.get(rnd.nextInt(pool.size()));
    }

    public static Text header(String type) {
        if (TYPE_OUTLAND.equals(type)) return Text.translatable("tooltip.savaru_affixes.inscription.outland").formatted(Formatting.LIGHT_PURPLE);
        if (TYPE_SECRET.equals(type)) return Text.translatable("tooltip.savaru_affixes.inscription.secret").formatted(Formatting.AQUA);
        return Text.literal("✧ Inscription");
    }

    public static Text displayLine(String type, String id) {
        var name = Text.translatable("inscription.savaru_affixes." + id);
        if (TYPE_OUTLAND.equals(type)) return Text.literal("⨝ ").formatted(Formatting.LIGHT_PURPLE).append(name.formatted(Formatting.LIGHT_PURPLE));
        if (TYPE_SECRET.equals(type)) return Text.literal("⨝ ").formatted(Formatting.AQUA).append(name.formatted(Formatting.AQUA));
        return Text.literal("⨝ ").append(name);
    }


    /** Display name text for tooltip (no color applied here). */
    public static Text displayName(String type, String id) {
        if (id == null || id.isEmpty()) return Text.literal("⨝ ???");
        // Our lang keys are namespaced:
        //   inscription.savaru_affixes.<id>
        // where <id> is stored as a plain string like "blackflash" (no namespace).
        String key = "inscription.savaru_affixes." + id;
        return Text.literal("⨝ ").append(Text.translatable(key));
    }

    /** Description lines for tooltip. Each line is a separate Text starting with a dash bullet. */
    public static java.util.List<Text> descriptionLines(String type, String id) {
        java.util.ArrayList<Text> out = new java.util.ArrayList<>();
        if (id == null || id.isEmpty()) return out;

        // Support both suffix styles:
        //   inscription_desc.savaru_affixes.<id>_1, _2, ...  (legacy)
        //   inscription_desc.savaru_affixes.<id>.1, .2, ...  (current)
        String baseUnderscore = "inscription_desc.savaru_affixes." + id + "_";
        String baseDot = "inscription_desc.savaru_affixes." + id + ".";

        // Up to 6 lines; missing keys will just show the key string, so guard by comparing.
        for (int i = 1; i <= 32; i++) {
            String k1 = baseUnderscore + i;
            Text t1 = Text.translatable(k1);
            if (!t1.getString().equals(k1)) {
                out.add(t1);
                continue;
            }

            String k2 = baseDot + i;
            Text t2 = Text.translatable(k2);
            if (t2.getString().equals(k2)) break;
            out.add(t2);
        }
        return out;
    }

    public static String getTypeForId(String id) {
        if (id == null) return null;
        if (OUTLAND_POOL.contains(id)) return TYPE_OUTLAND;
        if (SECRET_POOL.contains(id)) return TYPE_SECRET;
        return null;
    }

    public static boolean canApplyToWeapon(String type, Rarity rarity, ItemStack weapon, String id) {
        if (!canApplyToWeapon(type, rarity)) return false;
        if (id == null || id.isEmpty()) return false;
        return isIdCompatibleWithWeapon(id, weapon);
    }

public static String getInscriptionTarget(ItemStack stack) {
    var ins = getInscription(stack);
    if (ins == null) return null;
    if (ins.contains("target")) return ins.getString("target");
    return getTargetForId(ins.getString("id"));
}

public static boolean hasInscriptionId(ItemStack stack, String id) {
    if (stack == null || stack.isEmpty()) return false;
    var ins = getInscription(stack);
    if (ins == null) return false;
    String got = ins.getString("id");
    return id.equals(got) || ("savaru_affixes:" + id).equals(got);
}

}
