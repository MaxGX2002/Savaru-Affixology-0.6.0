package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class HundredBlossomsHooks {
    private HundredBlossomsHooks() {}

    private static final long COOLDOWN_TICKS = 20L * 20L;
    private static final double PROC_CHANCE = 0.20;
    private static final int ARROW_COUNT = 50;
    private static final double BURST_DAMAGE_MULT = 3.0;
    private static final double SEARCH_RADIUS = 12.0;
    private static final int MAX_CHAIN_TARGETS = 24;

    private static final Map<UUID, Long> PLAYER_CD = new ConcurrentHashMap<>();
    private static final Map<UUID, SpecialArrow> SPECIAL_ARROWS = new ConcurrentHashMap<>();
    private static final Map<UUID, ChainState> CHAINS = new ConcurrentHashMap<>();

    private static final class SpecialArrow {
        final UUID chainId;
        final double damage;
        final UUID ownerId;
        SpecialArrow(UUID chainId, double damage, UUID ownerId) {
            this.chainId = chainId;
            this.damage = damage;
            this.ownerId = ownerId;
        }
    }

    private static final class ChainState {
        final UUID ownerId;
        final Set<UUID> visited = new HashSet<>();
        int burstsUsed = 0;
        long createdAt;
        ChainState(UUID ownerId, long createdAt) {
            this.ownerId = ownerId;
            this.createdAt = createdAt;
        }
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(HundredBlossomsHooks::tick);
    }

    public static boolean isManagedProjectile(PersistentProjectileEntity proj) {
        return proj != null && SPECIAL_ARROWS.containsKey(proj.getUuid());
    }

    public static boolean handleSpecialArrowHit(PersistentProjectileEntity proj, LivingEntity target) {
        SpecialArrow data = SPECIAL_ARROWS.remove(proj.getUuid());
        if (data == null || target == null) return false;
        if (data.ownerId != null && data.ownerId.equals(target.getUuid())) return true;

        ChainState chain = CHAINS.get(data.chainId);
        if (chain == null) return true;

        InscriptionRuntime.magicTrueDamage(target, data.damage);

        // avoid ping-pong between the same entities
        if (!chain.visited.add(target.getUuid())) return true;

        if (!(target.getWorld() instanceof ServerWorld world)) return true;
        spawnMark(world, target.getPos());

        if (chain.burstsUsed >= MAX_CHAIN_TARGETS) return true;
        if (!hasUnvisitedTargetsNearby(world, target, chain.visited)) return true;

        var owner = world.getServer().getPlayerManager().getPlayer(data.ownerId);
        burstFrom(world, owner, target.getPos(), data.damage, data.chainId, chain);
        return true;
    }

    public static void onBowHit(ServerWorld world, PersistentProjectileEntity projectile, LivingEntity target, ItemStack weapon, LivingEntity owner) {
        if (world == null || projectile == null || target == null || owner == null) return;
        if (!(owner instanceof ServerPlayerEntity player)) return;

        long now = world.getTime();
        long next = PLAYER_CD.getOrDefault(player.getUuid(), 0L);
        if (now < next) return;
        if (world.random.nextDouble() >= PROC_CHANCE) return;

        PLAYER_CD.put(player.getUuid(), now + COOLDOWN_TICKS);

        double baseDamage = Math.max(1.0, projectile.getDamage());
        double burstDamage = baseDamage * BURST_DAMAGE_MULT;
        UUID chainId = UUID.randomUUID();
        ChainState chain = new ChainState(player.getUuid(), now);
        chain.visited.add(target.getUuid());
        CHAINS.put(chainId, chain);

        spawnMark(world, target.getPos());
        burstFrom(world, player, target.getPos(), burstDamage, chainId, chain);
    }

    private static void burstFrom(ServerWorld world, ServerPlayerEntity owner, Vec3d center, double damage, UUID chainId, ChainState chain) {
        chain.burstsUsed++;
        for (int i = 0; i < ARROW_COUNT; i++) {
            double angle = (Math.PI * 2.0 * i) / ARROW_COUNT;
            Vec3d dir = new Vec3d(Math.cos(angle), 0.06, Math.sin(angle)).normalize();
            ArrowEntity arrow = new ArrowEntity(EntityType.ARROW, world);
            arrow.setPos(center.x, center.y + 0.6, center.z);
            if (owner != null) arrow.setOwner(owner);
            arrow.setVelocity(dir.x * 2.3, dir.y * 2.3, dir.z * 2.3);
            arrow.setDamage(0.0);
            arrow.setCritical(true);
            InscriptionArrowRuntime.register(arrow, owner, world, 5L * 20L);
            SPECIAL_ARROWS.put(arrow.getUuid(), new SpecialArrow(chainId, damage, owner != null ? owner.getUuid() : chain.ownerId));
            world.spawnEntity(arrow);
        }
    }

    private static boolean hasUnvisitedTargetsNearby(ServerWorld world, LivingEntity center, Set<UUID> visited) {
        Box box = center.getBoundingBox().expand(SEARCH_RADIUS, 6.0, SEARCH_RADIUS);
        for (LivingEntity other : world.getEntitiesByClass(LivingEntity.class, box, e -> e.isAlive() && e != center)) {
            if (!visited.contains(other.getUuid())) return true;
        }
        return false;
    }

    private static void spawnMark(ServerWorld world, Vec3d center) {
        for (int i = 0; i < 26; i++) {
            double angle = (Math.PI * 2.0 * i) / 26.0;
            double x = center.x + Math.cos(angle) * 1.8;
            double z = center.z + Math.sin(angle) * 1.8;
            world.spawnParticles(ParticleTypes.CHERRY_LEAVES, x, center.y + 0.1, z, 1, 0.01, 0.02, 0.01, 0.0);
        }
        world.spawnParticles(ParticleTypes.CHERRY_LEAVES, center.x, center.y + 0.7, center.z, 16, 0.45, 0.25, 0.45, 0.02);
    }

    private static void tick(MinecraftServer server) {
        long now = server.getOverworld().getTime();
        if (server.getTicks() % 200 != 0) return;

        PLAYER_CD.entrySet().removeIf(e -> now - e.getValue() > 20L * 120L);
        CHAINS.entrySet().removeIf(e -> now - e.getValue().createdAt > 20L * 30L || e.getValue().burstsUsed > MAX_CHAIN_TARGETS);

        Iterator<Map.Entry<UUID, SpecialArrow>> it = SPECIAL_ARROWS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, SpecialArrow> e = it.next();
            boolean exists = false;
            for (ServerWorld world : server.getWorlds()) {
                if (world.getEntity(e.getKey()) != null) {
                    exists = true;
                    break;
                }
            }
            if (!exists) it.remove();
        }
    }
}
