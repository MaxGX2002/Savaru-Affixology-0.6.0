package com.savaru.savaru_affixes.inscription;
import java.util.UUID;

import com.savaru.savaru_affixes.UnidentifiedHandler;
import com.savaru.savaru_affixes.AffixHelper;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class BladeSongHooks {

    /**
     * Server time snapshot used by other runtime helpers (cooldowns, timers).
     * Updated whenever Blade Song tick logic runs.
     */
    private static long LAST_SERVER_TIME = 0L;

    /**
     * @return last captured server time (world.getTime())
     */
    public static long getServerTime() {
        return LAST_SERVER_TIME;
    }

    // Chants
    private static final String CHANT_RAIN = "射矢如雨，放各樣銃筒，亂如風雷。";
    private static final String CHANT_DONGXUAN = "二十八日，晴，出東軒公事。";
    private static final String CHANT_DECIDE = "今日固決死，願天必殲此賊。";

    private static final class Burst {
        final UUID playerId;
        int remaining;
        long nextTick;
        Burst(UUID id, int remaining, long nextTick) { this.playerId=id; this.remaining=remaining; this.nextTick=nextTick; }
    }
    private static final List<Burst> BURSTS = new ArrayList<>();

    public static void init() {
    ServerTickEvents.END_SERVER_TICK.register(BladeSongHooks::tick);
}

    
private static final class HoldState {
    long holdStartTick = -1;
    long nextTriggerTick = -1; // after first trigger, every 120s
    boolean firstTriggered = false;
}

private static final java.util.Map<UUID, HoldState> HOLD = new java.util.HashMap<>();

private static void tick(MinecraftServer server) {
    long now = server.getOverworld().getTime();

    
        LAST_SERVER_TIME = now;
// ---- Hold-timer trigger ----
    for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
        UUID pid = player.getUuid();

        ItemStack weapon = player.getMainHandStack();
        boolean holdingBladeSong = false;

        if (!weapon.isEmpty() && !UnidentifiedHandler.isUnidentified(weapon)) {
            var ins = InscriptionHelper.getInscription(weapon);
            if (ins != null) {
                String id = ins.getString("id");
                // accept both "blade_song" and "savaru_affixes:blade_song"
                holdingBladeSong = "blade_song".equals(id) || "savaru_affixes:blade_song".equals(id);
            }
        }

        HoldState st = HOLD.computeIfAbsent(pid, k -> new HoldState());

        if (!holdingBladeSong) {
            // reset if not holding in main hand
            st.holdStartTick = -1;
            st.nextTriggerTick = -1;
            st.firstTriggered = false;
            continue;
        }

        // start hold timer if not started
        if (st.holdStartTick < 0) st.holdStartTick = now;

        // First trigger after 5 seconds (100 ticks) of continuous holding
        if (!st.firstTriggered) {
            if (now - st.holdStartTick >= 100) {
                triggerBladeSong(server, player, now);
                st.firstTriggered = true;
                st.nextTriggerTick = now + 2400; // 120 seconds
            }
            continue;
        }

        // Subsequent triggers every 120 seconds while still holding
        if (st.nextTriggerTick >= 0 && now >= st.nextTriggerTick) {
            triggerBladeSong(server, player, now);
            st.nextTriggerTick = now + 2400;
        }
    }

    // ---- Handle queued arrow bursts ----
    if (!BURSTS.isEmpty()) {
        for (Iterator<Burst> it = BURSTS.iterator(); it.hasNext();) {
            Burst b = it.next();
            if (now < b.nextTick) continue;

            ServerPlayerEntity player = server.getPlayerManager().getPlayer(b.playerId);
            if (player == null) { it.remove(); continue; }

            ItemStack weapon = player.getMainHandStack();
            if (weapon.isEmpty() || UnidentifiedHandler.isUnidentified(weapon)) { it.remove(); continue; }
            var ins = InscriptionHelper.getInscription(weapon);
            if (ins == null) { it.remove(); continue; }
            String id = ins.getString("id");
            if (!"blade_song".equals(id) && !"savaru_affixes:blade_song".equals(id)) { it.remove(); continue; }

            doArrowBurst(player);
            b.remaining--;
            b.nextTick = now + 10; // 0.5s
            if (b.remaining <= 0) it.remove();
        }
    }
}

private static void triggerBladeSong(MinecraftServer server, ServerPlayerEntity player, long now) {
    int pick = player.getRandom().nextInt(3);
    if (pick == 0) {
        server.getPlayerManager().broadcast(Text.literal(CHANT_RAIN), false);
        BURSTS.add(new Burst(player.getUuid(), 3, now));
            InscriptionRuntime.setBladeSongRainActive(player.getUuid(), now + 60);
    } else if (pick == 1) {
        server.getPlayerManager().broadcast(Text.literal(CHANT_DONGXUAN), false);
        InscriptionRuntime.setBladeSongZero(player.getUuid(), now, 5 * 20);
    } else {
        server.getPlayerManager().broadcast(Text.literal(CHANT_DECIDE), false);
        InscriptionRuntime.setBladeSongNextMultiplier(player.getUuid(), now, 5.0, 20 * 20);
        InscriptionRuntime.applyBladeSongChant3Buff(player, 20);
    }
}


    private static void doArrowBurst(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0F);

        int count = 10 + world.random.nextInt(21); // 10-30
        double baseYaw = player.getYaw();
        double spread = 60.0;

        for (int i = 0; i < count; i++) {
            double yawOff = (world.random.nextDouble() - 0.5) * spread;
            double pitchOff = (world.random.nextDouble() - 0.5) * 8.0;

            ArrowEntity arrow = new ArrowEntity(EntityType.ARROW, world);
            arrow.setOwner(player);
            arrow.setPos(eye.x, eye.y - 0.1, eye.z);

            // Approximate direction by rotating yaw a bit
            float yaw = (float) (baseYaw + yawOff);
            float pitch = (float) (player.getPitch() + pitchOff);
            arrow.setVelocity(player, pitch, yaw, 0.0F, 2.7F, 1.0F);

            // "亂如風雷": lightning on hit.
            arrow.addCommandTag("savaru_bladesong_lightning");

            world.spawnEntity(arrow);
        }
    }
}