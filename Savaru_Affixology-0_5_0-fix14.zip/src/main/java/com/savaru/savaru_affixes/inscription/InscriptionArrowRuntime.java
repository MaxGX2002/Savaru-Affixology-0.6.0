package com.savaru.savaru_affixes.inscription;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class InscriptionArrowRuntime {
    private InscriptionArrowRuntime() {}

    private static final class Meta {
        final UUID ownerId;
        final long bornTick;
        final long ttlTicks;
        Meta(UUID ownerId, long bornTick, long ttlTicks) {
            this.ownerId = ownerId;
            this.bornTick = bornTick;
            this.ttlTicks = ttlTicks;
        }
    }

    private static final Map<UUID, Meta> ARROWS = new ConcurrentHashMap<>();

    public static void register(PersistentProjectileEntity proj, LivingEntity owner, ServerWorld world, long ttlTicks) {
        if (proj == null || world == null) return;
        ARROWS.put(proj.getUuid(), new Meta(owner != null ? owner.getUuid() : null, world.getTime(), ttlTicks));
    }

    public static boolean isManaged(PersistentProjectileEntity proj) {
        return proj != null && ARROWS.containsKey(proj.getUuid());
    }

    public static boolean isOwnerHit(PersistentProjectileEntity proj, LivingEntity target) {
        if (proj == null || target == null) return false;
        Meta m = ARROWS.get(proj.getUuid());
        return m != null && m.ownerId != null && m.ownerId.equals(target.getUuid());
    }

    public static boolean shouldBlockPickup(PersistentProjectileEntity proj, PlayerEntity player) {
        return proj != null && player != null && ARROWS.containsKey(proj.getUuid());
    }

    public static boolean shouldExpire(PersistentProjectileEntity proj) {
        if (proj == null || !(proj.getWorld() instanceof ServerWorld sw)) return false;
        Meta m = ARROWS.get(proj.getUuid());
        return m != null && sw.getTime() - m.bornTick >= m.ttlTicks;
    }

    public static void forget(PersistentProjectileEntity proj) {
        if (proj != null) ARROWS.remove(proj.getUuid());
    }

    public static void cleanup(ServerWorld world) {
        if (world == null) return;
        Iterator<Map.Entry<UUID, Meta>> it = ARROWS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Meta> e = it.next();
            if (world.getEntity(e.getKey()) == null) it.remove();
        }
    }
}
