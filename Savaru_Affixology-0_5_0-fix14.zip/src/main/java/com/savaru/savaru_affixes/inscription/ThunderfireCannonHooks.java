package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ThunderfireCannonHooks {
    private ThunderfireCannonHooks() {}

    private static final long TARGET_COOLDOWN_TICKS = 60L * 20L;
    private static final long STRIKE_DELAY_TICKS = 3L * 20L;
    private static final long LIGHTNING_DELAY_TICKS = 1L * 20L;
    private static final double EXTRA_PHYSICAL_MULT = 2.0;
    private static final double FIXED_MAGIC_DAMAGE = 250.0;
    private static final float INITIAL_EXPLOSION_DAMAGE = 100.0f;
    private static final float SKYFALL_EXPLOSION_DAMAGE = 1000.0f;
    private static final double SKYFALL_RADIUS = 3.5;

    private static final Map<UUID, Integer> TARGET_HITS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> TARGET_COOLDOWNS = new ConcurrentHashMap<>();
    private static final Map<UUID, PendingStrike> PENDING = new ConcurrentHashMap<>();

    private static final class PendingStrike {
        final net.minecraft.registry.RegistryKey<net.minecraft.world.World> worldKey;
        final UUID ownerId;
        final UUID targetId;
        final Vec3d fallbackPos;
        final long skyfallAt;
        long lightningAt;
        boolean arrowDropped;

        PendingStrike(ServerWorld world, UUID ownerId, UUID targetId, Vec3d fallbackPos, long skyfallAt) {
            this.worldKey = world.getRegistryKey();
            this.ownerId = ownerId;
            this.targetId = targetId;
            this.fallbackPos = fallbackPos;
            this.skyfallAt = skyfallAt;
        }
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(ThunderfireCannonHooks::tick);
    }

    public static void onBowHit(ServerWorld world, PersistentProjectileEntity proj, LivingEntity target, ItemStack weapon, LivingEntity owner) {
        if (world == null || proj == null || target == null || !(owner instanceof ServerPlayerEntity player)) return;

        long now = world.getTime();
        UUID targetId = target.getUuid();
        long cdUntil = TARGET_COOLDOWNS.getOrDefault(targetId, 0L);
        if (now < cdUntil) return;

        int hits = TARGET_HITS.getOrDefault(targetId, 0) + 1;
        if (hits < 3) {
            TARGET_HITS.put(targetId, hits);
            return;
        }

        TARGET_HITS.remove(targetId);
        TARGET_COOLDOWNS.put(targetId, now + TARGET_COOLDOWN_TICKS);

        float baseDamage = (float) Math.max(1.0, proj.getDamage());
        float extraPhysical = (float) (baseDamage * EXTRA_PHYSICAL_MULT);
        target.damage(world.getDamageSources().arrow(proj, player), extraPhysical);
        InscriptionRuntime.magicTrueDamage(target, FIXED_MAGIC_DAMAGE);
        boolean exploded = target.damage(world.getDamageSources().explosion(player, player), INITIAL_EXPLOSION_DAMAGE);
        if (!exploded && target.isAlive()) {
            InscriptionRuntime.magicTrueDamage(target, INITIAL_EXPLOSION_DAMAGE);
        }

        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, target.getX(), target.getBodyY(0.5), target.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getBodyY(0.7), target.getZ(), 18, 0.35, 0.45, 0.35, 0.08);
        world.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.PLAYERS, 0.9f, 0.9f);

        PENDING.put(targetId, new PendingStrike(world, player.getUuid(), targetId, target.getPos(), now + STRIKE_DELAY_TICKS));
    }

    private static void tick(MinecraftServer server) {
        long now = server.getOverworld().getTime();
        Iterator<Map.Entry<UUID, PendingStrike>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, PendingStrike> entry = it.next();
            PendingStrike pending = entry.getValue();
            ServerWorld world = server.getWorld(pending.worldKey);
            if (world == null) {
                it.remove();
                continue;
            }

            LivingEntity target = null;
            var entity = world.getEntity(pending.targetId);
            if (entity instanceof LivingEntity living && living.isAlive()) {
                target = living;
            }

            Vec3d center = target != null ? target.getPos() : pending.fallbackPos;
            var owner = server.getPlayerManager().getPlayer(pending.ownerId);

            if (!pending.arrowDropped && now >= pending.skyfallAt) {
                pending.arrowDropped = true;
                pending.lightningAt = now + LIGHTNING_DELAY_TICKS;
                spawnSkyfallArrow(world, owner, center);
                explodeSkyfall(world, owner, center);
            }

            if (pending.arrowDropped && now >= pending.lightningAt) {
                spawnLightning(world, center);
                it.remove();
            }
        }

        if (server.getTicks() % 1200 == 0) {
            TARGET_HITS.entrySet().removeIf(e -> !TARGET_COOLDOWNS.containsKey(e.getKey()));
            TARGET_COOLDOWNS.entrySet().removeIf(e -> now > e.getValue() + 20L * 120L);
        }
    }

    private static void spawnSkyfallArrow(ServerWorld world, ServerPlayerEntity owner, Vec3d center) {
        ArrowEntity arrow = new ArrowEntity(EntityType.ARROW, world);
        arrow.setPos(center.x, center.y + 16.0, center.z);
        arrow.setVelocity(0.0, -4.0, 0.0);
        arrow.setDamage(0.0);
        arrow.setCritical(true);
        if (owner != null) arrow.setOwner(owner);
        InscriptionArrowRuntime.register(arrow, owner, world, 5L * 20L);
        world.spawnEntity(arrow);

        for (int i = 0; i < 24; i++) {
            double y = center.y + 1.0 + (i * 0.6);
            world.spawnParticles(ParticleTypes.END_ROD, center.x, y, center.z, 2, 0.08, 0.0, 0.08, 0.0);
            world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, center.x, y, center.z, 2, 0.15, 0.05, 0.15, 0.02);
        }
        world.playSound(null, BlockPos.ofFloored(center), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.1f, 0.55f);
    }

    private static void explodeSkyfall(ServerWorld world, ServerPlayerEntity owner, Vec3d center) {
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y + 0.5, center.z, 1, 0.0, 0.0, 0.0, 0.0);
        world.spawnParticles(ParticleTypes.CLOUD, center.x, center.y + 0.2, center.z, 25, 0.5, 0.15, 0.5, 0.03);
        world.playSound(null, BlockPos.ofFloored(center), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.PLAYERS, 1.2f, 0.6f);

        Box box = Box.of(center.add(0.0, 0.5, 0.0), SKYFALL_RADIUS * 2.0, 4.0, SKYFALL_RADIUS * 2.0);
        for (LivingEntity hit : world.getEntitiesByClass(LivingEntity.class, box, LivingEntity::isAlive)) {
            boolean ok = hit.damage(world.getDamageSources().explosion(owner, owner), SKYFALL_EXPLOSION_DAMAGE);
            if (!ok && hit.isAlive()) {
                InscriptionRuntime.magicTrueDamage(hit, SKYFALL_EXPLOSION_DAMAGE);
            }
        }
    }

    private static void spawnLightning(ServerWorld world, Vec3d center) {
        LightningEntity lightning = EntityType.LIGHTNING_BOLT.create(world);
        if (lightning == null) return;
        lightning.refreshPositionAfterTeleport(center.x, center.y, center.z);
        world.spawnEntity(lightning);
    }
}
