package com.savaru.savaru_affixes.inscription;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class DistantThunderHooks {
    private DistantThunderHooks() {}
    private static final double PROC_CHANCE = 0.30;
    private static final Map<UUID, Integer> MARKS = new ConcurrentHashMap<>();

    public static void onBowHit(ServerWorld world, PersistentProjectileEntity proj, LivingEntity target, ItemStack weapon, LivingEntity owner) {
        if (world == null || target == null) return;
        if (world.random.nextDouble() < PROC_CHANCE) {
            strike(world, target, owner instanceof ServerPlayerEntity sp ? sp : null);
            MARKS.remove(target.getUuid());
            return;
        }
        int hits = MARKS.getOrDefault(target.getUuid(), 0) + 1;
        if (hits >= 3) {
            strike(world, target, owner instanceof ServerPlayerEntity sp ? sp : null);
            MARKS.remove(target.getUuid());
        } else {
            MARKS.put(target.getUuid(), hits);
        }
    }

    private static void strike(ServerWorld world, LivingEntity target, ServerPlayerEntity owner) {
        LightningEntity lightning = EntityType.LIGHTNING_BOLT.create(world);
        if (lightning == null) return;
        lightning.setPosition(target.getX(), target.getY(), target.getZ());
        world.spawnEntity(lightning);
    }
}
