package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 加具士命（Kagushimei）— 異鄉遠程銘刻
 *
 * 每 30 秒，玩家的下一支箭矢附帶黑色靈魂粒子。
 * 命中目標後：凋零 II + 燃燒，持續 20 秒。
 * 若效果過了 10 秒目標仍存活，在其周圍形成黑色靈魂粒子圓圈（半徑 4.5），
 * 圓圈範圍內所有生物持續燃燒，持續 10 秒。
 */
public final class KagushimeiHooks {
    private KagushimeiHooks() {}

    private static final long CHARGE_INTERVAL_TICKS = 30L * 20L; // 30s per charge
    private static final long RING_DELAY_TICKS      = 10L * 20L; // 10s after hit → ring
    private static final long RING_DURATION_TICKS   = 10L * 20L; // ring lasts 10s
    private static final double RING_RADIUS         = 4.5;
    private static final int WITHER_DURATION        = 20 * 20;   // 20s, Wither II
    private static final int FIRE_SECONDS           = 20;        // 20s fire

    // Player UUID → tick when the next charge is available (0 = immediately on first shot)
    private static final Map<UUID, Long> NEXT_CHARGE_AT = new ConcurrentHashMap<>();

    // Arrow entity UUIDs that carry the charge (emit soul particles in flight)
    // Key: arrow UUID, Value: server world-time when registered (for age-based cleanup)
    private static final Map<UUID, Long> CHARGED_ARROWS = new ConcurrentHashMap<>();

    // Target UUID → pending ring (waiting 10s after hit)
    private static final Map<UUID, PendingRing> PENDING_RINGS = new ConcurrentHashMap<>();

    // Target UUID → active ring (burning nearby mobs for 10s)
    private static final Map<UUID, ActiveRing> ACTIVE_RINGS = new ConcurrentHashMap<>();

    // -----------------------------------------------------------------------
    private static final class PendingRing {
        final net.minecraft.registry.RegistryKey<net.minecraft.world.World> worldKey;
        final UUID targetId;
        final long activateAt;

        PendingRing(ServerWorld w, UUID tid, long at) {
            worldKey   = w.getRegistryKey();
            targetId   = tid;
            activateAt = at;
        }
    }

    private static final class ActiveRing {
        final net.minecraft.registry.RegistryKey<net.minecraft.world.World> worldKey;
        final UUID targetId;
        final long expireAt;
        Vec3d pos;

        ActiveRing(ServerWorld w, UUID tid, Vec3d pos, long exp) {
            worldKey  = w.getRegistryKey();
            targetId  = tid;
            this.pos  = pos;
            expireAt  = exp;
        }
    }

    // -----------------------------------------------------------------------
    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(KagushimeiHooks::tick);
    }

    /**
     * Called from PersistentProjectileEntityTickMixin on the first few ticks of
     * each arrow in flight.  If the owning player's charge window has opened,
     * this arrow is marked as "charged" and the next window is pushed 30s ahead.
     */
    public static void tryClaimCharge(ServerPlayerEntity player,
                                      PersistentProjectileEntity proj, long now) {
        UUID pid = player.getUuid();
        // Already claimed by a previous arrow this window?
        if (now < NEXT_CHARGE_AT.getOrDefault(pid, 0L)) return;
        // Already marked (re-entry guard)?
        if (CHARGED_ARROWS.containsKey(proj.getUuid())) return;

        // Claim: register arrow, advance window
        CHARGED_ARROWS.put(proj.getUuid(), now);
        NEXT_CHARGE_AT.put(pid, now + CHARGE_INTERVAL_TICKS);
    }

    /** True while the given projectile should display soul-particle trail. */
    public static boolean isChargedArrow(PersistentProjectileEntity proj) {
        return proj != null && CHARGED_ARROWS.containsKey(proj.getUuid());
    }

    /** Called from PersistentProjectileEntityHitMixin when a charged arrow hits. */
    public static void onBowHit(ServerWorld world, PersistentProjectileEntity proj,
                                 LivingEntity target, ItemStack weapon, LivingEntity owner) {
        if (!(owner instanceof ServerPlayerEntity)) return;
        if (CHARGED_ARROWS.remove(proj.getUuid()) == null) return; // not a charged arrow → skip

        long now = world.getTime();

        // Wither II (20s) + fire (20s)
        target.addStatusEffect(new StatusEffectInstance(
                StatusEffects.WITHER, WITHER_DURATION, 1, false, true, true));
        target.setOnFireFor(FIRE_SECONDS);

        // Impact burst
        spawnSoulBurst(world, target.getPos(), 35);
        world.playSound(null, target.getBlockPos(),
                SoundEvents.ENTITY_WITHER_AMBIENT, SoundCategory.PLAYERS, 1.0f, 0.8f);

        // Schedule ring check 10s later
        PENDING_RINGS.put(target.getUuid(),
                new PendingRing(world, target.getUuid(), now + RING_DELAY_TICKS));
    }

    // -----------------------------------------------------------------------
    private static void tick(MinecraftServer server) {
        long now = server.getOverworld().getTime();

        // ── Pending → Active ──────────────────────────────────────────────
        Iterator<Map.Entry<UUID, PendingRing>> pit = PENDING_RINGS.entrySet().iterator();
        while (pit.hasNext()) {
            Map.Entry<UUID, PendingRing> e = pit.next();
            PendingRing pr = e.getValue();
            if (now < pr.activateAt) continue;
            pit.remove();

            ServerWorld world = server.getWorld(pr.worldKey);
            if (world == null) continue;

            var entity = world.getEntity(pr.targetId);
            if (!(entity instanceof LivingEntity target) || !target.isAlive()) continue;

            // Target survived 10s → ignite the ring
            Vec3d pos = target.getPos();
            spawnRingOnce(world, pos);
            world.playSound(null, target.getBlockPos(),
                    SoundEvents.ENTITY_BLAZE_AMBIENT, SoundCategory.PLAYERS, 1.2f, 0.4f);

            ACTIVE_RINGS.put(pr.targetId,
                    new ActiveRing(world, pr.targetId, pos, now + RING_DURATION_TICKS));
        }

        // ── Active rings: particles + burn ───────────────────────────────
        Iterator<Map.Entry<UUID, ActiveRing>> ait = ACTIVE_RINGS.entrySet().iterator();
        while (ait.hasNext()) {
            Map.Entry<UUID, ActiveRing> e = ait.next();
            ActiveRing ar = e.getValue();
            if (now > ar.expireAt) { ait.remove(); continue; }

            ServerWorld world = server.getWorld(ar.worldKey);
            if (world == null) { ait.remove(); continue; }

            // Track target position
            var entity = world.getEntity(ar.targetId);
            if (entity instanceof LivingEntity living && living.isAlive()) {
                ar.pos = living.getPos();
            }

            // Emit ring every 4 ticks (≈12.5 fps)
            if (now % 4 == 0) {
                spawnRingOnce(world, ar.pos);
            }

            // Burn all nearby mobs every 20 ticks (1s)
            if (now % 20 == 0) {
                Box box = Box.of(ar.pos.add(0, 1, 0),
                        (RING_RADIUS + 0.5) * 2, 4.0, (RING_RADIUS + 0.5) * 2);
                for (LivingEntity nearby : world.getEntitiesByClass(
                        LivingEntity.class, box, LivingEntity::isAlive)) {
                    if (nearby.getPos().subtract(ar.pos).horizontalLength() <= RING_RADIUS) {
                        nearby.setOnFireFor(3);
                    }
                }
            }
        }

        // ── Periodic cleanup of stale charged-arrow entries (> 600 ticks old) ──
        if (server.getTicks() % 600 == 0) {
            CHARGED_ARROWS.entrySet().removeIf(e -> now - e.getValue() > 600L);
        }
    }

    // -----------------------------------------------------------------------
    private static void spawnSoulBurst(ServerWorld world, Vec3d pos, int count) {
        world.spawnParticles(ParticleTypes.SOUL,
                pos.x, pos.y + 1.0, pos.z, count, 0.5, 0.6, 0.5, 0.04);
        world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME,
                pos.x, pos.y + 1.2, pos.z, 18, 0.3, 0.4, 0.3, 0.02);
    }

    /** Emit one frame of the circular ring. */
    private static void spawnRingOnce(ServerWorld world, Vec3d center) {
        final int STEPS = 28;
        for (int i = 0; i < STEPS; i++) {
            double angle = (2.0 * Math.PI * i) / STEPS;
            double x = center.x + RING_RADIUS * Math.cos(angle);
            double z = center.z + RING_RADIUS * Math.sin(angle);
            world.spawnParticles(ParticleTypes.SOUL,
                    x, center.y + 0.2, z, 1, 0.04, 0.12, 0.04, 0.0);
            world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    x, center.y + 0.2, z, 1, 0.02, 0.06, 0.02, 0.0);
        }
    }
}
