package com.savaru.savaru_affixes.inscription;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MimicArrowHooks {
    private MimicArrowHooks() {}
    private static final Map<UUID, Integer> MODES = new ConcurrentHashMap<>();

    public static int prepareProjectile(ServerWorld world, PersistentProjectileEntity proj) {
        return MODES.computeIfAbsent(proj.getUuid(), id -> world.random.nextInt(7));
    }

    public static void onBowHit(ServerWorld world, PersistentProjectileEntity proj, LivingEntity target, ItemStack weapon, LivingEntity owner) {
        int mode = prepareProjectile(world, proj);
        switch (mode) {
            case 1 -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 8 * 20, 0, false, true, true)); // spectral
            case 2 -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 5 * 20, 0, false, true, true));
            case 3 -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 4 * 20, 1, false, true, true));
            case 4 -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 5 * 20, 0, false, true, true));
            case 5 -> target.addStatusEffect(new StatusEffectInstance(StatusEffects.INSTANT_DAMAGE, 1, 0, false, true, true));
            case 6 -> {
                if (owner instanceof ServerPlayerEntity sp) sp.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 2 * 20, 0, false, true, true));
            }
            default -> { }
        }
        MODES.remove(proj.getUuid());
    }
}
