package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.registry.RegistryKey;
import net.minecraft.world.World;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 「星流七連」：提供 DOT 與「DOT 結束後回復」等需要跨 tick 的效果。
 * 其餘連段狀態機在 InscriptionRuntime / PlayerEntityTickMixin 內管理。
 */
public final class StarflowHooks {
    private StarflowHooks() {}

    // DOT: every 20 ticks deal 25 true magic damage, total 15s (300 ticks) => 15 hits.
    private static final int DOT_PERIOD = 20;
    private static final int DOT_TOTAL_TICKS = 15 * 20;
    private static final double DOT_DMG = 25.0;

    private static final class Dot {
        final RegistryKey<World> worldKey;
        final UUID playerId;
        int ticksLeft;
        int periodLeft;
        Dot(RegistryKey<World> worldKey, UUID playerId) {
            this.worldKey = worldKey;
            this.playerId = playerId;
            this.ticksLeft = DOT_TOTAL_TICKS;
            this.periodLeft = DOT_PERIOD;
        }
    }

    private static final Map<UUID, Dot> DOTS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> REGEN_AT = new ConcurrentHashMap<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(StarflowHooks::tick);
    }

    /** Start DOT on target and schedule a 3s regen for player after DOT ends. */
    public static void startDot(ServerWorld world, LivingEntity target, ServerPlayerEntity player) {
        if (world == null || target == null || player == null) return;
        if (!target.isAlive()) return;
        DOTS.put(target.getUuid(), new Dot(world.getRegistryKey(), player.getUuid()));
        // regen scheduled at now + DOT_TOTAL_TICKS (handled in tick)
        REGEN_AT.put(player.getUuid(), world.getTime() + DOT_TOTAL_TICKS);
    }

    private static void tick(MinecraftServer server) {
        // DOT ticking
        if (!DOTS.isEmpty()) {
            Iterator<Map.Entry<UUID, Dot>> it = DOTS.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Dot> e = it.next();
                UUID targetId = e.getKey();
                Dot d = e.getValue();

                ServerWorld world = server.getWorld(d.worldKey);
                if (world == null) {
                    it.remove();
                    continue;
                }
                LivingEntity target = (world.getEntity(targetId) instanceof LivingEntity le) ? le : null;
                if (target == null || !target.isAlive()) {
                    it.remove();
                    continue;
                }

                d.ticksLeft--;
                d.periodLeft--;
                if (d.ticksLeft <= 0) {
                    it.remove();
                    continue;
                }
                if (d.periodLeft > 0) continue;

                d.periodLeft = DOT_PERIOD;
                InscriptionRuntime.magicTrueDamage(target, DOT_DMG);
            }
        }

        // regen after DOT
        if (!REGEN_AT.isEmpty()) {
            Iterator<Map.Entry<UUID, Long>> it = REGEN_AT.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Long> e = it.next();
                UUID pid = e.getKey();
                long at = e.getValue();
                // use overworld time as baseline; any server tick ok
                ServerWorld any = server.getOverworld();
                if (any == null) break;
                if (any.getTime() < at) continue;

                ServerPlayerEntity p = server.getPlayerManager().getPlayer(pid);
                if (p != null) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 3 * 20, 0, false, true, true));
                }
                it.remove();
            }
        }
    }
}
