package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;

import net.minecraft.registry.RegistryKey;
import net.minecraft.world.World;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 「逕庭拳」：當目標身上存在特定負面狀態時，持續每 0.5 秒造成一次固定魔法傷害。
 *
 * 設計：首次觸發由攻擊事件啟動；之後以 tick 迴圈持續檢查並輸出，直到目標死亡或不再符合條件。
 */
public final class JingtinFistHooks {
    private JingtinFistHooks() {}

    private static final int PERIOD_TICKS = 10; // 0.5s
    private static final double DAMAGE = 20.0;

    private static final class Active {
        final RegistryKey<World> worldKey;
        int left;
        Active(RegistryKey<World> worldKey, int left) {
            this.worldKey = worldKey;
            this.left = left;
        }
    }

    private static final Map<UUID, Active> active = new ConcurrentHashMap<>();

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(JingtinFistHooks::onServerTick);
    }

    public static void activate(LivingEntity target) {
        if (target == null || target.isDead()) return;
        active.putIfAbsent(target.getUuid(), new Active(target.getWorld().getRegistryKey(), PERIOD_TICKS));
    }

    private static void onServerTick(MinecraftServer server) {
        if (active.isEmpty()) return;

        Iterator<Map.Entry<UUID, Active>> it = active.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Active> e = it.next();
            UUID id = e.getKey();
            Active a = e.getValue();

            ServerWorld world = server.getWorld(a.worldKey);
            if (world == null) {
                it.remove();
                continue;
            }

            LivingEntity ent = (world.getEntity(id) instanceof LivingEntity le) ? le : null;
            if (ent == null || ent.isDead()) {
                it.remove();
                continue;
            }

            if (!hasDebuff(ent)) {
                it.remove();
                continue;
            }

            a.left -= 1;
            if (a.left > 0) continue;

            a.left = PERIOD_TICKS;
            InscriptionRuntime.magicTrueDamage(ent, DAMAGE);
        }
    }

    private static boolean hasDebuff(LivingEntity e) {
        return e.hasStatusEffect(StatusEffects.POISON)
                || e.hasStatusEffect(StatusEffects.WITHER)
                || e.hasStatusEffect(StatusEffects.SLOWNESS)
                || e.hasStatusEffect(StatusEffects.DARKNESS)
                || e.hasStatusEffect(StatusEffects.NAUSEA)
                || e.hasStatusEffect(StatusEffects.WEAKNESS);
    }
}
