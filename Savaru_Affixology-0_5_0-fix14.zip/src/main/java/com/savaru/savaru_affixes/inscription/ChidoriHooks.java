package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.WindChargeEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 千鳥（Chidori）— 秘傳遠程銘刻
 *
 * 命中目標有 50% 機率觸發（冷卻 30 秒）：
 *   → 向玩家顯示訊息「風が私を呼んでいる」
 *   → 對目標產生風爆擊退
 *   → 目標獲得「蘊風」效果（發光 + 緩降，5 秒）
 *
 * 5 秒後：
 *   → 目標受到 40 點爆炸傷害
 *   → 目標周圍生成 8 枚風彈（向四周發射）
 *   → 目標獲得懸浮效果，持續 10 秒
 *
 * 10 秒後（懸浮結束後）：
 *   → 目標受到雷擊
 */
public final class ChidoriHooks {
    private ChidoriHooks() {}

    private static final double PROC_CHANCE         = 0.50;
    private static final long   COOLDOWN_TICKS      = 30L * 20L;   // 30s
    private static final long   WIND_DELAY_TICKS    = 5L  * 20L;   // 5s until wind explosion
    private static final int    LEVITATION_DURATION = 10  * 20;    // 10s levitation
    // Lightning fires after levitation ends
    private static final long   LIGHTNING_DELAY_TICKS = WIND_DELAY_TICKS + LEVITATION_DURATION;
    private static final float  EXPLOSION_DAMAGE    = 40.0f;
    private static final int    WIND_CHARGES        = 8;
    private static final double WIND_CHARGE_SPEED   = 1.4;

    // Player UUID → CD expiry tick
    private static final Map<UUID, Long> COOLDOWNS = new ConcurrentHashMap<>();
    // Target UUID → pending state
    private static final Map<UUID, PendingChidori> PENDING = new ConcurrentHashMap<>();

    // -----------------------------------------------------------------------
    private static final class PendingChidori {
        final net.minecraft.registry.RegistryKey<net.minecraft.world.World> worldKey;
        final UUID ownerId;
        final UUID targetId;
        final Vec3d fallbackPos;
        final long windAt;
        final long lightningAt;
        boolean windFired;

        PendingChidori(ServerWorld world, UUID ownerId, UUID targetId, Vec3d pos, long now) {
            this.worldKey     = world.getRegistryKey();
            this.ownerId      = ownerId;
            this.targetId     = targetId;
            this.fallbackPos  = pos;
            this.windAt       = now + WIND_DELAY_TICKS;
            this.lightningAt  = now + LIGHTNING_DELAY_TICKS;
        }
    }

    // -----------------------------------------------------------------------
    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(ChidoriHooks::tick);
    }

    public static void onBowHit(ServerWorld world, PersistentProjectileEntity proj,
                                 LivingEntity target, ItemStack weapon, LivingEntity owner) {
        if (!(owner instanceof ServerPlayerEntity player)) return;

        long now = world.getTime();
        UUID pid = player.getUuid();

        // Cooldown check
        if (now < COOLDOWNS.getOrDefault(pid, 0L)) return;

        // 50% proc
        if (world.random.nextDouble() >= PROC_CHANCE) return;

        // Set cooldown immediately
        COOLDOWNS.put(pid, now + COOLDOWN_TICKS);

        // ── Trigger ──────────────────────────────────────────────────────

        // 1. Message — chat (false = chat box, visible and not overwritten by other action bars)
        player.sendMessage(
                Text.literal("風が私を呼んでいる").formatted(Formatting.AQUA),
                false);

        // 2. Wind burst knockback (push target away from player)
        Vec3d delta = target.getPos().subtract(player.getPos());
        Vec3d dir   = delta.lengthSquared() > 0.001 ? delta.normalize() : new Vec3d(0, 1, 0);
        target.takeKnockback(2.8, -dir.x, -dir.z);

        // 3. 「蘊風」visual: Glowing + Slow Falling for the 5s waiting period
        target.addStatusEffect(new StatusEffectInstance(
                StatusEffects.GLOWING,      (int) WIND_DELAY_TICKS, 0, false, false, true));
        target.addStatusEffect(new StatusEffectInstance(
                StatusEffects.SLOW_FALLING, (int) WIND_DELAY_TICKS, 0, false, true,  true));

        // 4. Wind particles + sound on initial hit
        spawnWindBurst(world, target.getPos(), 18);
        world.playSound(null, target.getBlockPos(),
                SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.PLAYERS, 0.6f, 1.6f);

        // 5. Schedule pending phases
        PENDING.put(target.getUuid(),
                new PendingChidori(world, pid, target.getUuid(), target.getPos(), now));
    }

    // -----------------------------------------------------------------------
    private static void tick(MinecraftServer server) {
        long now = server.getOverworld().getTime();

        Iterator<Map.Entry<UUID, PendingChidori>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, PendingChidori> e = it.next();
            PendingChidori pc = e.getValue();
            ServerWorld world = server.getWorld(pc.worldKey);
            if (world == null) { it.remove(); continue; }

            // Resolve target (may have died)
            LivingEntity target = null;
            var entity = world.getEntity(pc.targetId);
            if (entity instanceof LivingEntity living && living.isAlive()) {
                target = living;
            }

            // ── Phase 1: Wind explosion + wind charges + levitation (5s) ──
            if (!pc.windFired && now >= pc.windAt) {
                pc.windFired = true;
                Vec3d pos = target != null ? target.getPos() : pc.fallbackPos;
                ServerPlayerEntity ownerPlayer = server.getPlayerManager().getPlayer(pc.ownerId);

                // Explosion damage
                if (target != null) {
                    boolean ok = target.damage(
                            world.getDamageSources().explosion(ownerPlayer, ownerPlayer),
                            EXPLOSION_DAMAGE);
                    if (!ok && target.isAlive()) {
                        InscriptionRuntime.magicTrueDamage(target, EXPLOSION_DAMAGE);
                    }
                    // Levitation for 10s (phase 2 timer is already set from construction)
                    target.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.LEVITATION, LEVITATION_DURATION, 1, false, true, true));
                }

                // Spawn 8 wind charges outward in a ring
                spawnWindCharges(world, ownerPlayer, pos);

                // Visual + sound
                world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER,
                        pos.x, pos.y + 0.5, pos.z, 1, 0.0, 0.0, 0.0, 0.0);
                world.spawnParticles(ParticleTypes.CLOUD,
                        pos.x, pos.y + 1.0, pos.z, 30, 0.7, 0.5, 0.7, 0.08);
                world.spawnParticles(ParticleTypes.POOF,
                        pos.x, pos.y + 1.5, pos.z, 20, 0.5, 0.6, 0.5, 0.06);
                world.playSound(null, BlockPos.ofFloored(pos),
                        SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.PLAYERS, 1.1f, 1.4f);
            }

            // ── Phase 2: Lightning strike (after levitation ends) ─────────
            if (pc.windFired && now >= pc.lightningAt) {
                Vec3d pos = target != null ? target.getPos() : pc.fallbackPos;
                spawnLightning(world, pos);
                it.remove();
            }
        }

        // Periodic cooldown cleanup
        if (server.getTicks() % 1200 == 0) {
            COOLDOWNS.entrySet().removeIf(ce -> now > ce.getValue() + 20L * 120L);
        }
    }

    // -----------------------------------------------------------------------
    private static void spawnWindBurst(ServerWorld world, Vec3d pos, int count) {
        world.spawnParticles(ParticleTypes.CLOUD,
                pos.x, pos.y + 0.8, pos.z, count, 0.45, 0.35, 0.45, 0.07);
        world.spawnParticles(ParticleTypes.POOF,
                pos.x, pos.y + 0.4, pos.z, count / 2, 0.4, 0.3, 0.4, 0.05);
    }

    /**
     * Spawn {@value WIND_CHARGES} wind-charge projectiles in a horizontal ring
     * around {@code center}, all shooting outward.
     *
     * Note: Uses {@code EntityType.WIND_CHARGE} (added in MC 1.21).
     * Verify the import path matches your Yarn/Quilt mapping version if needed.
     */
    private static void spawnWindCharges(ServerWorld world, ServerPlayerEntity owner, Vec3d center) {
        for (int i = 0; i < WIND_CHARGES; i++) {
            double angle = (2.0 * Math.PI * i) / WIND_CHARGES;
            double vx = Math.cos(angle) * WIND_CHARGE_SPEED;
            double vz = Math.sin(angle) * WIND_CHARGE_SPEED;

            WindChargeEntity wc = new WindChargeEntity(EntityType.WIND_CHARGE, world);
            wc.setPosition(center.x, center.y + 1.0, center.z);
            wc.setVelocity(vx, 0.1, vz);
            if (owner != null) wc.setOwner(owner);
            world.spawnEntity(wc);
        }
    }

    private static void spawnLightning(ServerWorld world, Vec3d pos) {
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
        if (bolt == null) return;
        bolt.refreshPositionAfterTeleport(pos.x, pos.y, pos.z);
        world.spawnEntity(bolt);
    }
}
