package com.savaru.savaru_affixes.inscription;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class SpringRainHooks {
    private SpringRainHooks() {}

    private static final long COOLDOWN_TICKS = 5L * 20L;
    private static final int START_DELAY = 10; // 0.5s
    private static final int WAVE_INTERVAL = 20; // 1s
    private static final int TOTAL_WAVES = 3;
    private static final double RADIUS = 3.0;
    private static final int ARROWS_PER_WAVE = 12;
    private static final double EXTRA_MAGIC_MULT = 1.5;
    private static final double RAIN_ARROW_MULT = 2.4;

    private static final Map<UUID, Long> PLAYER_CD = new ConcurrentHashMap<>();
    private static final Map<UUID, SpecialArrow> SPECIAL_ARROWS = new ConcurrentHashMap<>();
    private static final List<RainZone> ACTIVE_ZONES = new ArrayList<>();

    private static final class RainZone {
        final RegistryRef worldRef;
        final UUID ownerId;
        final Vec3d center;
        final double arrowDamage;
        long nextWaveTick;
        int wavesLeft;

        RainZone(ServerWorld world, UUID ownerId, Vec3d center, double arrowDamage, long startTick) {
            this.worldRef = new RegistryRef(world);
            this.ownerId = ownerId;
            this.center = center;
            this.arrowDamage = arrowDamage;
            this.nextWaveTick = startTick + START_DELAY;
            this.wavesLeft = TOTAL_WAVES;
        }
    }

    private record RegistryRef(net.minecraft.registry.RegistryKey<net.minecraft.world.World> worldKey) {
        RegistryRef(ServerWorld world) { this(world.getRegistryKey()); }
    }

    private record SpecialArrow(double damage, UUID ownerId) {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(SpringRainHooks::tick);
    }

    public static boolean isManagedProjectile(PersistentProjectileEntity proj) {
        return proj != null && SPECIAL_ARROWS.containsKey(proj.getUuid());
    }

    public static boolean handleSpecialArrowHit(PersistentProjectileEntity proj, LivingEntity target) {
        SpecialArrow arrow = SPECIAL_ARROWS.remove(proj.getUuid());
        if (arrow == null || target == null) return false;
        if (arrow.ownerId != null && arrow.ownerId.equals(target.getUuid())) return true;
        InscriptionRuntime.magicTrueDamage(target, arrow.damage);
        if (target.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.CRIT, target.getX(), target.getBodyY(0.5), target.getZ(), 10, 0.25, 0.2, 0.25, 0.05);
        }
        return true;
    }

    public static void onBowHit(ServerWorld world, PersistentProjectileEntity projectile, LivingEntity target, ItemStack weapon, LivingEntity owner) {
        if (world == null || projectile == null || target == null || owner == null) return;
        if (!(owner instanceof ServerPlayerEntity player)) return;

        long now = world.getTime();
        long next = PLAYER_CD.getOrDefault(player.getUuid(), 0L);
        if (now < next) return;
        PLAYER_CD.put(player.getUuid(), now + COOLDOWN_TICKS);

        double baseDamage = Math.max(1.0, projectile.getDamage());
        double extraMagic = baseDamage * EXTRA_MAGIC_MULT;
        InscriptionRuntime.magicTrueDamage(target, extraMagic);

        Vec3d center = target.getPos();
        ACTIVE_ZONES.add(new RainZone(world, player.getUuid(), center, baseDamage * RAIN_ARROW_MULT, now));
        spawnCircle(world, center, RADIUS, ParticleTypes.CLOUD, 24);
        world.spawnParticles(ParticleTypes.CRIT, center.x, center.y + 0.5, center.z, 12, 0.4, 0.15, 0.4, 0.02);
    }

    private static void tick(MinecraftServer server) {
        long now = server.getOverworld().getTime();
        Iterator<RainZone> it = ACTIVE_ZONES.iterator();
        while (it.hasNext()) {
            RainZone zone = it.next();
            ServerWorld world = server.getWorld(zone.worldRef.worldKey());
            if (world == null) {
                it.remove();
                continue;
            }
            if (now < zone.nextWaveTick) continue;

            spawnCircle(world, zone.center, RADIUS, ParticleTypes.CLOUD, 20);
            for (int i = 0; i < ARROWS_PER_WAVE; i++) {
                double angle = world.random.nextDouble() * Math.PI * 2.0;
                double dist = Math.sqrt(world.random.nextDouble()) * RADIUS;
                double x = zone.center.x + Math.cos(angle) * dist;
                double z = zone.center.z + Math.sin(angle) * dist;
                double y = zone.center.y + 8.0 + world.random.nextDouble() * 2.0;

                ArrowEntity arrow = new ArrowEntity(EntityType.ARROW, world);
                arrow.setPos(x, y, z);
                arrow.setVelocity(0.0, -2.2, 0.0);
                var owner = server.getPlayerManager().getPlayer(zone.ownerId);
                if (owner != null) arrow.setOwner(owner);
                arrow.setDamage(0.0);
                arrow.setCritical(true);
                InscriptionArrowRuntime.register(arrow, owner, world, 5L * 20L);
                SPECIAL_ARROWS.put(arrow.getUuid(), new SpecialArrow(zone.arrowDamage, owner != null ? owner.getUuid() : null));
                world.spawnEntity(arrow);
            }

            zone.wavesLeft--;
            zone.nextWaveTick += WAVE_INTERVAL;
            if (zone.wavesLeft <= 0) it.remove();
        }

        // cleanup stale cooldowns lightly
        if (server.getTicks() % 1200 == 0) {
            PLAYER_CD.entrySet().removeIf(e -> now - e.getValue() > 20L * 60L);
            cleanupSpecialArrows(server);
        }
    }

    private static void cleanupSpecialArrows(MinecraftServer server) {
        Iterator<Map.Entry<UUID, SpecialArrow>> it = SPECIAL_ARROWS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, SpecialArrow> e = it.next();
            boolean exists = false;
            for (ServerWorld world : server.getWorlds()) {
                if (world.getEntity(e.getKey()) != null) {
                    exists = true;
                    break;
                }
            }
            if (!exists) it.remove();
        }
    }

    private static void spawnCircle(ServerWorld world, Vec3d center, double radius, net.minecraft.particle.ParticleEffect particle, int count) {
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2.0 * i) / count;
            double x = center.x + Math.cos(angle) * radius;
            double z = center.z + Math.sin(angle) * radius;
            world.spawnParticles(particle, x, center.y + 0.05, z, 1, 0.02, 0.02, 0.02, 0.0);
        }
    }
}
